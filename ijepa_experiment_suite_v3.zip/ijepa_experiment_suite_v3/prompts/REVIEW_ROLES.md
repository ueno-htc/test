# Evidence-bound review prompts

These are reusable prompts for independent reviewers/agents if available. The delivered audit was
performed through code execution, statistical recomputation and primary-source checks; it does
not claim that separate external reviewer agents were actually run. No LLM/VLM is used in the model
or benchmark evaluation. Every reviewer must distinguish facts, causal hypotheses and untested plans.

## Experimental-method reviewer

Read result/config/environment/code together. Identify target-label leakage, split overlap, repeated
base samples, train/validation mismatch, misnamed baselines, unequal inputs, unequal source-data
access, and inactive constraints. Do not infer correctness from successful process exit. Produce
claim -> supporting file/key -> strongest alternative explanation -> minimal discriminating test.

## Statistical reviewer

Treat seeds, scenes, frames, clients and corruption blocks as different units. Compare matched seeds.
Do not replace missing results with zero or treat repeated frames as independent samples. Show mean,
sample SD, paired changes, and the number of genuinely independent units. A scene bootstrap conditional
on a trained model does not quantify training-seed uncertainty. Do not choose hypotheses or hyperparameters
on a final holdout. State practical effect sizes and preregister the next confirmation split.

## Systems / correctness reviewer

Verify frozen encoder parameters, mixed source calibration, class-balanced anchors, no target labels
in updates, exact SSM recurrence equivalence, full encoder costs, cold-start timing, communication byte
accounting, all-client versus sampled-client access, and no serialized trained weights. Run tests and
smoke, inspect failure/resume paths, and confirm all non-dataset files stay outside /localdata.

## Novelty / skeptical-area-chair reviewer

Find primary competing papers for the exact claim. Compare against Tempora and computationally constrained
TTA evaluation; VideoMamba; SparseRefine; controlled-physics benchmarks; Fed3R and federated PEFT.
Reject 'I-JEPA + component' as sufficient novelty. Ask what existing method or simple non-neural control
would falsify the claim. Specify a publishable contribution only after that alternative is eliminated.
Do not invent acceptance probabilities, report unrun experiments, or rename existing algorithms as new.

## Decision reviewer

For each theme: current evidence, known implementation problems, unresolved hypotheses, minimum next
run, advancement/pause conditions, and expected scientific contribution if successful. Do not rank
heterogeneous metrics with one arbitrary score. Allocate the next experiment budget to decisive tests,
not broad tuning of a failed proxy metric. Preserve negative results in the review bundle.
