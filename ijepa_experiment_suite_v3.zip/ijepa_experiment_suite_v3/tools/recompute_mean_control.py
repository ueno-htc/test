from pathlib import Path
import numpy as np,pandas as pd,json,sys
import argparse
parser=argparse.ArgumentParser(description='Recompute pilot01 CPU controls from original archived prediction NPZ files; no I-JEPA weights are needed.')
parser.add_argument('--results',type=Path,required=True,help='Directory outputs/pilot01/runs/physics')
parser.add_argument('--output',type=Path,required=True)
a=parser.parse_args()
a.output.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repos/ijepa_controlled_shift/src'))
from ijepa_controlled_shift.physics_data import analytic_trajectory
root=a.results.resolve()
rows=[]
for p in sorted(root.rglob('result.json')):
 cfg=json.loads((p.parent/'config.json').read_text()); seed=cfg['seed']; sp=cfg['physics']; n=cfg['data']['n_train']
 obs=sp['observed'];t=np.arange(obs+sp['future'])*sp['dt']; arr=[]
 for i in range(n):
  rng=np.random.default_rng(seed*1000000+i)
  x0=rng.uniform([.25,.18],[.65,.4]);v=rng.uniform([-.1,-.035],[.1,.035]);g=.08+.1*rng.uniform()
  arr.append(analytic_trajectory(x0,v,g,t)[obs:])
 mean=np.asarray(arr,dtype=np.float32).mean(0)
 for condition in ['ID','visual_only','dynamics_only','joint','law_shift_drag']:
  for method in ['ridge_visual','small_latent_SSL_plus_ridge','random_temporal_projection_plus_ridge','classical_contrast_tracker_plus_known_ballistic_prior']:
   d=np.load(p.parent/f'{method}_{condition}_predictions.npz');truth=d['target'];pred=d['predictions']
   baseline=((truth-mean)**2).mean();mse=((truth-pred)**2).mean()
   # Verify scene RNG exactly reproduces archived ground-truth arrays, without reading any model weights.
   for idx,scene in enumerate(d['scene_ids']):
    rng=np.random.default_rng(scene)
    x0=rng.uniform([.25,.18],[.65,.4]);v=rng.uniform([-.1,-.035],[.1,.035]);q=rng.uniform()
    g=(.24 if condition in ['joint','dynamics_only'] else .08)+.1*q
    gt=analytic_trajectory(x0,v,g,t,.8 if condition=='law_shift_drag' else 0)[obs:]
    np.testing.assert_allclose(gt,truth[idx],atol=1e-7,rtol=1e-6)
   rows.append(dict(seed=seed,condition=condition,method=method,rmse=float(np.sqrt(mse)),source_mean_rmse=float(np.sqrt(baseline)),skill_vs_source_mean=float(1-mse/baseline),pred_between_scene_std=float(pred.std(0).mean()),target_between_scene_std=float(truth.std(0).mean())))
f=pd.DataFrame(rows);f.to_csv(a.output/'physics_source_mean_control.csv',index=False)
print(f.groupby(['condition','method'])[['rmse','source_mean_rmse','skill_vs_source_mean']].mean().round(5).to_string())
