from pathlib import Path
import numpy as np,pandas as pd,json,sys,torch
import argparse
parser=argparse.ArgumentParser(description='Recompute pilot01 CPU controls from original archived prediction NPZ files; no I-JEPA weights are needed.')
parser.add_argument('--results',type=Path,required=True,help='Directory outputs/pilot01/runs/physics')
parser.add_argument('--output',type=Path,required=True)
a=parser.parse_args()
a.output.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repos/ijepa_controlled_shift/src'))
from ijepa_controlled_shift.physics_data import analytic_trajectory,render_trajectory
from ijepa_controlled_shift.physics import contrast_centroids,choose_ridge
from ijepa_controlled_shift.common import Standardizer
root=a.results.resolve();torch.set_num_threads(1)
rows=[]
for p in sorted(root.rglob('result.json')):
 cfg=json.loads((p.parent/'config.json').read_text()); seed=cfg['seed'];sp=cfg['physics'];obs=sp['observed']; t=np.arange(obs+sp['future'])*sp['dt']
 def get(ids,cond):
  tracks,truth=[],[]
  for scene in ids:
   rng=np.random.default_rng(scene);x0=rng.uniform([.25,.18],[.65,.4]);v=rng.uniform([-.1,-.035],[.1,.035]);q=rng.uniform()
   g=(.24 if cond in ['dynamics_only','joint'] else .08)+.1*q
   state=analytic_trajectory(x0,v,g,t,.8 if cond=='law_shift_drag' else 0.)
   image=render_trajectory(state[:obs],scene+500000,cfg['data']['image_size'],cond in ['visual_only','joint'])
   tracks.append(contrast_centroids(image[None])[0]);truth.append(state[obs:])
  return torch.tensor(np.array(tracks),dtype=torch.float32),torch.tensor(np.array(truth),dtype=torch.float32).flatten(1)
 x,y=get(range(seed*1000000,seed*1000000+cfg['data']['n_train']),'ID')
 vx,vy=get(range(seed*1000000+100000,seed*1000000+100000+cfg['data']['n_val']),'ID')
 # Feature statistics and ridge alpha fitted exclusively to train/validation.
 sc=Standardizer().fit(x);x,vx=sc.transform(x),sc.transform(vx)
 rr,choice=choose_ridge(x,y,vx,vy,sp['ridge_alphas'])
 for cond in ['ID','visual_only','dynamics_only','joint','law_shift_drag']:
  saved=np.load(p.parent/f'ridge_visual_{cond}_predictions.npz')
  tx,ty=get(saved['scene_ids'],cond);np.testing.assert_allclose(ty.numpy().reshape(-1,sp['future'],2),saved['target'],atol=1e-7,rtol=1e-6)
  pred=rr.predict(sc.transform(tx));mse=(pred-ty).square().mean().item()
  rows.append(dict(seed=seed,condition=cond,method='classical_tracker_plus_learned_ridge',rmse=float(np.sqrt(mse)),alpha=choice['alpha'],validation_mse=choice['val_mse'],uses_known_motion_equation=False,uses_GT_state_at_inference=False))
 print('seed',seed,'complete',flush=True)
f=pd.DataFrame(rows);f.to_csv(a.output/'physics_tracker_learned_ridge.csv',index=False)
print(f.groupby('condition').rmse.agg(['mean','std']).to_string())
