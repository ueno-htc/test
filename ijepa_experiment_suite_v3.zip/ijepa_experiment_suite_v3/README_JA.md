# I-JEPA experiment suite v3：pilot02後の絞り込み実験

## 目的と検証段階

今回の入力ログ（全5テーマ×3 seed）を解析し、次の実験を **⑥連合学習と⑤物理分布シフト** に絞った版です。
既存5テーマの独立リポジトリと一括実行・結果集約は維持しています。
新しく追加した実装は診断用対照であり、新規手法の優位性、トップ会議採択、実I-JEPAでの改良効果を実証したものではありません。

変更点：
- ⑥：class-mean方向の対角前処理、共分散作用によるblock Krylov部分空間、各clientの閉形式ridge。
- ⑥：fit、client validation、最終配布の論理通信量を分離。旧方式の通信量とは計上範囲が異なるため、無条件に削減率を比較しない。
- ⑤：同じ最後の画像から異なる未来へ分岐するterminal-matchedペア。sceneではなくpairをbootstrap単位にする。
- ⑤：最後の画像しか使わない決定論的予測器のoracle MSE下限を記録。学習可能な競合モデルとは扱わない。
- 全テーマ：学習済み重みを保存しない方針を維持。

既存仕様の詳細は `README_V2_JA.md` と各 `repos/` の文書を参照してください。

## 保存先

`/localdata/` は入力データセットのみです。
`models/`, `cache/`, `tmp/`, `outputs/`, `reports/` は **実行時のカレントディレクトリ** 配下です。
`run_all.sh` があるフォルダへ必ずcdする必要はありません。
既存キャッシュを使う場合は、既存の `models/` と `cache/` がある作業ディレクトリから起動してください。

`.pt/.pth/.pt2` の学習済み重みは出力しません。
入力の公開I-JEPA重みと特徴キャッシュは別扱いです。既存ファイルを削除しません。
公開モデルのライセンスと各データセットの配布条件は利用者が確認してください。

## 次の推奨実験

GPU対応PyTorchと、既存v2と同じ実験依存関係を利用できます。

```bash
unzip ijepa_experiment_suite_v3.zip

# 既存のモデル／キャッシュがある作業ディレクトリから実行
bash ./ijepa_experiment_suite_v3/run_all.sh real \
  --config ./ijepa_experiment_suite_v3/configs/decision_v3.yaml \
  --tasks federated physics \
  --device cuda \
  --seeds 0 1 2 \
  --name pilot03_decision
```

全6 runを逐次実行し、最後に集約します。
`configs/decision_v3.yaml` の物理設定は新しいpaired taskなので、v2のID精度と直接比較しないでください。
旧seed 0/1/2との比較は開発実験です。設定を固定した後、未使用seedと未使用データ条件で確認してください。

**共有する結果：**

```text
reports/pilot03_decision/review_bundle.zip
```

同一コード・設定で完了runをスキップし、未完了だけ再試行するには `--resume` を追加します。
epoch途中からの再開ではありません。コード・設定変更後は新しい `--name` を使ってください。

```bash
bash ./ijepa_experiment_suite_v3/run_all.sh report --name pilot03_decision
```

上は再集計のみです。生データ、特徴配列、学習済みモデルはreview bundleに含めません。

## CPUでの動作確認

```bash
bash ./ijepa_experiment_suite_v3/run_all.sh smoke \
  --config ./ijepa_experiment_suite_v3/configs/decision_v3.yaml \
  --tasks federated physics --device cpu --seeds 0 1 2 --name v3_smoke

bash ./ijepa_experiment_suite_v3/run_all.sh tests -q
```

Mockによる動作確認はI-JEPAの性能検証ではありません。本番失敗時にMockへ自動切替しません。
今回の検証は `verification/TEST_REPORT_JA.md` に記載しています。

## ⑥ 共分散を使った分類部分空間

中心化特徴をX、中心化ラベルをYとして、B=X^T Y, G=X^T X。
閉形式ridgeは W=(G+lambda I)^(-1)Bです。
Cクラスの分類器のrankがC−1以下であることは、class-meanのspanだけで最適分類できることを意味しません。

追加した `covariance_probe.py` は以下を比較します。
1. 対角前処理したclass-mean方向。
2. span[B, GB, G²B, ...] を通信予算に応じて拡張するblock Krylov診断。
3. 各clientだけで解くclosed-form ridge（通信なし）。

全共分散Gを送らず、各clientがG_i Qを計算し集約します。
これは既知の数値線形代数に基づく対照であり、新規アルゴリズムという主張ではありません。
モデル選択は各clientのvalidationで計算した損失和だけを集約します。テストラベルは選択に使いません。
単一プロセスシミュレーションであり、実ネットワーク、secure aggregation、差分プライバシーの実装ではありません。

主なログ：
- `rank`, `enrichment_steps`, `covariance_action_rounds`
- `normal_equation_relative_residual`
- `fit_only_payload_bytes`
- `validation_payload_bytes`
- `final_readout_payload_bytes`
- `total_round_payload_bytes`
- client別精度、worst-client、micro/macro accuracy

Krylov基底が全空間を張る、追加方向がなくなる、rank上限に達する場合は、それ以上のstageを実行しません。
低次元のMockではstep4の行がなくても失敗とは限りません。
通信計上はfloat64の論理payloadです。公開encoder初回配布、transportヘッダ、暗号化等は含みません。
v2方式はvalidation通信を含まないため、新方式とのbyte比をそのまま論文に用いてはいけません。
最終研究ではFP32・対称三角格納を使う強いfull-covariance対照も同じscopeで比較してください。

## ⑤ 最後の画像を揃える物理課題

`physics.terminal_matched=true` にすると、最後の観測位置・見た目を共有し、
最後の観測時刻の速度だけが反対の二軌道を生成します。
過去と未来は解析解で計算し、同一最終画像・異なる未来をテストしています。
真の速度・状態は画像入力モデルへ渡しません。

`data.n_train/n_val/n_test` は **軌道数** で偶数が必要です。
既定128/32/64軌道は、独立pairとしては64/16/32です。
サンプル数を増やす場合も、pairをtrain/validation/testへ分割しないでください。
現在の生成処理では各splitのseed範囲が異なり、pairはsplitを跨ぎません。

同一最後画像だけを入力する任意の決定論的予測器は、そのpairに対して同じ予測を返します。
未来のpair平均は、その制約下での実験上の最小MSEです。
`ORACLE_identical_last_image_error_floor` はこの下限診断です。
GTを使うoracleなので、画像モデルと同条件で学習した手法として扱わないでください。

この課題は履歴利用を検証するsanity benchmarkです。
一般的な物理理解、法則発見、リアルなロボット制御の証明ではありません。

## 検証・主張の範囲

- 既存結果の解析：ユーザーの公開I-JEPA / RTX4090ログに基づく。
- v3の確認：CPU上の個別テスト合計220成功、5スキップ、およびMockの6 run。
- v3の実I-JEPA性能：未測定。
- 新たな改善結果として使えるのは、今後実行する `pilot03_decision` の結果であり、添付Mock数値ではありません。

## 一次研究との関係

Fed3R（ICML2024）は固定特徴＋closed-form ridgeの既存法です。
IJCAI2026のfederated discriminative subspace discoveryは近接テーマです。
CALIPERとFrozen in a Frame（いずれも2026 preprint）は、物理課題のclean sceneや単一frameに依存した評価の限界を扱います。
今回の追加対照だけで新規性を主張せず、近接研究との差を検証してください。
