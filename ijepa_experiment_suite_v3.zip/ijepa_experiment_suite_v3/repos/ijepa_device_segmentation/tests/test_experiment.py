import pytest
import torch
from ijepa_device_segmentation.segmentation import TinySegmenter, DeploySegmenter, iou_from_confusion, select_candidate, pareto_front, conv_macs


def test_segmentation_deployment_shape():
    model = DeploySegmenter(TinySegmenter(4, 1, 3), 24).eval()
    x = torch.randint(0, 256, (2, 3, 32, 40), dtype=torch.uint8)
    assert model(x).shape == (2, 3, 32, 40)
    assert not any('teacher' in k or 'projector' in k for k in model.state_dict())


def test_iou_exact():
    r = iou_from_confusion(torch.tensor([[5, 1], [2, 2]]))
    assert r['miou'] == pytest.approx((5 / 8 + 2 / 5) / 2)


def test_iou_absent_class():
    r = iou_from_confusion(torch.tensor([[5, 0], [0, 0]]))
    assert r['miou'] == 1
    assert r['per_class_iou'][1] is None


def test_device_constraints_not_feasible():
    row = {'name': 'a', 'val_miou': .8, 'latency_p95_ms': 10, 'deploy_bytes': 300}
    assert select_candidate([row], 5, 500) is None
    assert select_candidate([row], 20, 100) is None
    assert select_candidate([row], 20, 500) is row


def test_pareto_dominated():
    rows = [{'name': 'a', 'val_miou': .8, 'latency_p95_ms': 10, 'deploy_bytes': 300},
            {'name': 'b', 'val_miou': .7, 'latency_p95_ms': 15, 'deploy_bytes': 400},
            {'name': 'c', 'val_miou': .5, 'latency_p95_ms': 5, 'deploy_bytes': 200}]
    assert set(pareto_front(rows)) == {'a', 'c'}


def test_conv_mac_counter_positive():
    model = DeploySegmenter(TinySegmenter(4, 1, 3), 24)
    assert conv_macs(model, torch.zeros(1, 3, 32, 32, dtype=torch.uint8)) > 0


import torch
from ijepa_device_segmentation.common import save_checkpoint
from ijepa_device_segmentation.segmentation import TinySegmenter, DeploySegmenter


def test_deployment_checkpoint_logs_only(tmp_path):
    import json
    model = DeploySegmenter(TinySegmenter(4, 1, 3), 24).eval()
    path = tmp_path / 'student.pt'
    save_checkpoint(path, model, kind='deploy_segmenter')
    assert not path.exists()
    row=json.loads(path.with_suffix('.model_log.json').read_text())
    assert row['weights_saved'] is False
    assert row['parameters'] > 0


def test_export_in_memory_no_file(tmp_path):
    model = DeploySegmenter(TinySegmenter(4, 1, 3), 24).eval()
    x = torch.randint(0, 256, (1, 3, 32, 32), dtype=torch.uint8)
    artifact = torch.export.export(model, (x,))
    torch.testing.assert_close(model(x), artifact.module()(x))
    assert not list(tmp_path.iterdir())
