import json
import numpy as np
import pytest
import torch
from torch import nn
from ijepa_device_segmentation.common import Standardizer, classification_metrics, dump_json, paired_bootstrap, split_indices, train_supervised
from ijepa_device_segmentation.data import read_manifest
from ijepa_device_segmentation.encoder import FeatureCache, MockEncoder, make_encoder


def test_standardizer_train_only():
    train = torch.tensor([[1., 3.], [3., 3.]])
    scaler = Standardizer().fit(train)
    before = scaler.mean.clone()
    assert torch.isfinite(scaler.transform(torch.tensor([[100., -200.]]))).all()
    torch.testing.assert_close(scaler.mean, before)
    assert scaler.transform(train).mean().abs() < 1e-5


def test_metrics_perfect():
    metrics = classification_metrics(torch.eye(3) * 50, torch.arange(3))
    assert metrics['accuracy'] == 1
    assert metrics['nll'] < 1e-5


def test_split_disjoint():
    a, b = split_indices(100, .2, 42)
    assert not set(a) & set(b)
    assert len(a) + len(b) == 100


def test_json_rejects_nan(tmp_path):
    with pytest.raises(ValueError):
        dump_json(tmp_path / 'bad.json', {'v': float('nan')})


def test_cache_content_addressed(tmp_path):
    enc = MockEncoder(torch.device('cpu'))
    cache = FeatureCache(tmp_path, enc, 3)
    a = np.full((4, 32, 32, 3), 100, dtype=np.uint8)
    first = cache.get(a)
    second = cache.get(a)
    torch.testing.assert_close(first, second)
    assert cache.events[-1]['cache_hit']
    a[0, 0, 0, 0] = 101
    cache.get(a)
    assert not cache.events[-1]['cache_hit']
    assert len(list(tmp_path.glob('*.npz'))) == 2


def test_spatial_cache_shape(tmp_path):
    encoder = MockEncoder(torch.device('cpu'))
    cache = FeatureCache(tmp_path, encoder)
    a = np.ones((2, 32, 32, 3), dtype=np.uint8)
    assert cache.get(a, 4, True).shape == (2, 32, 4, 4)
    assert cache.get(a, 2, False).shape == (2, 128)


def test_mock_cannot_masquerade_as_real():
    with pytest.raises(ValueError):
        make_encoder({'smoke': False, 'encoder': {'backend': 'mock'}}, torch.device('cpu'))


def test_manifest_group_leakage(tmp_path):
    path = tmp_path / 'bad.jsonl'
    path.write_text('\n'.join(json.dumps(r) for r in [
        {'id': 'a', 'group_id': 'scene', 'split': 'train'},
        {'id': 'b', 'group_id': 'scene', 'split': 'test'}]))
    with pytest.raises(ValueError, match='Group leakage'):
        read_manifest(str(path), {'id', 'group_id', 'split'})


def test_bootstrap_paired_constant():
    result = paired_bootstrap(np.full(8, 2.0), 1, 20)
    assert result['mean'] == result['ci95_low'] == result['ci95_high'] == 2


def test_train_selects_on_validation():
    model = nn.Linear(3, 2)
    x, y = torch.randn(12, 3), torch.arange(12) % 2
    history = train_supervised(model, x[:8], y[:8], x[8:], y[8:],
                                device=torch.device('cpu'), epochs=2, batch_size=4, lr=.01, seed=0)
    assert len(history['history']) == 2
    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())

