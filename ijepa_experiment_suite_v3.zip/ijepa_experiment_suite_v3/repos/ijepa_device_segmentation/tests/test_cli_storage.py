import json
import ast
import importlib
from pathlib import Path

import pytest
import torch

from ijepa_device_segmentation.cli import TASK, main, merge, set_value, load_config, smoke_overrides, validate
from ijepa_device_segmentation.storage import PROJECT, Storage, path_under, absolute_root


def test_config_overrides_types():
    config = {'a': {'b': 0, 'c': False, 'd': 'text'}}
    for item in ['a.b=10', 'a.c=true', 'a.d=hello']:
        set_value(config, item)
    assert config == {'a': {'b': 10, 'c': True, 'd': 'hello'}}
    with pytest.raises(ValueError):
        set_value(config, 'a.misspelled=1')


def test_merge_does_not_mutate_input():
    base = {'train': {'epochs': 30, 'lr': .01}}
    merged = merge(base, {'train': {'epochs': 3}})
    assert base['train']['epochs'] == 30
    assert merged['train'] == {'epochs': 3, 'lr': .01}


def test_cli_dry_run_no_model_or_data_access(capsys, tmp_path):
    main(['--work-dir', str(tmp_path / 'new'), '--dry-run'])
    configs = json.loads(capsys.readouterr().out)
    assert configs[0]['encoder']['backend'] == 'hf'
    assert configs[0]['task'] == TASK
    assert not (tmp_path / 'new').exists()
    assert configs[0]['encoder']['cache_dir'] == str(tmp_path / 'new/models/huggingface/hub')


def test_cli_duplicate_seeds_rejected():
    with pytest.raises(SystemExit):
        main(['--seeds', '0', '0', '--dry-run'])


def test_cli_rejects_other_task(capsys):
    with pytest.raises(ValueError, match='only'):
        main(['--set', 'task=unsupported', '--dry-run'])


def test_cli_has_no_cross_task_switch():
    with pytest.raises(SystemExit):
        main(['--tasks', 'all', '--dry-run'])


def test_default_is_localdata(monkeypatch):
    monkeypatch.delenv('IJEPA_WORK_DIR', raising=False)
    monkeypatch.delenv('DATASETS_ROOT', raising=False)
    s = Storage.create()
    assert s.root == Path.cwd()
    assert s.datasets == Path('/localdata')
    assert s.outputs == Path.cwd() / 'outputs' / PROJECT
    assert s.cache == Path.cwd() / 'cache' / PROJECT
    assert s.hub_cache == Path.cwd() / 'models/huggingface/hub'


def test_env_root_and_cli_precedence(tmp_path, monkeypatch):
    monkeypatch.setenv('IJEPA_WORK_DIR', str(tmp_path / 'env'))
    assert Storage.create().root == tmp_path / 'env'
    assert Storage.create(tmp_path / 'cli').root == tmp_path / 'cli'


def test_relative_work_root_resolves_from_cwd():
    assert Storage.create('relative').root == (Path.cwd() / 'relative').resolve()


def test_relative_override_anchored_to_storage_not_cwd(tmp_path, monkeypatch):
    s = Storage.create(tmp_path / 'root')
    elsewhere = tmp_path / 'elsewhere'; elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    assert path_under('trial', s.outputs) == s.outputs / 'trial'
    assert path_under('v2', s.cache) == s.cache / 'v2'


def test_storage_token_resolution_and_unknown_rejection(tmp_path):
    s = Storage.create(tmp_path / 'root')
    result = s.expand({'x': ['${DATASETS_ROOT}/images', '${HF_HUB_CACHE}']})
    assert result == {'x': [str(s.datasets / 'images'), str(s.hub_cache)]}
    with pytest.raises(ValueError, match='Unresolved'):
        s.expand('${NO_SUCH_ROOT}/data')


def test_config_paths_resolve_with_custom_root(capsys, tmp_path, monkeypatch):
    monkeypatch.setenv('IJEPA_WORK_DIR', str(tmp_path / 'env'))
    main(['--dry-run', '--output', 'sweep', '--cache', 'fresh'])
    cfg = json.loads(capsys.readouterr().out)[0]
    s = Storage.create()
    assert cfg['storage']['outputs'] == str(s.outputs / 'sweep')
    assert cfg['storage']['cache'] == str(s.cache / 'fresh')
    for key in ['root', 'manifest', 'corruption_root']:
        if key in cfg['data']:
            assert Path(cfg['data'][key]).is_relative_to(s.datasets)


def test_partial_yaml_overrides_work(tmp_path, capsys):
    path = tmp_path / 'custom.yaml'
    path.write_text('train:\n  epochs: 7\n')
    main(['--config', str(path), '--dry-run'])
    cfg = json.loads(capsys.readouterr().out)[0]
    assert cfg['train']['epochs'] == 7
    assert cfg['task'] == TASK


def test_packaged_configs_are_present():
    module = importlib.import_module(PROJECT)
    directory = Path(module.__file__).parent
    assert (directory / 'configs/base.yaml').is_file()
    assert (directory / 'configs/experiment.yaml').is_file()
    assert load_config()['task'] == TASK


def test_environment_policy_is_explicit(tmp_path, monkeypatch):
    import os
    s = Storage.create(tmp_path)
    for key in ['HF_HOME','HF_HUB_CACHE','HUGGINGFACE_HUB_CACHE','TORCH_HOME',
                'PIP_CACHE_DIR','XDG_CACHE_HOME','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR']:
        monkeypatch.setenv(key, '/old/cache')
    s.configure_environment()
    assert os.environ['HF_HOME'] == str(s.hf_home)
    assert os.environ['HF_HUB_CACHE'] == str(s.hub_cache)
    assert os.environ['TORCH_HOME'] == str(s.torch_home)


def test_no_sibling_packages_imported():
    own = Path(importlib.import_module(PROJECT).__file__).parent
    for path in own.glob('*.py'):
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.ImportFrom):
                name = node.module or ''
                assert not name.startswith('ijepa_mvp')
                if name.startswith('ijepa_'):
                    assert name.split('.')[0] == PROJECT
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.startswith('ijepa_'):
                        assert alias.name.split('.')[0] == PROJECT


def test_only_one_experiment_module_shipped():
    own = Path(importlib.import_module(PROJECT).__file__).parent
    candidates = {'tta','temporal','segmentation','physics','federated'}
    present = {name for name in candidates if (own / (name + '.py')).exists()}
    assert present == {TASK}


def test_cli_smoke_resume_and_fingerprint(tmp_path, capsys):
    root = tmp_path / 'localdata'
    argv = ['--smoke', '--device', 'cpu', '--work-dir', str(root)]
    main(argv)
    path = root / 'outputs' / PROJECT / 'smoke/seed_0/result.json'
    first = path.read_text()
    assert json.loads(first)['evidence_level'] == 'SMOKE_MOCK_NOT_IJEPA'
    main(argv + ['--resume'])
    assert path.read_text() == first
    assert '[SKIP]' in capsys.readouterr().out
    with pytest.raises(RuntimeError, match='Resume refused'):
        main(argv + ['--resume', '--set', 'train.lr=0.005'])
    with pytest.raises(FileExistsError):
        main(argv)
    cfg = json.loads((path.parent / 'config.json').read_text())
    assert cfg['storage']['outputs'] == str(root / 'outputs' / PROJECT)
    assert (root / 'cache' / PROJECT / 'mock').is_dir()
