# V2 update

This is a historical per-repository guide. For current commands and the enforced logs-only policy, read the suite-level `README_V2.md`. No trained `.pt` or export model is produced by v2.

---

# ijepa_device_segmentation: ④ 端末に載せるのは小型生徒だけ

このリポジトリは、このテーマだけを実行する独立版です。他のリポジトリや元の統合版には依存しません。

固定I-JEPAの前提と、元の実験・対照・評価手順を維持しています。物性推定研究とは独立したMVPです。

**公開checkpoint・実データ・GPUでの性能は未検証です。** CPUのMockによる動作確認と、I-JEPAの研究結果を区別してください。本番ロード失敗時にMockへ自動切替しません。

## 1. Dataset-only /localdata policy (v0.3)

Only input datasets live under `/localdata` (no extra `datasets/` suffix).
Model weights, feature/compiler caches, outputs and temporary files default to the
**current directory from which the script is invoked**, not the dataset directory.

```text
/localdata/                     # datasets only
  cifar-10-batches-py/
  CIFAR-10-C/
  oxford-iiit-pet/
  videos/video_manifest.jsonl
./models/huggingface/hub/        # shared public model cache
./models/torch/
./cache/ijepa_device_segmentation/
./outputs/ijepa_device_segmentation/
./artifacts/ijepa_device_segmentation/
./tmp/ijepa_device_segmentation/
```

`--data-root` > `DATASETS_ROOT` > `/localdata` selects input datasets.
`--work-dir` > `IJEPA_WORK_DIR` > caller cwd selects all other default paths.
`LOCALDATA_ROOT` and the former `--storage-root` option are retired.
The parent suite passes explicit absolute output paths for batch isolation.

```bash
bash run_all.sh dry-run
bash run_all.sh dry-run --data-root /localdata --work-dir "$PWD"
```

## 2. セットアップ

Python 3.10以上。WindowsではWSL/Linux上で `bash run_all.sh` を実行してください。

使用GPUに対応するPyTorchとtorchvisionを用意したうえで、このフォルダで実行します。

```bash
python -m pip install -e ".[real,test]"
```

CPUでソフトウェア検証だけを行う場合：

```bash
python -m pip install -e ".[test]"
bash run_all.sh tests -q
bash run_all.sh smoke
```

Current release verification is in the parent suite verification/ directory. Public-checkpoint/GPU execution remains unverified here.

### 公開checkpointと前処理

```text
model_id: facebook/ijepa_vith14_1k
revision: f157467ea509bc356ff9f61fd3c0d840eec5e04e
```

公式Hugging Faceリポジトリのコミットを固定しています。前処理は同じrevisionの `AutoImageProcessor` から読み込みます。ImageNetのmean/stdを手書きで代用しません。公式processorは224×224へのリサイズとmean/std=0.5を指定しています。

モデルID、解決されたrevision、前処理、dtype、ライブラリバージョンを記録します。ローカルモデルを使う場合は設定・重みファイルのSHA-256も記録します。元のI-JEPA predictorはこのHFエンコーダ経路では読み込みません。

公式モデルのカードには `CC-BY-NC-4.0` の表記があります。モデル重み・データは本ZIPに含めていません。利用時は配布元の条件を確認してください。

## 3. Commands

```bash
bash run_all.sh tests -q
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh smoke --seeds 0 1 2 --resume
bash run_all.sh check --expected-runs 3
bash run_all.sh report

# Real encoder; see the next section for data preparation.
bash run_all.sh real --device cuda --seeds 0 1 2

# No data/weight access or filesystem writes:
bash run_all.sh dry-run --config examples/override.yaml
```

`--tasks` は廃止しました。このリポジトリのテーマだけが実行されます。

設定は `src/ijepa_device_segmentation/configs/` に同梱し、wheel単体でも利用できます。

`--resume` は完了済み実行のスキップであり、epochの途中再開ではありません。設定・コードが変わった場合は拒否します。

## 4. ④ 端末に載せるのは小型生徒だけ

```bash
# 合成形状で仕組みを確認
bash run_all.sh real --device cuda

# 公開データでpilot
bash run_all.sh prepare --dataset pets --root /localdata
bash run_all.sh real --device cuda \
  --set data.dataset=pets --output ./outputs/ijepa_device_segmentation/pets
```

独自セグメンテーションデータは `image, mask, id, group_id, split` のJSONLで指定します。maskは整数class ID、255はignoreです。Oxford-IIIT Petでは配布maskの1..3を0..2へ変換します。

モデル幅・深さ・入力解像度ごとに、蒸留なしの教師あり学習とI-JEPA特徴蒸留を比較します。モデル選択にはvalidationのmIoUと測定資源だけを使い、選択された候補だけをtest評価します。

端末側では、保存された生徒checkpointだけをコピーして次を実行できます。

```bash
bash run_all.sh benchmark \
  --checkpoint ./outputs/ijepa_device_segmentation/real/seed_0/w8_d1_s64_kd0.2.pt \
  --device cpu --threads 1 --input-size 128 \
  --warmup 50 --repeats 200 \
  --output device_benchmark.json --export student.pt2
```

`student.pt2` は固定入力shapeの `torch.export` 成果物です。TensorRT、CoreML、NPU向けの変換や量子化を自動で行うものではありません。

計測対象は「uint8 RGB tensor → resize/normalize → 小型ネットワーク → 元解像度のlogits」です。ファイルdecode・通信は含みません。CPUで測った結果をスマートフォン/NPUの結果と読み替えないでください。

`deployment_bytes_budget` は**パラメータ・bufferの格納量**の制約であり、総RAMの上限制約ではありません。CUDAではallocated peakと増分を記録します。CPUはRSSの測定後値でありpeakではありません。GPUでの学習プロセス中の絶対peakには他の生存tensorが混ざり得るため、端末メモリの評価にはstandalone benchmarkを使用してください。

## 5. Repository structure

```text
ijepa_device_segmentation/
  run_all.sh
  pyproject.toml
  README_JA.md
  .env.example
  src/ijepa_device_segmentation/
    configs/base.yaml
    configs/experiment.yaml
    cli.py
    storage.py
    encoder.py
    common.py
    segmentation.py
    prepare.py
    report.py
    check.py
  tests/
  examples/
  docs/RESEARCH_REVIEW_JA.md
  docs/SOURCES.md
  verification/TEST_REPORT_JA.md
```

共通機能は各リポジトリに同梱しています。元の統合版や親フォルダのPYTHONPATHは不要です。Pythonパッケージ名もすべて異なります。

## 6. 実行と結果解釈の注意

- 同一seedの繰り返しを独立試行として集計しません。1 seedの標準偏差は0ではなくnullです。
- `--set` は既存の設定キーだけを変更でき、タイプミスしたキーはエラーになります。
- キャッシュの更新や大規模データを含め、絶対的な所要時間・GPUメモリ量は未測定です。初回はsubset、encoder batch size 1〜8から開始してください。
- `.pt` を読み込む際は、このパッケージのコードが作った信頼できるファイルを使用してください。ツールの読込は `weights_only=True` を使っています。
- 特定手法が勝つようなハイパーパラメータ探索、テスト結果によるモデル選択は実施していません。
- 本番の論文比較では、checkpoint・パラメータ数・sourceへのアクセス・更新予算・実測時間を揃える必要があります。

### オフライン／社内プロキシ環境

信頼された経路でcheckpoint一式をローカルディレクトリに配置して使用できます。TLS検証の無効化は行いません。

```bash
bash run_all.sh real --device cuda \
  --set encoder.model_id=./models/ijepa_vith14_1k \
  --set encoder.local_files_only=true \
  --set encoder.batch_size=2
```

