# ijepa_device_segmentation

## 3. ④ 実デバイス指標を目的関数にしたセグメンテーション

### 検証したい仮説

> 固定I-JEPAから小型モデルへ移す際、表現損失の改善は端末上での実効価値の改善と一致しない。蒸留の有無・モデル容量・解像度を、端末の実測制約の下で共同評価すると、計算量proxyだけでは選べない構成が見つかるか。

「実測値でNASを行った」というだけでは弱い。論文化には、**どの特徴を蒸留すると、どの端末制約下で効果が失われるか／保持されるか**という説明可能な規則が必要になる。

### MVPで修正した設計

I-JEPAの重いエンコーダを端末へ載せるのではなく、固定teacherの空間特徴を小型CNNへ蒸留する。CE単独とCE＋特徴cosine distillationを同じ候補集合で比較する。

width、depth、入力解像度を変更し、validationのmIoU、実測p95 latency、配布モデルのtensor bytesから選択する。quality-only、畳込みMACsを使ったproxy選択も対照とする。testは候補選択に使わない。

配布モデルからteacherと蒸留projectionを除外する。uint8画像のresize/normalizeから元解像度logitsまでを測定し、保存→読込→再推論および `torch.export` のround-tripもテストする。

### メモリとデバイスの厳密な定義

`deployment_bytes_budget` は重み・bufferの格納量であり、working RAMではない。CUDA peakはプロセス内の他tensorの影響を受けるため、端末評価には独立プロセスのbenchmarkを使う。CPU RSSの測定後値をpeakと呼ばない。

現在のbackendはPyTorch eagerである。デスクトップCPU/GPUで測定した結果を、スマートフォンNPUやTensorRTの結果と一般化しない。exportはモデル保存の確認であり、最適化済み端末runtimeへの変換ではない。

### 投稿へ進む条件

合成形状は機能確認に限定する。少なくとも公開セグメンテーションデータと実ターゲット機器で、蒸留効果とlatency制約の関係を確認する。MVPはOxford-IIIT Petと独自manifestに対応するが、Cityscapes等の主要ベンチマークのフル再現は未実装。

候補を6個測って最良を選ぶだけでは原理的な新規性が弱い。端末間で順位が入れ替わる条件、境界精度と特徴poolingの関係、固定teacherのどの情報を切り捨てられるかまで分析できる場合に研究を拡張する。

---

## 6. 投稿向け共通チェックリスト

| 観点 | MVPで実施 | 投稿前に追加が必要 |
|---|---|---|
| 再現性 | seed、設定、code hash、checkpoint revision、前処理、分割ID、モデル保存 | 実GPUでの再実行、環境lock、別環境追試 |
| 評価リーク | source/trainだけで前処理推定、validation選択、TTAラベル非参照、group分割 | 追加データでの独立追試、公式splitの監査 |
| 比較の公平性 | 共通特徴・損失・stream、対照とablation、実コスト記録 | 外部強ベースラインの正確な再現、同実測予算での比較 |
| 統計 | scene単位paired bootstrap、seed別出力、1 seedのSDをnull | 複数seedと独立データに基づくCI、クライアントの標本数感度 |
| 計算量 | ヘッド時間とE2E時間を区別、実測latency、送受信payload | 電力、ターゲット端末、総working memory、異なるruntime |
| 新規性 | 既存手法との重複を明記、反証可能な問いへ限定 | 網羅的な近接研究調査と、新規機構・理論・知見の確立 |

