from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from .common import array_digest, split_indices


def read_manifest(path: str, required: set[str]) -> list[dict]:
    p = Path(path)
    rows = [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
    if not rows:
        raise ValueError("Empty manifest")
    group_splits = {}
    ids = set()
    for row in rows:
        if not required <= row.keys():
            raise ValueError(f"Manifest missing {required - row.keys()}")
        if row["split"] not in {"train", "val", "test"}:
            raise ValueError("Manifest splits must be train/val/test")
        group = str(row["group_id"])
        if group in group_splits and group_splits[group] != row["split"]:
            raise ValueError("Group leakage between train/val/test")
        group_splits[group] = row["split"]
        if row["id"] in ids:
            raise ValueError("Duplicate manifest sample ID")
        ids.add(row["id"])
        row["_root"] = p.parent
    return rows


def segmentation_shapes(n: int, seed: int, size: int):
    rng = np.random.default_rng(seed)
    images, masks = [], []
    for _ in range(n):
        background = tuple(rng.integers(5, 60, 3).tolist())
        image, mask = Image.new("RGB", (size, size), background), Image.new("L", (size, size), 0)
        a, b = ImageDraw.Draw(image), ImageDraw.Draw(mask)
        for _ in range(int(rng.integers(1, 4))):
            label = int(rng.integers(1, 3))
            x, y = rng.integers(0, size * 2 // 3, 2)
            radius = int(rng.integers(max(3, size // 8), max(4, size // 3)))
            box = (int(x), int(y), min(size - 1, int(x) + radius), min(size - 1, int(y) + radius))
            color = tuple(rng.integers(80, 255, 3).tolist())
            fn1, fn2 = (a.ellipse, b.ellipse) if label == 1 else (a.rectangle, b.rectangle)
            fn1(box, fill=color)
            fn2(box, fill=label)
        images.append(np.asarray(image))
        masks.append(np.asarray(mask).astype(np.int64))
    return np.stack(images), np.stack(masks)


def segmentation_data(cfg: dict) -> dict:
    spec = cfg["data"]
    size = spec["image_size"]
    result = {}
    if spec["dataset"] == "shapes":
        for k, offset in [("train", 0), ("val", 100000), ("test", 200000)]:
            x, y = segmentation_shapes(spec[f"n_{k}"], cfg["seed"] + offset, size)
            result[k] = (x, y, [f"{k}-{i}" for i in range(len(x))])
    elif spec["dataset"] == "manifest":
        rows = read_manifest(spec["manifest"], {"image", "mask", "split", "id", "group_id"})
        for split in ["train", "val", "test"]:
            selected = [r for r in rows if r["split"] == split][:spec[f"n_{split}"]]
            images, masks, ids = [], [], []
            for row in selected:
                with Image.open(row["_root"] / row["image"]) as im:
                    images.append(np.asarray(im.convert("RGB").resize((size, size), Image.Resampling.BILINEAR)))
                with Image.open(row["_root"] / row["mask"]) as im:
                    masks.append(np.asarray(im.resize((size, size), Image.Resampling.NEAREST)).astype(np.int64))
                ids.append(row["id"])
            if not images:
                raise ValueError(f"Empty segmentation {split}")
            result[split] = (np.stack(images), np.stack(masks), ids)
    elif spec["dataset"] == "pets":
        from torchvision.datasets import OxfordIIITPet
        dev = OxfordIIITPet(spec["root"], split="trainval", target_types="segmentation",
                           download=spec.get("download", False))
        test = OxfordIIITPet(spec["root"], split="test", target_types="segmentation",
                            download=spec.get("download", False))
        tr, va = split_indices(len(dev), .2, cfg["seed"])
        for split, ds, indices in [("train", dev, tr), ("val", dev, va), ("test", test, np.arange(len(test)))]:
            images, masks, ids = [], [], []
            for i in indices[:spec[f"n_{split}"]]:
                image, mask = ds[int(i)]
                images.append(np.asarray(image.convert("RGB").resize((size, size), Image.Resampling.BILINEAR)))
                masks.append(np.asarray(mask.resize((size, size), Image.Resampling.NEAREST)).astype(np.int64) - 1)
                ids.append(f"{'test' if split == 'test' else 'trainval'}-{int(i)}")
            result[split] = (np.stack(images), np.stack(masks), ids)
    else:
        raise ValueError("Unknown segmentation dataset")
    for split, (_, y, _) in result.items():
        valid = (y == 255) | ((y >= 0) & (y < cfg["num_classes"]))
        if y.ndim != 3 or not valid.all():
            raise ValueError(f"Invalid {split} segmentation masks; expected integer class IDs / 255 ignore")
    # Disjoint IDs alone cannot rule out duplicate files; check exact image hashes too.
    seen = {}
    for split, (images, _, _) in result.items():
        for im in images:
            key = array_digest(im)
            if key in seen and seen[key] != split:
                raise ValueError("Duplicate image contents across segmentation splits")
            seen[key] = split
    return result

