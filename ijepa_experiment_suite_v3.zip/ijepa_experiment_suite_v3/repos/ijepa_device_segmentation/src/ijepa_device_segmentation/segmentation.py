from __future__ import annotations

import copy
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .common import (benchmark, dump_json, parameter_bytes, parameter_count, save_checkpoint)
from .data import segmentation_data


class DepthwiseBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, stride, 1, groups=in_channels, bias=False),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.GroupNorm(1, out_channels), nn.SiLU())

    def forward(self, x):
        return self.net(x)


class TinySegmenter(nn.Module):
    def __init__(self, width: int, depth: int, classes: int):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv2d(3, width, 3, 2, 1, bias=False),
                                  nn.GroupNorm(1, width), nn.SiLU())
        self.blocks = nn.Sequential(*[DepthwiseBlock(width, width, 2 if i == 0 else 1)
                                      for i in range(depth)])
        self.classifier = nn.Conv2d(width, classes, 1)

    def features(self, x):
        return self.blocks(self.stem(x))

    def forward(self, x):
        return self.classifier(self.features(x))


class DeploySegmenter(nn.Module):
    """Deployment artifact: uint8 BCHW RGB -> resize/normalize -> student -> dense logits.

    No I-JEPA teacher or distillation projection is loaded on the target device.
    Disk decoding and network transfer are outside this callable.
    """
    def __init__(self, student: TinySegmenter, input_size: int):
        super().__init__()
        self.student, self.input_size = student, input_size
        self.register_buffer("mean", torch.tensor([.485, .456, .406])[None, :, None, None])
        self.register_buffer("std", torch.tensor([.229, .224, .225])[None, :, None, None])

    def prepare(self, images):
        x = F.interpolate(images.float() / 255, (self.input_size, self.input_size),
                          mode="bilinear", align_corners=False)
        return (x - self.mean) / self.std

    def forward(self, images):
        logits = self.student(self.prepare(images))
        return F.interpolate(logits, images.shape[-2:], mode="bilinear", align_corners=False)


def iou_from_confusion(confusion: torch.Tensor) -> dict:
    confusion = confusion.double()
    intersection = confusion.diag()
    union = confusion.sum(0) + confusion.sum(1) - intersection
    present = union > 0
    values = intersection / union.clamp_min(1)
    return {"miou": float(values[present].mean()) if present.any() else 0.0,
            "per_class_iou": [float(v) if p else None for v, p in zip(values, present)],
            "confusion": confusion.long().tolist(),
            "absent_classes_excluded": True}


@torch.no_grad()
def evaluate(model: DeploySegmenter, images: torch.Tensor, masks: torch.Tensor,
             classes: int, device: torch.device, batch_size: int) -> dict:
    model.eval()
    conf = torch.zeros(classes, classes, dtype=torch.long)
    for x, y in zip(images.split(batch_size), masks.split(batch_size)):
        pred = model(x.to(device)).argmax(1).cpu()
        keep = y != 255
        bins = classes * y[keep].long() + pred[keep]
        conf += torch.bincount(bins, minlength=classes * classes).reshape(classes, classes)
    return iou_from_confusion(conf)


def conv_macs(model: nn.Module, example: torch.Tensor) -> int:
    count = [0]
    handles = []
    def hook(module, _inputs, output):
        count[0] += output.numel() * (module.in_channels // module.groups) * module.kernel_size[0] * module.kernel_size[1]
    for module in model.modules():
        if isinstance(module, nn.Conv2d):
            handles.append(module.register_forward_hook(hook))
    try:
        with torch.no_grad():
            model(example)
    finally:
        for h in handles:
            h.remove()
    return int(count[0])


def pareto_front(rows: list[dict]) -> list[str]:
    def dominates(a, b):
        av = (a["val_miou"], -a["latency_p95_ms"], -a["deploy_bytes"])
        bv = (b["val_miou"], -b["latency_p95_ms"], -b["deploy_bytes"])
        return all(x >= y for x, y in zip(av, bv)) and any(x > y for x, y in zip(av, bv))
    return [r["name"] for r in rows if not any(dominates(a, r) for a in rows if a is not r)]


def select_candidate(rows: list[dict], latency_ms: float, model_bytes: int) -> dict | None:
    eligible = [r for r in rows if r["latency_p95_ms"] <= latency_ms and r["deploy_bytes"] <= model_bytes]
    return max(eligible, key=lambda r: (r["val_miou"], -r["latency_p95_ms"])) if eligible else None


def run(cfg: dict, encoder, cache, out: Path, device: torch.device) -> dict:
    data = segmentation_data(cfg)
    x = {s: torch.from_numpy(a[0].copy()).permute(0, 3, 1, 2) for s, a in data.items()}
    y = {s: torch.from_numpy(a[1].copy()).long() for s, a in data.items()}
    teacher = cache.get(data["train"][0], grid=8, spatial=True)
    # Teacher is not needed again. Remove its GPU residency before student profiling.
    if device.type == "cuda" and hasattr(encoder, "model"):
        encoder.model.to("cpu")
        torch.cuda.empty_cache()
    candidates, models, all_histories = [], {}, {}
    classes = cfg["num_classes"]
    counts = torch.bincount(y["train"][y["train"] != 255], minlength=classes).float()
    weights = (counts.sum() / counts.clamp_min(1)).sqrt()
    weights = (weights / weights.mean()).to(device)
    for spec in cfg["segmentation"]["candidates"]:
        for kd in cfg["segmentation"]["distillation_weights"]:
            torch.manual_seed(cfg["seed"])
            student = TinySegmenter(spec["width"], spec["depth"], classes)
            model = DeploySegmenter(student, spec["input_size"]).to(device)
            projector = nn.Conv2d(spec["width"], teacher.shape[1], 1).to(device) if kd > 0 else None
            parameters = list(model.parameters()) + ([] if projector is None else list(projector.parameters()))
            optimizer = torch.optim.AdamW(parameters, lr=cfg["train"]["lr"], weight_decay=1e-4)
            best_score, best_state, history = -1.0, None, []
            generator = torch.Generator().manual_seed(cfg["seed"])
            for epoch in range(cfg["train"]["epochs"]):
                model.train()
                total = 0.0
                for indices in torch.randperm(len(x["train"]), generator=generator).split(cfg["train"]["batch_size"]):
                    inp, labels = x["train"][indices].to(device), y["train"][indices].to(device)
                    optimizer.zero_grad(set_to_none=True)
                    features = model.student.features(model.prepare(inp))
                    logits = F.interpolate(model.student.classifier(features), labels.shape[-2:],
                                           mode="bilinear", align_corners=False)
                    loss = F.cross_entropy(logits, labels, weight=weights, ignore_index=255)
                    if projector is not None:
                        p = F.adaptive_avg_pool2d(projector(features), teacher.shape[-2:])
                        target = teacher[indices].to(device)
                        # Feature cosine KD does not use test data or a trainable I-JEPA teacher.
                        loss = loss + kd * (1 - F.cosine_similarity(p, target, dim=1)).mean()
                    if not torch.isfinite(loss):
                        raise FloatingPointError("Non-finite segmentation training loss")
                    loss.backward()
                    nn.utils.clip_grad_norm_(parameters, 5)
                    optimizer.step()
                    total += float(loss.detach()) * len(indices)
                val = evaluate(model, x["val"], y["val"], classes, device, cfg["train"]["batch_size"])
                history.append({"epoch": epoch, "train_loss": total / len(x["train"]), "val_miou": val["miou"]})
                if val["miou"] > best_score:
                    best_score = val["miou"]
                    best_state = copy.deepcopy({k: v.detach().cpu() for k, v in model.state_dict().items()})
            model.load_state_dict(best_state)
            model.eval()
            example = x["val"][:1].to(device)
            profile = benchmark(lambda: model(example), device, **cfg["profile"],
                                scope="uint8_RGB_to_dense_logits; resizing+normalization+student; no teacher")
            name = f"w{spec['width']}_d{spec['depth']}_s{spec['input_size']}_kd{kd:g}"
            row = {"name": name, "spec": spec, "distillation_weight": kd, "val_miou": best_score,
                   "deploy_parameters": parameter_count(model), "deploy_bytes": parameter_bytes(model),
                   "conv_MACs_only": conv_macs(model, example), **profile}
            candidates.append(row)
            models[name] = (copy.deepcopy(model).cpu(), spec)
            all_histories[name] = history
            save_checkpoint(out / f"{name}.pt", model, kind="deploy_segmenter", spec=spec, classes=classes,
                            training_teacher=encoder.provenance, teacher_in_deployment=False,
                            distillation_weight=kd, input_format="uint8_BCHW_RGB")
            # The training-only KD projection is deliberately not exported.
            del optimizer, projector, model
    selections, tested = {}, {}
    for kd in cfg["segmentation"]["distillation_weights"]:
        rows = [r for r in candidates if r["distillation_weight"] == kd]
        selected = select_candidate(rows, cfg["segmentation"]["latency_budget_ms"],
                                     cfg["segmentation"]["deployment_bytes_budget"])
        quality_only = max(rows, key=lambda r: r["val_miou"])
        mac_rows = [r for r in rows if r["conv_MACs_only"] <= cfg["segmentation"]["mac_budget"]]
        mac_only = max(mac_rows, key=lambda r: r["val_miou"]) if mac_rows else None
        for rule, chosen in [("device_constrained", selected), ("quality_only", quality_only), ("MAC_proxy", mac_only)]:
            key = f"kd{kd:g}_{rule}"
            selections[key] = None if chosen is None else chosen["name"]
            if chosen is not None and chosen["name"] not in tested:
                model = models[chosen["name"]][0].to(device)
                tested[chosen["name"]] = evaluate(model, x["test"], y["test"], classes, device,
                                                   cfg["train"]["batch_size"])
                model.cpu()
    budget_frontiers = []
    for kd in cfg["segmentation"]["distillation_weights"]:
        subset = [r for r in candidates if r["distillation_weight"] == kd]
        # Profile-derived budgets are exploratory curves, NOT a declared target-device SLA.
        budgets = sorted(set(float(np.quantile([r["latency_p95_ms"] for r in subset], q))
                             for q in cfg["segmentation"].get("profile_budget_quantiles", [0.0, .5, 1.0])))
        for limit in budgets:
            selected = select_candidate(subset, limit, cfg["segmentation"]["deployment_bytes_budget"])
            budget_frontiers.append({"distillation_weight": kd, "p95_budget_ms": limit,
                "budget_origin": "validation_candidate_profile_quantile_EXPLORATORY",
                "selected_name": None if selected is None else selected["name"],
                "selected_val_miou": None if selected is None else selected["val_miou"]})
    dump_json(out / "validation_budget_curve.json", budget_frontiers)
    dump_json(out / "candidate_validation.json", candidates)
    dump_json(out / "training.json", all_histories)
    dump_json(out / "split_ids.json", {s: a[2] for s, a in data.items()})
    return {"theme": "04_device_measured_segmentation", "dataset": cfg["data"]["dataset"],
            "candidates": candidates, "pareto_validation": pareto_front(candidates),
            "selection_uses_test_labels": False, "selected_names": selections, "selected_test_metrics": tested,
            "resource_constraints": {"p95_latency_ms": cfg["segmentation"]["latency_budget_ms"],
                                      "model_tensor_bytes_NOT_total_RAM": cfg["segmentation"]["deployment_bytes_budget"]},
            "all_candidates_meet_configured_resource_constraints": all(
                r["latency_p95_ms"] <= cfg["segmentation"]["latency_budget_ms"] and
                r["deploy_bytes"] <= cfg["segmentation"]["deployment_bytes_budget"] for r in candidates),
            "budget_curve_is_validation_only": True,
            "cpu_peak_memory_measured": False, "target_device_claim": "only the device named in environment.json",
            "deployment_contains_ijepa": False}
