"""Standalone runner for ijepa_device_segmentation; no sibling repository is imported."""
from __future__ import annotations

import argparse
import copy
import datetime
import importlib
import json
import shutil
import traceback
from pathlib import Path

import yaml

from .common import code_digest, device_of, digest, dump_json, environment, seed_all
from .encoder import FeatureCache, make_encoder
from .storage import PROJECT, Storage, ensure_writable_directory, path_under

TASK = "segmentation"


def merge(a: dict, b: dict) -> dict:
    result = copy.deepcopy(a)
    for key, value in b.items():
        result[key] = merge(result[key], value) if isinstance(value, dict) and isinstance(result.get(key), dict) else value
    return result


def set_value(config: dict, assignment: str) -> None:
    if "=" not in assignment:
        raise ValueError("--set requires dotted.key=value")
    key, text = assignment.split("=", 1)
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        value = text
    parts, target = key.split("."), config
    for name in parts[:-1]:
        if name not in target or not isinstance(target[name], dict):
            raise ValueError(f"Unknown configuration path: {key}")
        target = target[name]
    if parts[-1] not in target:
        raise ValueError(f"Unknown configuration key: {key}")
    target[parts[-1]] = value


def smoke_overrides(cfg: dict) -> dict:
    c = copy.deepcopy(cfg)
    c["smoke"] = True
    c["encoder"]["backend"] = "mock"
    c["encoder"]["batch_size"] = 32
    c["profile"] = {"warmup": 1, "repeats": 3}
    c["train"].update(epochs=3, batch_size=16, lr=.01)
    c["data"].update(dataset="shapes", n_train=24, n_val=8, n_test=8, image_size=32)
    c["segmentation"]["candidates"] = [{"width": 4, "depth": 1, "input_size": 24},
                                        {"width": 8, "depth": 2, "input_size": 32}]
    c["segmentation"]["latency_budget_ms"] = 1000.0
    return c


def load_config(path: Path | None = None) -> dict:
    config_dir = Path(__file__).resolve().parent / "configs"
    base = yaml.safe_load((config_dir / "base.yaml").read_text(encoding="utf-8"))
    experiment = yaml.safe_load((config_dir / "experiment.yaml").read_text(encoding="utf-8"))
    cfg = merge(base, experiment)
    if path:
        extra = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(extra, dict):
            raise ValueError("--config must contain a YAML mapping")
        cfg = merge(cfg, extra)
    return cfg


def validate(cfg: dict, check_data: bool = True) -> None:
    if cfg.get("task") != TASK:
        raise ValueError(f"This standalone repository supports only {TASK}")
    if cfg["train"]["epochs"] < 1 or cfg["train"]["batch_size"] < 1:
        raise ValueError("epochs and batch_size must be positive")
    if cfg["encoder"]["batch_size"] < 1:
        raise ValueError("encoder.batch_size must be positive")
    if cfg["profile"]["repeats"] < 2:
        raise ValueError("profile.repeats must be >= 2")
    if not cfg["smoke"] and cfg["encoder"]["backend"] == "mock":
        raise ValueError("Refusing a mock encoder outside --smoke")
    if check_data and cfg["data"]["dataset"] == "manifest":
        if not Path(cfg["data"]["manifest"]).is_file():
            raise FileNotFoundError(cfg["data"]["manifest"])


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description=f"Standalone frozen-I-JEPA {TASK} research pilot")
    parser.add_argument("--config", type=Path, help="YAML overrides of packaged defaults")
    parser.add_argument("--seeds", nargs="+", type=int, default=[0])
    parser.add_argument("--device", default="auto")
    parser.add_argument("--smoke", action="store_true", help="Explicit MOCK_NOT_IJEPA software test")
    parser.add_argument("--work-dir", type=Path, help="Generated files: default caller cwd")
    parser.add_argument("--data-root", type=Path, help="Datasets only: default /localdata")
    parser.add_argument("--output", type=Path, help="Absolute path, or subdirectory of this project's output root")
    parser.add_argument("--cache", type=Path, help="Absolute path, or subdirectory of this project's cache root")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--resume", action="store_true", help="Skip complete fingerprint-matching runs only")
    parser.add_argument("--overwrite", action="store_true", help="Replace selected generated run directories")
    parser.add_argument("--dry-run", action="store_true", help="Print resolved settings without filesystem writes/model access")
    args = parser.parse_args(argv)
    if args.resume and args.overwrite:
        parser.error("--resume and --overwrite are mutually exclusive")
    if len(set(args.seeds)) != len(args.seeds):
        parser.error("Do not repeat seeds: identical repetitions are not independent evidence")
    storage = Storage.create(args.work_dir, args.data_root)
    cfg = load_config(args.config)
    if args.smoke:
        cfg = smoke_overrides(cfg)
    for item in args.set:
        set_value(cfg, item)
    cfg = storage.expand(cfg)
    cfg["storage"] = storage.snapshot()
    for key in ("root", "manifest", "corruption_root"):
        if key in cfg.get("data", {}):
            cfg["data"][key] = str(path_under(cfg["data"][key], storage.datasets))
    cfg["encoder"]["cache_dir"] = str(path_under(cfg["encoder"]["cache_dir"], storage.hub_cache))
    output = path_under(args.output, storage.outputs)
    cache_root = path_under(args.cache, storage.cache)
    cfg["storage"].update(outputs=str(output), cache=str(cache_root))
    validate(cfg, check_data=False)
    resolved = [dict(copy.deepcopy(cfg), seed=seed) for seed in args.seeds]
    if args.dry_run:
        print(json.dumps(resolved, indent=2))
        return
    storage.configure_environment()
    validate(cfg)
    device = device_of(args.device)
    for cfg in resolved:
        cfg["device"] = str(device)
        kind = "SMOKE_MOCK_NOT_IJEPA" if cfg["smoke"] else "PUBLIC_IJEPA_PILOT"
        run_dir = output / ("smoke" if cfg["smoke"] else "real") / f"seed_{cfg['seed']}"
        fingerprint = digest({"config": cfg, "code": code_digest()})
        result_path = run_dir / "result.json"
        if result_path.exists() and args.resume:
            previous = json.loads(result_path.read_text())
            if previous.get("fingerprint") != fingerprint or previous.get("status") != "complete":
                raise RuntimeError(f"Resume refused: code/config changed or incomplete run: {run_dir}")
            print(f"[SKIP] {run_dir}: complete fingerprint-matching result", flush=True)
            continue
        if run_dir.exists() and any(run_dir.iterdir()):
            if not args.overwrite:
                raise FileExistsError(f"Existing run: {run_dir}; pass --resume or --overwrite explicitly")
            if run_dir.is_symlink():
                raise RuntimeError("Refusing to overwrite a symlinked run directory")
            shutil.rmtree(run_dir)
        ensure_writable_directory(run_dir)
        seed_all(cfg["seed"], cfg["threads"])
        dump_json(run_dir / "config.json", cfg)
        dump_json(run_dir / "environment.json", environment())
        dump_json(run_dir / "storage.json", cfg["storage"])
        status = {"status": "running", "evidence_level": kind, "fingerprint": fingerprint,
                  "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        dump_json(run_dir / "status.json", status)
        print(f"[RUN] {PROJECT} seed={cfg['seed']} evidence={kind} device={device}", flush=True)
        try:
            encoder = make_encoder(cfg, device)
            dump_json(run_dir / "encoder.json", encoder.provenance)
            cache = FeatureCache(cache_root / ("mock" if cfg["smoke"] else "ijepa"), encoder,
                                 cfg["encoder"]["batch_size"])
            module = importlib.import_module(f"{__package__}.{TASK}")
            result = module.run(cfg, encoder, cache, run_dir, device)
            result.update(artifact_policy="logs_only_v2", weights_saved=False, evidence_level=kind, fingerprint=fingerprint, seed=cfg["seed"],
                          status="complete", project=PROJECT)
            dump_json(run_dir / "cache_events.json", cache.events)
            dump_json(result_path, result)
            status["status"] = "complete"
            dump_json(run_dir / "status.json", status)
            print(f"[OK] {result_path}", flush=True)
            del encoder, cache
        except Exception as exc:
            status.update(status="failed", exception_type=type(exc).__name__, message=str(exc))
            dump_json(run_dir / "status.json", status)
            (run_dir / "traceback.txt").write_text(traceback.format_exc())
            raise


if __name__ == "__main__":
    main()
