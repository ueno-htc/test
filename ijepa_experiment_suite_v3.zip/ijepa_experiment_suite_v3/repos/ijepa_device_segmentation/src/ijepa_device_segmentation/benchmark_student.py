"""Run on the actual intended device. No encoder/checkpoint download is needed."""
import argparse
from pathlib import Path

import torch
from .storage import Storage, path_under

from ijepa_device_segmentation.common import benchmark, device_of, dump_json, environment, parameter_bytes, seed_all
from ijepa_device_segmentation.segmentation import DeploySegmenter, TinySegmenter, conv_macs


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--work-dir", type=Path)
    p.add_argument("--data-root", type=Path)
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--device", default="cpu")
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--input-size", type=int, default=128)
    p.add_argument("--warmup", type=int, default=50)
    p.add_argument("--repeats", type=int, default=200)
    p.add_argument("--output", type=Path)
    p.add_argument("--export", type=Path, help="Disabled in logs-only v2; retained only for a clear error")
    a = p.parse_args(argv)
    storage = Storage.create(a.work_dir, a.data_root)
    storage.configure_environment()
    a.checkpoint = path_under(a.checkpoint, storage.outputs)
    a.output = path_under(a.output, storage.artifacts / "device_benchmark.json", storage.artifacts)
    if a.export:
        raise ValueError("Model export is disabled by logs-only v2 policy")
    seed_all(0, a.threads)
    checkpoint = torch.load(a.checkpoint, map_location="cpu", weights_only=True)
    if checkpoint.get("kind") != "deploy_segmenter":
        raise ValueError("This tool accepts only exported segmentation students")
    spec = checkpoint["spec"]
    model = DeploySegmenter(TinySegmenter(spec["width"], spec["depth"], checkpoint["classes"]),
                            spec["input_size"]).to(device_of(a.device)).eval()
    model.load_state_dict(checkpoint["state_dict"])
    device = device_of(a.device)
    example = torch.randint(0, 256, (1, 3, a.input_size, a.input_size), dtype=torch.uint8, device=device)
    result = benchmark(lambda: model(example), device, a.warmup, a.repeats,
                       scope="uint8_RGB_to_dense_logits_including_resize_and_normalization")
    result.update(environment=environment(), deploy_bytes=parameter_bytes(model),
                  conv_MACs_only=conv_macs(model, example), checkpoint=str(a.checkpoint),
                  input_shape=list(example.shape), teacher_in_deployment=False)
    dump_json(a.output, result)
    print(a.output)


if __name__ == "__main__":
    main()
