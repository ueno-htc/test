"""Explicit dataset preparation; runtime data are stored below /localdata."""
import argparse
from pathlib import Path
from .storage import Storage, path_under, ensure_writable_directory


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["pets"], default="pets")
    p.add_argument("--work-dir", type=Path)
    p.add_argument("--data-root", type=Path)
    p.add_argument("--root", type=Path)
    a = p.parse_args(argv)
    storage = Storage.create(a.work_dir, a.data_root)
    storage.configure_environment()
    a.root = path_under(a.root, storage.datasets)
    ensure_writable_directory(a.root)
    from torchvision.datasets import OxfordIIITPet
    for split in ["trainval", "test"]:
        OxfordIIITPet(str(a.root), split=split, target_types="segmentation", download=True)
    print("Dataset preparation completed; existing valid data were retained.")


if __name__ == "__main__":
    main()
