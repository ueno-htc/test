# V2 update

This is a historical per-repository guide. For current commands and the enforced logs-only policy, read the suite-level `README_V2.md`. No trained `.pt` or export model is produced by v2.

---

# ijepa_temporal_ssm: ③ 時間間隔を考慮したSSM

このリポジトリは、このテーマだけを実行する独立版です。他のリポジトリや元の統合版には依存しません。

固定I-JEPAの前提と、元の実験・対照・評価手順を維持しています。物性推定研究とは独立したMVPです。

**公開checkpoint・実データ・GPUでの性能は未検証です。** CPUのMockによる動作確認と、I-JEPAの研究結果を区別してください。本番ロード失敗時にMockへ自動切替しません。

## 1. Dataset-only /localdata policy (v0.3)

Only input datasets live under `/localdata` (no extra `datasets/` suffix).
Model weights, feature/compiler caches, outputs and temporary files default to the
**current directory from which the script is invoked**, not the dataset directory.

```text
/localdata/                     # datasets only
  cifar-10-batches-py/
  CIFAR-10-C/
  oxford-iiit-pet/
  videos/video_manifest.jsonl
./models/huggingface/hub/        # shared public model cache
./models/torch/
./cache/ijepa_temporal_ssm/
./outputs/ijepa_temporal_ssm/
./artifacts/ijepa_temporal_ssm/
./tmp/ijepa_temporal_ssm/
```

`--data-root` > `DATASETS_ROOT` > `/localdata` selects input datasets.
`--work-dir` > `IJEPA_WORK_DIR` > caller cwd selects all other default paths.
`LOCALDATA_ROOT` and the former `--storage-root` option are retired.
The parent suite passes explicit absolute output paths for batch isolation.

```bash
bash run_all.sh dry-run
bash run_all.sh dry-run --data-root /localdata --work-dir "$PWD"
```

## 2. セットアップ

Python 3.10以上。WindowsではWSL/Linux上で `bash run_all.sh` を実行してください。

使用GPUに対応するPyTorchとtorchvisionを用意したうえで、このフォルダで実行します。

```bash
python -m pip install -e ".[real,test]"
```

CPUでソフトウェア検証だけを行う場合：

```bash
python -m pip install -e ".[test]"
bash run_all.sh tests -q
bash run_all.sh smoke
```

Current release verification is in the parent suite verification/ directory. Public-checkpoint/GPU execution remains unverified here.

### 公開checkpointと前処理

```text
model_id: facebook/ijepa_vith14_1k
revision: f157467ea509bc356ff9f61fd3c0d840eec5e04e
```

公式Hugging Faceリポジトリのコミットを固定しています。前処理は同じrevisionの `AutoImageProcessor` から読み込みます。ImageNetのmean/stdを手書きで代用しません。公式processorは224×224へのリサイズとmean/std=0.5を指定しています。

モデルID、解決されたrevision、前処理、dtype、ライブラリバージョンを記録します。ローカルモデルを使う場合は設定・重みファイルのSHA-256も記録します。元のI-JEPA predictorはこのHFエンコーダ経路では読み込みません。

公式モデルのカードには `CC-BY-NC-4.0` の表記があります。モデル重み・データは本ZIPに含めていません。利用時は配布元の条件を確認してください。

## 3. Commands

```bash
bash run_all.sh tests -q
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh smoke --seeds 0 1 2 --resume
bash run_all.sh check --expected-runs 3
bash run_all.sh report

# Real encoder; see the next section for data preparation.
bash run_all.sh real --device cuda --seeds 0 1 2

# No data/weight access or filesystem writes:
bash run_all.sh dry-run --config examples/override.yaml
```

`--tasks` は廃止しました。このリポジトリのテーマだけが実行されます。

設定は `src/ijepa_temporal_ssm/configs/` に同梱し、wheel単体でも利用できます。

`--resume` は完了済み実行のスキップであり、epochの途中再開ではありません。設定・コードが変わった場合は拒否します。

## 4. ③ 時間間隔を考慮したSSM

```bash
bash run_all.sh real --device cuda
```

標準設定は、同じフレーム集合を逆順にしたペアを含む**遅延した循環色順序の合成課題**です。最初・最後のフレームは同一の空背景であり、以前の「最後の色だけで分類できる」設定を除いています。Mean/First/Lastを対照として残しています。

これは時間情報の使用を確認するsanity testであり、実動画認識の性能を証明しません。実動画は、事前にRGBフレームを `uint8 [T,H,W,3]` の `.npy` として保存して、JSONLで指定できます。

```json
{"id":"train_clip_001","group_id":"source_video_001","split":"train","frames":"clips/train_001.npy","label":0}
{"id":"val_clip_001","group_id":"source_video_002","split":"val","frames":"clips/val_001.npy","label":1}
{"id":"test_clip_001","group_id":"source_video_003","split":"test","frames":"clips/test_001.npy","label":0}
```

```bash
bash run_all.sh real --device cuda \
  --set data.dataset=manifest --set data.manifest=/localdata/videos/video_manifest.jsonl \
  --set num_classes=10
```

パスはmanifestの親からの相対パス、または絶対パスです。`group_id` がtrain/val/testを跨ぐ場合は停止します。動画は指定フレーム数以上必要です。現実の不規則timestampを直接読む機能は未実装で、gapは読み込んだ等間隔クリップのフレームindex差です。

`motion_topk` は全クリップの安価な画素差を参照する**オフライン選択**です。因果的なオンラインフレーム選択とは主張しません。SSMの逐次状態更新と、この選択方式は区別してください。

## 5. Repository structure

```text
ijepa_temporal_ssm/
  run_all.sh
  pyproject.toml
  README_JA.md
  .env.example
  src/ijepa_temporal_ssm/
    configs/base.yaml
    configs/experiment.yaml
    cli.py
    storage.py
    encoder.py
    common.py
    temporal.py
    prepare.py
    report.py
    check.py
  tests/
  examples/
  docs/RESEARCH_REVIEW_JA.md
  docs/SOURCES.md
  verification/TEST_REPORT_JA.md
```

共通機能は各リポジトリに同梱しています。元の統合版や親フォルダのPYTHONPATHは不要です。Pythonパッケージ名もすべて異なります。

## 6. 実行と結果解釈の注意

- 同一seedの繰り返しを独立試行として集計しません。1 seedの標準偏差は0ではなくnullです。
- `--set` は既存の設定キーだけを変更でき、タイプミスしたキーはエラーになります。
- キャッシュの更新や大規模データを含め、絶対的な所要時間・GPUメモリ量は未測定です。初回はsubset、encoder batch size 1〜8から開始してください。
- `.pt` を読み込む際は、このパッケージのコードが作った信頼できるファイルを使用してください。ツールの読込は `weights_only=True` を使っています。
- 特定手法が勝つようなハイパーパラメータ探索、テスト結果によるモデル選択は実施していません。
- 本番の論文比較では、checkpoint・パラメータ数・sourceへのアクセス・更新予算・実測時間を揃える必要があります。

### オフライン／社内プロキシ環境

信頼された経路でcheckpoint一式をローカルディレクトリに配置して使用できます。TLS検証の無効化は行いません。

```bash
bash run_all.sh real --device cuda \
  --set encoder.model_id=./models/ijepa_vith14_1k \
  --set encoder.local_files_only=true \
  --set encoder.batch_size=2
```

