#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$REPO_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
export CUBLAS_WORKSPACE_CONFIG="${CUBLAS_WORKSPACE_CONFIG:-:4096:8}"
export PYTHONHASHSEED="${PYTHONHASHSEED:-0}"
export TOKENIZERS_PARALLELISM=false
export IJEPA_WORK_DIR="${IJEPA_WORK_DIR:-$PWD}"
export DATASETS_ROOT="${DATASETS_ROOT:-/localdata}"
export HF_HOME="$IJEPA_WORK_DIR/models/huggingface"
export HF_HUB_CACHE="$HF_HOME/hub"
export HUGGINGFACE_HUB_CACHE="$HF_HUB_CACHE"
export TORCH_HOME="$IJEPA_WORK_DIR/models/torch"
export PIP_CACHE_DIR="$IJEPA_WORK_DIR/cache/pip"
export XDG_CACHE_HOME="$IJEPA_WORK_DIR/cache"
export TORCHINDUCTOR_CACHE_DIR="$IJEPA_WORK_DIR/cache/ijepa_temporal_ssm/torchinductor"
export TRITON_CACHE_DIR="$IJEPA_WORK_DIR/cache/ijepa_temporal_ssm/triton"
PYTHON="${PYTHON:-python}"
MODE="${1:-smoke}"
if [ "$#" -gt 0 ]; then shift; fi
case "$MODE" in
  smoke) exec "$PYTHON" -m ijepa_temporal_ssm.cli --smoke --device cpu "$@" ;;
  real) exec "$PYTHON" -m ijepa_temporal_ssm.cli "$@" ;;
  dry-run) exec "$PYTHON" -m ijepa_temporal_ssm.cli --dry-run "$@" ;;
  tests) mkdir -p "$IJEPA_WORK_DIR/tmp/ijepa_temporal_ssm"
    exec "$PYTHON" -m pytest "$REPO_ROOT/tests" \
    -o "cache_dir=$IJEPA_WORK_DIR/cache/ijepa_temporal_ssm/pytest" \
    --basetemp "$IJEPA_WORK_DIR/tmp/ijepa_temporal_ssm/pytest_$$" "$@" ;;
  prepare) exec "$PYTHON" -m ijepa_temporal_ssm.prepare "$@" ;;
  report) exec "$PYTHON" -m ijepa_temporal_ssm.report "$@" ;;
  check) exec "$PYTHON" -m ijepa_temporal_ssm.check "$@" ;;
  *) echo "Usage: bash run_all.sh {smoke|real|dry-run|tests|prepare|report|check} [options]" >&2; exit 2 ;;
esac
