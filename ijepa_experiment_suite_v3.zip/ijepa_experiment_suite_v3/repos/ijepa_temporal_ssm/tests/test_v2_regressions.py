import numpy as np
import torch
from ijepa_temporal_ssm.temporal import DiagonalSSM, rgb_order_positive_control, TemporalClassifier
from ijepa_temporal_ssm.data import order_video_data


def test_vectorized_final_matches_loop_values_and_gradients():
    m=DiagonalSSM(5,3)
    x=torch.randn(2,13,5,requires_grad=True)
    dt=torch.rand(2,13)+.1
    a=m(x,dt)[0][:,-1]
    ga=torch.autograd.grad(a.square().sum(), [x]+list(m.parameters()),retain_graph=True)
    b=m.final_output(x,dt)
    gb=torch.autograd.grad(b.square().sum(), [x]+list(m.parameters()))
    torch.testing.assert_close(a,b,atol=2e-6,rtol=2e-5)
    for av,bv in zip(ga,gb):
        torch.testing.assert_close(av,bv,atol=5e-6,rtol=1e-4)


def test_generator_rgb_positive_control():
    v,y,_=order_video_data(30,42,32,32)
    np.testing.assert_array_equal(rgb_order_positive_control(v),y)


def test_pair_pool_classifier_runs_backward():
    m=TemporalClassifier(8,2,16,'pair_pool')
    x=torch.randn(4,12,9)
    m(x).square().sum().backward()
    assert all(p.grad is not None for p in m.parameters())


def test_gap_aware_gru_accepts_the_same_time_information():
    m=TemporalClassifier(8,2,16,'gru_gap')
    x=torch.randn(4,12,9); x[...,-1]=2
    m(x).square().sum().backward()
    assert m.gap_embedding.weight.grad is not None
