import numpy as np
import pytest
import torch
from ijepa_temporal_ssm.data import order_video_data
from ijepa_temporal_ssm.temporal import DiagonalSSM, TemporalClassifier, select_frames


def test_ssm_streaming_equivalent():
    model = DiagonalSSM(6, 3)
    x, dt = torch.randn(2, 9, 6), torch.rand(2, 9) + .1
    full, final = model(x, dt)
    state = model.initial_state(2, torch.device('cpu'))
    stream = []
    for t in range(9):
        y, state = model.step(x[:, t], state, dt[:, t])
        stream.append(y)
    torch.testing.assert_close(full, torch.stack(stream, 1))
    torch.testing.assert_close(final, state)


def test_ssm_constant_input_gap_semigroup():
    m = DiagonalSSM(3, 2)
    u = torch.randn(2, 3)
    s = m.initial_state(2, torch.device('cpu'))
    _, once = m.step(u, s, torch.full((2,), 4.0))
    for _ in range(4):
        _, s = m.step(u, s, torch.ones(2))
    torch.testing.assert_close(once, s, atol=1e-6, rtol=1e-5)


def test_ssm_gradients():
    m = DiagonalSSM(4, 3)
    y, _ = m(torch.randn(2, 7, 4), torch.ones(2, 7))
    y.square().mean().backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in m.parameters())


def test_mean_cannot_distinguish_permutation():
    model = TemporalClassifier(8, 2, 16, 'mean').eval()
    x = torch.randn(2, 12, 9)
    x[..., -1] = 1
    torch.testing.assert_close(model(x), model(x.flip(1)), atol=1e-6, rtol=1e-5)


def test_order_pairs_have_identical_frame_multisets():
    videos, labels, groups = order_video_data(3, 0, 8, 32)
    assert np.array_equal(videos[0], videos[1, ::-1])
    assert labels.tolist() == [0, 1, 0, 1, 0, 1]
    assert groups[0] == groups[1]


@pytest.mark.parametrize('policy', ['uniform', 'motion_topk'])
def test_frame_selector_exact_budget(policy):
    v = np.zeros((20, 16, 16, 3), dtype=np.uint8)
    v[10:] = 200
    idx = select_frames(v, 7, policy)
    assert len(idx) == len(set(idx)) == 7
    assert idx[0] == 0 and idx[-1] == 19
    assert np.all(np.diff(idx) > 0)


def test_order_no_endpoint_shortcut():
    videos, labels, groups = order_video_data(6, 0, 16, 32)
    for i in range(0, len(videos), 2):
        np.testing.assert_array_equal(videos[i, 0], videos[i + 1, 0])
        np.testing.assert_array_equal(videos[i, -1], videos[i + 1, -1])

