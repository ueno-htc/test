"""Dataset-only /localdata policy; all generated state defaults to the caller's cwd."""
from __future__ import annotations
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

PROJECT = "ijepa_temporal_ssm"
DEFAULT_ROOT = Path("/localdata")

def absolute_root(value: str | Path | None = None) -> Path:
    raw = str(value if value is not None else os.environ.get("IJEPA_WORK_DIR", Path.cwd()))
    expanded = os.path.expandvars(os.path.expanduser(raw))
    if not expanded or "$" in expanded:
        raise ValueError("Work directory must be a nonempty resolved path")
    return Path(expanded).resolve()

@dataclass(frozen=True)
class Storage:
    root: Path
    data_root: Path

    @classmethod
    def create(cls, value: str | Path | None = None, data_root: str | Path | None = None) -> "Storage":
        raw = str(data_root if data_root is not None else os.environ.get("DATASETS_ROOT", DEFAULT_ROOT))
        expanded = os.path.expandvars(os.path.expanduser(raw))
        if not expanded or "$" in expanded:
            raise ValueError("Dataset root must be a nonempty resolved path")
        return cls(absolute_root(value), Path(expanded).resolve())

    @property
    def datasets(self) -> Path:
        return self.data_root
    @property
    def hf_home(self) -> Path:
        return self.root / "models" / "huggingface"
    @property
    def hub_cache(self) -> Path:
        return self.hf_home / "hub"
    @property
    def torch_home(self) -> Path:
        return self.root / "models" / "torch"
    @property
    def cache(self) -> Path:
        return self.root / "cache" / PROJECT
    @property
    def outputs(self) -> Path:
        return self.root / "outputs" / PROJECT
    @property
    def artifacts(self) -> Path:
        return self.root / "artifacts" / PROJECT
    @property
    def generated(self) -> Path:
        return self.datasets / "synthetic" / PROJECT
    @property
    def temporary(self) -> Path:
        return self.root / "tmp" / PROJECT

    def snapshot(self) -> dict[str, str]:
        return {"project": PROJECT, "root": str(self.root), "work_dir": str(self.root),
                "datasets": str(self.datasets), "hf_home": str(self.hf_home),
                "hub_cache": str(self.hub_cache), "torch_home": str(self.torch_home),
                "cache": str(self.cache), "outputs": str(self.outputs),
                "artifacts": str(self.artifacts), "generated": str(self.generated),
                "temporary": str(self.temporary), "path_policy": "datasets_only_under_data_root_v3"}

    def tokens(self) -> dict[str, str]:
        return {"WORK_ROOT": str(self.root), "DATASETS_ROOT": str(self.datasets),
                "HF_HOME": str(self.hf_home), "HF_HUB_CACHE": str(self.hub_cache),
                "CACHE_ROOT": str(self.cache), "OUTPUT_ROOT": str(self.outputs),
                "ARTIFACTS_ROOT": str(self.artifacts), "GENERATED_ROOT": str(self.generated)}

    def expand(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {k: self.expand(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self.expand(v) for v in value]
        if not isinstance(value, str):
            return value
        result = value
        for token, replacement in self.tokens().items():
            result = result.replace("${" + token + "}", replacement)
        if re.search(r"\$\{[^}]+\}", result):
            raise ValueError(f"Unresolved storage token: {result}")
        return os.path.expanduser(result)

    def configure_environment(self) -> None:
        os.environ.update({"IJEPA_WORK_DIR": str(self.root), "DATASETS_ROOT": str(self.datasets),
                           "HF_HOME": str(self.hf_home), "HF_HUB_CACHE": str(self.hub_cache),
                           "HUGGINGFACE_HUB_CACHE": str(self.hub_cache), "TORCH_HOME": str(self.torch_home),
                           "PIP_CACHE_DIR": str(self.root / "cache" / "pip"),
                           "XDG_CACHE_HOME": str(self.root / "cache"),
                           "TORCHINDUCTOR_CACHE_DIR": str(self.cache / "torchinductor"),
                           "TRITON_CACHE_DIR": str(self.cache / "triton"),
                           "TMPDIR": str(self.temporary)})
        # tempfile may have been imported before environment configuration.
        self.temporary.mkdir(parents=True, exist_ok=True)
        import tempfile
        tempfile.tempdir = str(self.temporary)

def path_under(value: str | Path | None, default: Path, relative_base: Path | None = None) -> Path:
    if value is None:
        return default.resolve()
    path = Path(os.path.expandvars(os.path.expanduser(str(value))))
    return path.resolve() if path.is_absolute() else ((relative_base or default) / path).resolve()

def ensure_writable_directory(path: Path) -> None:
    try:
        path.mkdir(parents=True, exist_ok=True)
        if not os.access(path, os.W_OK):
            raise PermissionError(str(path))
    except OSError as exc:
        raise RuntimeError(f"Cannot write to {path}. Check --work-dir for generated outputs or --data-root for dataset preparation.") from exc
