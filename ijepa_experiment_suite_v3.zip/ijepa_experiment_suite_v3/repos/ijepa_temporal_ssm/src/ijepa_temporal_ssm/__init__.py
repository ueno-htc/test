"""Standalone I-JEPA temporal research MVP."""
__version__ = "0.2.0"
