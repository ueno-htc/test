from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw


def read_manifest(path: str, required: set[str]) -> list[dict]:
    p = Path(path)
    rows = [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
    if not rows:
        raise ValueError("Empty manifest")
    group_splits = {}
    ids = set()
    for row in rows:
        if not required <= row.keys():
            raise ValueError(f"Manifest missing {required - row.keys()}")
        if row["split"] not in {"train", "val", "test"}:
            raise ValueError("Manifest splits must be train/val/test")
        group = str(row["group_id"])
        if group in group_splits and group_splits[group] != row["split"]:
            raise ValueError("Group leakage between train/val/test")
        group_splits[group] = row["split"]
        if row["id"] in ids:
            raise ValueError("Duplicate manifest sample ID")
        ids.add(row["id"])
        row["_root"] = p.parent
    return rows


def order_video_data(n_groups: int, seed: int, frames: int, size: int):
    """Delayed cyclic-color order pairs with identical frame multisets.

    Three color pairs are cycled: red->green, green->blue, blue->red are label 0;
    reversed sequences are label 1. Individual cue colors have balanced marginals
    across a complete three-group cycle. First/last frames are identical blanks,
    so the earlier two-phase last-frame shortcut is explicitly removed.
    """
    if frames < 6:
        raise ValueError("Delayed-order sequences require at least six frames")
    rng = np.random.default_rng(seed)
    videos, labels, groups = [], [], []
    colors = [(230, 60, 65), (50, 220, 70), (50, 85, 230)]
    duration = max(1, frames // 8)
    for group in range(n_groups):
        sequence = []
        bg = tuple(rng.integers(0, 30, 3).tolist())
        cx, cy = rng.integers(size // 3, size * 2 // 3, 2)
        first, second = colors[group % 3], colors[(group + 1) % 3]
        for t in range(frames):
            im = Image.new("RGB", (size, size), bg)
            color = first if 1 <= t < 1 + duration else second if frames - 1 - duration <= t < frames - 1 else None
            if color is not None:
                draw = ImageDraw.Draw(im)
                r = max(3, size // 6)
                draw.ellipse((int(cx-r), int(cy-r), int(cx+r), int(cy+r)), fill=color)
            sequence.append(np.asarray(im))
        video = np.stack(sequence)
        videos.extend([video, video[::-1].copy()])
        labels.extend([0, 1])
        groups.extend([f"{seed}-{group}"] * 2)
    return np.stack(videos), np.asarray(labels), groups


def video_data(cfg: dict) -> dict:
    spec = cfg["data"]
    result = {}
    if spec["dataset"] == "order":
        for k, offset in [("train", 0), ("val", 100000), ("test", 200000)]:
            result[k] = order_video_data(spec[f"n_{k}"] // 2, cfg["seed"] + offset,
                                         spec["frames"], spec["image_size"])
    elif spec["dataset"] == "manifest":
        rows = read_manifest(spec["manifest"], {"frames", "label", "id", "split", "group_id"})
        for split in ["train", "val", "test"]:
            videos, labels, groups = [], [], []
            for row in [r for r in rows if r["split"] == split][:spec[f"n_{split}"]]:
                a = np.load(row["_root"] / row["frames"], allow_pickle=False)
                if a.dtype != np.uint8 or a.ndim != 4 or a.shape[-1] != 3 or len(a) < spec["frames"]:
                    raise ValueError("Video .npy must be uint8 THWC RGB with enough frames")
                idx = np.linspace(0, len(a) - 1, spec["frames"]).round().astype(int)
                size = spec["image_size"]
                videos.append(np.stack([np.asarray(Image.fromarray(a[i]).resize((size, size))) for i in idx]))
                labels.append(int(row["label"]))
                groups.append(str(row["group_id"]))
            if not videos:
                raise ValueError(f"Empty video {split}")
            result[split] = (np.stack(videos), np.asarray(labels), groups)
    else:
        raise ValueError("Unknown video dataset")
    for split, (_, labels, _) in result.items():
        if np.any(labels < 0) or np.any(labels >= cfg["num_classes"]):
            raise ValueError(f"Video labels out of range in {split}")
    return result

