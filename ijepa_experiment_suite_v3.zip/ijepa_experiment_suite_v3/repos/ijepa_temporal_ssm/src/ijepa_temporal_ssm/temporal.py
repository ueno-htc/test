from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .common import (Standardizer, benchmark, classification_metrics, dump_json,
                     parameter_count, predict, save_checkpoint, train_supervised)
from .data import video_data


class DiagonalSSM(nn.Module):
    """Real diagonal stable recurrence with exact ZOH decay for piecewise-constant input.

    This is an original minimal reference, NOT Mamba or an official S4D reproduction.
    State is B x H x S, independent of sequence length at streaming inference.
    """
    def __init__(self, channels: int, state_size: int = 4):
        super().__init__()
        self.log_rates = nn.Parameter(torch.linspace(-4, 0, state_size).repeat(channels, 1))
        self.B = nn.Parameter(torch.ones(channels, state_size) / math.sqrt(state_size))
        self.C = nn.Parameter(torch.randn(channels, state_size) / math.sqrt(state_size))
        self.D = nn.Parameter(torch.ones(channels))
        self.channels, self.state_size = channels, state_size

    def initial_state(self, batch: int, device: torch.device, dtype=torch.float32):
        return torch.zeros(batch, self.channels, self.state_size, device=device, dtype=dtype)

    def step(self, u: torch.Tensor, state: torch.Tensor, delta: torch.Tensor):
        a = torch.exp(-self.log_rates.exp()[None] * delta[:, None, None].clamp_min(1e-4))
        state = a * state + (1 - a) * self.B[None] * u[:, :, None]
        output = (state * self.C[None]).sum(-1) + self.D[None] * u
        return output, state

    def final_output(self, u: torch.Tensor, deltas: torch.Tensor):
        """Exact final ZOH readout without a Python time loop.

        This vectorized batch kernel materializes O(B*T*H*S) working tensors.
        It is NOT claimed to be a constant-memory streaming kernel; use step().
        """
        dt = deltas.clamp_min(1e-4)
        remaining = dt.sum(1, keepdim=True) - dt.cumsum(1)
        rate = self.log_rates.exp()[None, None]
        gain = -torch.expm1(-dt[:, :, None, None] * rate)
        decay = torch.exp(-remaining[:, :, None, None] * rate)
        state = (decay * gain * self.B[None, None] * u[:, :, :, None]).sum(1)
        return (state * self.C[None]).sum(-1) + self.D[None] * u[:, -1]

    def forward(self, u: torch.Tensor, deltas: torch.Tensor):
        state = self.initial_state(len(u), u.device, u.dtype)
        outputs = []
        for i in range(u.shape[1]):
            y, state = self.step(u[:, i], state, deltas[:, i])
            outputs.append(y)
        return torch.stack(outputs, dim=1), state


class TemporalClassifier(nn.Module):
    def __init__(self, input_dim: int, classes: int, hidden: int, kind: str):
        super().__init__()
        self.kind = kind
        self.project = nn.Sequential(nn.Linear(input_dim, hidden), nn.LayerNorm(hidden), nn.GELU())
        if kind in {"ssm", "gap_ssm"}:
            self.core = DiagonalSSM(hidden)
        elif kind in {"gru", "gru_gap"}:
            if kind == "gru_gap":
                self.gap_embedding = nn.Linear(1, hidden, bias=False)
            self.core = nn.GRU(hidden, hidden, batch_first=True)
        elif kind == "transformer":
            layer = nn.TransformerEncoderLayer(hidden, 4, hidden * 2, dropout=0, batch_first=True)
            self.core = nn.TransformerEncoder(layer, 1, enable_nested_tensor=False)
        elif kind not in {"mean", "first", "last", "pair_pool"}:
            raise ValueError(kind)
        self.head = nn.Sequential(nn.Linear(hidden * (4 if kind == "pair_pool" else 1), hidden), nn.GELU(), nn.Linear(hidden, classes))

    def forward(self, x: torch.Tensor):
        # Last channel is an explicit time gap and is never feature-standardized.
        features, gaps = x[..., :-1], x[..., -1]
        u = self.project(features)
        if self.kind == "mean":
            h = u.mean(1)
        elif self.kind == "first":
            h = u[:, 0]
        elif self.kind == "last":
            h = u[:, -1]
        elif self.kind == "pair_pool":
            midpoint = max(1, u.shape[1] // 2)
            a, b = u[:, :midpoint].mean(1), u[:, midpoint:].mean(1)
            h = torch.cat([a, b, b-a, a*b], -1)
        elif self.kind in {"gru", "gru_gap"}:
            if self.kind == "gru_gap":
                u = u + self.gap_embedding(torch.log1p(gaps.clamp_min(0))[..., None])
            h = self.core(u)[0][:, -1]
        elif self.kind == "transformer":
            times = gaps.cumsum(1)
            freq = torch.exp(torch.arange(0, u.shape[-1], 2, device=u.device) * (-math.log(10000) / u.shape[-1]))
            pos = torch.zeros_like(u)
            pos[..., 0::2] = torch.sin(times[..., None] * freq)
            pos[..., 1::2] = torch.cos(times[..., None] * freq)
            h = self.core(u + pos).mean(1)
        else:
            delta = gaps if self.kind == "gap_ssm" else torch.ones_like(gaps)
            h = self.core.final_output(u, delta)
        return self.head(h)


def select_frames(video: np.ndarray, count: int, policy: str) -> np.ndarray:
    total = len(video)
    if not 2 <= count <= total:
        raise ValueError("Frame budget must satisfy 2 <= budget <= clip length")
    if policy == "uniform" or count == total:
        return np.linspace(0, total - 1, count).round().astype(np.int64)
    if policy == "motion_topk":
        # Offline cheap-pixel selector. Accesses the whole clip, NOT a causal online policy.
        stride = max(1, video.shape[1] // 16)
        small = video[:, ::stride, ::stride].astype(np.float32)
        scores = np.abs(np.diff(small, axis=0)).mean((1, 2, 3))
        interior = np.arange(1, total - 1)
        order = np.argsort(-scores[interior - 1], kind="stable")
        return np.sort(np.r_[0, interior[order[:count - 2]], total - 1]).astype(np.int64)
    raise ValueError(policy)


def encoded_video_features(videos: np.ndarray, count: int, policy: str, cache, grid: int):
    indices = np.stack([select_frames(v, count, policy) for v in videos])
    chosen = np.stack([v[idx] for v, idx in zip(videos, indices)])
    n, t, h, w, c = chosen.shape
    z = cache.get(chosen.reshape(n * t, h, w, c), grid=grid).reshape(n, t, -1)
    # Unit is one frame of the source clip. First selected observation has duration 1.
    gaps = np.concatenate([np.ones((n, 1)), np.diff(indices, axis=1)], axis=1).astype(np.float32)
    return z, torch.from_numpy(gaps), indices


def rgb_order_positive_control(videos: np.ndarray) -> np.ndarray:
    """Generator-specific known-palette order rule, NOT learned general video understanding.

    Subtract the blank first frame; the source generator defines red->green->blue
    as positive cyclic order. This uses no target labels or simulator states.
    """
    rgb = videos.astype(np.float32).mean((2, 3))
    delta = rgb - rgb[:, :1]
    middle = videos.shape[1] // 2
    a, b = delta[:, :middle].mean(1), delta[:, middle:].mean(1)
    score = (a[:,0]*b[:,1] + a[:,1]*b[:,2] + a[:,2]*b[:,0]
             -a[:,1]*b[:,0] - a[:,2]*b[:,1] - a[:,0]*b[:,2])
    return (score < 0).astype(np.int64)


def run(cfg: dict, encoder, cache, out: Path, device: torch.device) -> dict:
    data = video_data(cfg)
    grid = cfg["temporal"]["spatial_pool_grid"]
    prepared = {}
    results = []
    if cfg["data"]["dataset"] == "order":
        control = {split: float(np.mean(rgb_order_positive_control(item[0]) == item[1]))
                   for split, item in data.items()}
        dump_json(out / "rgb_positive_control.json", {
            "accuracy": control, "kind": "known_generator_rule_not_learned", 
            "purpose": "verify_task_solvability_without_IJEPA"})
    for spec in cfg["temporal"]["experiments"]:
        kind, policy, budget = spec["kind"], spec["policy"], spec["frames"]
        key = (policy, budget)
        if key not in prepared:
            raw = {s: encoded_video_features(data[s][0], budget, policy, cache, grid)
                   for s in ["train", "val", "test"]}
            scaler = Standardizer().fit(raw["train"][0])
            prepared[key] = (scaler, {s: torch.cat([scaler.transform(z), gaps[..., None]], -1)
                                    for s, (z, gaps, _) in raw.items()})
            dump_json(out / f"selected_indices_{policy}_{budget}.json",
                      {s: a[2] for s, a in raw.items()})
        scaler, features = prepared[key]
        # Reinitialization is deterministic per comparison, not dependent on loop history.
        torch.manual_seed(cfg["seed"])
        model = TemporalClassifier(features["train"].shape[-1] - 1, cfg["num_classes"],
                                   cfg["temporal"]["hidden"], kind)
        labels = {s: torch.tensor(data[s][1], dtype=torch.long) for s in data}
        history = train_supervised(model, features["train"], labels["train"], features["val"],
                                   labels["val"], device=device, seed=cfg["seed"], **cfg["train"])
        scores = classification_metrics(predict(model, features["test"], device), labels["test"])
        sample = features["test"][:1].to(device)
        prof = benchmark(lambda: model(sample), device, **cfg["profile"], scope="temporal_head_only")
        scaling = []
        for length in cfg["temporal"]["profile_lengths"]:
            repeated = sample.repeat(1, math.ceil(length / sample.shape[1]), 1)[:, :length]
            scaling.append({"frames": length, **benchmark(lambda: model(repeated), device,
                            **cfg["profile"], scope="head_only_repeated_features_not_accuracy_test")})
        # Measured E2E includes pixel selection, preprocessing, encoder, normalization, and head.
        video = data["test"][0][0]
        def e2e():
            idx = select_frames(video, budget, policy)
            chosen = video[idx]
            z = torch.cat([encoder.encode(chosen[i:i + cache.batch_size], grid=grid)
                           for i in range(0, len(chosen), cache.batch_size)])
            gaps = torch.tensor(np.r_[1, np.diff(idx)], dtype=torch.float32)
            inp = torch.cat([scaler.transform(z), gaps[:, None]], -1)[None].to(device)
            return model(inp)
        e2e_profile = benchmark(e2e, device, warmup=1, repeats=cfg["temporal"]["e2e_repeats"],
                                scope="raw_RGB_clip_to_logits_includes_frozen_encoder")
        name = f"{kind}_{policy}_{budget}"
        dump_json(out / f"{name}_training.json", history)
        save_checkpoint(out / f"{name}.pt", model, model_spec=spec, standardizer=scaler.state(),
                        encoder=encoder.provenance)
        results.append({"name": name, "test": scores, "parameters": parameter_count(model),
                        "encoded_frames_per_clip": budget, "selector": policy,
                        "ssm_kernel": "vectorized_final_ZOH_nonstreaming" if "ssm" in kind else None,
                        "training_final_loss": history["history"][-1]["train_loss"],
                        "selector_causal": policy == "uniform", "head_profile": prof,
                        "end_to_end_profile": e2e_profile, "length_latency": scaling})
    if cfg["temporal"].get("overfit_diagnostic", False):
        scaler, f = next(iter(prepared.values()))
        # Training-only control. The same examples are deliberately used for model
        # selection; this number must never be reported as held-out accuracy.
        n = min(24, len(f["train"]))
        lab = torch.tensor(data["train"][1][:n]).long()
        torch.manual_seed(cfg["seed"])
        probe = TemporalClassifier(f["train"].shape[-1]-1, cfg["num_classes"], cfg["temporal"]["hidden"], "pair_pool")
        hist = train_supervised(probe, f["train"][:n], lab, f["train"][:n], lab,
               device=device, epochs=80 if not cfg.get("smoke") else 8,
               batch_size=n, lr=.003, seed=cfg["seed"])
        dump_json(out / "overfit_control.json", {
            "n_training_examples": n, "evaluation_split": "TRAINING_ONLY_NOT_GENERALIZATION",
            "metrics": classification_metrics(predict(probe, f["train"][:n], device), lab), "history": hist})
    dump_json(out / "group_ids.json", {s: a[2] for s, a in data.items()})
    return {"theme": "03_gap_aware_temporal_ssm", "dataset": cfg["data"]["dataset"],
            "claim_scope": "small temporal pilot; diagonal SSM is not optimized Mamba/S4D",
            "paired_order_task_is_sanity_test_not_action_recognition_benchmark": cfg["data"]["dataset"] == "order",
            "records": results}
