import json
import torch
from ijepa_tta.tta import balanced_anchor_indices, calibrate
from ijepa_tta.common import save_checkpoint


def test_class_order_does_not_poison_anchor_selection():
    y = torch.arange(10).repeat_interleave(40)
    idx = balanced_anchor_indices(y, 64, 0)
    counts = torch.bincount(y[idx], minlength=10)
    assert len(idx.unique()) == 64
    assert counts.min() == 6 and counts.max() == 7


def test_mixed_batch_calibration_avoids_class_mean_confound():
    x = torch.cat([torch.full((80,4), -5.),torch.full((80,4),5.)])
    h = torch.nn.Linear(4,2)
    c = calibrate(h,x,torch.device('cpu'),16,seed=0,draws=128)
    assert c['legacy_storage_order_threshold_DIAGNOSTIC'] == 25
    assert c['drift_threshold'] < 8


def test_model_metadata_does_not_save_weights(tmp_path):
    path=tmp_path/'model.pt'
    save_checkpoint(path, torch.nn.Linear(3,2))
    assert not path.exists()
    obj=json.loads(path.with_suffix('.model_log.json').read_text())
    assert obj['weights_saved'] is False
    assert 'weight' not in obj
