import inspect
import numpy as np
import pytest
import torch
from torch import nn
from ijepa_tta.common import Standardizer, classification_metrics, dump_json, paired_bootstrap, split_indices, train_supervised
from ijepa_tta.data import stratified_take, cifar_c_block
from ijepa_tta.encoder import FeatureCache, MockEncoder, make_encoder
from ijepa_tta.tta import AffineAdapter, UpdateBudget, adapt_stream


def test_standardizer_train_only():
    train = torch.tensor([[1., 3.], [3., 3.]])
    scaler = Standardizer().fit(train)
    before = scaler.mean.clone()
    assert torch.isfinite(scaler.transform(torch.tensor([[100., -200.]]))).all()
    torch.testing.assert_close(scaler.mean, before)
    assert scaler.transform(train).mean().abs() < 1e-5


def test_metrics_perfect():
    metrics = classification_metrics(torch.eye(3) * 50, torch.arange(3))
    assert metrics['accuracy'] == 1
    assert metrics['nll'] < 1e-5


def test_split_disjoint():
    a, b = split_indices(100, .2, 42)
    assert not set(a) & set(b)
    assert len(a) + len(b) == 100


def test_stratified_take_balanced():
    y = np.repeat(np.arange(4), 20)
    idx = stratified_take(y, 32, 5)
    assert len(set(idx)) == 32
    assert (np.bincount(y[idx]) == 8).all()


def test_stratified_take_uneven():
    y = np.array([0] * 2 + [1] * 10 + [2] * 8)
    idx = stratified_take(y, 17, 5)
    assert len(set(idx)) == 17
    assert len(idx) == 17


def test_json_rejects_nan(tmp_path):
    with pytest.raises(ValueError):
        dump_json(tmp_path / 'bad.json', {'v': float('nan')})


def test_cache_content_addressed(tmp_path):
    enc = MockEncoder(torch.device('cpu'))
    cache = FeatureCache(tmp_path, enc, 3)
    a = np.full((4, 32, 32, 3), 100, dtype=np.uint8)
    first = cache.get(a)
    second = cache.get(a)
    torch.testing.assert_close(first, second)
    assert cache.events[-1]['cache_hit']
    a[0, 0, 0, 0] = 101
    cache.get(a)
    assert not cache.events[-1]['cache_hit']
    assert len(list(tmp_path.glob('*.npz'))) == 2


def test_spatial_cache_shape(tmp_path):
    encoder = MockEncoder(torch.device('cpu'))
    cache = FeatureCache(tmp_path, encoder)
    a = np.ones((2, 32, 32, 3), dtype=np.uint8)
    assert cache.get(a, 4, True).shape == (2, 32, 4, 4)
    assert cache.get(a, 2, False).shape == (2, 128)


def test_mock_cannot_masquerade_as_real():
    with pytest.raises(ValueError):
        make_encoder({'smoke': False, 'encoder': {'backend': 'mock'}}, torch.device('cpu'))


def test_cifar_c_requires_official_files(tmp_path):
    with pytest.raises(FileNotFoundError):
        cifar_c_block(tmp_path, 'brightness', 3, np.array([0]), np.array([0]))


@pytest.mark.parametrize('cap', [0, 1, 5, 30])
def test_hard_budget(cap):
    b = UpdateBudget(cap, 10)
    for i in range(10):
        if b.available(i):
            b.consume()
    assert b.used <= cap
    assert b.used <= 10


def test_affine_does_not_unfreeze_head():
    adapter = AffineAdapter(nn.Linear(4, 3))
    assert not any(p.requires_grad for p in adapter.head.parameters())
    assert adapter.log_scale.requires_grad


def test_adaptation_interface_has_no_target_labels():
    signature = inspect.signature(adapt_stream)
    assert all('label' not in p for p in signature.parameters)


def tta_call(method, cap):
    torch.manual_seed(10)
    head = nn.Linear(4, 3)
    x = torch.randn(20, 4)
    before = head(x[:5]).detach()
    result = adapt_stream(head, x, method=method, max_updates=cap,
                          calibration={'entropy_threshold': 20, 'drift_threshold': -1},
                          anchor_x=x[:4], device=torch.device('cpu'), batch_size=5,
                          lr=.05, anchor_weight=1, seed=0)
    return head, x, before, result


def test_predict_before_adapt():
    head, x, before, (logits, adapted, trace) = tta_call('periodic', 4)
    torch.testing.assert_close(logits[:5], before)
    assert sum(t['updated'] for t in trace) == 4
    assert not torch.equal(adapted.log_scale, torch.zeros_like(adapted.log_scale))
    torch.testing.assert_close(head(x[:5]).detach(), before)


def test_zero_budget_exact_source():
    head, x, _, (logits, _, trace) = tta_call('drift_gate', 0)
    torch.testing.assert_close(logits, head(x).detach())
    assert not any(t['updated'] for t in trace)


def test_bootstrap_paired_constant():
    result = paired_bootstrap(np.full(8, 2.0), 1, 20)
    assert result['mean'] == result['ci95_low'] == result['ci95_high'] == 2


def test_train_selects_on_validation():
    model = nn.Linear(3, 2)
    x, y = torch.randn(12, 3), torch.arange(12) % 2
    history = train_supervised(model, x[:8], y[:8], x[8:], y[8:],
                                device=torch.device('cpu'), epochs=2, batch_size=4, lr=.01, seed=0)
    assert len(history['history']) == 2
    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters())

