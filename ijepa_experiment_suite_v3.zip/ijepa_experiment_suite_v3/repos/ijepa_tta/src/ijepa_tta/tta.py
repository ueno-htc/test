from __future__ import annotations

import copy
import math
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .common import (Standardizer, classification_metrics, dump_json, parameter_count,
                     predict, save_checkpoint, sync, train_supervised, dump_jsonl)
from .data import classification_data, cifar_c_block, corrupt_pixels


class AffineAdapter(nn.Module):
    def __init__(self, source_head: nn.Linear):
        super().__init__()
        self.head = copy.deepcopy(source_head).requires_grad_(False)
        self.log_scale = nn.Parameter(torch.zeros(source_head.in_features))
        self.bias = nn.Parameter(torch.zeros(source_head.in_features))

    def forward(self, x):
        return self.head(x * self.log_scale.exp() + self.bias)

    @torch.no_grad()
    def project(self, radius: float = .2):
        self.log_scale.clamp_(-radius, radius)
        self.bias.clamp_(-radius, radius)


def entropy(logits: torch.Tensor) -> torch.Tensor:
    return -(logits.softmax(-1) * logits.log_softmax(-1)).sum(-1)


class UpdateBudget:
    """Hard step cap and causal token release. No test labels or future features used."""
    def __init__(self, maximum: int, batches: int):
        self.maximum = maximum
        self.batches = batches
        self.used = 0
        if maximum < 0 or batches < 1:
            raise ValueError("Invalid update budget")

    def available(self, batch_index: int) -> bool:
        released = math.ceil((batch_index + 1) * self.maximum / self.batches)
        return self.used < min(self.maximum, released)

    def consume(self):
        if self.used >= self.maximum:
            raise RuntimeError("Hard update budget exceeded")
        self.used += 1


def balanced_anchor_indices(labels: torch.Tensor, count: int, seed: int) -> torch.Tensor:
    """Source labels only; avoid taking class-ordered x[:64]."""
    rng = np.random.default_rng(seed)
    ys = labels.cpu().numpy()
    groups = [rng.permutation(np.flatnonzero(ys == c)).tolist() for c in np.unique(ys)]
    chosen = []
    while len(chosen) < min(count, len(ys)):
        for group in groups:
            if group and len(chosen) < min(count, len(ys)):
                chosen.append(group.pop())
    return torch.tensor(rng.permutation(chosen), dtype=torch.long)


def calibrate(head: nn.Module, val_features: torch.Tensor, device: torch.device,
              batch_size: int, seed: int = 0, draws: int = 128) -> dict:
    """Mix source-validation classes before estimating a batch-level drift threshold.

    v1 split storage was class-sorted, whereas target batches were class-mixed.
    The reference and target batch composition must follow the same protocol.
    """
    with torch.no_grad():
        e = entropy(predict(head, val_features, device))
    rng = np.random.default_rng(seed)
    count = min(batch_size, len(val_features))
    mixed = [float(val_features[rng.choice(len(val_features), count, replace=False)]
                   .mean(0).square().mean()) for _ in range(draws)]
    old = [float(a.mean(0).square().mean()) for a in val_features.split(batch_size)]
    return {"entropy_threshold": float(torch.quantile(e, .8)),
            "drift_threshold": float(np.quantile(mixed, .9)),
            "legacy_storage_order_threshold_DIAGNOSTIC": float(np.quantile(old, .9)),
            "batch_calibration": "random_mixed_source_validation_batches",
            "calibration_draws": draws, "batch_size": count,
            "fitted_on": "source_validation_only"}


def adapt_stream(source_head: nn.Linear, features: torch.Tensor, *, method: str,
                 max_updates: int, calibration: dict, anchor_x: torch.Tensor,
                 device: torch.device, batch_size: int, lr: float, anchor_weight: float,
                 seed: int, optimizer_name: str = "sgd", radius: float = .2) -> tuple[torch.Tensor, AffineAdapter, list[dict]]:
    """Prequential predict-then-adapt. Deliberately does not accept target labels.

    Entropy+KL with bounded post-encoder affine parameters is an MVP baseline, NOT
    the original TENT, EATA, or SAR algorithm. All policies use identical losses.
    """
    model = AffineAdapter(source_head).to(device).eval()
    if optimizer_name not in {"sgd", "adam"}:
        raise ValueError("optimizer_name must be sgd or adam")
    optim_cls = torch.optim.SGD if optimizer_name == "sgd" else torch.optim.Adam
    optimizer = optim_cls([model.log_scale, model.bias], lr=lr)
    n_batches = math.ceil(len(features) / batch_size)
    budget = UpdateBudget(max_updates, n_batches)
    rng = np.random.default_rng(seed)
    anchor_x = anchor_x.to(device)
    with torch.no_grad():
        anchor_prob = source_head(anchor_x).softmax(-1)
    predictions, trace = [], []
    for step, a in enumerate(features.split(batch_size)):
        a = a.to(device)
        sync(device)
        start = time.perf_counter()
        with torch.no_grad():
            before = model(a)
            e = entropy(before)
            reliable = e <= calibration["entropy_threshold"]
            drift = float(a.mean(0).square().mean())
            mean_entropy = float(e.mean())
        # This is the scored prediction. The update below cannot change it.
        predictions.append(before.cpu().clone())
        reliable_count = int(reliable.sum())
        trigger = method not in {"frozen"}
        if method == "random":
            trigger = rng.uniform() < .5
        elif method == "entropy_gate":
            trigger = reliable_count > 0 and mean_entropy > .5 * calibration["entropy_threshold"]
        elif method.startswith("drift_gate"):
            trigger = drift > calibration["drift_threshold"] and reliable_count > 0
        elif method not in {"frozen", "periodic"}:
            raise ValueError(f"Unknown adaptation policy {method}")
        updated = False
        update_ms = 0.0
        raw_grad_norm = step_norm = logit_change = changed_fraction = None
        entropy_loss = anchor_loss = None
        if trigger and reliable_count > 0 and budget.available(step):
            sync(device)
            update_start = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            loss = entropy(model(a[reliable])).mean()
            entropy_loss = float(loss.detach())
            previous_params = torch.cat([model.log_scale.detach().clone(), model.bias.detach().clone()])
            weight = 0.0 if method == "drift_gate_no_anchor" else anchor_weight
            if weight:
                kl = F.kl_div(model(anchor_x).log_softmax(-1), anchor_prob, reduction="batchmean")
                anchor_loss = float(kl.detach())
                loss = loss + weight * kl
            if not torch.isfinite(loss):
                raise FloatingPointError("TTA loss is not finite")
            loss.backward()
            raw_grad_norm = float(nn.utils.clip_grad_norm_([model.log_scale, model.bias], 1.0))
            optimizer.step()
            model.project(radius)
            with torch.no_grad():
                after = model(a)
                logit_change = float((after - before).abs().mean())
                changed_fraction = float((after.argmax(-1) != before.argmax(-1)).float().mean())
                current_params = torch.cat([model.log_scale.detach(), model.bias.detach()])
                step_norm = float((current_params - previous_params).norm())
            budget.consume()
            updated = True
            sync(device)
            update_ms = (time.perf_counter() - update_start) * 1000
        sync(device)
        trace.append({"batch": step, "n": len(a), "updated": updated,
                      "updates_so_far": budget.used, "reliable_samples": reliable_count,
                      "drift_score": drift, "mean_entropy": mean_entropy,
                      "update_ms": update_ms, "optimizer": optimizer_name,
                      "raw_gradient_norm": raw_grad_norm, "parameter_step_l2": step_norm,
                      "same_batch_mean_abs_logit_change_DIAGNOSTIC": logit_change,
                      "same_batch_prediction_flip_fraction_DIAGNOSTIC": changed_fraction,
                      "entropy_loss": entropy_loss, "source_anchor_kl": anchor_loss,
                      "first_update_in_run": updated and budget.used == 1,
                      "online_head_wall_ms": (time.perf_counter() - start) * 1000})
    return torch.cat(predictions), model, trace


def run(cfg: dict, encoder, cache, out: Path, device: torch.device) -> dict:
    data = classification_data(cfg)
    train_images, train_labels, train_ids = data["train"]
    val_images, val_labels, val_ids = data["val"]
    test_images, test_labels, test_ids = data["test"]
    raw_train, raw_val, raw_test = [cache.get(x) for x in [train_images, val_images, test_images]]
    scaler = Standardizer().fit(raw_train)
    x, vx, clean = [scaler.transform(a) for a in [raw_train, raw_val, raw_test]]
    y, vy, ty = [torch.tensor(a, dtype=torch.long) for a in [train_labels, val_labels, test_labels]]
    source = nn.Linear(x.shape[-1], cfg["num_classes"]).to(device)
    history = train_supervised(source, x, y, vx, vy, device=device, **cfg["train"], seed=cfg["seed"])
    clean_baseline = classification_metrics(predict(source, clean, device), ty)
    calibration = calibrate(source, vx, device, cfg["tta"]["batch_size"], cfg["seed"])
    anchor_idx = balanced_anchor_indices(y, min(64, len(y)), cfg["seed"])
    dump_json(out / "anchor_sampling.json", {
        "source_ids": train_ids[anchor_idx.numpy()],
        "class_counts": torch.bincount(y[anchor_idx], minlength=cfg["num_classes"]),
        "selection": "source_label_balanced_round_robin_not_first64"})
    dump_json(out / "source_training.json", history)
    dump_json(out / "source_calibration.json", calibration)
    dump_json(out / "split_ids.json", {"train": train_ids, "val": val_ids, "test": test_ids})
    save_checkpoint(out / "source.pt", source, standardizer=scaler.state(), encoder=encoder.provenance)
    blocks = [("clean_start", clean, ty)]
    for name in cfg["tta"]["corruptions"]:
        for severity in cfg["tta"]["severities"]:
            if cfg.get("smoke"):
                corrupted = corrupt_pixels(test_images, name, severity, cfg["seed"] + severity)
                labels = test_labels
            else:
                corrupted, labels = cifar_c_block(Path(cfg["data"]["corruption_root"]), name,
                                                  severity, test_ids, test_labels)
            blocks.append((f"{name}_s{severity}", scaler.transform(cache.get(corrupted)), torch.tensor(labels)))
    blocks.append(("clean_return", clean, ty))
    stream = torch.cat([b[1] for b in blocks])
    targets = torch.cat([b[2] for b in blocks])
    records = []
    for cap in cfg["tta"]["update_budgets"]:
        for method in cfg["tta"]["methods"]:
            # Identical source weights, order, source anchors, release schedule, and update loss.
            pred, adapted, trace = adapt_stream(
                source, stream, method=method, max_updates=cap, calibration=calibration,
                anchor_x=x[anchor_idx], device=device, batch_size=cfg["tta"]["batch_size"],
                lr=cfg["tta"]["lr"], anchor_weight=cfg["tta"]["anchor_weight"], seed=cfg["seed"],
                optimizer_name=cfg["tta"].get("optimizer", "sgd"), radius=cfg["tta"].get("radius", .2))
            metrics = classification_metrics(pred, targets)
            per_domain, offset = {}, 0
            for name, features, labels in blocks:
                per_domain[name] = classification_metrics(pred[offset:offset + len(features)], labels)
                offset += len(features)
            post = classification_metrics(predict(adapted, clean, device), ty)
            record = {"method": method, "hard_update_cap": cap, "actual_updates": sum(t["updated"] for t in trace),
                      "prequential": metrics, "per_domain": per_domain, "post_stream_clean": post,
                      "clean_retention_delta": post["accuracy"] - clean_baseline["accuracy"],
                      "adaptation_ms": sum(t["update_ms"] for t in trace),
                      "online_head_ms": sum(t["online_head_wall_ms"] for t in trace),
                      "trainable_parameters": parameter_count(adapted, True),
                      "encoder_time_excluded_from_online_head_ms": True,
                      "optimizer": cfg["tta"].get("optimizer", "sgd"),
                      "update_timing_includes_first_use_and_diagnostics": True,
                      "corruption_macro_accuracy": float(np.mean([v["accuracy"] for k, v in per_domain.items() if not k.startswith("clean")])),
                      "first_update_ms": next((t["update_ms"] for t in trace if t["updated"]), None),
                      "steady_update_ms_sum": sum(t["update_ms"] for t in trace if t["updated"] and not t["first_update_in_run"])}
            records.append(record)
            stem = f"{method}_budget{cap}"
            dump_json(out / f"{stem}_trace.json", trace)
            probabilities = pred.softmax(-1)
            domain_ids = [name for name, f, _ in blocks for _ in range(len(f))]
            base_ids = np.tile(test_ids, len(blocks))
            dump_jsonl(out / f"{stem}_predictions.jsonl.gz", (
                {"base_image_id": int(base_ids[i]), "domain": domain_ids[i],
                 "target": int(targets[i]), "predicted": int(pred[i].argmax()),
                 "confidence": float(probabilities[i].max()),
                 "p_true": float(probabilities[i, targets[i]])} for i in range(len(pred))))
            save_checkpoint(out / f"{stem}.pt", adapted, standardizer=scaler.state(), encoder=encoder.provenance)
    return {"theme": "01_budgeted_tta", "dataset": data["dataset"], "clean_source": clean_baseline,
            "protocol": "predict_then_adapt; continuous stream; source-statistics-assisted; no target-label access",
            "budget_unit": "gradient steps, not hard wall-clock deadline",
            "repeated_base_images_across_corruption_blocks": True,
            "baseline_scope": "post-encoder affine entropy baselines; NOT official TENT/EATA/SAR reproductions",
            "records": records}
