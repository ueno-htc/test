"""Standalone I-JEPA tta research MVP."""
__version__ = "0.2.0"
