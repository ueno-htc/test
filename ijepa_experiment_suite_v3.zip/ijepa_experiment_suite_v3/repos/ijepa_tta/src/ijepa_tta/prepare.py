"""Explicit dataset preparation. Large CIFAR-C downloads are opt-in and MD5-checked."""
import argparse
import hashlib
import tarfile
import urllib.request
from pathlib import Path
from .storage import Storage, path_under, ensure_writable_directory


def safe_extract(archive: Path, root: Path):
    root.mkdir(parents=True, exist_ok=True)
    base = root.resolve()
    with tarfile.open(archive) as tar:
        members = tar.getmembers()
        for member in members:
            path = (base / member.name).resolve()
            if base not in path.parents and path != base:
                raise ValueError("Unsafe archive traversal")
            if not (member.isfile() or member.isdir()):
                raise ValueError("Refusing links/devices in dataset archive")
        # Python 3.10-compatible validated extraction; only ordinary files/directories.
        for member in members:
            tar.extract(member, base)


def md5(path):
    h = hashlib.md5()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["cifar10", "cifar100"], default="cifar10")
    p.add_argument("--work-dir", type=Path)
    p.add_argument("--data-root", type=Path)
    p.add_argument("--root", type=Path)
    p.add_argument("--cifar10-c", action="store_true", help="Opt in to the approximately 2.9 GB official archive")
    a = p.parse_args(argv)
    storage = Storage.create(a.work_dir, a.data_root)
    storage.configure_environment()
    a.root = path_under(a.root, storage.datasets)
    ensure_writable_directory(a.root)
    from torchvision.datasets import CIFAR10, CIFAR100
    cls = CIFAR10 if a.dataset == "cifar10" else CIFAR100
    for train in [True, False]:
        cls(str(a.root), train=train, download=True)
    if a.cifar10_c:
        if a.dataset != "cifar10":
            p.error("--cifar10-c is only valid with --dataset cifar10")
        archive = a.root / "CIFAR-10-C.tar"
        expected = "56bf5dcef84df0e2308c6dcbcbbd8499"
        if not archive.exists():
            temporary = archive.with_suffix(".partial")
            urllib.request.urlretrieve("https://zenodo.org/records/2535967/files/CIFAR-10-C.tar?download=1", temporary)
            temporary.replace(archive)
        if md5(archive) != expected:
            raise ValueError(f"Checksum failed: {archive}. Delete the invalid archive and retry.")
        safe_extract(archive, a.root)
    print("Dataset preparation completed; existing valid data were retained.")


if __name__ == "__main__":
    main()
