from __future__ import annotations
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from .common import split_indices


def stratified_take(labels: np.ndarray, n: int, seed: int) -> np.ndarray:
    if n <= 0 or n >= len(labels):
        return np.arange(len(labels))
    classes = np.unique(labels)
    if n < len(classes):
        raise ValueError("Requested subset is smaller than the class count")
    rng = np.random.default_rng(seed)
    groups = [rng.permutation(np.flatnonzero(labels == c)) for c in classes]
    out = []
    positions = [0] * len(groups)
    while len(out) < n:
        for cid, group in enumerate(groups):
            if positions[cid] < len(group):
                out.append(group[positions[cid]])
                positions[cid] += 1
                if len(out) == n:
                    break
    return np.asarray(out, dtype=np.int64)


def classification_toy(n: int, seed: int, classes: int = 4, size: int = 32):
    rng = np.random.default_rng(seed)
    labels = np.arange(n) % classes
    rng.shuffle(labels)
    images = []
    colors = [(220, 70, 50), (50, 210, 80), (65, 85, 225), (210, 190, 50)]
    for label in labels:
        im = Image.new("RGB", (size, size), tuple(rng.integers(0, 45, 3).tolist()))
        draw = ImageDraw.Draw(im)
        x, y = rng.integers(2, size // 3, 2)
        r = int(rng.integers(size // 3, size // 2))
        draw.rectangle((int(x), int(y), int(x + r), int(y + r)), fill=colors[int(label)])
        image = np.asarray(im).astype(np.float32)
        images.append(np.clip(image + rng.normal(0, 5, image.shape), 0, 255).astype(np.uint8))
    return np.stack(images), labels.astype(np.int64)


def classification_data(cfg: dict) -> dict:
    spec = cfg["data"]
    seed = cfg["seed"]
    if cfg.get("smoke"):
        images, labels = classification_toy(spec["max_train"], seed, cfg["num_classes"])
        tests, test_labels = classification_toy(spec["max_test"], seed + 10000, cfg["num_classes"])
        all_ids = np.arange(len(images))
        test_ids = np.arange(len(tests))
        dataset = "SMOKE_SHAPES_NOT_CIFAR"
    else:
        try:
            from torchvision.datasets import CIFAR10, CIFAR100
        except ImportError as exc:
            raise RuntimeError("Install torchvision for real CIFAR experiments") from exc
        dataset = spec["dataset"].lower()
        if dataset not in {"cifar10", "cifar100"}:
            raise ValueError("Classification dataset must be cifar10 or cifar100")
        cls = CIFAR10 if dataset == "cifar10" else CIFAR100
        raw = cls(spec["root"], train=True, download=spec.get("download", False))
        test = cls(spec["root"], train=False, download=spec.get("download", False))
        all_labels = np.asarray(raw.targets, dtype=np.int64)
        all_test_labels = np.asarray(test.targets, dtype=np.int64)
        all_ids = stratified_take(all_labels, spec["max_train"], seed)
        test_ids = stratified_take(all_test_labels, spec["max_test"], seed + 1)
        images, labels = raw.data[all_ids], all_labels[all_ids]
        tests, test_labels = test.data[test_ids], all_test_labels[test_ids]
        expected = 10 if dataset == "cifar10" else 100
        if cfg["num_classes"] != expected:
            raise ValueError(f"Set num_classes={expected} for {dataset}")
    train_idx, val_idx = [], []
    for c in np.unique(labels):
        group = np.flatnonzero(labels == c)
        a, b = split_indices(len(group), spec["val_fraction"], seed + int(c))
        train_idx.extend(group[a].tolist())
        val_idx.extend(group[b].tolist())
    train_idx, val_idx = np.asarray(train_idx), np.asarray(val_idx)
    return {
        "train": (images[train_idx], labels[train_idx], all_ids[train_idx]),
        "val": (images[val_idx], labels[val_idx], all_ids[val_idx]),
        "test": (tests, test_labels, test_ids), "dataset": dataset,
    }


def corrupt_pixels(images: np.ndarray, name: str, severity: int, seed: int) -> np.ndarray:
    """Smoke-only synthetic pixel corruptions. Not the CIFAR-C benchmark."""
    rng = np.random.default_rng(seed)
    if name == "gaussian_noise":
        return np.clip(images.astype(float) + rng.normal(0, 6 * severity, images.shape), 0, 255).astype(np.uint8)
    if name == "brightness":
        return np.clip(images.astype(float) + 13 * severity, 0, 255).astype(np.uint8)
    if name == "defocus_blur":
        return np.stack([np.asarray(Image.fromarray(im).filter(ImageFilter.GaussianBlur(.4 * severity)))
                         for im in images])
    raise ValueError(f"Unknown smoke corruption: {name}")


def cifar_c_block(root: Path, corruption: str, severity: int, ids: np.ndarray,
                  expected_labels: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if not 1 <= severity <= 5:
        raise ValueError("CIFAR-C severity must be 1..5")
    image_path, label_path = root / f"{corruption}.npy", root / "labels.npy"
    if not image_path.exists() or not label_path.exists():
        raise FileNotFoundError(f"Official CIFAR-C files required: {image_path} and {label_path}")
    x, y = np.load(image_path, mmap_mode="r"), np.load(label_path, mmap_mode="r")
    if x.shape != (50000, 32, 32, 3):
        raise ValueError(f"Unexpected CIFAR-C image shape {x.shape}")
    offset = 10000 * (severity - 1)
    target = np.asarray(y[ids + offset] if len(y) == 50000 else y[ids], dtype=np.int64)
    if not np.array_equal(target, expected_labels):
        raise ValueError("CIFAR-C label alignment failed; clean/corrupted sample IDs differ")
    return np.asarray(x[ids + offset]).copy(), target

