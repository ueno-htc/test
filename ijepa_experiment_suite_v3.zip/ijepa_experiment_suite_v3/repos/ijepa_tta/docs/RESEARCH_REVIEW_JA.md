# ijepa_tta

## 1. ① 資源制約付きTest-Time Adaptation

### 検証したい仮説

> 固定された視覚表現・補正容量・更新損失を共通にしても、更新するタイミングの選択によって、予算当たりの頑健性と忘却の関係が変わる。その差を、ターゲットラベルを使わないshift指標から予測できるか。

「TTAを軽量にした」ではなく、**適応を実行する条件の価値**を評価対象とする。

### MVPの定式化と実装

sourceで標準化した特徴に対し、
\(h_\phi(z)=W[\exp(s)\odot z+b]+c\)
を用いる。sourceで訓練した \(W,c\) は固定し、テスト時は \(s,b\) だけを更新する。

予算は \(\sum_t u_t\le B\) の更新回数上限であり、streamに沿って利用可能な更新枠を解放する。候補はPeriodic、Random、Entropy gate、Drift gateであり、同じ補正パラメータ、entropy損失、sourceアンカーKL、パラメータの有界化を共有する。アンカーなしのablationも含めた。

Drift gateはsource標準化空間のbatch平均の二乗距離を使う単純なproxyである。最適な価値推定器やcontextual banditを実装したとは主張しない。

採点は**predict-then-adapt**である。`adapt_stream` はターゲットラベルを引数に取らない。予測結果とラベルの照合は外側の評価関数が行う。thresholdはsource validationから求める。公式CIFAR-Cのseverity blockとclean CIFARのIDを照合する。[S3]

### 主な査読懸念と対処

**新規性の重複。** EATAには既に信頼できる非冗長サンプルを使う効率化がある。計算時間を考慮した評価や時間依存効用にも既存研究がある。従って単純gateを新規手法と呼ばず、比較の初期基準とする。[S4][S5][S6]

**比較する資源が違う。** 更新回数が同じでも、選択処理、sourceアンカー参照、特徴抽出の時間は違う。MVPは実更新回数と後段時間を記録するが、hard real-time制約や電力制約を満たすものではない。同じ上限でも実際に使用した更新回数が違うため、上限同一の比較と実行コスト同一の比較を混同しない。

**source-freeではない。** source特徴アンカーを保存している。sourceアクセス条件を揃えた対照が必要であり、厳密なsource-freeとの直接比較は避ける。

**CIFAR特有の問題。** 小画像をcheckpointの入力解像度へ拡大する。ImageNetで事前学習された表現の利用であるため、解像度や事前学習データの効果をTTAの効果と混同しない。

### 投稿へ進む条件／中止・再設計条件

少なくとも複数seed、複数shift順序、複数更新予算で、Periodic/Randomに対する改善が再現し、cleanへの復帰時に大きな劣化を起こさないことを最初の条件とする。効果が「更新回数が多いだけ」「sourceアンカーを余分に参照しただけ」で消えるならgateの論文化は再設計する。

原版TENT/EATA/SARや近年の時間制約評価の再現、複数の同規模checkpoint、過去を知らない未見shift、選択コストを含む端末計測は**投稿前の未実装事項**である。MVP内のaffine entropy補正を、それらの公式再現として報告してはいけない。

---

## 6. 投稿向け共通チェックリスト

| 観点 | MVPで実施 | 投稿前に追加が必要 |
|---|---|---|
| 再現性 | seed、設定、code hash、checkpoint revision、前処理、分割ID、モデル保存 | 実GPUでの再実行、環境lock、別環境追試 |
| 評価リーク | source/trainだけで前処理推定、validation選択、TTAラベル非参照、group分割 | 追加データでの独立追試、公式splitの監査 |
| 比較の公平性 | 共通特徴・損失・stream、対照とablation、実コスト記録 | 外部強ベースラインの正確な再現、同実測予算での比較 |
| 統計 | scene単位paired bootstrap、seed別出力、1 seedのSDをnull | 複数seedと独立データに基づくCI、クライアントの標本数感度 |
| 計算量 | ヘッド時間とE2E時間を区別、実測latency、送受信payload | 電力、ターゲット端末、総working memory、異なるruntime |
| 新規性 | 既存手法との重複を明記、反証可能な問いへ限定 | 網羅的な近接研究調査と、新規機構・理論・知見の確立 |

