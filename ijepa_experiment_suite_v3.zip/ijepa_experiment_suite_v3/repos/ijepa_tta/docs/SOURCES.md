# Primary sources and implementation boundaries

References inherited from the original MVP review (2026-10-31); not a new literature survey.
No public model weights or datasets are bundled.

## [S1] I-JEPA
- Assran et al., Self-Supervised Learning from Images with a Joint-Embedding Predictive Architecture, CVPR 2023.
- Official code: https://github.com/facebookresearch/ijepa
- Paper: https://arxiv.org/abs/2301.08243
- Our use: frozen image encoder. We do not load or reproduce the original pretraining predictor.

## [S2] Hugging Face I-JEPA implementation and immutable checkpoint
- Official integration documentation: https://huggingface.co/docs/transformers/model_doc/ijepa
- Model: https://huggingface.co/facebook/ijepa_vith14_1k
- Pinned revision: https://huggingface.co/facebook/ijepa_vith14_1k/commit/f157467ea509bc356ff9f61fd3c0d840eec5e04e
- Processor: https://huggingface.co/facebook/ijepa_vith14_1k/blob/f157467ea509bc356ff9f61fd3c0d840eec5e04e/preprocessor_config.json
- Model config: https://huggingface.co/facebook/ijepa_vith14_1k/blob/f157467ea509bc356ff9f61fd3c0d840eec5e04e/config.json
- Model card license: CC-BY-NC-4.0. Check the exact upstream license and the terms of each dataset before commercial deployment.
- Public checkpoint execution has NOT been verified in the supplied CPU/offline environment.

## [S3] CIFAR-C
- Hendrycks and Dietterich, Benchmarking Neural Network Robustness to Common Corruptions and Perturbations, ICLR 2019.
- Official repository: https://github.com/hendrycks/robustness
- CIFAR-10-C archive: https://zenodo.org/records/2535967
- CIFAR-100-C archive: https://zenodo.org/records/3555552
- Our real-data loader uses the provided corruption arrays, not regenerated corruptions. Smoke images are explicitly unrelated to official CIFAR-C results.

## [S4] Computationally constrained TTA is already a research topic
- Alfarra et al., Evaluation of Test-Time Adaptation Under Computational Time Constraints, ICML 2024.
- https://proceedings.mlr.press/v235/alfarra24a.html
- Consequence: adding a time or update budget alone is not a novelty claim.

## [S5] Time-dependent utility in online TTA
- Tempora: Characterising the Time-Contingent Utility of Online Test-Time Adaptation, ICML 2026.
- https://proceedings.mlr.press/v306/sreeram26a.html
- Consequence: utility under deadlines/latency must be distinguished from a hard cap on gradient updates. This MVP enforces the latter, not a hard real-time deadline.

## [S6] Efficient anti-forgetting TTA
- Niu et al., Efficient Test-Time Model Adaptation without Forgetting, ICML 2022.
- https://proceedings.mlr.press/v162/niu22a.html
- Official code: https://github.com/mr-eggplant/EATA
- Our entropy gates and source-feature anchor loss are simplified controls, not an EATA reproduction. Storing source feature anchors is not strictly source-free adaptation.

## [S8] TENT
- Wang et al., Tent: Fully Test-Time Adaptation by Entropy Minimization, ICLR 2021.
- Official code: https://github.com/DequanWang/tent
- The affine feature adapter used here does not reproduce the original batch-normalization adaptation protocol.

