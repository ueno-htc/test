# V2 update

This is a historical per-repository guide. For current commands and the enforced logs-only policy, read the suite-level `README_V2.md`. No trained `.pt` or export model is produced by v2.

---

# ijepa_tta: ① CIFAR / CIFAR-C

このリポジトリは、このテーマだけを実行する独立版です。他のリポジトリや元の統合版には依存しません。

固定I-JEPAの前提と、元の実験・対照・評価手順を維持しています。物性推定研究とは独立したMVPです。

**公開checkpoint・実データ・GPUでの性能は未検証です。** CPUのMockによる動作確認と、I-JEPAの研究結果を区別してください。本番ロード失敗時にMockへ自動切替しません。

## 1. Dataset-only /localdata policy (v0.3)

Only input datasets live under `/localdata` (no extra `datasets/` suffix).
Model weights, feature/compiler caches, outputs and temporary files default to the
**current directory from which the script is invoked**, not the dataset directory.

```text
/localdata/                     # datasets only
  cifar-10-batches-py/
  CIFAR-10-C/
  oxford-iiit-pet/
  videos/video_manifest.jsonl
./models/huggingface/hub/        # shared public model cache
./models/torch/
./cache/ijepa_tta/
./outputs/ijepa_tta/
./artifacts/ijepa_tta/
./tmp/ijepa_tta/
```

`--data-root` > `DATASETS_ROOT` > `/localdata` selects input datasets.
`--work-dir` > `IJEPA_WORK_DIR` > caller cwd selects all other default paths.
`LOCALDATA_ROOT` and the former `--storage-root` option are retired.
The parent suite passes explicit absolute output paths for batch isolation.

```bash
bash run_all.sh dry-run
bash run_all.sh dry-run --data-root /localdata --work-dir "$PWD"
```

## 2. セットアップ

Python 3.10以上。WindowsではWSL/Linux上で `bash run_all.sh` を実行してください。

使用GPUに対応するPyTorchとtorchvisionを用意したうえで、このフォルダで実行します。

```bash
python -m pip install -e ".[real,test]"
```

CPUでソフトウェア検証だけを行う場合：

```bash
python -m pip install -e ".[test]"
bash run_all.sh tests -q
bash run_all.sh smoke
```

Current release verification is in the parent suite verification/ directory. Public-checkpoint/GPU execution remains unverified here.

### 公開checkpointと前処理

```text
model_id: facebook/ijepa_vith14_1k
revision: f157467ea509bc356ff9f61fd3c0d840eec5e04e
```

公式Hugging Faceリポジトリのコミットを固定しています。前処理は同じrevisionの `AutoImageProcessor` から読み込みます。ImageNetのmean/stdを手書きで代用しません。公式processorは224×224へのリサイズとmean/std=0.5を指定しています。

モデルID、解決されたrevision、前処理、dtype、ライブラリバージョンを記録します。ローカルモデルを使う場合は設定・重みファイルのSHA-256も記録します。元のI-JEPA predictorはこのHFエンコーダ経路では読み込みません。

公式モデルのカードには `CC-BY-NC-4.0` の表記があります。モデル重み・データは本ZIPに含めていません。利用時は配布元の条件を確認してください。

## 3. Commands

```bash
bash run_all.sh tests -q
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh smoke --seeds 0 1 2 --resume
bash run_all.sh check --expected-runs 3
bash run_all.sh report

# Real encoder; see the next section for data preparation.
bash run_all.sh real --device cuda --seeds 0 1 2

# No data/weight access or filesystem writes:
bash run_all.sh dry-run --config examples/override.yaml
```

`--tasks` は廃止しました。このリポジトリのテーマだけが実行されます。

設定は `src/ijepa_tta/configs/` に同梱し、wheel単体でも利用できます。

`--resume` は完了済み実行のスキップであり、epochの途中再開ではありません。設定・コードが変わった場合は拒否します。

## 4. ① CIFAR / CIFAR-C

```bash
# CIFAR-10と公式CIFAR-10-Cを明示的に取得
# CIFAR-10-Cの大容量ダウンロードは --cifar10-c を付けたときのみ
bash run_all.sh prepare --dataset cifar10 --root /localdata --cifar10-c

bash run_all.sh real --device cuda --seeds 0 1 2
```

手動配置も可能です。

```text
/localdata/CIFAR-10-C/
  labels.npy
  gaussian_noise.npy
  defocus_blur.npy
  brightness.npy
  ...
```

最初は5,000枚のCIFAR訓練画像と1,000枚のテスト画像を使うpilotです。訓練側からvalidationを切り分けます。完全評価の例：

```bash
bash run_all.sh real --device cuda \
  --set data.max_train=50000 --set data.max_test=10000 \
  --set 'tta.severities=[1,2,3,4,5]' \
  --set 'tta.corruptions=["gaussian_noise","shot_noise","impulse_noise","defocus_blur","glass_blur","motion_blur","zoom_blur","snow","frost","fog","brightness","contrast","elastic_transform","pixelate","jpeg_compression"]' \
  --output ./outputs/ijepa_tta/full
```

CIFAR-100では `num_classes=100`、`data.dataset=cifar100`、公式CIFAR-100-Cのパスを設定してください。CIFAR-100-Cの自動ダウンローダは含めていません。

```bash
bash run_all.sh real --device cuda \
  --set num_classes=100 --set data.dataset=cifar100 \
  --set data.corruption_root=/localdata/CIFAR-100-C
```

**採点は適応前です。** 更新関数にターゲットラベルを渡しません。共通のaffine補正と共通損失の下で、更新するタイミングを比較します。元のTENT/EATA/SARの名称で独自簡略実装を報告しません。

hard budgetは勾配更新回数です。実測更新時間も保存しますが、wall-clock deadlineを厳守するスケジューラではありません。`online_head_ms` は後段処理のみで、I-JEPA特徴抽出を含みません。sourceの特徴アンカーを保存するため、厳密なsource-free設定でもありません。

## 5. Repository structure

```text
ijepa_tta/
  run_all.sh
  pyproject.toml
  README_JA.md
  .env.example
  src/ijepa_tta/
    configs/base.yaml
    configs/experiment.yaml
    cli.py
    storage.py
    encoder.py
    common.py
    tta.py
    prepare.py
    report.py
    check.py
  tests/
  examples/
  docs/RESEARCH_REVIEW_JA.md
  docs/SOURCES.md
  verification/TEST_REPORT_JA.md
```

共通機能は各リポジトリに同梱しています。元の統合版や親フォルダのPYTHONPATHは不要です。Pythonパッケージ名もすべて異なります。

## 6. 実行と結果解釈の注意

- 同一seedの繰り返しを独立試行として集計しません。1 seedの標準偏差は0ではなくnullです。
- `--set` は既存の設定キーだけを変更でき、タイプミスしたキーはエラーになります。
- キャッシュの更新や大規模データを含め、絶対的な所要時間・GPUメモリ量は未測定です。初回はsubset、encoder batch size 1〜8から開始してください。
- `.pt` を読み込む際は、このパッケージのコードが作った信頼できるファイルを使用してください。ツールの読込は `weights_only=True` を使っています。
- 特定手法が勝つようなハイパーパラメータ探索、テスト結果によるモデル選択は実施していません。
- 本番の論文比較では、checkpoint・パラメータ数・sourceへのアクセス・更新予算・実測時間を揃える必要があります。

### オフライン／社内プロキシ環境

信頼された経路でcheckpoint一式をローカルディレクトリに配置して使用できます。TLS検証の無効化は行いません。

```bash
bash run_all.sh real --device cuda \
  --set encoder.model_id=./models/ijepa_vith14_1k \
  --set encoder.local_files_only=true \
  --set encoder.batch_size=2
```

