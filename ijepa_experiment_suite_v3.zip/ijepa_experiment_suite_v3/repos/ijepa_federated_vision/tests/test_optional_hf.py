"""Optional API test. Random tiny IJepaModel validates integration, not public weights."""
import numpy as np
import pytest
import torch


def test_hf_tiny_local_encoder(tmp_path):
    pytest.importorskip('transformers')
    from transformers import IJepaConfig, IJepaModel, ViTImageProcessor
    from ijepa_federated_vision.encoder import FrozenIJEPA
    config = IJepaConfig(image_size=32, patch_size=8, hidden_size=32, num_hidden_layers=1,
                        num_attention_heads=4, intermediate_size=64)
    model = IJepaModel(config)
    model.save_pretrained(tmp_path)
    ViTImageProcessor(size={'height': 32, 'width': 32}).save_pretrained(tmp_path)
    wrapper = FrozenIJEPA({'model_id': str(tmp_path), 'dtype': 'float32', 'local_files_only': True},
                         torch.device('cpu'))
    z = wrapper.encode(np.zeros((2, 32, 32, 3), dtype=np.uint8))
    assert z.shape == (2, 32)
    assert not z.requires_grad
    assert not any(p.requires_grad for p in wrapper.parameters())
