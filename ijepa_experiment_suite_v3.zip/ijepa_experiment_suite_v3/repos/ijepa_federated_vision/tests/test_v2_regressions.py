import numpy as np
import torch
from ijepa_federated_vision.closed_form import sufficient_statistics, ridge_solutions


def test_closed_form_solution_matches_central_ridge():
    x=torch.randn(31,6);y=torch.arange(31)%3
    groups=[np.arange(0,10),np.arange(10,31)]
    stats,nb=sufficient_statistics(x,y,groups,3)
    alpha,w,b=next(ridge_solutions(stats,[.1]))
    a=x.double()-x.double().mean(0)
    t=torch.nn.functional.one_hot(y,3).double(); target=t-t.mean(0)
    expected=torch.linalg.solve(a.T@a+.1*torch.eye(6,dtype=torch.float64),a.T@target)
    torch.testing.assert_close(w,expected.float(),atol=1e-6,rtol=1e-5)
    torch.testing.assert_close(b,(t.mean(0)-x.double().mean(0)@expected).float(),atol=1e-6,rtol=1e-5)
    assert nb == 2*8*(6*6+6*3+6+3+1)


def test_federated_statistics_partition_invariance():
    x=torch.randn(20,7);y=torch.arange(20)%4
    a,_=sufficient_statistics(x,y,[np.arange(20)],4)
    b,_=sufficient_statistics(x,y,[np.arange(0,20,2),np.arange(1,20,2)],4)
    for k in ['xx','xy','sx','sy']:
        torch.testing.assert_close(a[k],b[k],atol=1e-12,rtol=1e-12)
    assert a['n']==b['n']
