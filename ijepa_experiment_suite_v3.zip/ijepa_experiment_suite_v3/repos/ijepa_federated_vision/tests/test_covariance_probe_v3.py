import numpy as np
import torch
from ijepa_federated_vision.covariance_probe import (orthogonal_columns, first_moments,
 covariance_action, validation_select, run_covariance_controls)

def test_federated_moments_and_actions_match_centralized():
    g=torch.Generator().manual_seed(13)
    x=torch.randn(60,6,generator=g);y=torch.arange(60)%3
    groups=[np.arange(0,20),np.arange(20,60)]
    m=first_moments(x,y,groups,3);a=x.double()-x.double().mean(0)
    q=orthogonal_columns(torch.randn(6,3,generator=g))
    torch.testing.assert_close(covariance_action(x,groups,m['mu'],q),a.T@a@q)
    target=torch.nn.functional.one_hot(y,3).double()
    torch.testing.assert_close(m['rhs'],a.T@(target-target.mean(0)))
    torch.testing.assert_close(q.T@q,torch.eye(q.shape[1],dtype=torch.float64))

def test_full_krylov_span_reproduces_full_ridge():
    g=torch.Generator().manual_seed(14)
    x=torch.randn(90,6,generator=g);y=(x[:,0]+.4*x[:,1]>0).long()
    groups=[np.arange(0,40),np.arange(40,70)];vals=[np.arange(70,80),np.arange(80,90)]
    m=first_moments(x,y,groups,2);q=orthogonal_columns(m['rhs']);gq=covariance_action(x,groups,m['mu'],q)
    for _ in range(8):
        new=orthogonal_columns(gq,against=q)
        if not new.shape[1]:break
        q=torch.cat([q,new],1);gq=covariance_action(x,groups,m['mu'],q)
        if q.shape[1]==6:break
    loss,alpha,w=validation_select(x,y,vals,q,m['mu'],m['prior'],q.T@gq,q.T@m['rhs'],[1.])
    a=x[:70].double()-m['mu']
    exact=torch.linalg.solve(a.T@a+torch.eye(6,dtype=torch.float64),m['rhs'])
    torch.testing.assert_close(q@w,exact,atol=1e-8,rtol=1e-7)

def test_run_reports_payload_and_local_control():
    g=torch.Generator().manual_seed(15)
    x=torch.randn(90,8,generator=g);y=torch.arange(90)%3
    spec={'ridge_alphas':[.1,1.],'fairness_min_test_count':2,
          'covariance_steps':[0,1,2], 'covariance_max_rank':8,'local_closed_form_control':True}
    rows=run_covariance_controls(x,y,x,y,[np.arange(25),np.arange(25,50)],
          [np.arange(50,60),np.arange(60,70)],[np.arange(70,80),np.arange(80,90)],spec,3)
    assert any(r['method']=='local_closed_form_ridge' for r in rows)
    for r in rows:
        assert r['total_round_payload_bytes']==r['uplink_payload_bytes']+r['downlink_payload_bytes']
        assert 0<=r['test']['micro_accuracy']<=1
        if 'normal_equation_relative_residual' in r:
            assert np.isfinite(r['normal_equation_relative_residual'])
            assert r['full_covariance_transmitted'] is False
