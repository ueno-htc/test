import numpy as np
import pytest
import torch
from ijepa_federated_vision.federated import FederatedHead, aggregate, shared_bytes, allocate_with_probabilities, dirichlet_partition


def test_federated_partition_exhaustive_disjoint():
    y = np.repeat(np.arange(4), 50)
    groups, proportions = dirichlet_partition(y, 4, 4, .5, 1, 8)
    combined = np.concatenate(groups)
    assert sorted(combined.tolist()) == list(range(len(y)))
    assert len(set(combined)) == len(y)
    assert np.allclose(proportions.sum(1), 1)


def test_federated_same_population_distribution():
    probs = np.array([[1., 0.], [0., 1.]])
    labels = np.array([0, 1, 0, 1])
    groups = allocate_with_probabilities(labels, probs, 0)
    assert np.all(labels[groups[0]] == 0)
    assert np.all(labels[groups[1]] == 1)


def test_federated_infeasible_partition_fails():
    with pytest.raises(ValueError):
        dirichlet_partition(np.zeros(10, dtype=int), 4, 1, .2, 0, 8)


def test_weighted_aggregation():
    states = [{'w': torch.tensor([1.])}, {'w': torch.tensor([5.])}]
    assert aggregate(states, [3, 1])['w'].item() == 2


def test_fixed_basis_aggregation_commutes_with_product():
    basis = torch.randn(3, 8)
    a, b = torch.randn(4, 3), torch.randn(4, 3)
    torch.testing.assert_close(((a + b) / 2) @ basis, (a @ basis + b @ basis) / 2)


def test_unaligned_factor_average_not_product_average():
    a, b = torch.tensor([[1.]]), torch.tensor([[2.]])
    c, d = torch.tensor([[3.]]), torch.tensor([[4.]])
    assert not torch.allclose((a + c) / 2 @ ((b + d) / 2), (a @ b + c @ d) / 2)


def test_personal_bias_not_communicated():
    model = FederatedHead(8, 4, 'fixed_basis', 2, True)
    assert 'private_bias' not in model.shared_state()
    assert 'basis' not in model.shared_state()
    assert 'private_bias' in model.state_dict()
    assert shared_bytes(model.shared_state()) == (4 * 2 + 4) * 4


def test_fixed_basis_identical_across_clients():
    a, b = FederatedHead(8, 4, 'fixed_basis', 2), FederatedHead(8, 4, 'fixed_basis', 2)
    torch.testing.assert_close(a.basis, b.basis)


def test_low_rank_head_backward():
    model = FederatedHead(8, 4, 'learned_factors', 2)
    logits = model(torch.randn(10, 8))
    logits.square().sum().backward()
    assert model.left.grad is not None

