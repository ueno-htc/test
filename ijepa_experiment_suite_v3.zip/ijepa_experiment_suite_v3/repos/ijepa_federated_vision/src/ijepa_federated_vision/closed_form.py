"""Diagnostic baselines, not a proposed novel federated algorithm.

Ridge sufficient-statistic aggregation follows the Fed3R principle (ICML 2024).
All fitting/alpha selection uses client training/validation only. This is still
single-process FL simulation and provides no privacy guarantee.
"""
from __future__ import annotations
import numpy as np
import torch
from torch.nn import functional as F
from .common import classification_metrics


def sufficient_statistics(x, y, groups, classes):
    d = x.shape[1]
    stats = {'xx': torch.zeros(d,d,dtype=torch.float64),
             'xy': torch.zeros(d,classes,dtype=torch.float64),
             'sx': torch.zeros(d,dtype=torch.float64),
             'sy': torch.zeros(classes,dtype=torch.float64), 'n': 0}
    payload = 0
    for idx in groups:
        a = x[idx].double()
        b = F.one_hot(y[idx], classes).double()
        stats['xx'] += a.T @ a
        stats['xy'] += a.T @ b
        stats['sx'] += a.sum(0)
        stats['sy'] += b.sum(0)
        stats['n'] += len(idx)
        # Logical full matrices in float64, including sums/count; not triangular compression.
        payload += 8 * (d*d + d*classes + d + classes + 1)
    return stats, payload


def ridge_solutions(stats, alphas):
    n = stats['n']
    mu, target_mu = stats['sx']/n, stats['sy']/n
    gram = stats['xx'] - n*torch.outer(mu,mu)
    rhs = stats['xy'] - n*torch.outer(mu,target_mu)
    values, vectors = torch.linalg.eigh((gram+gram.T)/2)
    values = values.clamp_min(0)
    projected = vectors.T @ rhs
    for alpha in alphas:
        if alpha <= 0: raise ValueError('Ridge alpha must be positive')
        w = vectors @ (projected / (values[:,None] + alpha))
        bias = target_mu - mu @ w
        yield float(alpha), w.float(), bias.float()


def choose_solution(stats, vx, vy, classes, alphas):
    target = F.one_hot(vy, classes).float()
    best = None
    for alpha, w, bias in ridge_solutions(stats, alphas):
        error = float((vx @ w + bias - target).square().mean())
        if best is None or error < best[0]: best = (error,alpha,w,bias)
    return best


def run_controls(x,y,tx,ty,train_groups,val_groups,test_groups,spec,classes,device):
    from .federated import FederatedHead, client_evaluation
    a,b = np.concatenate(train_groups),np.concatenate(val_groups)
    count = len(train_groups)
    alphas = spec.get('ridge_alphas',[.001,.01,.1,1.,10.])
    results=[]
    def evaluate_head(name,w,bias,upload,download,choice,extra=None):
        model=FederatedHead(x.shape[1],classes,'full').to(device)
        with torch.no_grad():
            model.weight.copy_(w.T.to(device)); model.bias.copy_(bias.to(device))
        test=client_evaluation(model,{},tx,ty,test_groups,device,spec['fairness_min_test_count'])
        results.append({'method':name,'test':test,'uplink_payload_bytes':int(upload),
            'downlink_payload_bytes':int(download),'total_round_payload_bytes':int(upload+download),
            'validation_selection':choice,'diagnostic_baseline_not_new_method':True,
            'all_clients_participate_in_statistics_round':True,**(extra or {})})
    full_stats, full_upload = sufficient_statistics(x,y,train_groups,classes)
    loss,alpha,w,bias = choose_solution(full_stats,x[b],y[b],classes,alphas)
    evaluate_head('Fed3R_style_full_ridge',w,bias,full_upload, count*(w.numel()+bias.numel())*4,
                  {'alpha':alpha,'source_validation_mse':loss},
                  {'statistics_dtype':'float64','privacy_guarantee':None,'rounds':1})
    # Class-sum directions are a task-aligned alternative to a random 4-D subspace.
    prototypes = (full_stats['xy']/full_stats['sy'].clamp_min(1)[None]).T.float()
    mu = (full_stats['sx']/full_stats['n']).float()
    _,singular,vt = torch.linalg.svd(prototypes-mu,full_matrices=False)
    maxrank = max(1,min(classes-1, int((singular>1e-7).sum()), x.shape[1]))
    prototype_upload = count*8*(x.shape[1]*classes + classes)
    for rank in sorted(set(min(int(r),maxrank) for r in spec.get('prototype_ranks',[4,9]))):
        if rank<1: raise ValueError('Invalid prototype rank')
        basis=vt[:rank].T.contiguous()
        px=x@basis
        stats,up=sufficient_statistics(px,y,train_groups,classes)
        loss,alpha,lw,lb = choose_solution(stats,px[b],y[b],classes,alphas)
        # Actual simulation broadcasts a float32 basis and low-dimensional readout.
        down=count*4*(basis.numel()+lw.numel()+lb.numel())
        evaluate_head(f'prototype_subspace_ridge_r{rank}',basis@lw,lb,prototype_upload+up,down,
              {'alpha':alpha,'source_validation_mse':loss},
              {'rank':rank,'basis_uses_client_train_labels_only':True,'rounds':2,
               'expanded_matrix_used_only_for_evaluation':True})
    # No-image label-prior baseline: isolates benefits of private class biases.
    local_prior=[]
    for cid,idx in enumerate(test_groups):
        counts=torch.bincount(y[train_groups[cid]],minlength=classes).float()+1
        logits=counts.log()[None].expand(len(idx),-1)
        metrics=classification_metrics(logits,ty[idx]) if len(idx) else {'n':0,'accuracy':None}
        local_prior.append({'client':cid,**metrics})
    eligible=[r['accuracy'] for r in local_prior if r['n']>=spec['fairness_min_test_count']]
    total=sum(r['n'] for r in local_prior)
    results.append({'method':'local_label_prior_NO_IMAGE','total_round_payload_bytes':0,
       'test':{'micro_accuracy':sum(r['accuracy']*r['n'] for r in local_prior if r['n'])/total,
               'macro_client_accuracy':float(np.mean([r['accuracy'] for r in local_prior if r['n']])),
               'worst_client_accuracy_min_count':min(eligible) if eligible else None,
               'p10_client_accuracy_min_count':float(np.quantile(eligible,.1)) if eligible else None,
               'clients':local_prior},'diagnostic_baseline_not_new_method':True})
    return results
