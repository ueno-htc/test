"""Standalone I-JEPA federated research MVP."""
__version__ = "0.2.0"
