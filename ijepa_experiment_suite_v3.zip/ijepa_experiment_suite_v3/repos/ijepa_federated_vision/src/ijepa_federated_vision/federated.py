from __future__ import annotations

import copy
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .common import (classification_metrics, dump_json, parameter_bytes,
                     predict, save_checkpoint, split_indices, train_supervised)
from .data import classification_data


def allocate_with_probabilities(labels: np.ndarray, class_probabilities: np.ndarray,
                                seed: int) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    clients = [[] for _ in range(class_probabilities.shape[1])]
    for label in range(class_probabilities.shape[0]):
        indices = rng.permutation(np.flatnonzero(labels == label))
        counts = rng.multinomial(len(indices), class_probabilities[label])
        chunks = np.split(indices, np.cumsum(counts)[:-1])
        for client, chunk in zip(clients, chunks):
            client.extend(chunk.tolist())
    return [rng.permutation(a).astype(np.int64) for a in clients]


def dirichlet_partition(labels: np.ndarray, clients: int, classes: int,
                        alpha: float, seed: int, min_size: int = 8):
    if alpha <= 0 or clients * min_size > len(labels):
        raise ValueError("Infeasible Dirichlet partition; lower clients/min_size or add samples")
    rng = np.random.default_rng(seed)
    for attempt in range(200):
        probabilities = rng.dirichlet(np.full(clients, alpha), size=classes)
        groups = allocate_with_probabilities(labels, probabilities, seed + attempt + 1)
        if min(map(len, groups)) >= min_size:
            return groups, probabilities
    raise RuntimeError("Could not obtain nonempty clients after 200 attempts; relax non-IID severity")


class FederatedHead(nn.Module):
    def __init__(self, dim: int, classes: int, mode: str = "full", rank: int = 4,
                 personal: bool = False, basis_seed: int = 721):
        super().__init__()
        self.mode, self.personal = mode, personal
        self.bias = nn.Parameter(torch.zeros(classes))
        if mode == "full":
            self.weight = nn.Parameter(torch.zeros(classes, dim))
        else:
            if not 1 <= rank <= min(dim, classes):
                raise ValueError("Rank must be <= min(feature_dim, num_classes)")
            generator = torch.Generator().manual_seed(basis_seed)
            basis = torch.linalg.qr(torch.randn(dim, rank, generator=generator), mode="reduced").Q.T
            basis = basis * (dim / rank) ** .5
            if mode == "fixed_basis":
                self.register_buffer("basis", basis)
            elif mode == "learned_factors":
                self.basis = nn.Parameter(basis)
            else:
                raise ValueError(mode)
            self.left = nn.Parameter(torch.zeros(classes, rank))
        if personal:
            self.private_bias = nn.Parameter(torch.zeros(classes))

    def forward(self, x):
        if self.mode == "full":
            logits = F.linear(x, self.weight, self.bias)
        else:
            logits = F.linear(F.linear(x, self.basis), self.left, self.bias)
        return logits + self.private_bias if self.personal else logits

    def shared_state(self) -> dict[str, torch.Tensor]:
        # Fixed basis buffers and personalized bias are not communicated each round.
        return {name: value.detach().cpu().clone() for name, value in self.named_parameters()
                if name != "private_bias"}

    @torch.no_grad()
    def load_shared(self, state: dict[str, torch.Tensor]):
        named = dict(self.named_parameters())
        for name, value in state.items():
            named[name].copy_(value.to(named[name].device))


def aggregate(states: list[dict], weights: list[int]) -> dict:
    if not states or len(states) != len(weights) or sum(weights) <= 0:
        raise ValueError("Invalid aggregation inputs")
    total = float(sum(weights))
    return {key: sum(state[key] * (weight / total) for state, weight in zip(states, weights))
            for key in states[0]}


def shared_bytes(state: dict) -> int:
    return sum(t.numel() * t.element_size() for t in state.values())


def local_update(model: FederatedHead, x: torch.Tensor, y: torch.Tensor,
                 indices: np.ndarray, cfg: dict, device: torch.device, seed: int,
                 proximal_mu: float = 0.0):
    model.to(device).train()
    reference = {k: v.to(device) for k, v in model.shared_state().items()}
    optimizer = torch.optim.SGD(model.parameters(), lr=cfg["lr"])
    generator = torch.Generator().manual_seed(seed)
    for _ in range(cfg["local_epochs"]):
        permutation = torch.randperm(len(indices), generator=generator).numpy()
        for start in range(0, len(indices), cfg["batch_size"]):
            idx = indices[permutation[start:start + cfg["batch_size"]]]
            optimizer.zero_grad(set_to_none=True)
            loss = F.cross_entropy(model(x[idx].to(device)), y[idx].to(device))
            if proximal_mu:
                loss = loss + .5 * proximal_mu * sum((p - reference[k]).square().sum()
                       for k, p in model.named_parameters() if k in reference)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5)
            optimizer.step()
    model.eval()


def client_evaluation(global_model: FederatedHead, private: dict[int, torch.Tensor],
                      x: torch.Tensor, y: torch.Tensor, groups: list[np.ndarray],
                      device: torch.device, min_count: int, scales: dict | None = None) -> dict:
    rows, correct, total = [], 0.0, 0
    model = copy.deepcopy(global_model).to(device)
    for cid, idx in enumerate(groups):
        if not len(idx):
            rows.append({"client": cid, "n": 0, "accuracy": None})
            continue
        if model.personal:
            scale = 1.0 if scales is None else scales.get(cid, 1.0)
            with torch.no_grad():
                model.private_bias.copy_(private[cid].to(device) * scale)
        metrics = classification_metrics(predict(model, x[idx], device), y[idx])
        rows.append({"client": cid, **metrics})
        correct += metrics["accuracy"] * len(idx)
        total += len(idx)
    eligible = [r["accuracy"] for r in rows if r["n"] >= min_count]
    all_scores = [r["accuracy"] for r in rows if r["n"] > 0]
    return {"micro_accuracy": correct / max(total, 1),
            "macro_client_accuracy": float(np.mean(all_scores)) if all_scores else None,
            "worst_client_accuracy_min_count": min(eligible) if eligible else None,
            "p10_client_accuracy_min_count": float(np.quantile(eligible, .1)) if eligible else None,
            "fairness_min_test_count": min_count, "fairness_eligible_clients": len(eligible), "clients": rows}


def run(cfg: dict, encoder, cache, out: Path, device: torch.device) -> dict:
    data = classification_data(cfg)
    # For FL, source train+val is repartitioned by clients, then locally split.
    images = np.concatenate([data["train"][0], data["val"][0]])
    labels_np = np.concatenate([data["train"][1], data["val"][1]])
    source_ids = np.concatenate([data["train"][2], data["val"][2]])
    x = F.normalize(cache.get(images).float(), dim=-1)
    tx = F.normalize(cache.get(data["test"][0]).float(), dim=-1)
    y, ty = torch.tensor(labels_np).long(), torch.tensor(data["test"][1]).long()
    spec = cfg["federated"]
    groups, proportions = dirichlet_partition(labels_np, spec["clients"], cfg["num_classes"],
                                              spec["alpha"], cfg["seed"], spec["min_client_samples"])
    test_groups = allocate_with_probabilities(data["test"][1], proportions, cfg["seed"] + 100000)
    train_groups, val_groups = [], []
    for cid, group in enumerate(groups):
        a, b = split_indices(len(group), spec["val_fraction"], cfg["seed"] + cid)
        train_groups.append(group[a])
        val_groups.append(group[b])
    dump_json(out / "client_partitions.json", {
        "train_global_ids": [source_ids[i] for i in train_groups],
        "val_global_ids": [source_ids[i] for i in val_groups],
        "test_global_ids": [data["test"][2][i] for i in test_groups],
        "class_to_client_probabilities": proportions,
        "train_label_counts": [np.bincount(labels_np[g], minlength=cfg["num_classes"]) for g in train_groups],
        "test_and_train_share_sampling_probabilities_not_sample_ids": True})
    results = []
    # Centralized readout is a non-federated diagnostic upper reference, clearly separated.
    central = nn.Linear(x.shape[-1], cfg["num_classes"])
    a, b = np.concatenate(train_groups), np.concatenate(val_groups)
    central_history = train_supervised(central, x[a], y[a], x[b], y[b], device=device,
                                       seed=cfg["seed"], **cfg["train"])
    results.append({"method": "CENTRALIZED_reference_NOT_federated", "test": classification_metrics(predict(central, tx, device), ty)})
    save_checkpoint(out / "centralized_reference.pt", central, encoder=encoder.provenance)
    dump_json(out / "centralized_training.json", central_history)
    participation_rng = np.random.default_rng(cfg["seed"])
    count = max(1, int(round(spec["clients"] * spec["participation"])))
    schedule = [participation_rng.choice(spec["clients"], count, replace=False).tolist() for _ in range(spec["rounds"])]
    dump_json(out / "participation_schedule.json", schedule)
    methods = [("fedavg_full", "full", False, 0.0), ("fedavg_full_personal", "full", True, 0.0), ("fedprox_full", "full", False, spec["proximal_mu"]),
               ("fixed_basis", "fixed_basis", False, 0.0),
               ("factor_average", "learned_factors", False, 0.0),
               ("fixed_basis_personal", "fixed_basis", True, 0.0)]
    for name, mode, personal, mu in methods:
        torch.manual_seed(cfg["seed"])
        global_model = FederatedHead(x.shape[-1], cfg["num_classes"], mode, spec["rank"], personal).to(device)
        private = {cid: torch.zeros(cfg["num_classes"]) for cid in range(spec["clients"])}
        best, best_state, best_private, best_round = -1, None, None, None
        history, uplink, downlink = [], 0, 0
        for round_idx, selected in enumerate(schedule):
            states, weights = [], []
            shared = global_model.shared_state()
            for cid in selected:
                local = copy.deepcopy(global_model)
                if personal:
                    with torch.no_grad():
                        local.private_bias.copy_(private[cid].to(device))
                downlink += shared_bytes(shared)
                local_update(local, x, y, train_groups[cid], spec, device,
                             cfg["seed"] + round_idx * spec["clients"] + cid, mu)
                state = local.shared_state()
                uplink += shared_bytes(state)
                states.append(state)
                weights.append(len(train_groups[cid]))
                if personal:
                    private[cid] = local.private_bias.detach().cpu().clone()
            global_model.load_shared(aggregate(states, weights))
            val = client_evaluation(global_model, private, x, y, val_groups, device, 1)
            history.append({"round": round_idx, "validation": val,
                            "uplink_payload_bytes": uplink, "downlink_payload_bytes": downlink})
            if val["micro_accuracy"] > best:
                best, best_round = val["micro_accuracy"], round_idx
                best_state = copy.deepcopy(global_model.state_dict())
                best_private = copy.deepcopy(private)
        global_model.load_state_dict(best_state)
        private = best_private
        # Local bias shrinkage is selected on each client's validation split only.
        scales = {}
        if personal:
            for cid, idx in enumerate(val_groups):
                best_local, best_scale = -1.0, 0.0
                for scale in [0.0, .25, .5, 1.0]:
                    with torch.no_grad():
                        global_model.private_bias.copy_(private[cid].to(device) * scale)
                    value = classification_metrics(predict(global_model, x[idx], device), y[idx])["accuracy"]
                    if value > best_local:
                        best_local, best_scale = value, scale
                scales[cid] = best_scale
            with torch.no_grad():
                global_model.private_bias.zero_()
        test = client_evaluation(global_model, private, tx, ty, test_groups, device,
                                 spec["fairness_min_test_count"], scales if personal else None)
        results.append({"method": name, "rank": None if mode == "full" else spec["rank"],
                        "test": test, "best_round_selected_by_validation": best_round,
                        "executed_rounds": spec["rounds"], "uplink_payload_bytes": uplink,
                        "downlink_payload_bytes": downlink, "total_round_payload_bytes": uplink + downlink,
                        "static_basis_seed_bytes_per_client": 8 if mode == "fixed_basis" else 0,
                        "private_bias_shrinkage": scales, "head_deploy_bytes": parameter_bytes(global_model),
                        "rounds_after_selected_checkpoint_still_counted_in_communication": True})
        save_checkpoint(out / f"{name}.pt", global_model, private_biases=private, private_scales=scales,
                        encoder=encoder.provenance, model_spec={"dim": x.shape[-1], "classes": cfg["num_classes"],
                                                             "mode": mode, "rank": spec["rank"], "personal": personal})
        dump_json(out / f"{name}_rounds.json", history)
    # Local-only is essential: otherwise average FL gains can hide negative transfer.
    local_rows = []
    local_config = dict(spec)
    for cid, idx in enumerate(train_groups):
        local = FederatedHead(x.shape[-1], cfg["num_classes"], "full").to(device)
        best_val, best_local = -1, None
        for r, selected in enumerate(schedule):
            if cid not in selected:
                continue
            local_update(local, x, y, idx, local_config, device, cfg["seed"] + r * spec["clients"] + cid)
            value = classification_metrics(predict(local, x[val_groups[cid]], device), y[val_groups[cid]])["accuracy"]
            if value > best_val:
                best_val, best_local = value, copy.deepcopy(local.state_dict())
        if best_local is not None:
            local.load_state_dict(best_local)
        if len(test_groups[cid]):
            metrics = classification_metrics(predict(local, tx[test_groups[cid]], device), ty[test_groups[cid]])
            local_rows.append({"client": cid, **metrics})
        else:
            local_rows.append({"client": cid, "n": 0, "accuracy": None})
        save_checkpoint(out / f"local_only_client{cid}.pt", local, encoder=encoder.provenance)
    eligible = [r["accuracy"] for r in local_rows if r["n"] >= spec["fairness_min_test_count"]]
    local_micro = sum(r["accuracy"] * r["n"] for r in local_rows if r["n"]) / max(1, sum(r["n"] for r in local_rows))
    results.append({"method": "local_only", "total_round_payload_bytes": 0,
                    "test": {"micro_accuracy": local_micro, "clients": local_rows,
                             "worst_client_accuracy_min_count": min(eligible) if eligible else None}})
    if spec.get("closed_form_controls", True):
        from .closed_form import run_controls
        results.extend(run_controls(x,y,tx,ty,train_groups,val_groups,test_groups,spec,
                                    cfg["num_classes"],device))
    if spec.get("covariance_controls", False):
        from .covariance_probe import run_covariance_controls
        results.extend(run_covariance_controls(x,y,tx,ty,train_groups,val_groups,test_groups,
                                               spec,cfg["num_classes"]))
    local_by_client = {r["client"]: r["accuracy"] for r in local_rows if r["n"]}
    for row in results:
        if "clients" in row["test"] and row["method"] != "local_only":
            deltas = [r["accuracy"] - local_by_client[r["client"]] for r in row["test"]["clients"] if r["n"]]
            row["fraction_clients_worse_than_local_only"] = float(np.mean(np.asarray(deltas) < 0))
    return {"theme": "06_parameter_efficient_federated_vision", "dataset": data["dataset"],
            "records": results, "feature_normalization": "per-sample L2; no centrally fitted feature mean/std",
            "static_encoder_install_bytes_per_client": parameter_bytes(getattr(encoder, "model", encoder)),
            "communication_scope": "logical tensor payload, upload AND download; transport/security overhead excluded",
            "simulation_only_not_a_private_networked_deployment": True,
            "privacy_guarantee": None, "backbone_adapters_trained": False,
            "rank_scope": "classifier after the frozen encoder; not LoRA inside I-JEPA"}
