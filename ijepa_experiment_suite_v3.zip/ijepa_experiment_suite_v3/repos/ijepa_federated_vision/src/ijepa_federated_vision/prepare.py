"""Explicit dataset preparation; runtime data are stored below /localdata."""
import argparse
from pathlib import Path
from .storage import Storage, path_under, ensure_writable_directory


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", choices=["cifar10", "cifar100"], default="cifar10")
    p.add_argument("--work-dir", type=Path)
    p.add_argument("--data-root", type=Path)
    p.add_argument("--root", type=Path)
    a = p.parse_args(argv)
    storage = Storage.create(a.work_dir, a.data_root)
    storage.configure_environment()
    a.root = path_under(a.root, storage.datasets)
    ensure_writable_directory(a.root)
    from torchvision.datasets import CIFAR10, CIFAR100
    cls = CIFAR10 if a.dataset == "cifar10" else CIFAR100
    for train in [True, False]:
        cls(str(a.root), train=train, download=True)
    print("Dataset preparation completed; existing valid data were retained.")


if __name__ == "__main__":
    main()
