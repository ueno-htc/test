"""Covariance-aware diagnostic controls, NOT a claim of a new FL algorithm.

Only sums, covariance-vector products and scalar validation errors are exchanged
in the modeled protocol. The implementation is a single-process simulation.
Logical float64 payload includes basis/statistics, local validation and final
readout. Encoder distribution, transport, privacy mechanisms are excluded.
"""
from __future__ import annotations
import numpy as np
import torch
from torch.nn import functional as F
from .common import classification_metrics


def orthogonal_columns(a: torch.Tensor, against: torch.Tensor | None = None) -> torch.Tensor:
    a = a.double()
    if against is not None and against.shape[1]:
        # Reorthogonalization avoids spurious rank from finite-precision projection.
        for _ in range(2):
            a = a - against @ (against.T @ a)
    if a.shape[1] == 0:
        return a
    u, s, _ = torch.linalg.svd(a, full_matrices=False)
    threshold = max(1e-12, float(s.max()) * 1e-9)
    return u[:, s > threshold]


def first_moments(x, y, groups, classes):
    d=x.shape[1]
    sums=torch.zeros(d,dtype=torch.float64)
    squares=torch.zeros_like(sums)
    xy=torch.zeros(d,classes,dtype=torch.float64)
    counts=torch.zeros(classes,dtype=torch.float64)
    n=0
    for idx in groups:
        a=x[idx].double();b=F.one_hot(y[idx],classes).double()
        sums+=a.sum(0);squares+=a.square().sum(0);xy+=a.T@b;counts+=b.sum(0);n+=len(idx)
    if n<2:raise ValueError('At least two training samples are required')
    mu=sums/n;prior=counts/n
    return {'mu':mu,'prior':prior,'rhs':xy-n*torch.outer(mu,prior),
            'diag':(squares-n*mu.square()).clamp_min(0),'n':n,
            'upload_bytes':len(groups)*8*(2*d+d*classes+classes+1)}


def covariance_action(x, groups, mean, basis):
    """Compute G Q without building/transmitting the d by d covariance matrix."""
    out=torch.zeros_like(basis,dtype=torch.float64)
    for idx in groups:
        a=x[idx].double()-mean
        out+=a.T@(a@basis)
    return out


def validation_select(x,y,val_groups,basis,mean,prior,gram,rhs,alphas):
    """Clients score all candidate readouts; the server receives scalar sums only.

    Local factors are float64. Test data are not accepted by this function.
    """
    best=None
    gram=(gram+gram.T)/2
    eig,v=torch.linalg.eigh(gram)
    eig=eig.clamp_min(0)
    proj=v.T@rhs
    for alpha in alphas:
        if alpha<=0:raise ValueError('Regularization must be positive')
        w=v@(proj/(eig[:,None]+float(alpha)))
        total=0.;count=0
        for idx in val_groups:
            z=(x[idx].double()-mean)@basis
            target=F.one_hot(y[idx],len(prior)).double()
            total+=float((z@w+prior-target).square().sum())
            count+=len(idx)*len(prior)
        error=total/max(1,count)
        if best is None or error<best[0]:best=(error,float(alpha),w)
    return best


def _score(w,b,x,y,groups,min_count):
    rows=[]
    for cid,idx in enumerate(groups):
        m=classification_metrics((x[idx].double()@w+b).float(),y[idx]) if len(idx) else {'n':0,'accuracy':None}
        rows.append({'client':cid,**m})
    active=[r for r in rows if r['n']]
    valid=[r['accuracy'] for r in active if r['n']>=min_count]
    return {'micro_accuracy':sum(r['n']*r['accuracy'] for r in active)/sum(r['n'] for r in active),
      'macro_client_accuracy':float(np.mean([r['accuracy'] for r in active])),
      'worst_client_accuracy_min_count':min(valid) if valid else None,
      'p10_client_accuracy_min_count':float(np.quantile(valid,.1)) if valid else None,
      'fairness_min_test_count':min_count,'fairness_eligible_clients':len(valid),'clients':rows}


def local_ridge_control(x,y,tx,ty,train_groups,val_groups,test_groups,alphas,classes,min_count):
    """Per-client optimally solved ridge, so Local-only is not limited to SGD."""
    rows=[];choices=[]
    for cid,(tr,va,te) in enumerate(zip(train_groups,val_groups,test_groups)):
        a=x[tr].double();target=F.one_hot(y[tr],classes).double()
        mean=a.mean(0);prior=target.mean(0);a=a-mean;target=target-prior
        eig,u=torch.linalg.eigh(a@a.T);eig=eig.clamp_min(0)
        aty=a.T@u;uty=u.T@target
        best=None
        for alpha in alphas:
            w=aty@(uty/(eig[:,None]+alpha));bias=prior-mean@w
            loss=float((x[va].double()@w+bias-F.one_hot(y[va],classes).double()).square().mean())
            if best is None or loss<best[0]:best=(loss,alpha,w,bias)
        loss,alpha,w,bias=best;choices.append({'client':cid,'alpha':alpha,'validation_mse':loss})
        metrics=classification_metrics((tx[te].double()@w+bias).float(),ty[te]) if len(te) else {'n':0,'accuracy':None}
        rows.append({'client':cid,**metrics})
    active=[r for r in rows if r['n']];valid=[r['accuracy'] for r in active if r['n']>=min_count]
    return {'method':'local_closed_form_ridge','diagnostic_baseline_not_new_method':True,
      'total_round_payload_bytes':0,'uplink_payload_bytes':0,'downlink_payload_bytes':0,
      'test':{'micro_accuracy':sum(r['n']*r['accuracy'] for r in active)/sum(r['n'] for r in active),
        'macro_client_accuracy':float(np.mean([r['accuracy'] for r in active])),
        'worst_client_accuracy_min_count':min(valid) if valid else None,
        'p10_client_accuracy_min_count':float(np.quantile(valid,.1)) if valid else None,'clients':rows},
      'validation_selection':choices,'privacy_guarantee':None}


def run_covariance_controls(x,y,tx,ty,train_groups,val_groups,test_groups,spec,classes):
    moments=first_moments(x,y,train_groups,classes)
    mu,prior,rhs,diag=[moments[k] for k in ['mu','prior','rhs','diag']]
    k=len(train_groups);d=x.shape[1];alphas=spec['ridge_alphas'];minimum=spec['fairness_min_test_count']
    rows=[];base=orthogonal_columns(rhs)
    if base.shape[1]==0:raise ValueError('No between-class signal in training data')
    limit=min(d,int(spec.get('covariance_max_rank',64)))
    steps=sorted(set(int(i) for i in spec.get('covariance_steps',[0,1,2,4])))
    if not steps or min(steps)<0:raise ValueError('Nonnegative covariance_steps required')
    def record(name,q,gq,upload,download,products,extra=None):
        val,alpha,coef=validation_select(x,y,val_groups,q,mu,prior,q.T@gq,q.T@rhs,alphas)
        w=q@coef;bias=prior-mu@w
        # Initial moments, basis traffic and covariance products are already counted.
        # Validation: M low-dimensional coefficients + alpha ids and M losses/counts.
        val_down=k*len(alphas)*8*(q.shape[1]*classes+classes+1)
        val_up=k*len(alphas)*16
        final_down=k*8*(q.shape[1]*classes+classes+1)
        test=_score(w,bias,tx,ty,test_groups,minimum)
        # G W computed from the already communicated GQ; no full covariance oracle.
        residual=rhs-gq@coef-alpha*w
        row={'method':name,'test':test,'rank':q.shape[1],
          'validation_selection':{'alpha':alpha,'source_validation_mse':val,'protocol':'client_scalar_loss_sums_only'},
          'uplink_payload_bytes':upload+val_up,'downlink_payload_bytes':download+val_down+final_down,
          'total_round_payload_bytes':upload+download+val_up+val_down+final_down,
          'fit_only_payload_bytes':upload+download,'validation_payload_bytes':val_up+val_down,
          'final_readout_payload_bytes':final_down,'covariance_action_rounds':products,
          'normal_equation_relative_residual':float(residual.norm()/rhs.norm().clamp_min(1e-12)),
          'diagnostic_baseline_not_new_method':True,'privacy_guarantee':None,
          'communication_accounting':'v3_fit_plus_client_validation_plus_final_float64_no_transport',
          'communication_not_directly_comparable_to_v2_fit_only_counts':True,
          'full_covariance_transmitted':False,'expanded_readout_used_only_for_evaluation':True,**(extra or {})}
        rows.append(row)
    # Variance-aware directions are a classical preconditioning diagnostic.
    q=orthogonal_columns(rhs/(diag+1.0)[:,None])[:,:limit]
    gq=covariance_action(x,train_groups,mu,q)
    common_down=k*8*(d+classes) # broadcast centering mean and class prior once
    record('diagonal_preconditioned_classmean_ridge',q,gq,
           moments['upload_bytes']+k*8*d*q.shape[1],common_down+k*8*d*q.shape[1],1)
    # Block Krylov span [B, GB, G^2 B, ...]. Known numerical construction, not new.
    q=base[:,:limit];gq=covariance_action(x,train_groups,mu,q);last=gq
    upload=moments['upload_bytes']+k*8*d*q.shape[1];download=common_down+k*8*d*q.shape[1]
    products=1
    for step in range(max(steps)+1):
        if step in steps:
            record(f'covariance_krylov_s{step}_ridge',q,gq,upload,download,products,{'enrichment_steps':step})
        if step==max(steps) or q.shape[1]>=limit:break
        new=orthogonal_columns(last,against=q)[:,:limit-q.shape[1]]
        if not new.shape[1]:break
        last=covariance_action(x,train_groups,mu,new)
        q=torch.cat([q,new],1);gq=torch.cat([gq,last],1)
        upload+=k*8*d*new.shape[1];download+=k*8*d*new.shape[1];products+=1
    if spec.get('local_closed_form_control',True):
        rows.append(local_ridge_control(x,y,tx,ty,train_groups,val_groups,test_groups,alphas,classes,minimum))
    return rows
