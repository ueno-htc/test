# Primary sources and implementation boundaries

References inherited from the original MVP review (2026-10-31); not a new literature survey.
No public model weights or datasets are bundled.

## [S1] I-JEPA
- Assran et al., Self-Supervised Learning from Images with a Joint-Embedding Predictive Architecture, CVPR 2023.
- Official code: https://github.com/facebookresearch/ijepa
- Paper: https://arxiv.org/abs/2301.08243
- Our use: frozen image encoder. We do not load or reproduce the original pretraining predictor.

## [S2] Hugging Face I-JEPA implementation and immutable checkpoint
- Official integration documentation: https://huggingface.co/docs/transformers/model_doc/ijepa
- Model: https://huggingface.co/facebook/ijepa_vith14_1k
- Pinned revision: https://huggingface.co/facebook/ijepa_vith14_1k/commit/f157467ea509bc356ff9f61fd3c0d840eec5e04e
- Processor: https://huggingface.co/facebook/ijepa_vith14_1k/blob/f157467ea509bc356ff9f61fd3c0d840eec5e04e/preprocessor_config.json
- Model config: https://huggingface.co/facebook/ijepa_vith14_1k/blob/f157467ea509bc356ff9f61fd3c0d840eec5e04e/config.json
- Model card license: CC-BY-NC-4.0. Check the exact upstream license and the terms of each dataset before commercial deployment.
- Public checkpoint execution has NOT been verified in the supplied CPU/offline environment.

## [S3] CIFAR-C
- Hendrycks and Dietterich, Benchmarking Neural Network Robustness to Common Corruptions and Perturbations, ICLR 2019.
- Official repository: https://github.com/hendrycks/robustness
- CIFAR-10-C archive: https://zenodo.org/records/2535967
- CIFAR-100-C archive: https://zenodo.org/records/3555552
- Our real-data loader uses the provided corruption arrays, not regenerated corruptions. Smoke images are explicitly unrelated to official CIFAR-C results.

## [S9] FedProx
- Li et al., Federated Optimization in Heterogeneous Networks, MLSys 2020.
- Official code: https://github.com/litian96/FedProx
- Paper: https://arxiv.org/abs/1812.06127
- Our full-head proximal baseline implements a local proximal penalty in this fixed-feature setup; published benchmark numbers are not directly comparable.

## [S10] FedAvg
- McMahan et al., Communication-Efficient Learning of Deep Networks from Decentralized Data, AISTATS 2017.
- https://proceedings.mlr.press/v54/mcmahan17a.html
- Our simulation performs sample-count-weighted aggregation in one process. It does not implement a distributed transport, secure aggregation, or differential privacy.

## [S11] Fixed-factor federated low-rank adaptation already exists
- Sun et al., Improving LoRA in Privacy-preserving Federated Learning, ICLR 2024 (FFA-LoRA).
- https://proceedings.iclr.cc/paper_files/paper/2024/hash/4e243e95c913b367775d71d7182b99d9-Abstract-Conference.html
- Consequence: fixing one low-rank factor is not novel. This MVP studies head-only fixed-feature controls, not LoRA inserted inside I-JEPA.

## [S12] Aggregation error in federated low-rank adaptation
- FedEx-LoRA: Exact Aggregation for Federated and Efficient Fine-Tuning of Large Language Models, ACL 2025.
- https://aclanthology.org/2025.acl-long.67/
- Official code: https://github.com/CERT-Lab/fedex-lora
- Our factor-averaging control intentionally exposes the distinction between averaging factors and averaging the resulting matrices. It is not a FedEx-LoRA reproduction.

