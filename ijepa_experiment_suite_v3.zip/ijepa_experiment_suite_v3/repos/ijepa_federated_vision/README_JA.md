# V2 update

This is a historical per-repository guide. For current commands and the enforced logs-only policy, read the suite-level `README_V2.md`. No trained `.pt` or export model is produced by v2.

---

# ijepa_federated_vision: ⑥ 非IID連合学習

このリポジトリは、このテーマだけを実行する独立版です。他のリポジトリや元の統合版には依存しません。

固定I-JEPAの前提と、元の実験・対照・評価手順を維持しています。物性推定研究とは独立したMVPです。

**公開checkpoint・実データ・GPUでの性能は未検証です。** CPUのMockによる動作確認と、I-JEPAの研究結果を区別してください。本番ロード失敗時にMockへ自動切替しません。

## 1. Dataset-only /localdata policy (v0.3)

Only input datasets live under `/localdata` (no extra `datasets/` suffix).
Model weights, feature/compiler caches, outputs and temporary files default to the
**current directory from which the script is invoked**, not the dataset directory.

```text
/localdata/                     # datasets only
  cifar-10-batches-py/
  CIFAR-10-C/
  oxford-iiit-pet/
  videos/video_manifest.jsonl
./models/huggingface/hub/        # shared public model cache
./models/torch/
./cache/ijepa_federated_vision/
./outputs/ijepa_federated_vision/
./artifacts/ijepa_federated_vision/
./tmp/ijepa_federated_vision/
```

`--data-root` > `DATASETS_ROOT` > `/localdata` selects input datasets.
`--work-dir` > `IJEPA_WORK_DIR` > caller cwd selects all other default paths.
`LOCALDATA_ROOT` and the former `--storage-root` option are retired.
The parent suite passes explicit absolute output paths for batch isolation.

```bash
bash run_all.sh dry-run
bash run_all.sh dry-run --data-root /localdata --work-dir "$PWD"
```

## 2. セットアップ

Python 3.10以上。WindowsではWSL/Linux上で `bash run_all.sh` を実行してください。

使用GPUに対応するPyTorchとtorchvisionを用意したうえで、このフォルダで実行します。

```bash
python -m pip install -e ".[real,test]"
```

CPUでソフトウェア検証だけを行う場合：

```bash
python -m pip install -e ".[test]"
bash run_all.sh tests -q
bash run_all.sh smoke
```

Current release verification is in the parent suite verification/ directory. Public-checkpoint/GPU execution remains unverified here.

### 公開checkpointと前処理

```text
model_id: facebook/ijepa_vith14_1k
revision: f157467ea509bc356ff9f61fd3c0d840eec5e04e
```

公式Hugging Faceリポジトリのコミットを固定しています。前処理は同じrevisionの `AutoImageProcessor` から読み込みます。ImageNetのmean/stdを手書きで代用しません。公式processorは224×224へのリサイズとmean/std=0.5を指定しています。

モデルID、解決されたrevision、前処理、dtype、ライブラリバージョンを記録します。ローカルモデルを使う場合は設定・重みファイルのSHA-256も記録します。元のI-JEPA predictorはこのHFエンコーダ経路では読み込みません。

公式モデルのカードには `CC-BY-NC-4.0` の表記があります。モデル重み・データは本ZIPに含めていません。利用時は配布元の条件を確認してください。

## 3. Commands

```bash
bash run_all.sh tests -q
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh smoke --seeds 0 1 2 --resume
bash run_all.sh check --expected-runs 3
bash run_all.sh report

# Real encoder; see the next section for data preparation.
bash run_all.sh real --device cuda --seeds 0 1 2

# No data/weight access or filesystem writes:
bash run_all.sh dry-run --config examples/override.yaml
```

`--tasks` は廃止しました。このリポジトリのテーマだけが実行されます。

設定は `src/ijepa_federated_vision/configs/` に同梱し、wheel単体でも利用できます。

`--resume` は完了済み実行のスキップであり、epochの途中再開ではありません。設定・コードが変わった場合は拒否します。

## 4. ⑥ 非IID連合学習

```bash
bash run_all.sh prepare --dataset cifar10 --root /localdata
bash run_all.sh real --device cuda --seeds 0 1 2

# 非IID度、rank、参加率の変更例
bash run_all.sh real --device cuda \
  --set federated.alpha=0.1 --set federated.rank=8 \
  --set federated.participation=1.0 --output ./outputs/ijepa_federated_vision/alpha01_r8
```

rankは `min(feature_dim, num_classes)` 以下です。訓練・testは同じclass-to-client確率を共有しますが、サンプルIDは独立です。各クライアントのvalidationも分離します。

特徴の正規化はサンプルごとのL2です。全クライアントの特徴を集めて標準化統計を推定しません。集中学習参照だけは明示的に全訓練特徴を使います。

固定基底方式では基底を共有し、係数だけを通信します。学習する両因子を別々に平均する方式も対照として実装しています。個人化バイアスは集約せず、その縮小係数は各クライアントのvalidationだけで選びます。

アップロードとダウンロードの両方を計上します。巨大な固定エンコーダの初回配布量は別項目です。通信量削減はI-JEPA推論の軽量化を意味しません。小さいtest集合でworst-clientを過大解釈しないよう、最低サンプル数と対象クライアント数を記録します。

## 5. Repository structure

```text
ijepa_federated_vision/
  run_all.sh
  pyproject.toml
  README_JA.md
  .env.example
  src/ijepa_federated_vision/
    configs/base.yaml
    configs/experiment.yaml
    cli.py
    storage.py
    encoder.py
    common.py
    federated.py
    prepare.py
    report.py
    check.py
  tests/
  examples/
  docs/RESEARCH_REVIEW_JA.md
  docs/SOURCES.md
  verification/TEST_REPORT_JA.md
```

共通機能は各リポジトリに同梱しています。元の統合版や親フォルダのPYTHONPATHは不要です。Pythonパッケージ名もすべて異なります。

## 6. 実行と結果解釈の注意

- 同一seedの繰り返しを独立試行として集計しません。1 seedの標準偏差は0ではなくnullです。
- `--set` は既存の設定キーだけを変更でき、タイプミスしたキーはエラーになります。
- キャッシュの更新や大規模データを含め、絶対的な所要時間・GPUメモリ量は未測定です。初回はsubset、encoder batch size 1〜8から開始してください。
- `.pt` を読み込む際は、このパッケージのコードが作った信頼できるファイルを使用してください。ツールの読込は `weights_only=True` を使っています。
- 特定手法が勝つようなハイパーパラメータ探索、テスト結果によるモデル選択は実施していません。
- 本番の論文比較では、checkpoint・パラメータ数・sourceへのアクセス・更新予算・実測時間を揃える必要があります。

### オフライン／社内プロキシ環境

信頼された経路でcheckpoint一式をローカルディレクトリに配置して使用できます。TLS検証の無効化は行いません。

```bash
bash run_all.sh real --device cuda \
  --set encoder.model_id=./models/ijepa_vith14_1k \
  --set encoder.local_files_only=true \
  --set encoder.batch_size=2
```

