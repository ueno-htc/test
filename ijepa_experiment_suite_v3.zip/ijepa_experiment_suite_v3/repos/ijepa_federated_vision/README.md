# V2 update

This is a historical per-repository guide. For current commands and the enforced logs-only policy, read the suite-level `README_V2.md`. No trained `.pt` or export model is produced by v2.

---

# ijepa_federated_vision v0.3

Independent single-theme MVP, orchestrated by the parent suite when needed.

Datasets default to `/localdata` directly. Everything else defaults to caller cwd.
Use `--data-root` and `--work-dir` separately. Old `LOCALDATA_ROOT` is not used.

```bash
python -m pip install -e ".[real,test]"
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh real --device cuda --seeds 0 1 2
```

See README_JA.md for the experimental protocol and docs/RESEARCH_REVIEW_JA.md for limitations.
The parent `run_all.sh` runs all five tasks and creates one `review_bundle.zip`.
