# Path policy v0.3

/localdata contains datasets only (no automatic /datasets suffix).
All model downloads, caches, logs, outputs, exported models and temporary files default to the caller cwd.
Use --data-root for datasets and --work-dir for generated files.
The old --storage-root / LOCALDATA_ROOT option is intentionally not retained.
Old dataset locations can be used via --data-root /localdata/datasets, without moving files.
Old completed runs have a different code fingerprint; do not resume them with this release.
The parent suite orchestrates independent child processes; these repositories remain standalone.
