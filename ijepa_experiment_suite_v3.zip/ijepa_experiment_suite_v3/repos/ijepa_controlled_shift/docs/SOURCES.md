# Primary sources and implementation boundaries

References inherited from the original MVP review (2026-10-31); not a new literature survey.
No public model weights or datasets are bundled.

## [S1] I-JEPA
- Assran et al., Self-Supervised Learning from Images with a Joint-Embedding Predictive Architecture, CVPR 2023.
- Official code: https://github.com/facebookresearch/ijepa
- Paper: https://arxiv.org/abs/2301.08243
- Our use: frozen image encoder. We do not load or reproduce the original pretraining predictor.

## [S2] Hugging Face I-JEPA implementation and immutable checkpoint
- Official integration documentation: https://huggingface.co/docs/transformers/model_doc/ijepa
- Model: https://huggingface.co/facebook/ijepa_vith14_1k
- Pinned revision: https://huggingface.co/facebook/ijepa_vith14_1k/commit/f157467ea509bc356ff9f61fd3c0d840eec5e04e
- Processor: https://huggingface.co/facebook/ijepa_vith14_1k/blob/f157467ea509bc356ff9f61fd3c0d840eec5e04e/preprocessor_config.json
- Model config: https://huggingface.co/facebook/ijepa_vith14_1k/blob/f157467ea509bc356ff9f61fd3c0d840eec5e04e/config.json
- Model card license: CC-BY-NC-4.0. Check the exact upstream license and the terms of each dataset before commercial deployment.
- Public checkpoint execution has NOT been verified in the supplied CPU/offline environment.

## [S13] PhysVid
- PhysVid: Physics Aware Local Conditioning for Generative Video Models.
- Project: https://5aurabhpathak.github.io/PhysVid/
- This project motivated controllable interventions only. Our analytic free-fall/linear-drag benchmark is independent: no video generator, no PhysVid reproduction, and no claim of discovering general physical laws.

