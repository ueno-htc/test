from __future__ import annotations

import numpy as np


def analytic_trajectory(x0: np.ndarray, velocity: np.ndarray, gravity: float,
                        times: np.ndarray, drag: float = 0.0) -> np.ndarray:
    """Exact unit-mass ballistic / linear-drag motion. Positive y points downward.

    Mass is deliberately not a target: it is not identifiable in free fall.
    No collisions, hidden clipping, or semi-implicit integration are used.
    """
    t = np.asarray(times, dtype=np.float64)[:, None]
    g = np.array([0.0, gravity])
    if drag == 0:
        return x0 + velocity * t + .5 * g * t * t
    if drag < 0:
        raise ValueError("drag must be nonnegative")
    q = -np.expm1(-drag * t) / drag
    return x0 + velocity * q + g / drag * (t - q)


def render_trajectory(states: np.ndarray, style_seed: int, size: int,
                      visual_shift: bool = False) -> np.ndarray:
    """Subpixel soft disk with background/color interventions independent of gravity."""
    rng = np.random.default_rng(style_seed)
    yy, xx = np.meshgrid((np.arange(size) + .5) / size, (np.arange(size) + .5) / size, indexing="ij")
    if visual_shift:
        texture = .5 + .5 * np.sin(40 * xx + rng.uniform(0, 6)) * np.cos(35 * yy)
        background = np.repeat((.16 + .18 * texture)[..., None], 3, axis=-1)
        color = np.array([.08, .9, .6])
    else:
        background = np.broadcast_to(rng.uniform(.01, .09, 3), (size, size, 3)).copy()
        color = np.array([.95, .25, .1])
    images = []
    radius = .065
    for x, y in states:
        distance = np.sqrt((xx - x) ** 2 + (yy - y) ** 2)
        alpha = np.clip((radius - distance) * size + .5, 0, 1)[..., None]
        image = background * (1 - alpha) + color * alpha
        images.append(np.round(np.clip(image, 0, 1) * 255).astype(np.uint8))
    return np.stack(images)


def physics_dataset(n: int, seed: int, observed: int, future: int, size: int,
                    dt: float, dynamics_ood: bool = False, visual_shift: bool = False,
                    law_shift: bool = False, terminal_matched: bool = False) -> dict:
    if terminal_matched and n % 2:
        raise ValueError("terminal_matched requires an even sample count for disjoint pairs")
    images, states, gravity, ids, group_ids = [], [], [], [], []
    times = np.arange(observed + future) * dt
    for i in range(n):
        scene = seed + i
        group_id = seed + i // 2 if terminal_matched else scene
        rng = np.random.default_rng(group_id)
        x0 = rng.uniform([.25, .18], [.65, .4])
        velocity = rng.uniform([-.1, -.035], [.1, .035])
        q = rng.uniform()
        g = .24 + .10 * q if dynamics_ood else .08 + .10 * q
        drag = .8 if law_shift else 0.0
        if terminal_matched:
            # Both members have exactly the same last observed position and style,
            # but opposite terminal velocities. Ground truth is not supplied to any
            # image-input method. Backward evaluation is an exact analytic solution.
            terminal_position = rng.uniform([.3, .25], [.65, .45])
            terminal_velocity = np.array([rng.uniform(.08, .14), rng.uniform(.015, .035)])
            terminal_velocity *= 1 if i % 2 == 0 else -1
            trajectory = analytic_trajectory(terminal_position, terminal_velocity, g,
                                             times - times[observed-1], drag)
        else:
            trajectory = analytic_trajectory(x0, velocity, g, times, drag)
        if np.any(trajectory < .07) or np.any(trajectory > .93):
            raise ValueError("Trajectory leaves FOV: reduce dt/length or initial state ranges")
        video = render_trajectory(trajectory, group_id + 500000, size, visual_shift)
        images.append(video)
        states.append(trajectory)
        gravity.append(g)
        ids.append(scene)
        group_ids.append(group_id)
    return {"images": np.stack(images), "states": np.stack(states).astype(np.float32),
            "gravity": np.asarray(gravity, dtype=np.float32), "scene_ids": np.asarray(ids),
            "times": times.astype(np.float32), "drag": .8 if law_shift else 0.0,
            "visual_shift": visual_shift, "dynamics_ood": dynamics_ood,
            "group_ids": np.asarray(group_ids), "terminal_matched": terminal_matched}


def fit_quadratic(observed: np.ndarray, observed_times: np.ndarray,
                  future_times: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Known ballistic law prior fitted per sequence, not a learned physical law."""
    a = np.stack([np.ones_like(observed_times), observed_times, .5 * observed_times ** 2], -1)
    coefficients = np.einsum("kt,ntd->nkd", np.linalg.pinv(a), observed)
    b = np.stack([np.ones_like(future_times), future_times, .5 * future_times ** 2], -1)
    return np.einsum("tk,nkd->ntd", b, coefficients), coefficients[:, 2]
