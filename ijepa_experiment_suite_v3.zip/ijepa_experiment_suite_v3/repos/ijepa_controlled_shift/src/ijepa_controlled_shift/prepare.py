"""Prepare storage only. Synthetic data are generated deterministically during a run."""
import argparse
import json
from pathlib import Path
from .storage import Storage, ensure_writable_directory


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work-dir', type=Path)
    p.add_argument('--data-root', type=Path)
    a = p.parse_args(argv)
    storage = Storage.create(a.work_dir, a.data_root)
    storage.configure_environment()
    for path in [storage.datasets, storage.generated, storage.cache, storage.outputs, storage.artifacts]:
        ensure_writable_directory(path)
    print(json.dumps(storage.snapshot(), indent=2))
    print('No external dataset downloaded. Synthetic samples are generated from the run configuration.')


if __name__ == '__main__':
    main()
