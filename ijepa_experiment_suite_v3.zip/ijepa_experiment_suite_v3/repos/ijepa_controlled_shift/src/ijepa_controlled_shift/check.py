"""Check this repository's saved runs; never reinterpret smoke numbers as I-JEPA evidence."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
from .common import code_digest, dump_json
from .storage import PROJECT, Storage, path_under


def finite_numbers(value):
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError('Non-finite metric')
    elif isinstance(value, dict):
        for item in value.values():
            finite_numbers(item)
    elif isinstance(value, list):
        for item in value:
            finite_numbers(item)


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--work-dir', type=Path)
    p.add_argument('--data-root', type=Path)
    p.add_argument('--root', type=Path, help='Default: this project output root/smoke')
    p.add_argument('--expected-runs', type=int, default=3)
    p.add_argument('--output', type=Path)
    args = p.parse_args(argv)
    storage = Storage.create(args.work_dir, args.data_root)
    root = path_under(args.root, storage.outputs / 'smoke', storage.outputs)
    paths = sorted(root.rglob('result.json'))
    if len(paths) != args.expected_runs:
        raise ValueError(f'Expected {args.expected_runs} completed runs, got {len(paths)} below {root}')
    seeds = set()
    evidence = set()
    for path in paths:
        result = json.loads(path.read_text())
        finite_numbers(result)
        if result['status'] != 'complete' or result['project'] != PROJECT:
            raise ValueError(f'Invalid or foreign result: {path}')
        if result['seed'] in seeds:
            raise ValueError('Repeated seed is not independent evidence')
        seeds.add(result['seed']); evidence.add(result['evidence_level'])
        saved_env = json.loads((path.parent / 'environment.json').read_text())
        if saved_env['code_sha256'] != code_digest():
            raise ValueError('Source changed since run; verification must be repeated')
        if result['image_encoder_updated'] or result['law_discovery_claim']:
            raise ValueError('Incorrect physics experiment boundary')
    if len(evidence) != 1:
        raise ValueError('Do not combine smoke and public-checkpoint evidence')
    report = {'project': PROJECT, 'runs': len(paths), 'seeds': sorted(seeds),
              'evidence_level': next(iter(evidence)), 'finite_metrics': True,
              'source_code_sha256': code_digest(), 'run_root': str(root)}
    output = path_under(args.output, storage.outputs / 'integrity.json', storage.outputs)
    dump_json(output, report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
