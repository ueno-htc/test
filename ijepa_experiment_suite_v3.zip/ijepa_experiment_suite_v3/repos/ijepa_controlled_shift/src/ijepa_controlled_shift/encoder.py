from __future__ import annotations

import math
import hashlib
import importlib.metadata
import time
import tempfile
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch import nn
from torch.nn import functional as F

from .common import array_digest, digest, dump_json, sync


class MockEncoder(nn.Module):
    """Deterministic untrained image features for SOFTWARE tests, never I-JEPA results."""
    def __init__(self, device: torch.device):
        super().__init__()
        generator = torch.Generator().manual_seed(9183)
        self.register_buffer("projection", torch.randn(8, 32, generator=generator) / math.sqrt(8))
        self.hidden_size = 32
        self.device = device
        self.provenance = {"kind": "MOCK_NOT_IJEPA", "version": 2, "hidden_size": 32,
                           "preprocessing": "RGB adaptive pooling 8x8", "torch_version": str(torch.__version__)}
        self.to(device).eval()

    @torch.no_grad()
    def encode(self, images: np.ndarray, grid: int = 1, spatial: bool = False) -> torch.Tensor:
        x = torch.from_numpy(np.ascontiguousarray(images)).permute(0, 3, 1, 2).float().to(self.device) / 255
        x = F.adaptive_avg_pool2d(x, (8, 8))
        ys, xs = torch.meshgrid(torch.linspace(-1, 1, 8, device=self.device),
                               torch.linspace(-1, 1, 8, device=self.device), indexing="ij")
        intensity = x.mean(1, keepdim=True)
        features = torch.cat([x, x.square(), intensity * xs, intensity * ys], dim=1)
        z = torch.einsum("bdhw,dk->bkhw", features, self.projection)
        if spatial:
            return F.adaptive_avg_pool2d(z, (grid, grid)).cpu()
        return F.adaptive_avg_pool2d(z, (grid, grid)).flatten(1).cpu()


class FrozenIJEPA(nn.Module):
    """Public encoder only. Its original predictor is NOT implicitly reused or trained."""
    def __init__(self, cfg: dict, device: torch.device):
        super().__init__()
        try:
            from transformers import AutoImageProcessor, IJepaModel
        except ImportError as exc:
            raise RuntimeError("Install real dependencies: parent suite: bash run_all.sh setup; standalone repo: pip install -e '.[real,test]'") from exc
        self.device = device
        model_id = cfg["model_id"]
        revision = cfg.get("revision")
        local = Path(model_id).is_dir()
        if not local and (not revision or revision in {"main", "master"}):
            raise ValueError("Pin an immutable checkpoint revision, not main/master")
        kwargs = {"local_files_only": cfg.get("local_files_only", False)}
        if cfg.get("cache_dir"):
            kwargs["cache_dir"] = cfg["cache_dir"]
        if not local:
            kwargs["revision"] = revision
        dtype_name = cfg.get("dtype", "float32")
        self.dtype = getattr(torch, dtype_name)
        if self.dtype == torch.float16 and device.type == "cpu":
            raise ValueError("float16 CPU extraction is unsupported here; use float32")
        self.processor = AutoImageProcessor.from_pretrained(model_id, use_fast=False, **kwargs)
        if getattr(self.processor, "do_center_crop", False):
            raise ValueError("Center cropping breaks dense alignment; use a square-resize processor")
        self.model = IJepaModel.from_pretrained(model_id, torch_dtype=self.dtype, **kwargs).to(device)
        self.model.requires_grad_(False).eval()
        self.hidden_size = self.model.config.hidden_size
        resolved = getattr(self.model.config, "_commit_hash", None) or revision
        local_hashes = None
        if local:
            local_hashes = {}
            for p in sorted(Path(model_id).glob("*")):
                if p.is_file() and p.suffix in {".json", ".safetensors", ".bin"}:
                    h = hashlib.sha256()
                    with p.open("rb") as f:
                        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
                            h.update(chunk)
                    local_hashes[p.name] = h.hexdigest()
        self.provenance = {
            "kind": "PUBLIC_FROZEN_IJEPA", "model_id": model_id,
            "requested_revision": revision, "resolved_revision": resolved,
            "local_file_sha256": local_hashes, "dtype": dtype_name,
            "hidden_size": self.hidden_size, "processor": self.processor.to_dict(),
            "architecture": "IJepaModel", "source_predictor_loaded": False,
            "transformers_version": importlib.metadata.version("transformers"),
            "torch_version": str(torch.__version__),
        }

    def train(self, mode: bool = True):
        super().train(False)
        self.model.eval()
        return self

    @torch.no_grad()
    def encode(self, images: np.ndarray, grid: int = 1, spatial: bool = False) -> torch.Tensor:
        self.model.eval()
        inputs = self.processor(images=[Image.fromarray(im) for im in images], return_tensors="pt")
        inputs = {k: v.to(self.device, dtype=self.dtype) for k, v in inputs.items()}
        tokens = self.model(**inputs).last_hidden_state
        b, n, d = tokens.shape
        side = math.isqrt(n)
        if side * side != n:
            raise ValueError(f"Expected square patch tokens without CLS; got {n}")
        z = tokens.transpose(1, 2).reshape(b, d, side, side).float()
        z = F.adaptive_avg_pool2d(z, (grid, grid))
        return (z if spatial else z.flatten(1)).cpu()


def make_encoder(cfg: dict, device: torch.device):
    if cfg["encoder"]["backend"] == "mock":
        if not cfg.get("smoke", False):
            raise ValueError("Mock encoder is permitted only in explicit --smoke mode")
        return MockEncoder(device)
    if cfg["encoder"]["backend"] != "hf":
        raise ValueError("Unknown encoder backend")
    return FrozenIJEPA(cfg["encoder"], device)


class FeatureCache:
    """Content-addressed cache; data pixels, processor, checkpoint, and pooling are keyed."""
    def __init__(self, root: Path, encoder, batch_size: int = 8):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.encoder = encoder
        self.batch_size = batch_size
        self.events: list[dict] = []

    def get(self, images: np.ndarray, grid: int = 1, spatial: bool = False) -> torch.Tensor:
        if images.dtype != np.uint8 or images.ndim != 4 or images.shape[-1] != 3 or len(images) == 0:
            raise ValueError("Expected nonempty uint8 NHWC RGB images")
        implementation_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        spec = {"cache_version": 4, "encoder_implementation_sha256": implementation_sha,
                "pixels_sha256": array_digest(images),
                "encoder": self.encoder.provenance, "grid": grid, "spatial": spatial}
        key = digest(spec)
        path = self.root / f"{key}.npz"
        start = time.perf_counter()
        hit = path.exists()
        if hit:
            with np.load(path, allow_pickle=False) as f:
                if str(f["key"]) != key:
                    raise RuntimeError("Cache key mismatch")
                z = torch.from_numpy(f["features"].copy()).float()
        else:
            parts = []
            for i in range(0, len(images), self.batch_size):
                parts.append(self.encoder.encode(images[i:i + self.batch_size], grid, spatial))
            z = torch.cat(parts).float()
            if not torch.isfinite(z).all():
                raise FloatingPointError("Non-finite encoder output")
            with tempfile.NamedTemporaryFile(dir=self.root, prefix=key + ".", suffix=".tmp", delete=False) as f:
                temp = Path(f.name)
                try:
                    np.savez_compressed(f, features=z.numpy(), key=np.array(key))
                except Exception:
                    temp.unlink(missing_ok=True)
                    raise
            temp.replace(path)
            dump_json(path.with_suffix(".json"), spec)
        if len(z) != len(images) or not torch.isfinite(z).all():
            raise ValueError("Corrupt feature cache: invalid length or non-finite entries")
        sync(self.encoder.device)
        self.events.append({"key": key, "cache_hit": hit, "n_images": len(images),
                            "wall_seconds": time.perf_counter() - start})
        return z
