"""Flatten completed run metrics without mixing MOCK and I-JEPA evidence."""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from .storage import PROJECT, Storage, path_under


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--work-dir", type=Path)
    p.add_argument("--data-root", type=Path)
    p.add_argument("--root", type=Path)
    p.add_argument("--output", type=Path)
    a = p.parse_args(argv)
    storage = Storage.create(a.work_dir, a.data_root)
    a.root = path_under(a.root, storage.outputs)
    a.output = path_under(a.output, storage.outputs / "summary.csv", storage.outputs)
    if not a.root.is_dir():
        raise FileNotFoundError(f"Result root does not exist: {a.root}")
    rows = []
    for path in sorted(a.root.rglob("result.json")):
        r = json.loads(path.read_text())
        if r.get("project") != PROJECT:
            raise ValueError(f"Foreign repository result: {path}")
        if r.get("status") != "complete":
            continue
        for rec in r.get("records", []):
            name = rec.get("name", rec.get("method", "unknown"))
            if "hard_update_cap" in rec:
                name += f"_budget{rec['hard_update_cap']}"
            if "condition" in rec:
                name += "_" + rec["condition"]
            metrics = rec.get("prequential", rec.get("test", rec))
            for key in ["accuracy", "micro_accuracy", "worst_client_accuracy_min_count", "position_rmse", "ece"]:
                value = metrics.get(key)
                if isinstance(value, (int, float)):
                    rows.append({"evidence": r["evidence_level"], "theme": r["theme"], "seed": r["seed"],
                                 "method": name, "metric": key, "value": value})
        for name, metrics in r.get("selected_test_metrics", {}).items():
            rows.append({"evidence": r["evidence_level"], "theme": r["theme"], "seed": r["seed"],
                         "method": name, "metric": "miou", "value": metrics["miou"]})
    a.output.parent.mkdir(parents=True, exist_ok=True)
    with a.output.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["evidence", "theme", "seed", "method", "metric", "value"])
        w.writeheader()
        w.writerows(rows)
    grouped = defaultdict(dict)
    for row in rows:
        key = tuple(row[k] for k in ["evidence", "theme", "method", "metric"])
        seed = row["seed"]
        if seed in grouped[key]:
            raise ValueError(f"Duplicate seed for comparison {key}; do not count repeated runs as independent")
        grouped[key][seed] = row["value"]
    aggregates = []
    for key, values in grouped.items():
        v = list(values.values())
        aggregates.append({**dict(zip(["evidence", "theme", "method", "metric"], key)),
                           "independent_seeds": len(v), "mean": float(np.mean(v)),
                           "sample_std": float(np.std(v, ddof=1)) if len(v) > 1 else None})
    a.output.with_suffix(".json").write_text(json.dumps(aggregates, indent=2, allow_nan=False))
    print(f"Wrote {len(rows)} metrics and {len(aggregates)} seed summaries; null SD means n=1, not zero variance.")


if __name__ == "__main__":
    main()
