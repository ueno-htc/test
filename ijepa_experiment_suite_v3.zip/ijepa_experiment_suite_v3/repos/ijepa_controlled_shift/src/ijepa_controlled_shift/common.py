from __future__ import annotations

import copy
import hashlib
import importlib.metadata
import json
import os
import platform
import random
import time
from pathlib import Path
from typing import Any, Callable

import numpy as np
import psutil
import torch
from torch import nn
from torch.nn import functional as F


def seed_all(seed: int, threads: int = 1) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(threads)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    # Deterministic CUDA linear algebra also requires the environment setting in run_all.sh.
    torch.use_deterministic_algorithms(True, warn_only=True)


def device_of(value: str) -> torch.device:
    value = "cuda" if value == "auto" and torch.cuda.is_available() else value
    value = "cpu" if value == "auto" else value
    d = torch.device(value)
    if d.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Pass --device cpu for smoke tests.")
    return d


def serializable(x: Any) -> Any:
    if isinstance(x, dict):
        return {str(k): serializable(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [serializable(v) for v in x]
    if isinstance(x, Path):
        return str(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().tolist()
    return x


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(serializable(data), indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temp, path)


def digest(data: Any) -> str:
    return hashlib.sha256(json.dumps(serializable(data), sort_keys=True).encode()).hexdigest()


def array_digest(x: np.ndarray) -> str:
    h = hashlib.sha256()
    h.update(str((x.shape, x.dtype)).encode())
    a = np.ascontiguousarray(x).view(np.uint8).reshape(-1)
    for i in range(0, a.size, 4 * 1024 * 1024):
        h.update(memoryview(a[i:i + 4 * 1024 * 1024]))
    return h.hexdigest()


def code_digest() -> str:
    h = hashlib.sha256()
    for p in sorted(Path(__file__).parent.glob("*.py")):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def environment() -> dict:
    versions = {}
    for name in ["torch", "torchvision", "transformers", "numpy", "Pillow", "pytest"]:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return {
        "python": platform.python_version(), "platform": platform.platform(),
        "processor": platform.processor(), "versions": versions,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU",
        "torch_threads": torch.get_num_threads(), "code_sha256": code_digest(),
    }


def sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def benchmark(fn: Callable, device: torch.device, warmup: int = 10, repeats: int = 30,
              scope: str = "forward") -> dict:
    if repeats < 2 or warmup < 0:
        raise ValueError("Benchmark requires repeats >= 2 and warmup >= 0")
    with torch.inference_mode():
        for _ in range(warmup):
            fn()
        sync(device)
        baseline = torch.cuda.memory_allocated(device) if device.type == "cuda" else None
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        times = []
        for _ in range(repeats):
            sync(device)
            start = time.perf_counter()
            fn()
            sync(device)
            times.append((time.perf_counter() - start) * 1000)
    peak = torch.cuda.max_memory_allocated(device) if device.type == "cuda" else None
    return {
        "scope": scope, "runtime": "pytorch_eager", "device": str(device),
        "warmup": warmup, "repeats": repeats, "batch_size": 1,
        "latency_median_ms": float(np.median(times)),
        "latency_p95_ms": float(np.percentile(times, 95)),
        "latency_samples_ms": times,
        "cuda_peak_allocated_bytes": peak,
        "cuda_incremental_peak_bytes": None if peak is None else peak - baseline,
        "cpu_rss_after_bytes_NOT_peak": psutil.Process().memory_info().rss,
        "threads": torch.get_num_threads(),
    }


def parameter_bytes(model: nn.Module) -> int:
    return sum(t.numel() * t.element_size() for t in model.state_dict().values())


def parameter_count(model: nn.Module, trainable: bool = False) -> int:
    return sum(p.numel() for p in model.parameters() if not trainable or p.requires_grad)


class Standardizer:
    """Fit only on training features; no target-stream statistics are fitted here."""
    def fit(self, x: torch.Tensor) -> "Standardizer":
        flat = x.reshape(-1, x.shape[-1]).float()
        self.mean = flat.mean(0)
        self.std = flat.std(0, unbiased=False).clamp_min(1e-3)
        return self

    def transform(self, x: torch.Tensor) -> torch.Tensor:
        return (x.float() - self.mean.to(x.device)) / self.std.to(x.device)

    def state(self) -> dict:
        return {"mean": self.mean, "std": self.std}


def classification_metrics(logits: torch.Tensor, labels: torch.Tensor, bins: int = 15) -> dict:
    logits, labels = logits.detach().cpu(), labels.detach().cpu().long()
    if len(labels) == 0:
        raise ValueError("Cannot score an empty split")
    prob = logits.softmax(-1)
    conf, pred = prob.max(-1)
    correct = pred.eq(labels)
    ece = 0.0
    for i in range(bins):
        mask = (conf >= i / bins) & (conf < (i + 1) / bins if i < bins - 1 else conf <= 1)
        if mask.any():
            ece += float(mask.float().mean() * (conf[mask].mean() - correct[mask].float().mean()).abs())
    return {"n": len(labels), "accuracy": correct.float().mean().item(),
            "nll": F.cross_entropy(logits, labels).item(), "ece": ece}


def train_supervised(model: nn.Module, x: torch.Tensor, y: torch.Tensor,
                     vx: torch.Tensor, vy: torch.Tensor, *, device: torch.device,
                     epochs: int, batch_size: int, lr: float, seed: int,
                     regression: bool = False, weight_decay: float = 1e-4) -> dict:
    """Validation-only early model selection. Test arrays are never accepted."""
    if not len(x) or not len(vx):
        raise ValueError("Training and validation splits must be nonempty")
    model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    loss_fn = F.mse_loss if regression else F.cross_entropy
    generator = torch.Generator().manual_seed(seed)
    best, best_state, history = float("inf"), None, []
    for epoch in range(epochs):
        model.train()
        permutation = torch.randperm(len(x), generator=generator)
        total = 0.0
        for idx in permutation.split(batch_size):
            optimizer.zero_grad(set_to_none=True)
            loss = loss_fn(model(x[idx].to(device)), y[idx].to(device))
            if not torch.isfinite(loss):
                raise FloatingPointError("Non-finite training loss")
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            total += float(loss.detach()) * len(idx)
        model.eval()
        with torch.no_grad():
            validation = sum(float(loss_fn(model(a.to(device)), b.to(device))) * len(a)
                             for a, b in zip(vx.split(batch_size), vy.split(batch_size))) / len(vx)
        history.append({"epoch": epoch, "train_loss": total / len(x), "val_loss": validation})
        if validation < best:
            best = validation
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    if best_state is None:
        raise RuntimeError("No model trained; epochs must be positive")
    model.load_state_dict(best_state)
    model.eval()
    return {"best_val_loss": best, "history": history}


@torch.no_grad()
def predict(model: nn.Module, x: torch.Tensor, device: torch.device, batch_size: int = 128) -> torch.Tensor:
    model.eval()
    return torch.cat([model(a.to(device)).detach().cpu() for a in x.split(batch_size)])


def split_indices(n: int, val_fraction: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    if n < 3 or not 0 < val_fraction < 1:
        raise ValueError("Invalid split size")
    p = np.random.default_rng(seed).permutation(n)
    nv = min(n - 1, max(1, int(round(n * val_fraction))))
    return p[nv:], p[:nv]


def save_checkpoint(path: Path, model: nn.Module, **metadata: Any) -> None:
    """LOGS ONLY. Best weights stay in RAM; no .pt/.pth/model arrays are written."""
    dump_json(path.with_suffix(".model_log.json"), {
        "weights_saved": False, "artifact_policy": "logs_only_v2",
        "model_class": type(model).__name__, "parameters": parameter_count(model),
        "trainable_parameters": parameter_count(model, True),
        "hypothetical_parameter_bytes": parameter_bytes(model),
        "metadata_keys": sorted(metadata),
    })


def log_tensor_payload(path: Path, payload: dict) -> None:
    """Record shapes/types only, never tensor contents or model parameters."""
    def describe(value):
        if isinstance(value, torch.Tensor):
            return {"shape": list(value.shape), "dtype": str(value.dtype)}
        if isinstance(value, dict):
            return {k: describe(v) for k, v in value.items()}
        return type(value).__name__
    dump_json(path.with_suffix(".model_log.json"), {
        "weights_saved": False, "artifact_policy": "logs_only_v2", "structure": describe(payload)})


def dump_jsonl(path: Path, rows) -> None:
    """Compressed text logs, not binary weights/features. Stream one record at a time."""
    import gzip
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(serializable(row), allow_nan=False) + "\n")


def paired_bootstrap(values: np.ndarray, seed: int, resamples: int = 1000) -> dict:
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or not len(values):
        raise ValueError("Expected nonempty per-scene differences")
    rng = np.random.default_rng(seed)
    means = np.array([rng.choice(values, len(values), replace=True).mean() for _ in range(resamples)])
    return {"mean": float(values.mean()), "ci95_low": float(np.quantile(means, .025)),
            "ci95_high": float(np.quantile(means, .975)), "n_independent_scenes": len(values)}
