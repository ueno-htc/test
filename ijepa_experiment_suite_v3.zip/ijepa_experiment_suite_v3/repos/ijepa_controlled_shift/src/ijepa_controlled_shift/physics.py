from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch import nn

from .common import (Standardizer, dump_json, paired_bootstrap, predict,
                     save_checkpoint, train_supervised, log_tensor_payload, dump_jsonl)
from .physics_data import physics_dataset, fit_quadratic


class MLP(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, hidden: int):
        super().__init__()
        self.trunk = nn.Sequential(nn.Flatten(1), nn.Linear(input_dim, hidden), nn.GELU(), nn.LayerNorm(hidden))
        self.head = nn.Linear(hidden, output_dim)

    def forward(self, x):
        return self.head(self.trunk(x))


class RidgeReadout:
    """Dual ridge solve; avoids a D x D inverse for high-dimensional frozen features."""
    def fit(self, x: torch.Tensor, y: torch.Tensor, alpha: float):
        x, y = x.flatten(1).double(), y.flatten(1).double()
        self.xmean, self.ymean = x.mean(0), y.mean(0)
        a, b = x - self.xmean, y - self.ymean
        scale = max(1, a.shape[1])
        kernel = a @ a.T / scale
        system = kernel + alpha * torch.eye(len(a), dtype=a.dtype)
        self.weights = a.T @ torch.linalg.solve(system, b) / scale
        return self

    def predict(self, x: torch.Tensor):
        return ((x.flatten(1).double() - self.xmean) @ self.weights + self.ymean).float()

    def state(self):
        return {"weights": self.weights.float(), "xmean": self.xmean.float(), "ymean": self.ymean.float()}


def choose_ridge(x, y, vx, vy, alphas):
    candidates = []
    for alpha in alphas:
        model = RidgeReadout().fit(x, y, alpha)
        error = float((model.predict(vx) - vy.flatten(1)).square().mean())
        candidates.append((error, alpha, model))
    error, alpha, model = min(candidates, key=lambda a: a[0])
    return model, {"alpha": alpha, "val_mse": error}


class TrainPCA:
    """Train-only unwhitened PCA; compression control for the SSL bottleneck."""
    def fit(self, x: torch.Tensor, rank: int):
        a = x.flatten(1).double()
        self.mean = a.mean(0)
        a = a - self.mean
        gram = a @ a.T
        values, vectors = torch.linalg.eigh(gram)
        valid = torch.where(values > max(1e-10, float(values.max()) * 1e-10))[0]
        if not len(valid):
            raise ValueError("PCA training features have zero rank")
        chosen = valid[-min(rank, len(valid)):]
        self.basis = a.T @ (vectors[:, chosen] / values[chosen].sqrt()[None])
        return self
    def transform(self, x):
        return ((x.flatten(1).double()-self.mean) @ self.basis).float()


def ablation_context(x: torch.Tensor, kind: str, seed: int):
    if kind == "lastframe_SSL":
        return x[:, -1:].expand_as(x).clone()
    if kind == "shuffled_time_SSL":
        # One deterministic permutation per scene. Same seed across paired test conditions.
        rng = np.random.default_rng(seed)
        return torch.stack([row[rng.permutation(x.shape[1])] for row in x])
    return x


def trajectory_metrics(pred: np.ndarray, truth: np.ndarray, dt: float, gravity: np.ndarray) -> dict:
    per_scene = np.mean((pred - truth) ** 2, axis=(1, 2))
    acceleration = np.diff(pred, n=2, axis=1) / dt ** 2
    true_acceleration = np.diff(truth, n=2, axis=1) / dt ** 2
    # Matching the actual GT acceleration also works for the deliberately changed drag law.
    residual = float(np.mean((acceleration - true_acceleration) ** 2))
    gravity_proxy = acceleration[:, :, 1].mean(1)
    return {"position_rmse": float(np.sqrt(per_scene.mean())),
            "per_scene_position_mse": per_scene.tolist(),
            "acceleration_residual_mse_against_actual_GT": residual,
            "gravity_proxy_mae_ballistic_interpretation_only": float(np.mean(np.abs(gravity_proxy - gravity))),
            "out_of_frame_fraction": float(np.mean((pred < 0) | (pred > 1)))}


def contrast_centroids(videos: np.ndarray, threshold: float = .35) -> np.ndarray:
    """Simple non-neural tracker: contrast against per-frame median RGB background.

    Uses only observed RGB, not simulator states or gravity. Strong deliberately
    included classical control for this easy, single-object rendered domain.
    """
    x = videos.astype(np.float32) / 255
    background = np.median(x, axis=(-3, -2), keepdims=True)
    weight = np.maximum(np.linalg.norm(x - background, axis=-1) - threshold, 0)
    h, w = x.shape[-3:-1]
    yy, xx = np.meshgrid((np.arange(h) + .5) / h, (np.arange(w) + .5) / w, indexing="ij")
    mass = weight.sum(axis=(-2, -1))
    # Failure to detect a foreground is explicit, not replaced by a GT position.
    if np.any(mass <= 1e-8):
        raise ValueError("Classical foreground tracker failed; revise source-only threshold or report failure")
    px = (weight * xx).sum(axis=(-2, -1)) / mass
    py = (weight * yy).sum(axis=(-2, -1)) / mass
    return np.stack([px, py], -1)


def run(cfg: dict, encoder, cache, out: Path, device: torch.device) -> dict:
    spec = cfg["physics"]
    observed, future, dt = spec["observed"], spec["future"], spec["dt"]
    base_seed = cfg["seed"] * 1000000
    kwargs = dict(observed=observed, future=future, size=cfg["data"]["image_size"], dt=dt,
                  terminal_matched=spec.get("terminal_matched", False))
    train = physics_dataset(cfg["data"]["n_train"], base_seed, **kwargs)
    val = physics_dataset(cfg["data"]["n_val"], base_seed + 100000, **kwargs)
    settings = {
        "ID": {}, "visual_only": {"visual_shift": True},
        "dynamics_only": {"dynamics_ood": True},
        "joint": {"dynamics_ood": True, "visual_shift": True},
        "law_shift_drag": {"law_shift": True},
    }
    tests = {name: physics_dataset(cfg["data"]["n_test"], base_seed + 200000, **kwargs, **shift)
             for name, shift in settings.items()}
    datasets = {"train": train, "val": val, **tests}
    if spec.get("terminal_matched", False):
        for data in datasets.values():
            if not np.array_equal(data["images"][0::2, observed-1], data["images"][1::2, observed-1]):
                raise AssertionError("Matched terminal images must be byte-identical")
    raw = {}
    for name, data in datasets.items():
        # Strict observation boundary. Test future frames do not enter any predictive model.
        a = data["images"][:, :observed]
        n, t, h, w, c = a.shape
        raw[name] = cache.get(a.reshape(n * t, h, w, c), grid=spec["spatial_pool_grid"]).reshape(n, t, -1)
    scaler = Standardizer().fit(raw["train"])
    features = {name: scaler.transform(z) for name, z in raw.items()}
    targets = {name: torch.from_numpy(data["states"][:, observed:].copy()).flatten(1)
               for name, data in datasets.items()}
    x, vx, y, vy = features["train"], features["val"], targets["train"], targets["val"]
    dim = x.shape[-1]
    ridge, ridge_choice = choose_ridge(x, y, vx, vy, spec["ridge_alphas"])
    log_tensor_payload(out / "ridge_visual.pt", {"readout": ridge.state(), "standardizer": scaler.state()})
    direct = MLP(observed * dim, future * 2, spec["hidden"])
    direct_history = train_supervised(direct, x, y, vx, vy, device=device, regression=True,
                                      seed=cfg["seed"], **cfg["train"])
    decoder = MLP(dim, 2, spec["hidden"])
    decoder_history = train_supervised(
        decoder, x.reshape(-1, dim), torch.from_numpy(train["states"][:, :observed].copy()).reshape(-1, 2),
        vx.reshape(-1, dim), torch.from_numpy(val["states"][:, :observed].copy()).reshape(-1, 2),
        device=device, regression=True, seed=cfg["seed"], **cfg["train"])
    # Optional small SSL temporal predictor: image encoder stays frozen. Its representation
    # is compared with an identically initialized but untrained random temporal projection.
    torch.manual_seed(cfg["seed"])
    ssl_model = MLP(observed * dim, dim, spec["hidden"])
    random_trunk = MLP(observed * dim, dim, spec["hidden"])
    random_trunk.load_state_dict(ssl_model.state_dict())
    future_targets = {}
    for name, data in [("train", train), ("val", val)]:
        future_targets[name] = scaler.transform(cache.get(data["images"][:, -1], grid=spec["spatial_pool_grid"]))
    ssl_history = train_supervised(ssl_model, x, future_targets["train"], vx, future_targets["val"],
                                   device=device, regression=True, seed=cfg["seed"], **cfg["train"])
    random_trunk.to(device).eval()
    with torch.no_grad():
        ssl_train, ssl_val = predict(ssl_model.trunk, x, device), predict(ssl_model.trunk, vx, device)
        rand_train, rand_val = predict(random_trunk.trunk, x, device), predict(random_trunk.trunk, vx, device)
    ssl_ridge, ssl_choice = choose_ridge(ssl_train, y, ssl_val, vy, spec["ridge_alphas"])
    random_ridge, random_choice = choose_ridge(rand_train, y, rand_val, vy, spec["ridge_alphas"])
    for name, model in [("direct_mlp", direct), ("position_decoder", decoder),
                         ("latent_ssl_predictor", ssl_model), ("random_temporal_projection", random_trunk)]:
        save_checkpoint(out / f"{name}.pt", model, standardizer=scaler.state(), encoder=encoder.provenance)
    log_tensor_payload(out / "temporal_readouts.pt", {"ssl": ssl_ridge.state(), "random": random_ridge.state()})
    # Learned classical control: observed RGB tracking + data-fitted ridge;
    # unlike the quadratic rollout this readout does not receive a motion equation.
    tracked_train = torch.tensor(contrast_centroids(train["images"][:, :observed]), dtype=torch.float32)
    tracked_val = torch.tensor(contrast_centroids(val["images"][:, :observed]), dtype=torch.float32)
    track_scaler = Standardizer().fit(tracked_train)
    track_ridge, track_choice = choose_ridge(track_scaler.transform(tracked_train), y,
        track_scaler.transform(tracked_val), vy, spec["ridge_alphas"])
    extra_predictors, diagnostic_choices, diagnostic_histories = {}, {}, {}
    if spec.get("diagnostic_controls", True):
        pca = TrainPCA().fit(x, spec["hidden"])
        for control, transform in [
            ("ridge_last_frame", lambda a: a[:, -1]),
            ("ridge_temporal_mean", lambda a: a.mean(1)),
            ("PCA_matched_dim_plus_ridge", pca.transform)]:
            readout, choice = choose_ridge(transform(x), y, transform(vx), vy, spec["ridge_alphas"])
            diagnostic_choices[control] = choice
            extra_predictors[control] = lambda a, r=readout, fn=transform: r.predict(fn(a))
        for control in ["lastframe_SSL", "shuffled_time_SSL", "residual_future_SSL"]:
            torch.manual_seed(cfg["seed"])
            model = MLP(observed * dim, dim, spec["hidden"])
            tr = ablation_context(x, control, cfg["seed"] + 100)
            va = ablation_context(vx, control, cfg["seed"] + 200)
            target_train, target_val = future_targets["train"], future_targets["val"]
            if control == "residual_future_SSL":
                target_train, target_val = target_train - x[:, -1], target_val - vx[:, -1]
            hist = train_supervised(model, tr, target_train, va, target_val,
                 device=device, regression=True, seed=cfg["seed"], **cfg["train"])
            r, choice = choose_ridge(predict(model.trunk, tr, device), y,
                   predict(model.trunk, va, device), vy, spec["ridge_alphas"])
            name = control + "_plus_ridge"
            diagnostic_choices[name], diagnostic_histories[name] = choice, hist
            extra_predictors[name] = lambda a, m=model, rr=r, k=control: rr.predict(
                predict(m.trunk, ablation_context(a, k, cfg["seed"]+300), device))
    records, scene_errors = [], {}
    for condition, data in tests.items():
        z = features[condition]
        obs_gt = data["states"][:, :observed]
        truth = data["states"][:, observed:]
        t_obs, t_future = data["times"][:observed], data["times"][observed:]
        decoded = predict(decoder, z.reshape(-1, dim), device).reshape(len(z), observed, 2).numpy()
        prior, _ = fit_quadratic(decoded, t_obs, t_future)
        oracle, _ = fit_quadratic(obs_gt, t_obs, t_future)
        tracked = contrast_centroids(data["images"][:, :observed])
        classical, _ = fit_quadratic(tracked, t_obs, t_future)
        last_velocity = (obs_gt[:, -1] - obs_gt[:, -2]) / dt
        constant_velocity = obs_gt[:, -1, None] + last_velocity[:, None] * (t_future - t_obs[-1])[None, :, None]
        preds = {
            "classical_contrast_tracker_plus_known_ballistic_prior": classical,
            "source_mean_trajectory_NO_IMAGE": y.mean(0).reshape(1,future,2).expand(len(z),future,2).numpy(),
            "classical_tracker_plus_learned_ridge": track_ridge.predict(track_scaler.transform(
                torch.tensor(tracked,dtype=torch.float32))).reshape(-1,future,2).numpy(),
            "ridge_visual": ridge.predict(z).reshape(-1, future, 2).numpy(),
            "direct_visual_mlp": predict(direct, z, device).reshape(-1, future, 2).numpy(),
            "decoded_positions_plus_known_ballistic_prior": prior,
            "small_latent_SSL_plus_ridge": ssl_ridge.predict(predict(ssl_model.trunk, z, device)).reshape(-1, future, 2).numpy(),
            "random_temporal_projection_plus_ridge": random_ridge.predict(predict(random_trunk.trunk, z, device)).reshape(-1, future, 2).numpy(),
            "ORACLE_state_constant_velocity": constant_velocity,
            "ORACLE_state_known_ballistic_prior": oracle,
        }
        if spec.get("terminal_matched", False):
            paired_truth = truth.reshape(-1, 2, future, 2)
            pair_mean = paired_truth.mean(1, keepdims=True)
            preds["ORACLE_identical_last_image_error_floor"] = np.repeat(pair_mean, 2, axis=1).reshape(truth.shape)
        for name, fn in extra_predictors.items():
            preds[name] = fn(z).reshape(-1, future, 2).numpy()
        for method, pred in preds.items():
            metrics = trajectory_metrics(pred, truth, dt, data["gravity"])
            errors = np.asarray(metrics["per_scene_position_mse"])
            if spec.get("terminal_matched", False):
                errors = errors.reshape(-1, 2).mean(1) # pair is the independent sampling unit
            scene_errors[(method, condition)] = errors
            records.append({"method": method, "condition": condition,
                            "uses_GT_states_at_inference": method.startswith("ORACLE"), **metrics})
            dump_jsonl(out / f"{method}_{condition}_predictions.jsonl.gz", (
                {"scene_id": int(data["scene_ids"][i]), "group_id": int(data["group_ids"][i]), "predictions": pred[i],
                 "target": truth[i], "gravity": float(data["gravity"][i])} for i in range(len(pred))))
    paired = []
    for method in sorted({r["method"] for r in records}):
        for condition in ["visual_only", "dynamics_only", "joint", "law_shift_drag"]:
            differences = scene_errors[(method, condition)] - scene_errors[(method, "ID")]
            paired.append({"method": method, "contrast": f"{condition}-ID",
                           **paired_bootstrap(differences, cfg["seed"], spec["bootstrap_resamples"])})
    dump_json(out / "split_scene_ids.json", {name: d["scene_ids"] for name, d in datasets.items()})
    dump_json(out / "training.json", {"direct": direct_history, "position_decoder": decoder_history,
                                      "small_SSL": ssl_history, "ridge": ridge_choice,
                                      "SSL_readout": ssl_choice, "random_readout": random_choice,
                                      "classical_learned_ridge_choice": track_choice, "diagnostic_choices": diagnostic_choices, "diagnostic_histories": diagnostic_histories})
    # A small inspectable sample, not a rendered figure generated for a user request.
    dump_json(out / "example_scene_metadata.json", {"states": train["states"][0],
              "times": train["times"], "gravity": train["gravity"][0], "images_saved": False})
    return {"theme": "05_controlled_physics_distribution_shift", "records": records,
            "paired_scene_bootstrap": paired,
            "training_scenes": len(np.unique(train["group_ids"])),
            "training_trajectories": len(train["images"]), "independent_test_scenes": len(np.unique(tests["ID"]["group_ids"])),
            "test_trajectories": len(tests["ID"]["images"]),
            "terminal_matched_pairs": spec.get("terminal_matched", False),
            "bootstrap_unit": "terminal_matched_pair" if spec.get("terminal_matched", False) else "scene",
            "identical_last_image_floor_is_oracle_not_competing_model": spec.get("terminal_matched", False),
            "simulation": "analytic free fall plus exact linear-drag law-shift control; no collisions",
            "context_frames": observed, "future_frames": future,
            "image_encoder_updated": False, "small_SSL_target": "last future image feature; train/validation only",
            "law_discovery_claim": False,
            "law_prior_warning": "Known ballistic rollout is imposed, not discovered. Oracle rows are upper-bound diagnostics.",
            "gravity_warning": "Gravity proxy is interpretable as g only in no-drag conditions; mass is not identifiable."}
