# V2 update

This is a historical per-repository guide. For current commands and the enforced logs-only policy, read the suite-level `README_V2.md`. No trained `.pt` or export model is produced by v2.

---

# ijepa_controlled_shift: ⑤ 制御された物理分布シフト

このリポジトリは、このテーマだけを実行する独立版です。他のリポジトリや元の統合版には依存しません。

固定I-JEPAの前提と、元の実験・対照・評価手順を維持しています。物性推定研究とは独立したMVPです。

**公開checkpoint・実データ・GPUでの性能は未検証です。** CPUのMockによる動作確認と、I-JEPAの研究結果を区別してください。本番ロード失敗時にMockへ自動切替しません。

## 1. Dataset-only /localdata policy (v0.3)

Only input datasets live under `/localdata` (no extra `datasets/` suffix).
Model weights, feature/compiler caches, outputs and temporary files default to the
**current directory from which the script is invoked**, not the dataset directory.

```text
/localdata/                     # datasets only
  cifar-10-batches-py/
  CIFAR-10-C/
  oxford-iiit-pet/
  videos/video_manifest.jsonl
./models/huggingface/hub/        # shared public model cache
./models/torch/
./cache/ijepa_controlled_shift/
./outputs/ijepa_controlled_shift/
./artifacts/ijepa_controlled_shift/
./tmp/ijepa_controlled_shift/
```

`--data-root` > `DATASETS_ROOT` > `/localdata` selects input datasets.
`--work-dir` > `IJEPA_WORK_DIR` > caller cwd selects all other default paths.
`LOCALDATA_ROOT` and the former `--storage-root` option are retired.
The parent suite passes explicit absolute output paths for batch isolation.

```bash
bash run_all.sh dry-run
bash run_all.sh dry-run --data-root /localdata --work-dir "$PWD"
```

## 2. セットアップ

Python 3.10以上。WindowsではWSL/Linux上で `bash run_all.sh` を実行してください。

使用GPUに対応するPyTorchとtorchvisionを用意したうえで、このフォルダで実行します。

```bash
python -m pip install -e ".[real,test]"
```

CPUでソフトウェア検証だけを行う場合：

```bash
python -m pip install -e ".[test]"
bash run_all.sh tests -q
bash run_all.sh smoke
```

Current release verification is in the parent suite verification/ directory. Public-checkpoint/GPU execution remains unverified here.

### 公開checkpointと前処理

```text
model_id: facebook/ijepa_vith14_1k
revision: f157467ea509bc356ff9f61fd3c0d840eec5e04e
```

公式Hugging Faceリポジトリのコミットを固定しています。前処理は同じrevisionの `AutoImageProcessor` から読み込みます。ImageNetのmean/stdを手書きで代用しません。公式processorは224×224へのリサイズとmean/std=0.5を指定しています。

モデルID、解決されたrevision、前処理、dtype、ライブラリバージョンを記録します。ローカルモデルを使う場合は設定・重みファイルのSHA-256も記録します。元のI-JEPA predictorはこのHFエンコーダ経路では読み込みません。

公式モデルのカードには `CC-BY-NC-4.0` の表記があります。モデル重み・データは本ZIPに含めていません。利用時は配布元の条件を確認してください。

## 3. Commands

```bash
bash run_all.sh tests -q
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh smoke --seeds 0 1 2 --resume
bash run_all.sh check --expected-runs 3
bash run_all.sh report

# Real encoder; see the next section for data preparation.
bash run_all.sh real --device cuda --seeds 0 1 2

# No data/weight access or filesystem writes:
bash run_all.sh dry-run --config examples/override.yaml
```

`--tasks` は廃止しました。このリポジトリのテーマだけが実行されます。

設定は `src/ijepa_controlled_shift/configs/` に同梱し、wheel単体でも利用できます。

`--resume` は完了済み実行のスキップであり、epochの途中再開ではありません。設定・コードが変わった場合は拒否します。

## 4. ⑤ 制御された物理分布シフト

```bash
bash run_all.sh real --device cuda --seeds 0 1 2
```

追加の物理シミュレータやデータ取得は不要です。解析解により、積分誤差・壁へのクリッピングを避けています。

- ID：学習範囲内の重力・外観。
- visual_only：同じ物理状態列のまま背景・色を変更。
- dynamics_only：初期条件と描画条件を対応させ、重力を学習範囲外へ変更。
- joint：外観と重力を両方変更。
- law_shift_drag：線形抵抗を加え、自由落下の運動方程式を変更。

観測8フレームから未来6フレームを予測します。testの未来フレームはモデル入力に入りません。source train/validationの未来画像特徴は、小型の未来特徴予測器のSSL学習にのみ使います。

比較には古典的なコントラスト追跡＋既知の二次運動式を含めます。単純な画像処理に負ける場合も結果を残し、I-JEPAが必要であるかを判断します。真の状態を入力するOracleは表現誤差を分離する診断用であり、通常の画像入力モデルと同条件の手法ではありません。

指標は位置RMSE、実際のGT加速度に対する残差、シフト前後のscene単位paired bootstrapです。同じsceneの複数描画を独立サンプルとは数えません。現在は単一物体・非衝突の2D課題であり、一般的な物理世界モデルやPhysVidの再現ではありません。

## 5. Repository structure

```text
ijepa_controlled_shift/
  run_all.sh
  pyproject.toml
  README_JA.md
  .env.example
  src/ijepa_controlled_shift/
    configs/base.yaml
    configs/experiment.yaml
    cli.py
    storage.py
    encoder.py
    common.py
    physics.py
    prepare.py
    report.py
    check.py
  tests/
  examples/
  docs/RESEARCH_REVIEW_JA.md
  docs/SOURCES.md
  verification/TEST_REPORT_JA.md
```

共通機能は各リポジトリに同梱しています。元の統合版や親フォルダのPYTHONPATHは不要です。Pythonパッケージ名もすべて異なります。

## 6. 実行と結果解釈の注意

- 同一seedの繰り返しを独立試行として集計しません。1 seedの標準偏差は0ではなくnullです。
- `--set` は既存の設定キーだけを変更でき、タイプミスしたキーはエラーになります。
- キャッシュの更新や大規模データを含め、絶対的な所要時間・GPUメモリ量は未測定です。初回はsubset、encoder batch size 1〜8から開始してください。
- `.pt` を読み込む際は、このパッケージのコードが作った信頼できるファイルを使用してください。ツールの読込は `weights_only=True` を使っています。
- 特定手法が勝つようなハイパーパラメータ探索、テスト結果によるモデル選択は実施していません。
- 本番の論文比較では、checkpoint・パラメータ数・sourceへのアクセス・更新予算・実測時間を揃える必要があります。

### オフライン／社内プロキシ環境

信頼された経路でcheckpoint一式をローカルディレクトリに配置して使用できます。TLS検証の無効化は行いません。

```bash
bash run_all.sh real --device cuda \
  --set encoder.model_id=./models/ijepa_vith14_1k \
  --set encoder.local_files_only=true \
  --set encoder.batch_size=2
```

