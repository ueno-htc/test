import numpy as np
import torch
from ijepa_controlled_shift.physics_data import analytic_trajectory, physics_dataset, fit_quadratic
from ijepa_controlled_shift.physics import RidgeReadout, trajectory_metrics


def test_ballistic_second_difference():
    t = np.arange(20) * .05
    trajectory = analytic_trajectory(np.array([.3, .2]), np.array([.1, -.02]), .2, t)
    acceleration = np.diff(trajectory, n=2, axis=0) / .05 ** 2
    np.testing.assert_allclose(acceleration[:, 0], 0, atol=1e-12)
    np.testing.assert_allclose(acceleration[:, 1], .2, atol=1e-12)


def test_ballistic_energy():
    t = np.arange(20) * .05
    v0, g = np.array([.1, -.02]), .2
    trajectory = analytic_trajectory(np.array([.3, .2]), v0, g, t)
    velocity = v0 + np.stack([t * 0, t * g], -1)
    energy = .5 * np.sum(velocity ** 2, axis=-1) - g * trajectory[:, 1]
    np.testing.assert_allclose(energy, energy[0], atol=1e-12)


def test_ballistic_quadratic_oracle():
    d = physics_dataset(4, 0, 8, 6, 32, .1)
    pred, acceleration = fit_quadratic(d['states'][:, :8], d['times'][:8], d['times'][8:])
    np.testing.assert_allclose(pred, d['states'][:, 8:], atol=2e-6)
    np.testing.assert_allclose(acceleration[:, 1], d['gravity'], atol=2e-6)


def test_visual_intervention_keeps_physics_identical():
    args = (4, 91, 8, 6, 32, .1)
    a, b = physics_dataset(*args), physics_dataset(*args, visual_shift=True)
    assert np.array_equal(a['states'], b['states'])
    assert np.array_equal(a['scene_ids'], b['scene_ids'])
    assert not np.array_equal(a['images'], b['images'])


def test_gravity_intervention_changes_trajectory():
    args = (4, 91, 8, 6, 32, .1)
    a, b = physics_dataset(*args), physics_dataset(*args, dynamics_ood=True)
    np.testing.assert_array_equal(a['states'][:, 0], b['states'][:, 0])
    assert not np.allclose(a['states'][:, -1], b['states'][:, -1])


def test_drag_law_breaks_exact_ballistic_fit():
    d = physics_dataset(4, 0, 8, 6, 32, .1, law_shift=True)
    pred, _ = fit_quadratic(d['states'][:, :8], d['times'][:8], d['times'][8:])
    assert np.mean((pred - d['states'][:, 8:]) ** 2) > 1e-8


def test_ridge_high_dimensional():
    x = torch.randn(8, 100)
    y = torch.randn(8, 3)
    model = RidgeReadout().fit(x, y, 1e-6)
    assert (model.predict(x) - y).abs().max() < 1e-4


def test_perfect_trajectory_metrics():
    d = physics_dataset(4, 0, 8, 6, 32, .1)
    y = d['states'][:, 8:]
    metrics = trajectory_metrics(y, y, .1, d['gravity'])
    assert metrics['position_rmse'] == 0
    assert metrics['acceleration_residual_mse_against_actual_GT'] == 0


def test_classical_tracker_no_ground_truth_access():
    from ijepa_controlled_shift.physics import contrast_centroids
    d = physics_dataset(3, 12, 8, 6, 32, .1)
    tracked = contrast_centroids(d['images'][:, :8])
    assert np.max(np.abs(tracked - d['states'][:, :8])) < .01

