import sys
from pathlib import Path
import pytest
import torch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

@pytest.fixture(autouse=True)
def isolated_runtime(tmp_path, monkeypatch):
    torch.set_num_threads(1)
    torch.manual_seed(0)
    monkeypatch.setenv("IJEPA_WORK_DIR", str(tmp_path / "work"))
    monkeypatch.setenv("DATASETS_ROOT", str(tmp_path / "datasets"))
