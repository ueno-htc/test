import torch
from ijepa_controlled_shift.physics import TrainPCA,ablation_context


def test_pca_is_train_only_and_rank_bounded():
    x=torch.randn(10,3,8)
    p=TrainPCA().fit(x,5)
    saved=p.basis.clone()
    assert p.transform(x).shape == (10,5)
    _=p.transform(torch.randn(7,3,8)*100)
    torch.testing.assert_close(saved,p.basis)
    torch.testing.assert_close(p.basis.T@p.basis,torch.eye(5,dtype=torch.float64),atol=1e-8,rtol=1e-8)


def test_shuffled_control_preserves_all_frames_and_is_reproducible():
    x=torch.arange(2*7*4).reshape(2,7,4).float()
    a=ablation_context(x,'shuffled_time_SSL',0)
    b=ablation_context(x,'shuffled_time_SSL',0)
    torch.testing.assert_close(a,b)
    torch.testing.assert_close(a.sort(dim=1).values,x.sort(dim=1).values)
    assert not torch.equal(a,x)


def test_last_frame_ablation_has_no_past_information():
    x=torch.randn(3,6,4)
    a=ablation_context(x,'lastframe_SSL',0)
    torch.testing.assert_close(a,x[:,-1:].expand_as(x))
