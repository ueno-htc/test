import numpy as np
import pytest
from ijepa_controlled_shift.physics_data import physics_dataset

@pytest.mark.parametrize('shift',[{}, {'visual_shift':True}, {'dynamics_ood':True}, {'visual_shift':True,'dynamics_ood':True}, {'law_shift':True}])
def test_terminal_images_identical_but_futures_differ(shift):
    d=physics_dataset(20,1234,8,6,32,.1,terminal_matched=True,**shift)
    assert np.array_equal(d['images'][0::2,7],d['images'][1::2,7])
    np.testing.assert_array_equal(d['states'][0::2,7],d['states'][1::2,7])
    assert np.mean((d['states'][0::2,8:]-d['states'][1::2,8:])**2)>1e-4
    assert len(np.unique(d['group_ids']))==10
    assert len(np.unique(d['scene_ids']))==20

def test_same_last_image_deterministic_prediction_error_floor():
    d=physics_dataset(20,25,8,6,32,.1,terminal_matched=True)
    truth=d['states'][:,8:].reshape(10,2,6,2)
    best=truth.mean(1,keepdims=True)
    pred=best+.037 # arbitrary equal prediction for both members
    floor=np.mean((best-truth)**2)
    assert np.mean((pred-truth)**2)>floor
    assert floor>0

def test_odd_dataset_size_is_rejected():
    with pytest.raises(ValueError):physics_dataset(3,1,8,6,32,.1,terminal_matched=True)
