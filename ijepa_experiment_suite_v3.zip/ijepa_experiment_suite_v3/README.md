# I-JEPA experiment suite v2: audited diagnostics, logs only

This revision responds to the real `pilot01` results (15 completed runs on RTX 3090).
It is a diagnostic research revision, not a proven improvement or a conference-ready method.
The image encoder remains frozen. No LLM/VLM is called. The five independent repositories
remain inside `repos/`, with a sequential parent runner and one review bundle.

## Storage and installation

Only datasets belong in `/localdata` (no automatic `/datasets` suffix).
`models/`, `cache/`, `tmp/`, `outputs/` and `reports/` belong to the shell's current
working directory. `--work-dir` and `--data-root` can override these independently.
Use the same working directory as pilot01 to reuse downloaded models and eligible feature caches.
The encoder implementation/cache keys were not changed. Cache hits require identical inputs,
checkpoint, preprocessing, dtype and pooling settings; reuse is not guaranteed for new features.

Unpack this revision alongside the original code, and invoke its entry point from the OLD
working directory, which already contains `models/` and `cache/`. For example:

```bash
# Working directory: your existing experiment directory, NOT /localdata.
cd /path/to/your/experiment_work
bash /path/to/ijepa_experiment_suite_v2/run_all.sh setup

# One sequential command: all five themes, three matched seeds, aggregation.
bash /path/to/ijepa_experiment_suite_v2/run_all.sh real \
  --config /path/to/ijepa_experiment_suite_v2/configs/diagnostic_v2.yaml \
  --device cuda --seeds 0 1 2 --name pilot02_diagnostic
```

If the archive is unpacked and run from a new working directory, this command is simpler,
but models/cache will live in that NEW directory:

```bash
cd ijepa_experiment_suite_v2
bash run_all.sh setup
bash run_all.sh real --config configs/diagnostic_v2.yaml \
  --device cuda --seeds 0 1 2 --name pilot02_diagnostic
```

Existing CIFAR files under `/localdata` are reused; do not add `--prepare-data` unnecessarily.
The default is a small matched-data diagnostic, not expansion to a full benchmark.
The next file to share is **`reports/pilot02_diagnostic/review_bundle.zip`**.

## What changed

| Theme | Revision | Interpretation boundary |
|---|---|---|
| TTA | Mixed source-validation batch calibration; balanced source anchors; optimizer/parameter-step/gradient/prediction-change logs; corruption-only accuracy; per-sample text predictions | Fixes a class-order confound. Improvement on CIFAR-C is not yet measured. Actual updates and cold-start time still matter. |
| Temporal | Exact vectorized final-state diagonal SSM; time-aware GRU; two-part interaction pooling; generator-specific RGB positive control; 24-example training-only overfit diagnostic | Not Mamba. Vectorized training materializes O(T) activations; streaming `step()` remains separate. No video accuracy advantage established. |
| Segmentation | Validation-only budget curves and a non-binding-budget flag; models held in RAM | Quantile-derived budgets are exploratory, not deployment SLAs. GPU eager timing is not a mobile result. |
| Physics | Mean trajectory without images; learned classical tracker + ridge; matched-dimensional PCA; last-frame/shuffled-time/residual-future SSL | Existing controls and new hypotheses, not confirmed innovations. Train/validation choose readout regularization. |
| Federated | Fed3R-style closed-form diagnostic; label-prior-only control; task-aligned prototype subspaces; full-rank personalization control | Closed-form aggregation is prior work, not our invention. Count full sufficient-statistic traffic. No privacy guarantee. |

## Logs-only policy

Training and validation-best weights stay **in memory**. Experiment outputs contain scalar
metrics, configuration/environment records, training histories, calibration traces, client/scene
identifiers and compressed JSONL predictions. Calls that used to save `.pt` now write
`*.model_log.json` with architecture/parameter-count metadata only; tensor weights are not serialized.
Physics predictions are compressed text, not `.npz`. Model export is disabled in this revision.
`review_bundle.zip` includes those diagnostic logs, but no trained weights, data arrays or feature caches.

**Necessary inputs are different from outputs:** the downloaded public encoder remains under
`models/`; reusable frozen-feature `.npz` caches remain under `cache/`. Neither is a trained-head
checkpoint or included in review bundles. Existing files from pilot01 are never deleted.
The old standalone student benchmark can read an old checkpoint, but this revision produces none.

## Optional diagnostic branches (do not pick a winner using target-test labels)

The default TTA optimizer stays SGD to isolate calibration/anchor corrections. A separate,
predeclared optimizer sensitivity run can be launched as follows:

```bash
bash run_all.sh real --tasks tta --device cuda --seeds 0 1 2 \
  --task-set tta:tta.optimizer=adam --task-set tta:tta.lr=0.001 \
  --name pilot02_tta_adam
```

This is a diagnostic alternative, NOT an already validated best setting. Do not report the best
of many test-tuned variants as an unbiased final result. Freeze a protocol before new seeds or shifts.

A bounded real-image segmentation check is available, but the synthetic result does not justify a
large segmentation sweep:

```bash
bash run_all.sh real --config configs/pets_pilot_v2.yaml --tasks segmentation \
  --prepare-data --device cuda --seeds 0 1 2 --name pilot02_pets
```

This uses only a 256/64/64 pilot subset, not a state-of-the-art Pet benchmark. The configured device
budget is still a starting point; use a declared target-device budget for any deployment claim.

## Tests, resumption and aggregation

```bash
bash run_all.sh tests
bash run_all.sh smoke --seeds 0 1 2 --name v2_smoke
bash run_all.sh real --config configs/diagnostic_v2.yaml \
  --device cuda --seeds 0 1 2 --name pilot02_diagnostic --resume
bash run_all.sh report --name pilot02_diagnostic
```

Never resume `pilot01` using changed code. Use a new batch name. Within the same v2 batch,
`--resume` skips matching completed runs and restarts failed/interrupted jobs from the beginning;
it does not restore training state because no training checkpoint is saved.

The included verification uses CPU and an explicit MockEncoder. It establishes software behavior,
not real-I-JEPA efficacy. The user-supplied pilot01 results are real-I-JEPA evidence; the two levels
must not be pooled. See `verification/TEST_REPORT.md`, `docs/DECISION_GATES.md` and `prompts/REVIEW_ROLES.md`.
