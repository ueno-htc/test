#!/usr/bin/env bash
set -euo pipefail
SUITE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$SUITE_ROOT${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
export IJEPA_WORK_DIR="${IJEPA_WORK_DIR:-$PWD}"
export DATASETS_ROOT="${DATASETS_ROOT:-/localdata}"
export PIP_CACHE_DIR="$IJEPA_WORK_DIR/cache/pip"
export HF_HOME="$IJEPA_WORK_DIR/models/huggingface"
export HF_HUB_CACHE="$HF_HOME/hub"
export HUGGINGFACE_HUB_CACHE="$HF_HUB_CACHE"
export TORCH_HOME="$IJEPA_WORK_DIR/models/torch"
export XDG_CACHE_HOME="$IJEPA_WORK_DIR/cache"
export PYTHONUNBUFFERED=1
PYTHON="${PYTHON:-python}"
MODE="${1:-real}"
if [ "$#" -gt 0 ]; then shift; fi
case "$MODE" in
  setup) exec "$PYTHON" -m pip install -r "$SUITE_ROOT/requirements-real.txt" "$@" ;;
  setup-smoke) exec "$PYTHON" -m pip install -r "$SUITE_ROOT/requirements.txt" "$@" ;;
  real|smoke|dry-run|report|tests) exec "$PYTHON" -m suite.runner "$MODE" "$@" ;;
  *) echo "Usage: bash run_all.sh {setup|setup-smoke|real|smoke|dry-run|report|tests} [options]" >&2; exit 2 ;;
esac
