import json
from pathlib import Path
import pytest
from suite import runner
from suite.report import flatten_result, aggregate, paired_comparisons

def test_dataset_root_separate_and_dry_run_writes_nothing(tmp_path, capsys):
    work, data = tmp_path / 'work', tmp_path / 'input'
    assert runner.main(['dry-run', '--work-dir', str(work), '--data-root', str(data)]) == 0
    plan = json.loads(capsys.readouterr().out)
    assert plan['work_dir'] == str(work) and plan['data_root'] == str(data)
    assert len(plan['tasks']) == 5
    assert not work.exists() and not data.exists()

def test_environment_caches_under_work_only(tmp_path):
    work, data = tmp_path / 'work', tmp_path / 'input'
    env = runner.child_env('ijepa_tta', work, data)
    for key in ['HF_HOME','HF_HUB_CACHE','TORCH_HOME','TMPDIR','XDG_CACHE_HOME','PIP_CACHE_DIR','TRITON_CACHE_DIR']:
        assert Path(env[key]).is_relative_to(work)
        assert not Path(env[key]).is_relative_to(data)
    assert env['DATASETS_ROOT'] == str(data)
    assert env['PYTHONPATH'].endswith('/ijepa_tta/src')

def test_duplicate_seed_or_task_rejected(tmp_path):
    for args in [['--seeds','0','0'], ['--tasks','tta','tta']]:
        with pytest.raises(SystemExit):
            runner.main(['dry-run', '--work-dir', str(tmp_path)] + args)

def test_bad_config_key_rejected():
    with pytest.raises(ValueError, match='Unknown'):
        runner.resolve_configs({'common':{'trani':{'epochs':5}}}, ['tta'], [], [])
    with pytest.raises(ValueError, match='not selected'):
        runner.resolve_configs({}, ['tta'], [], ['physics:train.epochs=4'])

def test_config_override_scopes():
    d=runner.resolve_configs({}, ['tta','physics'], ['encoder.batch_size=1'], ['physics:train.epochs=7'])
    assert d['tta']['encoder']['batch_size']==1 and 'train' not in d['tta']
    assert d['physics']['train']['epochs']==7

def test_dataset_directory_cannot_be_work_directory(tmp_path):
    with pytest.raises(SystemExit):
        runner.main(['smoke','--work-dir',str(tmp_path),'--data-root',str(tmp_path)])

def test_batch_lock_rejects_second_writer(tmp_path):
    with runner.BatchLock(tmp_path / '.lock'):
        with pytest.raises(RuntimeError, match='already running'):
            with runner.BatchLock(tmp_path / '.lock'):
                pass

def test_batch_name_rejects_traversal():
    for name in ['../oops','/tmp/out','a/b','..','']:
        with pytest.raises(ValueError):
            runner.safe_name(name)

def sample_record(seed=0, accuracy=.4):
    return {'project':'ijepa_tta','theme':'01_budgeted_tta','evidence_level':'SMOKE_MOCK_NOT_IJEPA',
            'seed':seed,'status':'complete','dataset':'synthetic',
            'records':[{'method':'frozen','hard_update_cap':0,'prequential':{'accuracy':accuracy}},
                       {'method':'drift_gate','hard_update_cap':3,'prequential':{'accuracy':accuracy+.1}}]}

def test_pairing_is_per_seed_and_missing_seeds_not_filled():
    r0=flatten_result('tta',sample_record(0,.3),{},Path('r0'))
    r1=flatten_result('tta',sample_record(1,.9),{},Path('r1'))
    r1=[r for r in r1 if r['variant']!='frozen']
    item=next(x for x in paired_comparisons(r0+r1) if x['baseline']=='frozen')
    assert item['n_paired_seeds']==1
    assert item['mean_delta_candidate_minus_baseline']==pytest.approx(.1)
    assert item['sample_std_of_paired_delta'] is None
    assert item['missing_baseline_seeds']==[1]

def test_aggregation_rejects_duplicate_seed():
    rows=flatten_result('tta',sample_record(),{},Path('r'))
    with pytest.raises(ValueError,match='Duplicate seed'):
        aggregate(rows+rows)

def test_segment_selection_policy_aggregates_different_architectures():
    rows=[]
    for seed,name,value in [(0,'arch_a',.5),(1,'arch_b',.7)]:
        r={'seed':seed,'evidence_level':'SMOKE_MOCK_NOT_IJEPA','dataset':'shapes',
           'selected_names':{'kd0_device_constrained':name},
           'selected_test_metrics':{name:{'miou':value}},
           'candidates':[{'name':name,'val_miou':value-.1,'deploy_bytes':500,'deploy_parameters':125,
                          'latency_p95_ms':2.,'latency_median_ms':1.,'conv_MACs_only':1000}]}
        rows+=flatten_result('segmentation',r,{},Path('r'))
    group=next(x for x in aggregate(rows) if x['variant']=='kd0_device_constrained' and x['metric']=='test.miou')
    assert group['n_seeds']==2 and group['mean']==pytest.approx(.6)
    assert group['selected_names_by_seed']=={'0':'arch_a','1':'arch_b'}

def test_no_scene_arrays_become_seed_metrics():
    r={'seed':0,'evidence_level':'SMOKE_MOCK_NOT_IJEPA','records':[{'method':'ridge','condition':'ID',
        'position_rmse':.3,'per_scene_position_mse':[1.,2.,3.]}]}
    rows=flatten_result('physics',r,{},Path('r'))
    assert len(rows)==1 and rows[0]['metric']=='position_rmse'

def test_failure_continues_resume_skips_complete_and_retries(tmp_path, monkeypatch):
    calls=[]
    failed_once=set()
    def execute(cmd,log,env,cwd,timeout=0):
        project=cmd[cmd.index('-m')+1].split('.')[0]
        task=next(k for k,v in runner.PROJECTS.items() if v==project)
        seed=int(cmd[cmd.index('--seeds')+1])
        calls.append((task,seed))
        log.parent.mkdir(parents=True,exist_ok=True)
        log.write_text('test fixture, not real model output')
        outcome={'returncode':0,'wall_seconds':.1,'timed_out':False,'interrupted':False}
        if task=='tta' and task not in failed_once:
            failed_once.add(task)
            return {**outcome,'returncode':1}
        out=Path(cmd[cmd.index('--output')+1]) / 'smoke' / f'seed_{seed}'
        r=sample_record(seed)
        r['project']=project
        if task!='tta':
            r.update(theme='03_temporal',records=[])
        runner.json_write(out/'result.json',r)
        runner.json_write(out/'config.json',{})
        return outcome
    monkeypatch.setattr(runner,'execute',execute)
    argv=['smoke','--work-dir',str(tmp_path/'work'),'--data-root',str(tmp_path/'datasets'),
          '--name','test','--tasks','tta','temporal','--seeds','0']
    assert runner.main(argv)==1
    assert calls==[('tta',0),('temporal',0)]
    state_path=tmp_path/'work/outputs/test/suite_state.json'
    assert runner.json_read(state_path)['status']=='partial_failure'
    assert (tmp_path/'work/reports/test/review_bundle.zip').exists()
    assert runner.main(argv+['--resume'])==0
    assert calls==[('tta',0),('temporal',0),('tta',0)]
    state=runner.json_read(state_path)
    assert len(state['jobs'][0]['attempts'])==2 and len(state['jobs'][1]['attempts'])==1
    assert not (tmp_path/'datasets').exists()
    with pytest.raises(SystemExit):
        runner.main(argv+['--resume','--set','encoder.batch_size=1'])

def test_mock_and_real_aggregates_stay_separate():
    r=sample_record()
    rows=flatten_result('tta',r,{},Path('r'))
    r['evidence_level']='PUBLIC_IJEPA_PILOT'
    rows+=flatten_result('tta',r,{},Path('r2'))
    groups=aggregate(rows)
    assert len(groups)==8
    assert {g['evidence'] for g in groups}=={'PUBLIC_IJEPA_PILOT','SMOKE_MOCK_NOT_IJEPA'}
    assert all(g['n_seeds']==1 for g in groups)
