# v3検証レポート

## 実行した検証

各pytest群の集計は次のとおりです。

|対象|成功|スキップ|
|---|---:|---:|
|一括実行suite|14|0|
|① TTA|41|1|
|③ Temporal|40|1|
|④ Segmentation|36|1|
|⑤ Physics|46|1|
|⑥ Federated|43|1|
|合計|220|5|

全群を一プロセスで実行した最終ログは `combined_pytest_v3.log`（220 passed, 5 skipped、終了コード0）です。
個別群のログは `tests_v3_final.log` と `federated_direct_v3.log` にもあります。
5件のスキップは未導入のtransformersを必要とする小型I-JEPA API検査です。
公開重みを用いるend-to-end性能試験ではありません。

実行環境はCPUのみ、PyTorch 2.10.0+cpuです。
当初の逐次pytestラッパーはこのツール環境の時間制限に達したため、
同じ全テストを `pytest --import-mode=importlib` の一プロセスで再実行し、
220成功、5スキップ、終了コード0を確認しました。
元のラッパーの時間制限を、使用者環境でも再現する不具合とは断定していません。

## 最終ソースのスモーク実行

最終ソースで⑥と⑤を各seed 0/1/2、合計6 run実行し、すべてcomplete。
最終レポートとreview bundleの生成まで正常終了しました。
`smoke_final.log`、`smoke_result_manifest.json`、`smoke_review_bundle.zip`を参照してください。
証拠レベルは全て `SMOKE_MOCK_NOT_IJEPA` です。
新たなニューラル手法が実I-JEPAで改善した証拠として使ってはいけません。

本番の推奨コマンドはdry-runでも設定解決を確認しました (`real_dry_run.log`)。
公開モデル・データのダウンロードやCUDA実行は行っていません。

## 新規に検査した性質

- clientの十分統計量と共分散作用G_i Qの合計が、集中計算のGQに一致する。
- Krylov基底が全空間を張る小型条件では、閉形式ridgeの解と一致する。
- local closed-form対照とvalidation選択が有限値で動作する。
- 各shift条件でpairの最後の画像が画素単位で等しい。
- pairの未来は異なり、pair平均が最後画像だけの予測の二乗誤差下限を与える。
- 奇数のpairサンプル設定を拒否する。
- 学習済み.pt/.pth/.pt2を保存しない。

入力重み・特徴キャッシュは学習済み出力重みとは別です。
今回の配布ZIPにはいずれも含めません。
