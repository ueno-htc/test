"""Sequential experiment orchestration and auditable cross-theme reports."""
__version__ = "0.3.0"
