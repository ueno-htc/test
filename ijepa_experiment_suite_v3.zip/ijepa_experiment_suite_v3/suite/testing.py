from pathlib import Path
import sys
from .runner import PROJECTS, ROOT, child_env, execute, json_write, utc

def run_tests(work: Path, data: Path) -> int:
    work.mkdir(parents=True, exist_ok=True)
    root = work / 'verification'
    root.mkdir(exist_ok=True)
    reports = []
    for task, project in [('suite', 'suite')] + list(PROJECTS.items()):
        directory = ROOT / 'tests' if task == 'suite' else ROOT / 'repos' / project / 'tests'
        env = child_env(project, work, data)
        if task == 'suite':
            env['PYTHONPATH'] = str(ROOT)
        command = [sys.executable, '-m', 'pytest', str(directory), '-q',
                   '-o', 'cache_dir=' + str(work / 'cache' / project / 'pytest'),
                   '--basetemp', str(work / 'tmp' / project / 'test_runs')]
        log = root / (task + '_pytest.log')
        print('[TEST] ' + task, flush=True)
        outcome = execute(command, log, env, work)
        print(log.read_text(encoding='utf-8', errors='replace'), flush=True)
        reports.append({'task':task, **outcome, 'log':str(log)})
        if outcome['interrupted']:
            break
    json_write(root / 'TESTS.json', {'generated_utc':utc(), 'reports':reports})
    return int(any(r['returncode'] != 0 for r in reports))
