"""Create one review bundle; never rank heterogeneous tasks or pool mock/real evidence."""
from __future__ import annotations
import csv
import math
import statistics
import zipfile
from collections import defaultdict
from pathlib import Path

from .runner import PROJECTS, ROOT, json_read, json_write, valid_result, utc

TITLES = {
    "tta": "01 TTA: resource-constrained adaptation",
    "temporal": "03 SSM: low-compute temporal understanding",
    "segmentation": "04 Segmentation: measured device constraints",
    "physics": "05 Physics: controlled distribution shifts",
    "federated": "06 Federated vision: non-IID / parameter efficiency",
}
LIMITS = {
    "tta": "Update-count caps are matched, not necessarily actual steps or wall-clock. Head time excludes the image encoder. Source anchors are retained; not strictly source-free.",
    "temporal": "The default order task is synthetic. Head-only speed is not end-to-end speed; motion_topk is offline. This diagonal SSM is not optimized Mamba.",
    "segmentation": "Validation-selected policies are compared; test labels do not choose architectures. Latency is only for the recorded device. Storage bytes are not peak RAM.",
    "physics": "Single-object 2D pilot. Known ballistic priors are not discovered laws. A classical tracker is a mandatory comparator; oracle-state methods are diagnostics only.",
    "federated": "Single-process FL simulation; no privacy guarantee. Legacy rows count fitting payload but not validation communication. V3 covariance rows additionally count local-validation messages; do not directly compare mixed cost scopes. Initial encoder installation is separate. Worst-client accuracy depends on sample counts.",
}
NEXT = {
    "tta": "Check source-anchor class balance and mixed-batch drift calibration first. Require prediction-change and parameter-step diagnostics; use corruption-only accuracy. Check drift_gate against periodic, entropy_gate and frozen at every budget. Inspect actual updates, retention and head time together. Repeat on held-out corruptions before promoting a scheduling hypothesis.",
    "temporal": "Inspect the RGB positive control and training-only overfit control before interpreting held-out chance accuracy. Check gap-aware SSM against the same-frame SSM/GRU/Transformer. A win in head time only is insufficient. If the synthetic order control works, use an independent real-video group split next.",
    "segmentation": "If every candidate meets the configured budgets, the device-specific selection hypothesis is untested. The budget curve is exploratory and validation-only. Compare distillation/no-distillation within the same validation selection policy. Inspect device-constrained versus MAC-proxy choices. Verify on the deployment device before claiming a device-specific advantage.",
    "physics": "Require superiority over PCA, last-frame SSL and shuffled-time SSL, not only random projection. Report the in-distribution versus shift tradeoff. Compare small-latent SSL with both ridge and random temporal projection for each shift separately. Check the classical tracker and decoder-plus-known-law controls before attributing gains to physical representations.",
    "federated": "Use Fed3R-style full ridge to diagnose feature utility without iterative optimizer confounding. Compare no-image label priors and task-aligned subspaces; these are controls, not new algorithms. Check fixed_basis_personal against fixed_basis, FedAvg and FedProx. Require acceptable mean and worst-client accuracy alongside lower communication; inspect negative transfer and low-count clients.",
}

def finite_scalar(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)

def numeric_leaves(obj: dict, prefix=""):
    """Lists are sample-level diagnostics; do not turn them into independent replicates."""
    for key, value in obj.items():
        path = prefix + key
        if finite_scalar(value):
            yield path, float(value)
        elif isinstance(value, dict):
            yield from numeric_leaves(value, path + ".")

def unit(metric: str):
    if metric.endswith("_ms"):
        return "ms"
    if "bytes" in metric:
        return "bytes"
    if metric.endswith("wall_seconds"):
        return "seconds"
    if any(s in metric for s in ("accuracy", "miou", "ece", "fraction", "retention_delta")):
        return "fraction"
    if "position_rmse" in metric:
        return "simulation_coordinate"
    return "native"

def direction(metric: str):
    if any(s in metric for s in ("accuracy", "miou", "retention_delta")):
        return "higher"
    if any(s in metric for s in ("rmse", "ece", "nll", "_ms", "bytes", "mse", "worse_than")):
        return "lower"
    return "descriptive"

def flatten_result(task, result, config, result_path):
    rows = []
    identity = {"evidence": result["evidence_level"], "task": task, "seed": result["seed"],
                "dataset": result.get("dataset", "analytic_physics_simulator"),
                "result_file": str(result_path)}
    def add(variant, condition, obj, role="method", selected_name=""):
        for metric, value in numeric_leaves(obj):
            rows.append({**identity, "variant": variant, "condition": str(condition), "role": role,
                         "selected_name": selected_name, "metric": metric, "value": value,
                         "unit": unit(metric), "direction": direction(metric)})
    if task == "segmentation":
        candidates = {r["name"]: r for r in result["candidates"]}
        for name, record in candidates.items():
            add(name, "validation_candidate", record, role="candidate")
        # Aggregate the algorithmic SELECTION POLICY, not the architecture it happened to select.
        for policy, name in result["selected_names"].items():
            if name is None:
                continue
            if name not in result["selected_test_metrics"] or name not in candidates:
                raise ValueError(f"Selected segmentation candidate missing metrics: {policy}/{name}")
            record = candidates[name]
            metrics = {"test": result["selected_test_metrics"][name],
                       "val_miou": record["val_miou"], "deploy_bytes": record["deploy_bytes"],
                       "deploy_parameters": record["deploy_parameters"],
                       "latency_p95_ms": record["latency_p95_ms"],
                       "latency_median_ms": record["latency_median_ms"],
                       "conv_MACs_only": record["conv_MACs_only"]}
            add(policy, "selected_policy", metrics, role="selection_policy", selected_name=name)
    else:
        for rec in result.get("records", []):
            name = rec.get("name", rec.get("method", "unknown"))
            condition = rec.get("condition", f"budget={rec['hard_update_cap']}" if "hard_update_cap" in rec else "all")
            role = "oracle" if rec.get("uses_GT_states_at_inference") else "method"
            add(name, condition, rec, role=role)
        if task == "tta":
            add("source_clean", "clean", result.get("clean_source", {}), role="reference")
    return rows

def aggregate(rows):
    groups = defaultdict(dict)
    selection = defaultdict(dict)
    for r in rows:
        key = tuple(r[x] for x in ("evidence", "task", "dataset", "variant", "condition", "role", "metric", "unit", "direction"))
        if r["seed"] in groups[key]:
            raise ValueError(f"Duplicate seed in metric group: {key}")
        groups[key][r["seed"]] = r["value"]
        if r["selected_name"]:
            selection[key][str(r["seed"])] = r["selected_name"]
    result = []
    columns = ("evidence", "task", "dataset", "variant", "condition", "role", "metric", "unit", "direction")
    for key, values in sorted(groups.items()):
        vals = list(values.values())
        result.append({**dict(zip(columns, key)), "n_seeds": len(vals), "seeds": sorted(values),
                       "mean": statistics.mean(vals),
                       "sample_std": statistics.stdev(vals) if len(vals) > 1 else None,
                       "minimum": min(vals), "maximum": max(vals),
                       "selected_names_by_seed": selection.get(key, {})})
    return result

def paired_comparisons(rows):
    if len({r["evidence"] for r in rows}) > 1:
        raise ValueError("Refusing paired comparisons across mock and real evidence")
    lookup = defaultdict(dict)
    for r in rows:
        key = (r["task"], r["variant"], r["condition"], r["metric"])
        if r["seed"] in lookup[key]:
            raise ValueError(f"Repeated seed: {key}")
        lookup[key][r["seed"]] = r["value"]
    specs = set()
    def add(task, a, ac, b, bc, metric):
        if (task, a, ac, metric) in lookup and (task, b, bc, metric) in lookup:
            specs.add((task, a, ac, b, bc, metric))
    for task, variant, condition, metric in list(lookup):
        if task == "tta" and variant == "drift_gate":
            if metric in {"corruption_macro_accuracy", "prequential.accuracy", "prequential.ece", "online_head_ms", "adaptation_ms", "actual_updates", "clean_retention_delta"}:
                for b in ("periodic", "random", "entropy_gate", "drift_gate_no_anchor"):
                    add(task, variant, condition, b, condition, metric)
                add(task, variant, condition, "frozen", "budget=0", metric)
        elif task == "temporal" and variant.startswith("gap_ssm_"):
            if metric in {"test.accuracy", "head_profile.latency_p95_ms", "end_to_end_profile.latency_p95_ms", "parameters"}:
                suffix = variant[len("gap_ssm_"):]
                for b in ("ssm_", "gru_", "gru_gap_", "transformer_", "mean_"):
                    add(task, variant, condition, b + suffix, condition, metric)
        elif task == "segmentation" and condition == "selected_policy":
            if metric in {"test.miou", "latency_p95_ms", "deploy_bytes"}:
                if variant.endswith("_device_constrained"):
                    prefix = variant[:-len("_device_constrained")]
                    add(task, variant, condition, prefix + "_MAC_proxy", condition, metric)
                    if not variant.startswith("kd0_"):
                        add(task, variant, condition, "kd0_device_constrained", condition, metric)
        elif task == "physics" and metric == "position_rmse":
            if variant == "small_latent_SSL_plus_ridge":
                for b in ("ridge_visual", "random_temporal_projection_plus_ridge", "PCA_matched_dim_plus_ridge", "lastframe_SSL_plus_ridge", "shuffled_time_SSL_plus_ridge", "classical_contrast_tracker_plus_known_ballistic_prior", "classical_tracker_plus_learned_ridge", "source_mean_trajectory_NO_IMAGE"):
                    add(task, variant, condition, b, condition, metric)
            if variant == "decoded_positions_plus_known_ballistic_prior":
                add(task, variant, condition, "classical_contrast_tracker_plus_known_ballistic_prior", condition, metric)
            if condition != "ID" and not variant.startswith("ORACLE"):
                add(task, variant, condition, variant, "ID", metric)
        elif task == "federated" and (variant in {"fixed_basis_personal", "fedavg_full_personal", "Fed3R_style_full_ridge", "prototype_subspace_ridge_r4", "prototype_subspace_ridge_r9", "diagonal_preconditioned_classmean_ridge", "local_closed_form_ridge"} or variant.startswith("covariance_krylov_")):
            if metric in {"test.micro_accuracy", "test.worst_client_accuracy_min_count", "total_round_payload_bytes", "fraction_clients_worse_than_local_only"}:
                for b in ("fixed_basis", "fedavg_full", "fedprox_full", "local_only", "local_closed_form_ridge", "local_label_prior_NO_IMAGE", "CENTRALIZED_reference_NOT_federated", "Fed3R_style_full_ridge", "prototype_subspace_ridge_r9"):
                    if metric == "total_round_payload_bytes" and (variant.startswith("covariance_") or variant == "diagonal_preconditioned_classmean_ridge"):
                        continue # V3 includes validation traffic; V2 rows do not. Avoid false cost ratios.
                    if b == variant: continue
                    add(task, variant, condition, b, condition, metric)
    records = []
    for task, a, ac, b, bc, metric in sorted(specs):
        av, bv = lookup[(task, a, ac, metric)], lookup[(task, b, bc, metric)]
        common = sorted(av.keys() & bv.keys())
        if not common:
            continue
        differences = [av[s] - bv[s] for s in common]
        d = direction(metric)
        signs = [x if d == "higher" else -x for x in differences] if d != "descriptive" else []
        ratios = [av[s] / bv[s] for s in common if bv[s] != 0]
        records.append({"task": task, "candidate": a, "candidate_condition": ac,
                        "baseline": b, "baseline_condition": bc, "metric": metric,
                        "direction": d, "unit": unit(metric), "n_paired_seeds": len(common),
                        "seeds": common, "candidate_mean": statistics.mean(av[s] for s in common),
                        "baseline_mean": statistics.mean(bv[s] for s in common),
                        "mean_delta_candidate_minus_baseline": statistics.mean(differences),
                        "sample_std_of_paired_delta": statistics.stdev(differences) if len(common) > 1 else None,
                        "paired_deltas": dict(zip(map(str, common), differences)),
                        "candidate_over_baseline_mean_ratio": statistics.mean(ratios) if ratios else None,
                        "ratio_n": len(ratios),
                        "wins": sum(x > 1e-12 for x in signs) if signs else None,
                        "ties": sum(abs(x) <= 1e-12 for x in signs) if signs else None,
                        "missing_candidate_seeds": sorted(bv.keys() - av.keys()),
                        "missing_baseline_seeds": sorted(av.keys() - bv.keys()),
                        "interpretation": "exploratory_paired_seed_comparison_not_significance_test"})
    return records

def csv_write(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)

def fmt(value, scale=1):
    return "NA" if value is None else f"{value * scale:.5g}"

def md_escape(value):
    return str(value).replace("|", "\\|").replace("\n", " ")

def write_markdown(path, summary, comparison):
    state = summary["state"]
    smoke = state["plan"]["mode"] == "smoke"
    lines = ["# I-JEPA experiment review", "", f"Batch: `{state['plan']['name']}` | Generated: {summary['generated_utc']}",
             f"Status: **{state['status']}** | Completed: **{summary['completed_runs']}/{summary['expected_runs']}**", "",
             "## Evidence boundary", ""]
    if smoke:
        lines += ["**SMOKE / MOCK ENCODER ONLY. These numbers verify software, not I-JEPA performance. Do not use this report to select a scientific winner.**", ""]
    else:
        lines += ["This is a public-checkpoint PILOT, not a paper-level benchmark. Dataset names, sample counts and device provenance must be checked below.", ""]
    lines += ["All comparisons are exploratory. Standard deviations use independent seeds, not frames/clients/corruption blocks. N=1 gives NA, not zero. Missing/failed runs are never filled with zero.",
              "No cross-theme scalar ranking is computed. No statistical significance, conference acceptance or unseen-device speed is claimed.", "",
              "## Storage", "", f"Datasets only: `{state['plan']['data_root']}`", f"Working directory (models, caches, results): `{state['plan']['work_dir']}`", "",
              "## Run coverage", "", "| Theme | Complete / expected | Evidence / dataset | Next action |", "|---|---:|---|---|"]
    for task in state["plan"]["tasks"]:
        jobs = [j for j in state["jobs"] if j["task"] == task]
        done = sum(j["status"] == "complete" for j in jobs)
        datasets = sorted({r["dataset"] for r in summary["metrics"] if r["task"] == task})
        action = "Run real checkpoint next; smoke is not scientific evidence" if smoke else ("Resolve failed/missing runs before comparison" if done < len(jobs) else "Inspect matched baselines and resource costs below")
        lines.append(f"| {TITLES[task]} | {done}/{len(jobs)} | {', '.join(datasets) or 'no usable result'} | {action} |")
    for task in state["plan"]["tasks"]:
        lines += ["", f"## {TITLES[task]}", "", LIMITS[task], "", "### Paired comparisons", ""]
        primary = {"tta": "corruption_macro_accuracy", "temporal": "test.accuracy", "segmentation": "test.miou",
                   "physics": "position_rmse", "federated": "test.micro_accuracy"}[task]
        subset = [r for r in comparison if r["task"] == task and r["metric"] == primary]
        # In physics, avoid flooding the main report with ID degradation diagnostics.
        if task == "physics":
            subset = [r for r in subset if r["candidate"] != r["baseline"]]
        lines += ["Delta is candidate minus baseline; for RMSE a negative delta is better. Accuracy/mIoU deltas are percentage points (pp).",
                  "", "| Candidate [condition] | Baseline [condition] | Candidate mean | Baseline mean | Paired delta | SD(delta) | n / wins |",
                  "|---|---|---:|---:|---:|---:|---:|"]
        if not subset:
            lines.append("| No paired primary result | - | NA | NA | NA | NA | 0 |")
        for r in subset:
            scale = 100 if r["unit"] == "fraction" else 1
            lines.append(f"| {md_escape(r['candidate'])} [{md_escape(r['candidate_condition'])}] | {md_escape(r['baseline'])} [{md_escape(r['baseline_condition'])}] | {fmt(r['candidate_mean'],scale)} | {fmt(r['baseline_mean'],scale)} | {fmt(r['mean_delta_candidate_minus_baseline'],scale)} | {fmt(r['sample_std_of_paired_delta'],scale)} | {r['n_paired_seeds']} / {r['wins']} |")
        lines += ["", "### Resource / robustness checks", "", "| Variant [condition] | Metric | Mean | SD | n |", "|---|---|---:|---:|---:|"]
        targets = {
            "tta": {"actual_updates", "online_head_ms", "clean_retention_delta"},
            "temporal": {"end_to_end_profile.latency_p95_ms", "head_profile.latency_p95_ms"},
            "segmentation": {"latency_p95_ms", "deploy_bytes"},
            "physics": {"acceleration_residual_mse_against_actual_GT", "out_of_frame_fraction"},
            "federated": {"test.worst_client_accuracy_min_count", "total_round_payload_bytes", "fit_only_payload_bytes", "validation_payload_bytes", "normal_equation_relative_residual", "fraction_clients_worse_than_local_only"},
        }[task]
        for r in summary["aggregates"]:
            if r["task"] != task or r["metric"] not in targets or r["role"] == "candidate":
                continue
            if task == "physics" and r["variant"] not in {"small_latent_SSL_plus_ridge", "ridge_visual", "classical_contrast_tracker_plus_known_ballistic_prior"}:
                continue
            lines.append(f"| {md_escape(r['variant'])} [{md_escape(r['condition'])}] | {r['metric']} ({r['unit']}) | {fmt(r['mean'])} | {fmt(r['sample_std'])} | {r['n_seeds']} |")
        lines += ["", "### Decision checkpoint", "", NEXT[task], ""]
        if smoke:
            lines += ["**Current decision: software check only; real I-JEPA evaluation remains pending.**", ""]
        else:
            lines += ["Any promising test-set comparison here is a development signal, not an unbiased final claim. Freeze a revised protocol and reserve independent test conditions for confirmation.", ""]
        selected = summary["selection_choices"].get(task, {})
        if selected:
            lines += ["### Validation-selected architectures by seed", "", "```json", __import__('json').dumps(selected, indent=2), "```", ""]
    lines += ["## Failures / incomplete jobs", ""]
    failures = [j for j in state["jobs"] if j["status"] != "complete"]
    if not failures:
        lines += ["None in this batch."]
    for j in failures:
        log = j["attempts"][-1].get("log") if j["attempts"] else "not launched"
        lines += [f"### {j['task']} seed={j['seed']}: {j['status']}", f"Error: {j.get('error','not completed')}",
                  f"Log: `{log}`", ""]
    if summary["report_errors"]:
        lines += ["", "## Report integrity errors", ""] + ["- " + x for x in summary["report_errors"]]
    lines += ["", "## How to use the bundle", "", "Share `review_bundle.zip` for the next research decision. It includes this report, full result JSON, per-sample compressed JSONL predictions, training/calibration diagnostics, resolved configurations, environment/encoder metadata, per-job logs, long-form metrics, seed aggregates and matched comparisons.",
              "It excludes datasets, image arrays, feature caches and model weights. Logs/configs may contain local paths or host details; inspect before sharing externally.",
              "", "`metrics.csv` keeps raw per-seed scalar values. `comparisons.csv` keeps paired effects. `summary.json` is machine-readable. The files are descriptive; no LLM service is called."]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")

def generate(state_path: Path) -> dict:
    state = json_read(state_path)
    plan = state["plan"]
    report_dir = Path(plan["work_dir"]) / "reports" / plan["name"]
    report_dir.mkdir(parents=True, exist_ok=True)
    rows, errors, artifacts, selections = [], [], [], {}
    for job in state["jobs"]:
        if job["status"] != "complete":
            continue
        valid, error = valid_result(job, plan)
        if not valid:
            errors.append(f"{job['task']}/{job['seed']}: {error}")
            continue
        path = Path(job["result"])
        try:
            r = json_read(path)
            c = json_read(path.parent / "config.json")
            rows += flatten_result(job["task"], r, c, path)
            if "selected_names" in r:
                selections.setdefault(job["task"], {})[str(job["seed"])] = r["selected_names"]
            artifacts.append(path)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            errors.append(f"{job['task']}/{job['seed']}: {exc}")
    grouped, comparison = aggregate(rows), paired_comparisons(rows)
    summary = {"schema_version": 3, "generated_utc": utc(), "state": state,
               "expected_runs": len(state["jobs"]), "completed_runs": len(artifacts),
               "metrics": rows, "aggregates": grouped, "comparisons": comparison,
               "selection_choices": selections, "report_errors": errors,
               "statistical_scope": "seed SD and exploratory paired differences; no significance claims"}
    json_write(report_dir / "summary.json", summary)
    json_write(report_dir / "aggregates.json", grouped)
    metric_fields = ["evidence", "task", "dataset", "seed", "variant", "condition", "role", "selected_name", "metric", "unit", "direction", "value", "result_file"]
    csv_write(report_dir / "metrics.csv", rows, metric_fields)
    csv_write(report_dir / "aggregates.csv", grouped, ["evidence", "task", "dataset", "variant", "condition", "role", "metric", "unit", "direction", "n_seeds", "mean", "sample_std", "minimum", "maximum"])
    csv_write(report_dir / "comparisons.csv", comparison, ["task", "candidate", "candidate_condition", "baseline", "baseline_condition", "metric", "unit", "direction", "n_paired_seeds", "candidate_mean", "baseline_mean", "mean_delta_candidate_minus_baseline", "sample_std_of_paired_delta", "wins", "ties", "candidate_over_baseline_mean_ratio", "ratio_n"])
    write_markdown(report_dir / "REPORT.md", summary, comparison)
    run_rows = [{"task": j["task"], "seed": j["seed"], "status": j["status"],
                 "attempts": len(j["attempts"]), "wall_seconds_all_attempts": sum(a.get("wall_seconds", 0) for a in j["attempts"]),
                 "error": j.get("error", "")} for j in state["jobs"]]
    csv_write(report_dir / "runs.csv", run_rows, ["task", "seed", "status", "attempts", "wall_seconds_all_attempts", "error"])
    archive = report_dir / "review_bundle.zip"
    # A small allowlist prevents model weights/datasets from accidentally entering review bundles.
    allowed_suffixes = (".json", ".jsonl", ".jsonl.gz", ".csv", ".log", ".txt")
    with zipfile.ZipFile(archive.with_suffix(".tmp"), "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(report_dir.iterdir()):
            if path.suffix in {".csv", ".json", ".md"}:
                z.write(path, "report/" + path.name)
        z.write(state_path, "runs/suite_state.json")
        batch = state_path.parent
        for path in sorted((batch / "configs").glob("*.yaml")):
            z.write(path, "runs/configs/" + path.name)
        for path in sorted((batch / "logs").glob("*.log")):
            z.write(path, "runs/logs/" + path.name)
        for path in sorted((batch / "runs").rglob("*")):
            if path.is_file() and path.name.endswith(allowed_suffixes):
                z.write(path, "runs/" + path.relative_to(batch).as_posix())
        for task in plan["tasks"]:
            review = ROOT / "repos" / PROJECTS[task] / "docs/RESEARCH_REVIEW_JA.md"
            if review.exists():
                z.write(review, "research_protocols/" + task + ".md")
    archive.with_suffix(".tmp").replace(archive)
    print(f"[REPORT] {report_dir / 'REPORT.md'}", flush=True)
    print(f"[SHARE THIS] {archive}", flush=True)
    return summary
