"""Run independent MVPs sequentially. No asynchronous service or remote execution."""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
import platform
import re
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
PROJECTS = {
    "tta": "ijepa_tta",
    "temporal": "ijepa_temporal_ssm",
    "segmentation": "ijepa_device_segmentation",
    "physics": "ijepa_controlled_shift",
    "federated": "ijepa_federated_vision",
}

def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()

def json_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    tmp.replace(path)

def json_read(path: Path) -> Any:
    def reject(value):
        raise ValueError(f"Non-finite JSON value: {value}")
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=reject)

def hash_object(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def merge(left: dict, right: dict) -> dict:
    result = copy.deepcopy(left)
    for key, value in right.items():
        if isinstance(result.get(key), dict) and isinstance(value, dict):
            result[key] = merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result

def source_fingerprint() -> str:
    h = hashlib.sha256()
    paths = list((ROOT / "suite").glob("*.py")) + [ROOT / "run_all.sh"]
    for project in PROJECTS.values():
        repo = ROOT / "repos" / project
        paths += list((repo / "src").rglob("*.py")) + list((repo / "src").rglob("*.yaml"))
        paths += [repo / "run_all.sh"]
    for path in sorted(paths):
        h.update(path.relative_to(ROOT).as_posix().encode())
        h.update(path.read_bytes())
    return h.hexdigest()

def version_info() -> dict:
    info = {"python": platform.python_version(), "platform": platform.platform(), "packages": {}}
    for name in ("torch", "torchvision", "transformers", "numpy", "Pillow", "PyYAML"):
        try:
            info["packages"][name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            info["packages"][name] = None
    # Platform and library changes are resume barriers. GPU provenance is also saved by each job.
    return info

def child_env(project: str, work: Path, data: Path) -> dict[str, str]:
    env = dict(os.environ)
    # Do not expose sibling source packages to each child process.
    env["PYTHONPATH"] = str(ROOT / "repos" / project / "src")
    env.update({
        "IJEPA_WORK_DIR": str(work), "DATASETS_ROOT": str(data),
        "HF_HOME": str(work / "models/huggingface"),
        "HF_HUB_CACHE": str(work / "models/huggingface/hub"),
        "HUGGINGFACE_HUB_CACHE": str(work / "models/huggingface/hub"),
        "TORCH_HOME": str(work / "models/torch"), "PIP_CACHE_DIR": str(work / "cache/pip"),
        "XDG_CACHE_HOME": str(work / "cache"), "TMPDIR": str(work / "tmp" / project),
        "TORCHINDUCTOR_CACHE_DIR": str(work / "cache" / project / "torchinductor"),
        "TRITON_CACHE_DIR": str(work / "cache" / project / "triton"),
        "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1", "PYTHONHASHSEED": "0",
        "CUBLAS_WORKSPACE_CONFIG": ":4096:8", "TOKENIZERS_PARALLELISM": "false",
    })
    return env

def terminate(proc: subprocess.Popen, sig: int) -> None:
    if proc.poll() is not None:
        return
    try:
        if os.name == "posix":
            os.killpg(proc.pid, sig)
        else:
            proc.terminate()
    except ProcessLookupError:
        pass

def execute(command: list[str], log: Path, env: dict[str, str], cwd: Path,
            timeout: float = 0) -> dict:
    log.parent.mkdir(parents=True, exist_ok=True)
    Path(env["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    timed_out = interrupted = False
    with log.open("w", encoding="utf-8") as out:
        out.write("COMMAND " + json.dumps(command) + "\n")
        out.flush()
        proc = subprocess.Popen(command, stdout=out, stderr=subprocess.STDOUT, env=env,
                                cwd=cwd, start_new_session=(os.name == "posix"))
        try:
            while proc.poll() is None:
                if timeout > 0 and time.monotonic() - start >= timeout:
                    timed_out = True
                    terminate(proc, signal.SIGTERM)
                    break
                time.sleep(.1)
        except KeyboardInterrupt:
            interrupted = True
            terminate(proc, signal.SIGINT)
        finally:
            if proc.poll() is None:
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    terminate(proc, signal.SIGKILL)
                    proc.wait()
    return {"returncode": proc.returncode, "wall_seconds": time.monotonic() - start,
            "timed_out": timed_out, "interrupted": interrupted}

def tail(path: Path, lines: int = 10) -> str:
    if not path.exists():
        return "log file missing"
    return "\n".join(path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:])

def safe_name(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", value):
        raise ValueError("--name must be a simple name, not a directory or traversal path")
    return value

def resolve_configs(config: dict, tasks: list[str], common_sets: list[str], task_sets: list[str]) -> dict:
    unknown = set(config) - {"seeds", "common", "tasks", "review"}
    if unknown:
        raise ValueError(f"Unknown suite configuration keys: {sorted(unknown)}")
    if set(config.get("tasks", {})) - set(PROJECTS):
        raise ValueError("Unknown task name in suite config")
    overrides = {task: merge(config.get("common", {}), config.get("tasks", {}).get(task, {})) for task in tasks}
    def assign(obj, item):
        if "=" not in item:
            raise ValueError("Overrides require dotted.key=value")
        key, raw = item.split("=", 1)
        value = yaml.safe_load(raw)
        if isinstance(value, (dict, list, int, float, bool)) or value is None:
            parsed = value
        else:
            parsed = str(value)
        node = obj
        for part in key.split(".")[:-1]:
            node = node.setdefault(part, {})
            if not isinstance(node, dict):
                raise ValueError(f"Non-mapping override parent: {key}")
        node[key.split(".")[-1]] = parsed
    for task in tasks:
        for item in common_sets:
            assign(overrides[task], item)
    for item in task_sets:
        if ":" not in item:
            raise ValueError("--task-set requires task:dotted.key=value")
        task, assignment = item.split(":", 1)
        if task not in overrides:
            raise ValueError(f"Override for a task not selected: {task}")
        assign(overrides[task], assignment)
    for task, override in overrides.items():
        repo = ROOT / "repos" / PROJECTS[task] / "src" / PROJECTS[task] / "configs"
        defaults = merge(yaml.safe_load((repo / "base.yaml").read_text()),
                         yaml.safe_load((repo / "experiment.yaml").read_text()))
        def validate_keys(template, extra, prefix=""):
            if not isinstance(extra, dict):
                raise ValueError(f"Configuration mapping expected: {prefix}")
            for key, value in extra.items():
                if key not in template:
                    raise ValueError(f"Unknown {task} configuration key: {prefix}{key}")
                if isinstance(template[key], dict):
                    validate_keys(template[key], value, prefix + key + ".")
        validate_keys(defaults, override)
        if override.get("task", task) != task:
            raise ValueError("Task identity cannot be overridden")
        if override.get("smoke", False):
            raise ValueError("Use the smoke command, not a configuration override")
    return overrides

def command_for(task: str, seed: int, config_path: Path, output: Path,
                plan: dict, dry: bool = False) -> list[str]:
    cmd = [sys.executable, "-m", PROJECTS[task] + ".cli", "--config", str(config_path),
           "--seeds", str(seed), "--device", plan["device"],
           "--work-dir", plan["work_dir"], "--data-root", plan["data_root"],
           "--output", str(output), "--cache", str(Path(plan["work_dir"]) / "cache" / PROJECTS[task])]
    if plan["mode"] == "smoke":
        cmd += ["--smoke"]
    if dry:
        cmd += ["--dry-run"]
    return cmd

def valid_result(job: dict, plan: dict) -> tuple[bool, str]:
    if not job.get("result"):
        return False, "No result path"
    path = Path(job["result"])
    try:
        r = json_read(path)
        expected = "SMOKE_MOCK_NOT_IJEPA" if plan["mode"] == "smoke" else "PUBLIC_IJEPA_PILOT"
        if r.get("status") != "complete" or r.get("evidence_level") != expected:
            return False, "Incomplete result or wrong evidence level"
        if r.get("project") != PROJECTS[job["task"]] or r.get("seed") != job["seed"]:
            return False, "Wrong project/seed"
        if job.get("result_sha256") and sha256_file(path) != job["result_sha256"]:
            return False, "Result changed since completion"
        return True, ""
    except (OSError, ValueError, TypeError) as exc:
        return False, str(exc)

class BatchLock:
    """Nonblocking OS lock: a crash releases it; no stale PID-file unlocking needed."""
    def __init__(self, path: Path):
        self.path = path
        self.file = None
    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("a+")
        if os.name != "posix":
            self.file.close()
            raise RuntimeError("Use Linux/WSL; POSIX batch locking is required")
        import fcntl
        try:
            fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.file.close()
            raise RuntimeError(f"This batch is already running: {self.path.parent}")
        return self
    def __exit__(self, *args):
        if self.file:
            self.file.close()

def prepare_datasets(state: dict, state_path: Path, timeout: float) -> bool:
    """Explicit opt-in; downloads data only, never installs Python packages."""
    plan = state["plan"]
    work, data = Path(plan["work_dir"]), Path(plan["data_root"])
    tasks = plan["tasks"]
    steps = []
    need = {}
    for task in tasks:
        directory = ROOT / "repos" / PROJECTS[task] / "src" / PROJECTS[task] / "configs"
        cfg = merge(merge(yaml.safe_load((directory / "base.yaml").read_text()),
                          yaml.safe_load((directory / "experiment.yaml").read_text())), plan["overrides"][task])
        dataset = cfg.get("data", {}).get("dataset")
        root_raw = cfg.get("data", {}).get("root", str(data))
        root = Path(str(root_raw).replace("${DATASETS_ROOT}", str(data))).expanduser()
        if not root.is_absolute():
            root = data / root
        if dataset in {"cifar10", "cifar100"}:
            key = (dataset, str(root.resolve()))
            need[key] = need.get(key, False) or task == "tta"
        if task == "segmentation" and dataset == "pets":
            steps.append((PROJECTS[task], ["--dataset", "pets", "--root", str(root.resolve())]))
    for (dataset, root), corruption in need.items():
        args = ["--dataset", dataset, "--root", root]
        if corruption and dataset == "cifar10":
            args += ["--cifar10-c"]
        steps.append((PROJECTS["tta"], args))
    all_ok = True
    for i, (project, args) in enumerate(steps):
        log = state_path.parent / "logs" / f"prepare_{len(state.get('preparation', [])) + 1}.log"
        cmd = [sys.executable, "-m", project + ".prepare", "--work-dir", str(work), "--data-root", str(data)] + args
        print(f"[PREPARE] {args}; log={log}", flush=True)
        outcome = execute(cmd, log, child_env(project, work, data), work, timeout)
        state.setdefault("preparation", []).append({**outcome, "command": cmd, "log": str(log), "finished_utc": utc()})
        json_write(state_path, state)
        if outcome["returncode"] != 0:
            all_ok = False
            print(tail(log), flush=True)
        if outcome["interrupted"]:
            return False
    return all_ok

def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["real", "smoke", "dry-run", "report", "tests"])
    p.add_argument("--config", type=Path, default=ROOT / "configs/suite.yaml")
    p.add_argument("--data-root", type=Path, default=Path(os.environ.get("DATASETS_ROOT", "/localdata")))
    p.add_argument("--work-dir", type=Path, default=Path(os.environ.get("IJEPA_WORK_DIR", Path.cwd())))
    p.add_argument("--name", help="Batch identifier. Default: real or smoke")
    p.add_argument("--tasks", nargs="+", choices=list(PROJECTS), default=list(PROJECTS))
    p.add_argument("--seeds", nargs="+", type=int)
    p.add_argument("--device", default="auto")
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="Override all selected tasks")
    p.add_argument("--task-set", action="append", default=[], metavar="TASK:KEY=VALUE")
    p.add_argument("--resume", action="store_true", help="Skip complete runs; retry failed/interrupted runs as new attempts")
    p.add_argument("--prepare-data", action="store_true", help="Explicitly download needed datasets before real runs")
    p.add_argument("--fail-fast", action="store_true")
    p.add_argument("--timeout-seconds", type=float, default=0, help="Optional timeout per child process; 0 means no limit")
    args = p.parse_args(argv)
    work, data = args.work_dir.expanduser().resolve(), args.data_root.expanduser().resolve()
    if args.timeout_seconds < 0:
        p.error("timeout must be nonnegative")
    if args.mode in {"smoke", "dry-run", "tests", "report"} and args.prepare_data:
        p.error("--prepare-data is valid only for real")
    name = safe_name(args.name or ("real" if args.mode in {"real", "dry-run", "report"} else args.mode))
    batch = work / "outputs" / name
    state_path = batch / "suite_state.json"
    if args.mode == "report":
        from .report import generate
        generate(state_path)
        return 0
    if args.mode == "tests":
        from .testing import run_tests
        return run_tests(work, data)
    config = yaml.safe_load(args.config.read_text(encoding="utf-8")) or {}
    seeds = args.seeds if args.seeds is not None else config.get("seeds", [0, 1, 2])
    if not seeds or any(type(s) is not int or s < 0 for s in seeds) or len(set(seeds)) != len(seeds):
        p.error("Seeds must be distinct nonnegative integers")
    if len(set(args.tasks)) != len(args.tasks):
        p.error("Do not repeat tasks")
    overrides = resolve_configs(config, args.tasks, args.set, args.task_set)
    mode = "real" if args.mode == "dry-run" else args.mode
    device = "cpu" if mode == "smoke" and args.device == "auto" else args.device
    plan = {"schema_version": 3, "name": name, "mode": mode, "tasks": args.tasks,
            "seeds": seeds, "device": device, "work_dir": str(work), "data_root": str(data),
            "overrides": overrides, "review": config.get("review", {}),
            "source_sha256": source_fingerprint(), "environment": version_info()}
    if args.mode == "dry-run":
        print(json.dumps(plan, indent=2, ensure_ascii=False))
        return 0
    if work == data or data in work.parents:
        p.error("--work-dir must not be inside the dataset root; /localdata is datasets only")
    work.mkdir(parents=True, exist_ok=True)
    fingerprint = hash_object(plan)
    with BatchLock(batch / ".lock"):
        if state_path.exists():
            if not args.resume:
                p.error(f"Batch exists: {batch}. Use --resume or choose a new --name.")
            state = json_read(state_path)
            if state["fingerprint"] != fingerprint:
                p.error("Resume refused: configuration, source, paths or environment changed; choose a new --name")
        else:
            state = {"schema_version": 3, "fingerprint": fingerprint, "plan": plan,
                     "started_utc": utc(), "status": "running", "preparation": [],
                     "jobs": [{"task": task, "seed": seed, "status": "pending", "attempts": []}
                              for task in args.tasks for seed in seeds]}
        state["status"] = "running"
        state.pop("runner_error", None)
        state["updated_utc"] = utc()
        json_write(state_path, state)
        interrupted = False
        try:
            if args.prepare_data:
                prepare_datasets(state, state_path, args.timeout_seconds)
                if any(x.get("interrupted") for x in state.get("preparation", [])[-1:]):
                    raise KeyboardInterrupt
            for n, job in enumerate(state["jobs"], 1):
                task, seed = job["task"], job["seed"]
                if job["status"] == "complete":
                    okay, error = valid_result(job, plan)
                    if not okay:
                        raise RuntimeError(f"Saved result integrity failure: {task}/{seed}: {error}")
                    print(f"[SKIP {n}/{len(state['jobs'])}] {task} seed={seed}", flush=True)
                    continue
                if job["status"] == "running" and job["attempts"]:
                    # A killed launcher cannot commit its final status; retain the abandoned attempt.
                    job["attempts"][-1].update(status="interrupted_uncommitted",
                                               abandoned_on_resume_utc=utc())
                    job["status"] = "interrupted"
                attempt = len(job["attempts"]) + 1
                out = batch / "runs" / task / f"seed_{seed}" / f"attempt_{attempt:03d}"
                conf = batch / "configs" / f"{task}.yaml"
                conf.parent.mkdir(parents=True, exist_ok=True)
                conf.write_text(yaml.safe_dump(overrides[task], sort_keys=False), encoding="utf-8")
                log = batch / "logs" / f"{task}_seed{seed}_attempt{attempt:03d}.log"
                cmd = command_for(task, seed, conf, out, plan)
                record = {"attempt": attempt, "started_utc": utc(), "command": cmd, "log": str(log),
                          "output": str(out), "status": "running"}
                job.update(status="running", result=str(out / mode / f"seed_{seed}" / "result.json"))
                job.pop("result_sha256", None)
                job["attempts"].append(record)
                json_write(state_path, state)
                print(f"[RUN {n}/{len(state['jobs'])}] {task} seed={seed} -> {log}", flush=True)
                outcome = execute(cmd, log, child_env(PROJECTS[task], work, data), work, args.timeout_seconds)
                record.update(outcome, finished_utc=utc())
                okay, error = valid_result(job, plan)
                if outcome["returncode"] == 0 and okay:
                    job["status"] = record["status"] = "complete"
                    job["result_sha256"] = sha256_file(Path(job["result"]))
                    job.pop("error", None)
                    print(f"[OK] {task} seed={seed} ({outcome['wall_seconds']:.1f}s)", flush=True)
                else:
                    job["status"] = record["status"] = "interrupted" if outcome["interrupted"] else "failed"
                    job["error"] = error or f"Process exit {outcome['returncode']}"
                    print(f"[FAILED] {task} seed={seed}\n{tail(log)}", flush=True)
                state["updated_utc"] = utc()
                json_write(state_path, state)
                if outcome["interrupted"]:
                    interrupted = True
                    break
                if args.fail_fast and job["status"] != "complete":
                    break
        except KeyboardInterrupt:
            interrupted = True
        except Exception as exc:
            state["runner_error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            complete = sum(j["status"] == "complete" for j in state["jobs"])
            state["status"] = "interrupted" if interrupted else ("complete" if complete == len(state["jobs"]) and not state.get("runner_error") else "partial_failure")
            state["updated_utc"] = utc()
            json_write(state_path, state)
            from .report import generate
            generate(state_path)
    return 0 if state["status"] == "complete" else (130 if interrupted else 1)

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError, FileNotFoundError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
