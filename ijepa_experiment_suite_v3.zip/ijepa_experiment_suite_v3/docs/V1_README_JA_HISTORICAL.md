# I-JEPA 一括実験スイート v0.3

①TTA、③動画SSM、④セグメンテーション、⑤物理分布シフト、⑥連合学習を順番に実行し、結果を1ファイルに集約します。
②3DGSは対象外です。各テーマは `repos/` 内で独立したままです。

## 1. 保存先

**`/localdata` に置くのはデータセットだけです。**
残りは、スクリプトを呼び出したカレントディレクトリ配下に保存します。
スクリプト内で `cd` して保存先を変えることはしません。

```text
/localdata/
  cifar-10-batches-py/
  cifar-100-python/
  CIFAR-10-C/
  CIFAR-100-C/
  oxford-iiit-pet/
  videos/video_manifest.jsonl
  segmentation/mask_manifest.jsonl

./models/huggingface/hub/       # checkpoint
./models/torch/
./cache/<project>/             # features / compiler cache
./outputs/<batch>/             # state, logs, configs, raw run results
./reports/<batch>/             # aggregated report and review bundle
./artifacts/                   # optional standalone exports
./tmp/                         # test/runtime temporary files
```

既存データが `/localdata/datasets` にある場合は `--data-root /localdata/datasets` を指定し、移動せず利用できます。
生成物の保存先だけ変える場合は `--work-dir /path/to/work` です。
環境変数は `DATASETS_ROOT` と `IJEPA_WORK_DIR`。旧 `LOCALDATA_ROOT` / `--storage-root` は使用しません。
入力データのルート内に作業ディレクトリを置く指定は拒否します。

## 2. 最初の実行

Python 3.10以上、Linux/WSLを想定。使用GPUに対応するPyTorchを用意してから依存関係を導入してください。
各リポジトリを個別に `pip install -e` する必要はありません。

```bash
cd ijepa_experiment_suite
bash run_all.sh setup

# 5 tasks x 3 seeds; prepare required data, run sequentially, aggregate automatically
bash run_all.sh real --prepare-data --device cuda --seeds 0 1 2 --name pilot01
```

データが配置済みなら `--prepare-data` は不要です。
標準設定ではCIFAR-10とCIFAR-10-Cを取得します。CIFAR-10-Cは大容量です。
データ取得失敗時に別のデータやMockへ自動切替しません。
リモートサービスやLLMによる採点は使いません。

一括実行は逐次処理です。各テーマ・seedを別プロセスで起動し、終了後にGPUメモリを解放します。
公開checkpointのダウンロード先は共有し、特徴キャッシュはテーマ別です。

## 3. 次の方針を検討するために渡すファイル

**`reports/pilot01/review_bundle.zip` を一つ渡せば、結果・設定・ログを同時に確認できます。**

| File | Contents |
|---|---|
| REPORT.md | Per-theme paired baseline differences, costs, limitations, next decision checks |
| summary.json | Full machine-readable aggregation and run status |
| metrics.csv | Raw scalar metrics per seed |
| aggregates.csv | Independent-seed means / sample SD / counts |
| comparisons.csv | Paired deltas and cost ratios for specified comparisons |
| runs.csv | Completion/failure/attempt counts and wall time |
| runs/ in ZIP | Original result/config/environment/encoder JSON and process logs |

データセット、特徴配列、モデル重みは集約ZIPに含めません。
ログと設定にローカルパスや環境情報が含まれるため、外部共有時は確認してください。

異なるテーマの精度を無理に合成した総合順位は作りません。
同じseedのベースラインと提案候補の差を集計し、失敗は0で埋めません。
seedが1つの場合、標準偏差は0ではなくNA/nullです。
④は選ばれたモデル名ではなく、validation上の選択方針を単位に集計します。

## 4. 失敗・中断・再開

一つの実行が失敗しても、残りは継続し、最後に失敗を含むレポートを生成します。
全実行成功は終了コード0、部分失敗は1、通常のCtrl+C中断は130です。
同じbatchの同時書込みはロックで拒否します。

```bash
# Skip completed runs; retry failed/interrupted jobs from their beginning
bash run_all.sh real --device cuda --seeds 0 1 2 --name pilot01 --resume

# Regenerate aggregation without training
bash run_all.sh report --name pilot01

# Stop at the first failed job, while still writing an incomplete report
bash run_all.sh real --device cuda --name debug01 --fail-fast
```

再開は完了runのスキップであり、epochやFL roundの途中再開ではありません。
失敗した試行は `attempt_001` などとして残し、再試行は別フォルダに書きます。
コード・設定・環境・保存先が変わった場合は別の `--name` を使います。
データは実験中に書き換えないでください。データ更新後も新しいbatch名が必要です。
完了runの再開判定ではデータ全体の再ハッシュを行いません。

## 5. 設定変更

```bash
# Shared overrides
bash run_all.sh real --device cuda --name pilot02 \
  --set encoder.batch_size=1

# Per-theme override
bash run_all.sh real --device cuda --name pilot03 \
  --task-set tta:tta.update_budgets='[0,8,16]' \
  --task-set federated:federated.rounds=30

# Selected themes only
bash run_all.sh real --device cuda --name tta_physics \
  --tasks tta physics

# Print the plan without touching data/checkpoints or writing generated files
bash run_all.sh dry-run
```

`configs/suite.yaml` が初期設定です。完全な評価ではなくpilotである点に注意してください。
標準の①⑥はCIFAR subset、③は合成時間順序課題、④は合成形状、⑤は解析的物理シミュレーションです。
`real` は公開I-JEPAを使う意味であり、全テーマが実写データを使う意味ではありません。
実動画manifestとPetsを使う例は `configs/real_data.example.yaml` です。
動画の取得や分割は自動では行いません。データ形式は各 `repos/*/README_JA.md` に記載しています。

```bash
bash run_all.sh real --config configs/real_data.example.yaml \
  --prepare-data --device cuda --name realdata01
```

## 6. オフライン動作確認

```bash
bash run_all.sh setup-smoke
bash run_all.sh tests
bash run_all.sh smoke --seeds 0 1 2
bash run_all.sh smoke --seeds 0 1 2 --resume
```

**smokeはMockエンコーダです。I-JEPAの性能結果ではありません。**
公開重み、実データ、CUDAによる検証はこの配布時点で未実施です。
正式な既存手法の完全再現やトップ会議採択を保証する成果物ではありません。
元の研究設計とセルフレビューは各 `repos/*/docs/` に保持しています。
