# I-JEPA pilot01: evidence audit and research decisions

**Scope.** User-supplied `outputs(1).zip`, 15 complete runs, five themes, seeds 0/1/2.
This report distinguishes observed results, source-code defects, new CPU control experiments,
and proposed experiments. It does not estimate conference acceptance probabilities.

## 1. Evidence and reproducibility

All 15 results declare `PUBLIC_IJEPA_PILOT`, not Mock. Environment records identify an RTX 3090,
PyTorch 2.6.0, CUDA 12.4 and Transformers 4.57.1. The frozen encoder is
`facebook/ijepa_vith14_1k`, revision `f157467ea509bc356ff9f61fd3c0d840eec5e04e`, float32,
encoder batch size 2. The recorded child-package code hashes match the distributed original
source for every run. Thus the implementation audit applies to the code actually executed.
This verifies recorded provenance, not an independent rerun on the user's GPU.

The seeds vary model initialization and sampled/generated data. Mean +/- sample SD below is over
three runs; it is not a confidence interval for all future datasets. Repeated CIFAR base images,
frames, clients and paired renderings are not additional independent training runs. Scene bootstraps
in `audit_evidence.json` are conditional on each trained model. Pilot01 is now development evidence:
new hypotheses must eventually be tested on reserved seeds and shift factors.

## 2. Executive decisions

| Theme | Current conclusion | Next action | Publication prospects on current evidence |
|---|---|---|---|
| 01 TTA | Essentially no accuracy gain; calibration/anchor bugs confound the diagnosis | Correct the implementation and instrument effective update size before scaling CIFAR | No present algorithmic result; conditional continuation |
| 03 Temporal SSM | Chance-level classification; encoder dominates runtime | Verify cue accessibility/overfit, compare time-aware controls; fix the loop kernel | Low priority until the task is learned |
| 04 Device segmentation | Distillation slightly hurts; every constraint is slack | One binding-budget/real-image diagnostic, not a large sweep | Low; current setup cannot test the advertised hardware hypothesis |
| 05 Controlled shift | SSL improves appearance-shift robustness but hurts ID/dynamics; simple trackers dominate | Isolate temporal prediction from compression, then preserve state information | Highest diagnostic value, but not evidence for physical-law learning |
| 06 Federated | Local-only beats federated variants; random rank-4 projection discards task capacity | Closed-form, no-image prior, full-rank personalization and aligned-subspace controls | No current communication/accuracy dominance; potentially recoverable |

No theme presently supports a top-conference superiority claim. A four-page **preliminary diagnostic
extended abstract**, not a submission-ready paper, is supplied for theme 05.

## 3. Theme 01: resource-constrained TTA

### Observed results

The source uses 5,000 CIFAR-10 training images before source train/validation separation, and 1,000
base test images. The stream repeats these base images under three corruption types and three
severities, with clean blocks at the beginning and end. Frozen clean accuracy is 89.23% on average.
Corruption-only accuracy is **73.7296 +/- 0.9505%** frozen versus **73.7185 +/- 0.9396%** for drift gating
with nominal cap 32. The all-stream values are 76.5485% and 76.5394%, respectively. Thus including the
clean blocks does not hide a useful gain: the difference is essentially zero, slightly negative.
Drift gating makes 21 updates, while periodic makes 32. A common cap is not equal realized work.

### Verified implementation defects and confounds

The stratified split concatenates classes. Calibration then takes contiguous validation batches,
so it measures mostly single-class means rather than the mixed-class target batch distribution.
The 64 source anchors are `x[:64]`, all from one class. These are defects in the supplied MVP, not
failures of I-JEPA or of TTA in general. The drift threshold therefore mixes class-composition change
with domain change. Additionally, the first adapting method pays CUDA backward/setup warm-up: an
8-update run can look slower than a later 32-update run. Those timings cannot establish scheduler
superiority. The old logs do not contain per-sample predictions or parameter displacement, so we
cannot retrospectively distinguish tiny ineffective updates from opposing effects on examples.

### Revision and decision

V2 uses shuffled mixed source-validation batches, class-balanced source anchors, optimizer/loss and
parameter-step diagnostics, before/after logit changes, cold-start flags, corruption-only metrics
and compressed per-sample prediction logs. SGD remains the default to isolate the bug fixes; Adam
is an explicit separate sensitivity run, not a claimed improvement. First prove that useful adaptation
exists. Only then optimize when to spend updates, comparing periodic/random at equal actual work.
Advance to larger CIFAR-C and reserved corruptions only after a practically meaningful gain without
clean-return damage. A provisional development gate is >=1 point corruption gain with <=0.5 point
clean degradation, to be checked on new conditions, not tuned on the current test stream.

**Novelty constraint:** compute-limited evaluation and time-contingent TTA utility are already studied
by Alfarra et al. (ICML 2024) and Tempora (ICML 2026) [2,3]. A future contribution needs a defensible
update-value allocation principle, not merely a threshold gate attached to I-JEPA.

## 4. Theme 03: low-compute temporal modeling

Mean, first-frame, last-frame and Transformer accuracy are 50%. GRU averages 47.92%; uniform
16-frame gap-SSM reaches only **52.08 +/- 2.39%**. The synthetic task is balanced binary cyclic cue
order with matched reverse-order pairs and blank endpoints. SSM training loss remains close to
log(2), so a near-chance test score is not yet a useful generalization experiment.

At 16 frames, GRU head p95 is approximately **0.54 ms**, Transformer **1.12 ms**, and gap-SSM **2.26 ms**.
End-to-end latency is approximately **384-386 ms**, dominated by I-JEPA frame encoding. The Python
SSM time loop loses even at head-only latency. These are measured on this hardware; theoretical
linear scaling alone does not reverse the result.

V2 adds an exact vectorized final-state readout (tested against sequential values AND gradients),
a time-aware GRU, interaction pooling between early/late halves, a known-generator RGB rule and a
24-example training-only overfit test. The RGB rule scores 100% in the new CPU smoke runs; this is a
generator-specific sanity control, not a learned video model. The actual public-I-JEPA feature
accessibility still needs the user's rerun. The vectorized batch kernel uses O(T) working memory;
only the separate streaming recurrence has constant state memory.

If cue information is readable but sequence learning fails, revise the head/objective. If cue
information is missing, inspect spatial pooling before claiming SSM limitations. Do not advance to
large video datasets until the basic task is learned. A worthwhile later hypothesis concerns
observation-budget allocation under irregular sampling, compared with time-aware GRU at identical
observations. VideoMamba already establishes SSM-based efficient video modeling [4].

## 5. Theme 04: device-aware segmentation

Validation selects the same largest candidate (width 24, depth 3, input 128) for quality-only,
MAC-proxy and device-constrained selection in all seeds. Selected test mIoU is **90.4096 +/- 2.3883%**
without distillation and **90.1946 +/- 2.4664%** with distillation: a paired mean change of **-0.2150
percentage points**, negative in all three runs.

All candidates satisfy every configured constraint. The latency limit is 20 ms, versus measured
candidate p95 around 1.6-1.9 ms; parameter storage is at most 13,188 bytes versus a 2,000,000-byte
limit; the largest MAC count is 5,160,960 versus 20,000,000. The constraint cannot affect selection.
High synthetic-shape mIoU therefore supports neither I-JEPA distillation nor hardware-aware design.

V2 records slack constraints and validation-only candidate-selection curves across measured latency
quantiles. These quantiles are exploratory, not actual device SLAs. One 256/64/64 Pet pilot is provided
as an optional low-budget external-data check. Keep this theme low priority unless distillation or
binding-budget performance improves. Native target-device/backend evaluation is mandatory before an
on-device claim; RTX 3090 eager timing is not a phone result. A width sweep is not novel; selective
refinement work such as SparseRefine is a substantive comparator [5].

## 6. Theme 05: what actually improved?

128 train, 32 validation and 64 held-out scene families per seed; eight observed frames and six
future frames at dt=0.1. I-JEPA features are spatially pooled to a 2x2 grid. Source gravity is
0.08-0.18 and held-out gravity is 0.24-0.34 in simulation units. Appearance changes ball color AND
background together; this is one composite intervention, not independent color/texture evidence.
The encoder is frozen. The small downstream SSL predictor learns the last future image feature;
it is not the pretrained I-JEPA predictor and does not update I-JEPA.

| Method | ID | Appearance only | Gravity OOD | Joint | Drag-law shift |
|---|---:|---:|---:|---:|---:|
| Frozen feature ridge | .01777 | .13578 | .05015 | .13207 | .01835 |
| Future-feature SSL + ridge | .02682 | .08035 | .05893 | .08706 | .02620 |
| Random bottleneck + ridge | .03855 | .10344 | .07136 | .12566 | .03520 |
| Source mean, no image (audit control) | .10782 | .10782 | .12440 | .12440 | .10323 |
| RGB tracker + learned ridge (audit control) | .00114 | .00118 | .00416 | .00416 | .00674 |
| RGB tracker + imposed quadratic prior | .00119 | .00126 | .00120 | .00127 | .00375 |

Values are mean future-position RMSE over three runs, lower is better. Full SDs are in
`physics_aggregate.csv`. The two audit controls were computed during this analysis, not present in
pilot01: trajectories/images were reconstructed using the supplied generator, seeds and config;
reconstructed test targets were checked against every archived prediction target. They do not use
I-JEPA, do not retrain any user neural model and do not claim a hardware latency comparison.

### Interpretation supported by the data

SSL reduces mean RMSE by **40.83% under appearance shift** and **34.08% under joint shift** relative
to full-feature ridge. It is better than the identically initialized random bottleneck, so training
that bottleneck matters. It also beats the source-mean predictor; the gain is not explained by
returning one constant mean trajectory. Mean per-run skill relative to the source mean is about
0.445 under appearance shift and 0.499 under joint shift (these are not standard centered-test R2).

However, SSL worsens ID RMSE by **50.94%**, gravity OOD by **17.52%**, and drag-law shift by **42.78%**.
The ridge appearance failure is especially severe: it is worse than predicting the source mean.
A 40% reduction over that weak out-of-distribution baseline is not by itself a strong physics result.
Even the learned tracker baseline, which is supplied NO motion equation and uses only observed RGB
plus source future-position labels for its ridge fit, beats SSL by roughly 68x on appearance shift
and 21x on joint shift. Thus the gap is not explained solely by the explicit quadratic prior in the
original classical baseline.

### Hypotheses and discriminating experiments

H1: a lower-capacity bottleneck suppresses nuisance variation; this need not involve temporal physics.
H2: future-feature prediction learns temporally useful information beyond static appearance.
H3: predicting full future features spends capacity on static appearance and sacrifices position,
whereas predicting a future-minus-last residual can retain more motion information.

V2 tests matched-rank train-only PCA, last-frame-only SSL, per-scene shuffled-time SSL, and
residual-future SSL with matched downstream architecture/training. It retains random, source-mean,
learned-tracker and known-law controls. Match source future-image exposure when making an SSL-specific
claim; ridge originally sees less unlabeled future imagery. A separate state-preservation/ID-versus-OOD
tradeoff is the scientific question, not 'I-JEPA discovered physics'. No new-I-JEPA result from these
ablations is available yet.

If PCA/last-frame SSL explains the gain, recast the finding as representation regularization. If the
residual objective wins over those controls without excessive ID damage on fresh factors, extend
color/texture independently, introduce occlusion and multi-object events, preserve fair classical
baselines, and compare at least two alternative frozen visual representations. IntPhys 2 provides
an example of controlled physical reasoning evaluation, but is a different task from this pilot [6].
The supplied four-page abstract intentionally reports the tradeoff and its limitations rather than
inventing a superiority or law-discovery claim.

## 7. Theme 06: non-IID federated vision

| Method | Mean test accuracy | Total round payload |
|---|---:|---:|
| Centralized reference (not federated) | 82.00% | not a comparable FL traffic measure |
| Local-only | 57.00% | 0 |
| FedAvg full head | 46.77% | 10,248,000 bytes |
| FedProx full head | 46.63% | 10,248,000 bytes |
| Fixed random rank-4 basis | 25.37% | 40,000 bytes |
| Factor averaging | 30.97% | see per-seed log |
| Fixed basis + private bias | 50.40% | 40,000 bytes |

The 256x payload reduction of the fixed-basis model is not a useful dominance claim: the personalized
variant still loses 6.6 points to zero-communication local-only, with about 43.3% of clients harmed.
Worst-client personalization may improve relative to some baselines, but it does not erase the
mean-accuracy loss or the inadequacy of the comparison.

The rank-4 model projects 1,280 features into a random 4-D subspace; it is NOT a low-rank residual on
an already useful classifier. Moreover, centralized AdamW and federated local SGD use different
training budgets, so the central-FedAvg gap does not isolate statistical heterogeneity. Private bias
could exploit label proportions without useful image information, motivating a no-image prior.

V2 adds full closed-form ridge aggregation (Fed3R-style), task-aligned class-prototype subspaces,
full-head private-bias personalization and local class-prior prediction. The closed-form implementation
is numerically checked against centralized ridge and is partition-invariant. It counts dense float64
sufficient-statistic traffic, which can be LARGE at dimension 1,280; one round is not synonymous with
low communication. All-client participation for the statistics controls is explicit. Fed3R is existing
ICML 2024 work [7], not a proposed novelty. Prototype subspaces are diagnostics, not claimed inventions.

Do not scale to CIFAR-100 until a sensible accuracy/traffic/fairness frontier is recovered. A later
research question could address task-aligned residual-capacity allocation under client heterogeneity,
but only after strong frozen-feature and personalization baselines are competitive.

## 8. Next execution and trust boundaries

Run all five diagnostics at the same 0/1/2 seeds first to isolate implementation changes. Do not
resume the old batch; use `pilot02_diagnostic`. Only after selecting and freezing a hypothesis should
fresh seeds and previously reserved shift factors serve as confirmation. `README_V2.md` gives the
one-command execution and optional branches. `/localdata` remains datasets-only. Trained weights are
not saved; scalar/scene/sample logs are aggregated. Feature caches and public input weights remain
in the current directory and are excluded from review bundles.

The code revision passed CPU tests and Mock smoke runs, not a new public-I-JEPA GPU benchmark.
The CPU learned-tracker/source-mean controls are real analyses of the reconstructed pilot scenes;
they must not be confused with the Mock neural smoke runs. Reusable role-based review prompts are
included, but no fictitious independent agent reviews or unperformed GPU experiments are claimed.

## Primary references checked during this audit

[1] Assran et al. Self-Supervised Learning From Images With a Joint-Embedding Predictive Architecture.
CVPR 2023. https://openaccess.thecvf.com/content/CVPR2023/html/Assran_Self-Supervised_Learning_From_Images_With_a_Joint-Embedding_Predictive_Architecture_CVPR_2023_paper.html

[2] Alfarra et al. Evaluation of Test-Time Adaptation Under Computational Time Constraints. ICML 2024.
https://proceedings.mlr.press/v235/alfarra24a.html

[3] Sreeram et al. Tempora: Characterising the Time-Contingent Utility of Online Test-Time Adaptation.
ICML 2026. https://proceedings.mlr.press/v306/sreeram26a.html

[4] Li et al. VideoMamba: State Space Model for Efficient Video Understanding. ECCV 2024.
https://www.ecva.net/papers/eccv_2024/papers_ECCV/html/3773_ECCV_2024_paper.php

[5] Liu et al. Sparse Refinement for Efficient High-Resolution Semantic Segmentation. ECCV 2024.
https://www.ecva.net/papers/eccv_2024/papers_ECCV/html/8392_ECCV_2024_paper.php

[6] Bordes et al. IntPhys 2: Benchmarking Intuitive Physics Understanding In Complex Synthetic
Environments. 2025. https://arxiv.org/abs/2506.09849

[7] Fani et al. Accelerating Heterogeneous Federated Learning with Closed-form Classifiers. ICML 2024.
https://proceedings.mlr.press/v235/fani-24a.html
