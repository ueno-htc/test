# Predeclared next-stage decisions

These are engineering research gates for the NEXT development run, not claims of statistical
significance, acceptance odds, or universally required conference thresholds. Pilot01 is now
development data. Run matched seeds 0/1/2 to isolate implementation changes; then lock a candidate
before evaluating fresh seeds and reserved shifts. Do not move goalposts to rescue a failed hypothesis.

## 01 TTA

First require mixed-batch calibration, at least one source anchor per class when possible, nonzero
parameter steps and measurable logit changes. If almost no predictions change, investigate optimizer
scale/trust-region/loss conflict rather than crediting a scheduling rule. Compare actual update counts
and per-domain results, not just nominal caps. Separate first-backward cold-start from steady state.
A practical promotion gate is >=1 percentage point corruption-only gain over frozen and credible
advantage over periodic/random at matched actual work, while clean-return loss stays <=0.5 points.
These margins are chosen now for usefulness, not inferred significance. Repeat on reserved corruption
families and larger CIFAR evaluation only after the corrected pilot passes. Timing must include the
encoder for deployment claims. Reference: Alfarra et al., ICML 2024; Tempora, ICML 2026.

## 03 Temporal

The known-generator RGB rule should solve the synthetic task; it is NOT a general learned model.
A frozen-feature head should overfit 24 TRAINING examples (>95% is a debugging target). If not,
probe cue identity/localization, normalization, pooling and optimization before changing the SSM.
Only advance when a held-out order-sensitive head materially beats the chance/static controls.
Compare gap-SSM with gap-aware GRU at the same frame indices and timestamps. Measure end-to-end
cost, not Python-kernel asymptotics. A head-only win of 1 ms against a ~384 ms encoder path is not a
useful deployment result. The possible research direction is observation-budget allocation plus
stable irregular-time memory, not simply appending an SSM. VideoMamba is a direct prior comparator.

## 04 Segmentation

A synthetic ~90% mIoU is not evidence for I-JEPA distillation. All pilot01 constraints were slack.
Inspect validation-only budget curves. Candidate selection must change under a genuinely binding,
predeclared resource constraint before claiming hardware-aware decisions. Quantile budgets diagnose
this but are not a real device SLA. Give this theme at most one small real-image check (Pet), then
pause unless distillation or constrained quality improves reproducibly. Keep test labels out of
architecture selection. A device-specific claim requires the actual device/backend. SparseRefine
already studies selective dense/sparse computation; a width sweep alone is not novelty.

## 05 Physics / controlled shift

Primary development question: does temporal prediction, rather than generic compression or
last-frame appearance, cause the observed robustness tradeoff? Compare original SSL with matched
PCA, random projection, last-frame SSL, shuffled-time SSL and residual-future SSL. Preserve all
classical controls, including learned tracker + ridge (no supplied motion equation), and source-mean
prediction. Use the same source train/validation and fixed input/label budgets. The original SSL
accesses source future images; explicitly match that extra unlabeled exposure where appropriate.
A useful next gate is a consistent gain over compression/last-frame controls on a NEW appearance
factor without large ID loss, not merely another win over the fragile full-feature ridge. A provisional
margin is >=10% relative OOD RMSE reduction with <=10% ID RMSE deterioration. Verify this on new
seeds after method selection, not by tuning against pilot01.

If residual-future prediction preserves ID information but improves appearance robustness, extend
to independently varied texture, color, lighting and occlusion, with at least two frozen visual
pretraining controls. Do not remove the tracker merely because it wins. Add difficult but natural
multi-object/occlusion settings and report its failure modes fairly. If PCA or last-frame SSL explains
the gain, recast as representation regularization, not physics learning. The current single-object
benchmark cannot justify universal physical understanding or a novel law-discovery claim.

## 06 Federated

Verify Fed3R-style full ridge matches the centralized ridge solution for identical features, labels
and regularization. It may communicate more than the iterative head in this small-class regime;
record that cost rather than claiming one-round implies low bytes. Compare label-prior-only and
local-only baselines, full-rank personalization, and task-aligned vs random rank-4/9 bases.
If useful features are recovered by the closed-form control, separate optimizer insufficiency from
non-IID effects. A parameter-efficient method must beat zero-communication local-only in a useful
region of the accuracy/fairness/traffic frontier, not merely beat an overcompressed random head.
Require both average and adequately sampled worst-client performance; record negative transfer.
Only then expand to CIFAR-100 or feature/domain heterogeneity. Prototype/ridge baselines are existing
ideas, not a new top-conference method; the research question would concern task-aligned residual
capacity allocation under heterogeneous clients and explicit byte budgets.
