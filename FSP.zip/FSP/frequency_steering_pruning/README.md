# Frequency-Steering Pruning v4 — Spectral-Steering

Frequency-Steering Pruning（FSP）は、CNN／ViT の構造的プルーニングにおいて**モデルの周波数感度をタスクが必要とする周波数依存に合わせて誘導する**ための PyTorch 研究基盤である。v4 では評価プロトコルの修正と、新しい基準 **Spectral-Steering**（`pruning.method=spectral_steering`）を導入した。詳細な変更理由は `docs/V4_CHANGES.md`、数式は `frequency_pruning/pruning/spectral.py` の冒頭を参照。

## 唯一の実行方法

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

`run_all.sh` が次を一括して実行する（各 run は 1 GPU 1 プロセスで最大 8 並列）。

| stage | 内容 | 主な出力 |
|---|---|---|
| preflight / selftest | 固定パス・Python・8×H200・NCCL・`RLIMIT_NOFILE` の検査、Gloo control-plane self-test | `outputs/_orchestrator/preflight.json` |
| tuning | ImageNet val 10k で `lambda × target_profile` を選択 | `outputs/tuning/resnet50/best_result.json` |
| main | ResNet-50 / EfficientNet-B4 × 目標スパース率 `FSP_SPARSITIES` × seed × 全手法 | `outputs/main/<arch>/sp<..>/seed<..>/<method>/` |
| ablations | Spectral-Steering の推定器・符号・目標プロファイル・λ・回復手順のアブレーション（ResNet-50） | `outputs/ablations/` |
| vit | DeiT-B / ViT-B/16（任意で ViT-L/16）の head + MLP プルーニング | `outputs/vit/` |
| transfer | NEU-CLS / DTD / CUB-200-2011（＋ `TRANSFER_EXTRA` の ImageFolder データセット） | `outputs/transfer/` |
| aggregate / figures | 全 `summary.json` の集計と図表生成 | `outputs/all_results.csv`, `outputs/figures/` |

別の preflight、学習、評価、可視化、集計コマンドを事前・事後に実行する必要はない。

## 固定実行環境

```text
/home/ueno/FSP/frequency_steering_pruning
/home/ueno/.conda/envs/vip/bin/python
/localdata/imagenet/
/localdata/imagenet_family/imagenet-c
/localdata/NEU-CLS
/localdata          (torchvision DTD: /localdata/dtd/ を内包)
/localdata/CUB_200_2011
```

## Spectral-Steering の定式化（要約）

入力勾配 $g = \partial L/\partial x$ のスペクトルパワーを半径方向の帯域 $b$ で積分した **帯域感度** $S_b=\frac1N\sum_n\sum_{f\in b}|\mathcal F[g_n](f)|^2$ は、振幅 $\varepsilon$ の Fourier 基底ノイズ $\varepsilon U_f$ に対する一次の損失変化 $\varepsilon\langle g,U_f\rangle$ をそのまま帯域で集計したものである（ノイズのサンプリングは不要、微分可能）。構造単位 $g$（channel / head / MLP hidden）のゲートに関する一次近似で

$$c_{g,b}=\frac{\partial S_b/\partial\text{gate}_g}{S_b}$$

（ゲート除去による帯域感度の相対変化）を double back-propagation で求める。一方 **タスク依存** $r_b$ は帯域 $b$ を band-stop した入力での損失増加であり、感度と依存は別物である（高周波ノイズに脆弱だが高周波情報は使っていない、という状態がありうる）。目標重み $w=\hat r-\hat s$（零和・L1 正規化）を用いて keep-score を

$$\text{score}_g=\frac{I_0(g)}{\overline{I_0}}+\lambda\frac{\sum_b w_b c_{g,b}}{\overline{|\cdot|}},\qquad I_0(g)=\text{mean}_{\text{batch}}\left|\frac{\partial L}{\partial \text{gate}_g}\right|$$

と定義する。$w_b<0$（タスクが依存しないのにモデルが過敏な帯域）に寄与する単位は先に削られ、$w_b>0$ の帯域を支える単位は保護される。$\lambda=0$ または `target_profile=flat` のとき gate レベル Taylor-FO（`taylor`）に一致する。

### 構造単位と物理エクスポート

| Architecture | プルーニング単位 | Physical export |
|---|---|---|
| ResNet-50 | bottleneck hidden channel | 依存する Conv／BatchNorm 軸を同時 slice |
| EfficientNet-B4 | MBConv expanded channel | expansion、depthwise、SE、projection を再構築 |
| DeiT-B / ViT-B / ViT-L | attention head と MLP hidden channel | QKV、projection、FC1／FC2 を再構築 |

export 時には masked model と slim model を同じ device・FP32 で比較し、許容誤差を超える場合は run を完了扱いにしない。

## 比較手法（`pruning.method`）

| method | 内容 |
|---|---|
| `dense` | 事前学習（転移では task-adapted）重みをそのまま評価する参照 |
| `dense_finetuned` | プルーニング run と同じ epoch 予算で追加学習した dense |
| `random` / `magnitude` | ランダム／L1 ノルム |
| `snip` | パラメータ単位 $|g\cdot w|$（旧実装、勾配をバッチ合算後に絶対値） |
| `taylor` | gate レベル Taylor-FO（Molchanov et al. 2019、ミニバッチごとに絶対値） |
| `hap` | gate レベル経験 Fisher／Hutchinson 二階近似 |
| `lfs` | VTC-LFC 型：低域通過入力のみで Taylor 重要度（周波数系ベースライン） |
| `steering_only` / `frequency_steering` | v3 までの $|(g_{HP}-\lambda g_{LP})w|$（互換維持） |
| `spectral_steering` | **本手法**。`pruning.spectral.*` で推定器（exact / noise / filtered）、目標（auto / reliance / high / low / flat / manual）、λ、符号を制御 |

アブレーション名（`ablations.py` / `--methods`）：`spectral_noise`, `spectral_filtered`, `spectral_unsigned`, `spectral_reliance`, `spectral_high`, `spectral_low`, `spectral_flat`, `spectral_lambda0.5`, `spectral_lambda2`, `spectral_bands8`, `spectral_nokd`, `spectral_norecal`, `taylor_fourier_aug`, `taylor_nokd`。任意の上書きは `method@key=value,...` 形式（例 `spectral_steering@spectral.lambda=0.25`）。

## 予算と速度（v4.1）

- `pruning.budget: macs`（既定）：`target_sparsity` は **MAC 削減率**。各 round でランキングの prefix を二分探索し、物理 export 後の MAC が目標に達する最小集合を刈る。単位数ではなく MAC で全手法を揃える（Taylor 系は同じ単位数で magnitude より 5–7 pt 多く MAC を削るため、単位数基準の比較は不公平）。
- `pruning.channel_alignment: 8`：保持チャネル数を 8 の倍数へ丸める（attention head は対象外）。不規則幅は MAC を削っても GPU で速くならない（v4.0 では MAC −60% で速度 0.96–1.12 倍）。
- 速度は `speedup_vs_dense`（dense の slim モデル基準、batch 1/32/128）で報告する。`measured_speedup` はゲート付きモデル基準で過大なので使わない。
- `spectral_trajectory`：round ごとに刈り直後・BN 再校正後・回復後の帯域感度と、一次予測 −Σc_{g,b} vs 実測 ΔS_b を記録する。

## 公平な回復プロトコル（全手法共通）

- 同一の構造グループ・global selection・決定論的 calibration subset（**train split から抽出**）
- 同一の sparsity schedule（幾何級数 `num_rounds` 段）と per-layer 最小幅
- 各ラウンド後の BatchNorm 再キャリブレーション（`bn_recalibration_batches`、ViT は無効）
- dense 教師からの logit 蒸留（`train.distill_dense`, α=0.5, T=2）は transfer のみ既定 on。ImageNet では LS 学習済み教師からの KD が効かなかったため既定 off（`spectral_kd`/`taylor_kd` で再検証）
- 同一の optimizer・epoch 予算・augmentation。`dense_finetuned` にも同じ予算を与える
- 評価：clean / ImageNet-C（周波数帯別集計）/ 任意で ImageNet-Sketch・Stylized-ImageNet（ImageNet-R は評価しない）/ LP・HP 入力 / 帯域感度・依存プロファイル / 物理 param・MAC・実測 throughput

## 制御可能性の指標

各 run の `summary.json` に dense と最終モデルの `spectral` ブロック（帯域感度 $\hat s$、band-stop 依存 $\hat r$、band-stop top-1）を記録する。`tools/collect_results.py` は `profile_mismatch_dense/pruned`（$\|\hat r-\hat s\|_1$）と `steering_gain`（mismatch の減少量）、帯域ごとの `sens_shift_*`、ImageNet-C の `high/mid/low_freq_top1` を列として出力し、`tools/make_figures.py` が Pareto 図・プロファイル比較・steering gain・ImageNet-C 帯域別の図と `results_table.md` を生成する。

## 同じ 1 コマンドで使える任意設定

すべて `run_all.sh` への環境変数として指定する。

```bash
FSP_SPARSITIES=0.3,0.5,0.7 FSP_SEEDS=42,43,44 bash run_all.sh
SKIP_TUNING=1 LAMBDA=1.0 PROFILE=auto bash run_all.sh
SKIP_ABLATIONS=1 SKIP_VIT=1 bash run_all.sh
VIT_MODELS=deit_base_patch16_224,vit_b_16,vit_l_16 bash run_all.sh
TRANSFER_EXTRA="kth_tips2b=/localdata/kth_tips2b;sun397_sub=/localdata/sun397_sub" bash run_all.sh
IMAGENET_SKETCH_ROOT=/localdata/imagenet-sketch bash run_all.sh
METHODS=dense,taylor,spectral_steering bash run_all.sh
FSP_MAX_PARALLEL_JOBS=4 FSP_PRECISION=fp32 bash run_all.sh
RESNET50_WEIGHTS=IMAGENET1K_V1 bash run_all.sh            # 既存論文と同じ 76.13 基準
FSP_EXTRA_SETS="train.lr=0.004;train.final_epochs=20" bash run_all.sh   # 全 stage へ一括上書き
FSP_STOP_ON_STAGE_FAILURE=1 bash run_all.sh               # 既定は失敗 stage があっても後続を実行
```

プロトコルを変更した版（v4.1）で再実行する前に、旧結果は `mv outputs outputs_v4.0` で退避すること（`COMPLETED` の version が異なる run は再実行される）。

`FSP_SMOKE_ONLY=1`（CPU 合成データ）は release 検証用であり、本番の研究実験ではない。

## 出力

各 run は、設定、checkpoint、saliency（単位×帯域の寄与表を含む）、pruning plan、学習・評価 metrics、周波数 error curve、ImageNet-C 詳細、Fourier heat map、帯域プロファイル、slim model、TorchScript、export metrics、`summary.json`、`COMPLETED` を保存する。全体集計は `outputs/all_results.csv`、図表は `outputs/figures/`。前リリース（v3）の実測結果は参照用に `docs/previous_results_v3.csv` へ移動した。

## 研究上の注意

Spectral-Steering は「構造プルーニングで周波数感度をタスクの周波数依存に合わせられる」という検証可能な仮説であり、全 corruption への一様な改善を前提としない。clean accuracy、帯域プロファイルの mismatch、ImageNet-C 帯域別結果、物理的 param/MAC 削減、実測 latency、複数 seed の信頼区間を併記すること。
