# Frequency-Steering Pruning v6 — cross-layer calibration

CNN／ViT の構造的プルーニングの研究基盤。当初の主題（周波数特性の誘導によるタスク特化）は v3〜v5 の 4 世代の実験で支持されず、
v6 では実験から得られた事実「精度を決めるのは層間の較正（深さ方向の配分）で、最適点はタスクとデータ量で変わる」を検証する。

- 評価：`docs/V6_EVALUATION.md`（最新）、`docs/V5_EVALUATION.md`、`docs/V4_1_EVALUATION.md`
- 論文草稿（日本語 8 ページ）：`paper/paper_draft_ja.pdf`。ソースは `paper/tex/`（XeLaTeX、`./build.sh 11pt 1.12 0.9`）、図は `python paper/make_paper_figures.py --run-a <v5 の outputs> --run-b <v6 の outputs>` で再生成できる
- 仮説と判定規則：`docs/HYPOTHESES_V6.md`　論理と見通し：`docs/PAPER_LOGIC_V6.md`
- 研究ループの役割分担：`agents/README.md`

## 唯一の実行方法

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

完了済みの run（`summary.json` と `COMPLETED`）は再実行されない。v5 の `outputs/` をそのまま残して実行すれば、追加分だけが走る。

| stage | 内容 | 目安（8 GPU） | 出力 |
|---|---|---|---|
| preflight / selftest | 固定パス・GPU・NCCL・FD 上限の検査 | 数分 | `outputs/_orchestrator/` |
| transfer | 転移タスク × アーキ × 3 seed。α 掃引（`taylor_mix*`）、先読み選択（`taylor_auto`）、Dense ゲート | 半日 | `outputs/transfer/` |
| transfer_latency | 同じ転移タスクを**実測速度**を揃えて比較（既定 DeiT-B、速度 30% 削減） | 数時間 | `outputs/latency/` |
| lowdata | ImageNet/ResNet-50 を学習データ 10%（128,000 枚）で回復。逆転の原因がデータ量かを検証 | 3–4 時間 | `outputs/lowdata/` |
| specialize | 崩壊の種類ごとの特化を検証：周波数頑健性から各層の削る割合を決める（`ralloc_*`）、学習し直す画像に帯域ノイズを加える／帯域を除く（`*_noise_*`, `*_aug_*`）。`docs/RESEARCH_PLAN_V7.md` | 16 時間前後 | `outputs/specialize/` |
| main / vit / ablations | ImageNet 全データ。v5 の結果を再利用し、追加変種のみ実行 | 追加分のみ | `outputs/main/` ほか |
| aggregate / analysis / figures | 集計、自動監査（Dense ゲート・順位・仮説 G1–G7・論文ゲート）、図表 | 数分 | `outputs/all_results.csv`, `outputs/analysis/`, `outputs/figures/` |

推奨：まず安い 3 stage だけを回す。

```bash
SKIP_MAIN=1 SKIP_VIT=1 SKIP_ABLATIONS=1 bash run_all.sh
```

## 検証対象の手法

gate レベル Taylor スコアに対し、層内順位の百分位とネットワーク全体での百分位を混ぜる：

$$q_g(\alpha) = (1-\alpha)\,p^{\text{layer}}_g + \alpha\,p^{\text{global}}_g$$

α = 0 は全層を同じ割合で刈る一様配分、α = 1 は損失で較正されたグローバル順位。
`taylor_auto` は α の候補ごとに「最終予算まで一括で刈る → 200 step 回復 → 学習データから切り出した hold-out の損失」で比較し、最良の α で通常の反復手順を実行する（検証・テスト画像は選択に使わない）。

予算は `pruning.budget` で選ぶ：`macs`（物理 MAC、既定）、`latency`（export したモデルの実測速度）、`units`（単位数）。保持チャネル数は 8 の倍数に揃える。

## 手法名

| 名前 | 内容 |
|---|---|
| `dense` / `dense_finetuned` | 参照（追加学習なし）／同一予算で追加学習 |
| `random`, `magnitude`, `taylor`, `lfs`, `hap`, `frequency_steering` | 層ごと z-score で正規化する従来基準 |
| `taylor_global` | Taylor をグローバル順位で（v5 で転移 +3.1 pt、12/12） |
| `taylor_mix0` / `0.25` / `0.5` / `0.75` / `taylor_mix1` | 較正族 α の掃引 |
| `taylor_auto` / `taylor_auto5` | 先読みで α を選択（候補 3 個／5 個） |
| `taylor_sum` / `taylor_mean` / `taylor_max` / `taylor_std` / `taylor_lamp`, `magnitude_global` / `magnitude_mean` / `magnitude_lamp` | 固定の層間正規化ベースライン（`taylor` は gaussian 正規化に相当） |
| `srp`, `srp_lambda0`, `srp_lambda1`, `srp_od`, `srp_pass`, `srp_low`, `rfc` | 帯域依存を使う基準（v5 で効果なし。G6 の決着用に `srp` のみ既定で実行） |
| `*_rpr` | 依存保存型の回復学習（対照実験で有害。既定では実行しない） |
| `ralloc_hi` / `ralloc_lo` / `ralloc_all`（`_a1` は α=1） | 周波数頑健性の一次近似から各層の削る割合を決め、層内は Taylor で選ぶ |
| `taylor_mix0_noise_hi` / `_noise_lo`, `taylor_mix0_aug_hi` / `_aug_lo` | 学習し直す画像に帯域ノイズを加える／帯域を除く |
| `ralloc_hi_noise_hi` / `ralloc_lo_noise_lo`, `dense_finetuned_noise_hi` / `_lo` | 両者の併用／削らない対照 |

任意の上書きは `method@key=value,...`（例 `taylor@layer_normalization=rankmix,rank_mix_alpha=0.3`）。

## 同じ 1 コマンドで使える設定

```bash
SKIP_MAIN=1 SKIP_VIT=1 SKIP_ABLATIONS=1 bash run_all.sh                 # 転移＋速度一致＋低データ ImageNet
TRANSFER_TV="Flowers102=/localdata/flowers102;OxfordIIITPet=/localdata/pets;FGVCAircraft=/localdata/aircraft;Food101=/localdata/food101" bash run_all.sh
FSP_DOWNLOAD=1 TRANSFER_TV="Flowers102=/localdata/tv;EuroSAT=/localdata/tv" bash run_all.sh
TRANSFER_EXTRA="kth=/localdata/kth_tips2b;mvtec=/localdata/mvtec_cls" bash run_all.sh
FSP_SEEDS=42,43,44 MODELS=resnet50 METHODS=dense,magnitude,taylor,taylor_mix0.5,taylor_global,taylor_auto bash run_all.sh   # ImageNet を 3 seed に
LOWDATA_TRAIN_SIZE=64000 FSP_LOWDATA_SEEDS=42,43,44 bash run_all.sh
LATENCY_MODELS=deit_base_patch16_224,resnet50 FSP_LATENCY_TARGETS=0.3 bash run_all.sh
SKIP_LOWDATA=1 SKIP_LATENCY=1 SKIP_CONTROLLED=1 bash run_all.sh
SKIP_TRANSFER=1 SKIP_LOWDATA=1 SKIP_MAIN=1 SKIP_VIT=1 bash run_all.sh   # specialize stage のみ
FSP_EXTRA_SETS="train.lr=0.004" FSP_STOP_ON_STAGE_FAILURE=1 bash run_all.sh
```

論文ゲートは転移の (dataset, arch) グループを 6 以上要求する。DTD・CUB × 2 アーキでは 4 なので、`TRANSFER_TV` か `TRANSFER_EXTRA` でデータセットを足すこと。
固定パス：`/localdata/imagenet/`, `/localdata/imagenet_family/imagenet-c`, `/localdata/NEU-CLS`, `/localdata`（DTD）, `/localdata/CUB_200_2011`。

## 出力

各 run：設定、checkpoint、saliency、pruning plan、学習・評価 metrics、帯域依存プロファイル、層別保持率、先読みの記録（`lookahead.json`）、
slim model、export metrics、`summary.json`、`COMPLETED`。全体：`outputs/all_results.csv`、`outputs/analysis/analysis_report.md`、`outputs/figures/`。

## 注意

- v6 の主張は未検証の仮説を含む。主張できるのは `outputs/analysis/analysis_report.md` の論文ゲートが READY になった内容だけ。
- MAC 削減は実測速度と一致しない（v5：ResNet-50 は MAC −50% で 1.06–1.12 倍、DeiT-B は刈る場所により 1.15〜1.78 倍）。
- CPU の smoke とユニットテスト（71 件）は実装経路のみを検証する。
