# Frequency-Steering Pruning v4 verification report

Verification date: 2026-10-31 (CPU-only container; no datasets, no GPU)

## Environment

- Python 3.12.3, PyTorch 2.15.0 (CPU), torchvision 0.29.2, NumPy 2.4.4,
  Matplotlib 3.10.8, PyYAML 6.0.3, Pillow 12.1.1

## Automated checks

1. `python -m compileall -q .` completed successfully.
2. `python -m pytest -q` passed all 44 tests (9 legacy + 35 new/updated), including
   `tests/test_spectral.py`: band masks partition the spectrum, band filters keep
   the DC term, steering weights are zero-sum / L1-normalised and vanish when the
   profiles match, every estimator (exact / noise / filtered, signed / unsigned)
   yields finite scores, `spectral_steering` with `target_profile=flat` equals
   `taylor`, BN recalibration updates statistics, the dense / dense_finetuned
   budget rules, and method-spec parsing.
3. `bash -n run_all.sh` and every other shell script passed syntax validation.
4. `FSP_SMOKE_ONLY=1 FSP_ALLOW_NONSTANDARD_ROOT=1 bash run_all.sh` completed:
   Gloo control-plane self-test, CPU preflight, the `spectral_steering` smoke run
   (exact estimator, auto target, BN recalibration, dense distillation, spectral
   profiles, Fourier maps, physical export with max |diff| 4e-6), the
   `taylor + frequency_augment` smoke run, and result collection.
5. Additional CPU runs exercised `taylor`, `lfs`, `dense`, `dense_finetuned`,
   `spectral_steering` with the `noise` and `filtered` estimators, the ViT debug
   model, `transfer.py` with a generic ImageFolder dataset (two-phase shared
   dense checkpoint verified to give identical dense accuracy in both phases),
   `tools/collect_results.py` and `tools/make_figures.py`.

## What has not been claimed

No ImageNet, ImageNet-C, NEU-CLS, DTD or CUB experiment was executed
here. This report establishes implementation completeness and executable
control flow; it does not establish accuracy, robustness or statistical
significance of Spectral-Steering.
