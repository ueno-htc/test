# Frequency-Steering Pruning v6 verification report

Verification date: 2026-11-19 (CPU-only container; no real datasets, no GPU)

## Automated checks

1. `python -m compileall -q .` completed successfully.
2. `python -m pytest -q` passed all 64 tests (v6 additions: rank-mix alpha = 1 equals the global ranking, alpha = 0
   prunes every group by the same percentile, intermediate alpha interpolates, hold-out split, training subset,
   latency-budget search, aliases). Earlier: 56 tests (v5 additions: SRP scoring modes including the output-difference
   estimator, SRP with lambda = 0 equals global gate-level Taylor, Reliance-Filtered Calibration with threshold 0
   equals global Taylor, weight modes, method aliases, dense-gate thresholds, source-reliance table, torchvision
   dataset wrapper, MAC-budget search and channel alignment, override ordering).
3. `FSP_SMOKE_ONLY=1 FSP_ALLOW_NONSTANDARD_ROOT=1 bash run_all.sh` completed.
4. `transfer.py` was exercised on a synthetic ImageFolder dataset with several seeds (task adaptation, dense
   gate, shared dense checkpoint, MAC budget with alignment, distinct dataset labels, reliance trajectory).
5. `tools/collect_results.py`, `tools/make_figures.py` and `tools/analyze_results.py` were run on the real v4.1
   result tree (147 runs); the figure stage that crashed on the server completes.
6. `tools/controlled_experiment.py` was run on CPU (ResNet-18, 32 px, 61 runs); results and the audit report are
   in `docs/figures_controlled/` and `docs/CONTROLLED_EXPERIMENT_V5.md`.

## What the controlled experiment showed

No band-based selection term (seven formulations) improved on globally ranked gate-level Taylor, and
reliance-preserving recovery reduced accuracy. Global ranking instead of per-layer z-scoring was the only clear
improvement. These are synthetic-task results with 2-3 seeds.

## What has not been claimed

No v5 experiment has been run on real data. This report establishes implementation completeness, executable
control flow and the controlled mechanism check only.

## v6 additions exercised on CPU

- `train.py` with `layer_normalization=rankmix`, `rankmix_auto` (look-ahead), `budget=latency` and
  `data.train_subset_size`.
- `transfer.py` with `taylor_mix0.5`, `taylor_global`, `taylor_auto` from a shared dense checkpoint, and a
  second pass with `pruning.budget=latency`.
- `tools/analyze_results.py` (G1-G7 and the v6 gate) on the real v5 result tree: G1 SUPPORTED, G2 and G6
  INCONCLUSIVE, the remaining v6 hypotheses NO DATA.

No v6 experiment has been run on real data.
