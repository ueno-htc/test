#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gc
from pathlib import Path

import numpy as np
import torch

from frequency_pruning.checkpoint import load_checkpoint
from frequency_pruning.config import resolve_config
from frequency_pruning.datasets import build_dataset_bundle, build_loaders
from frequency_pruning.models import build_model
from frequency_pruning.utils import save_json, set_seed
from frequency_pruning.visualization import (
    compare_frequency_maps,
    compute_fourier_sensitivity_heatmap,
    compute_layer_frequency_maps,
    save_heatmap,
    save_layer_maps,
)


def load_model(path: str, config, num_classes: int, device: torch.device):
    model = build_model(
        config["model"]["arch"],
        num_classes,
        weights="NONE",
        image_size=int(config["model"]["image_size"]),
    )
    load_checkpoint(path, model, strict_model=True, strict_masks=False)
    return model.to(device).eval()


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate model-level and per-layer Fourier heat maps")
    parser.add_argument("--config", required=True)
    parser.add_argument("--dense-checkpoint", required=True)
    parser.add_argument("--pruned-checkpoint", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--skip-model-map", action="store_true")
    parser.add_argument("--skip-layer-map", action="store_true")
    args = parser.parse_args()

    config = resolve_config(args.config, args.overrides)
    device = torch.device("cuda" if args.device == "auto" and torch.cuda.is_available() else args.device if args.device != "auto" else "cpu")
    set_seed(int(config["experiment"]["seed"]), True)
    bundle = build_dataset_bundle(config)
    config["model"]["num_classes"] = bundle.num_classes
    loaders = build_loaders(bundle, config, distributed=False)
    loader = loaders["val"]
    if loader is None:
        raise ValueError("A validation dataset is required")
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    dense = load_model(args.dense_checkpoint, config, bundle.num_classes, device)
    pruned = load_model(args.pruned_checkpoint, config, bundle.num_classes, device)
    vis = config["visualization"]
    summary = {}

    if not args.skip_model_map:
        kwargs = dict(
            resolution=int(vis["heatmap_resolution"]),
            amplitude=float(vis["heatmap_amplitude"]),
            max_batches=int(vis["heatmap_batches"]),
            amp=str(config["train"]["amp"]),
            channels_last=bool(config["model"].get("channels_last", False)) and device.type == "cuda",
            reduce_distributed=False,
        )
        dense_heat = compute_fourier_sensitivity_heatmap(dense, loader, device, **kwargs)
        pruned_heat = compute_fourier_sensitivity_heatmap(pruned, loader, device, **kwargs)
        shift = pruned_heat - dense_heat
        np.save(output / "dense.npy", dense_heat)
        np.save(output / "pruned.npy", pruned_heat)
        np.save(output / "shift.npy", shift)
        save_heatmap(dense_heat, output / "dense.png", "Dense Fourier sensitivity")
        save_heatmap(pruned_heat, output / "pruned.png", "Pruned Fourier sensitivity")
        save_heatmap(shift, output / "shift.png", "Pruned - dense", symmetric=True)
        summary["model"] = {"dense": "dense.png", "pruned": "pruned.png", "shift": "shift.png"}

    if not args.skip_layer_map:
        kwargs = dict(
            max_batches=int(vis["layer_batches"]),
            target_size=64,
            amp=str(config["train"]["amp"]),
            channels_last=bool(config["model"].get("channels_last", False)) and device.type == "cuda",
            max_layers=int(vis.get("max_layers", 0)),
            reduce_distributed=False,
        )
        dense_maps = compute_layer_frequency_maps(dense, loader, device, **kwargs)
        pruned_maps = compute_layer_frequency_maps(pruned, loader, device, **kwargs)
        save_layer_maps(dense_maps, output / "layers_dense", "dense")
        save_layer_maps(pruned_maps, output / "layers_pruned", "pruned")
        summary["layers"] = compare_frequency_maps(dense_maps, pruned_maps, output / "layer_shift")

    save_json(output / "summary.json", summary)
    print(output.resolve())


if __name__ == "__main__":
    main()
