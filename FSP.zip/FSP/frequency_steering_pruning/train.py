#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import time
import traceback
from pathlib import Path

from frequency_pruning.config import resolve_config
from frequency_pruning.distributed import cleanup_distributed
from frequency_pruning.runner import run_experiment

try:
    from torch.distributed.elastic.multiprocessing.errors import record
except ImportError:  # pragma: no cover - old/non-distributed torch
    def record(function):
        return function


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Frequency-Steering structured pruning training pipeline"
    )
    parser.add_argument("--config", type=str, default="", help="YAML or JSON configuration file")
    parser.add_argument(
        "--set",
        dest="overrides",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Override a dotted configuration key; repeat as needed",
    )
    parser.add_argument("--run-dir", type=str, default="", help="Exact output directory")
    parser.add_argument(
        "--evaluate-only",
        action="store_true",
        help="Skip pruning/training and evaluate the loaded checkpoint",
    )
    return parser


def _write_failure(run_dir: str, error: BaseException) -> None:
    if not run_dir:
        return
    path = Path(run_dir)
    try:
        path.mkdir(parents=True, exist_ok=True)
        payload = {
            "status": "failed",
            "time_unix": time.time(),
            "host": socket.gethostname(),
            "pid": os.getpid(),
            "rank": int(os.environ.get("RANK", "0")),
            "local_rank": int(os.environ.get("LOCAL_RANK", "0")),
            "world_size": int(os.environ.get("WORLD_SIZE", "1")),
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
        }
        temporary = path / "FAILED.json.tmp"
        temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        temporary.replace(path / "FAILED.json")
    except Exception as write_error:
        # Preserve the original failure while still surfacing the secondary
        # filesystem problem instead of silently swallowing it.
        print(
            f"WARNING: could not write FAILED.json: {type(write_error).__name__}: {write_error}",
            file=sys.stderr,
            flush=True,
        )


@record
def main() -> None:
    args = build_parser().parse_args()
    try:
        config = resolve_config(args.config or None, args.overrides)
        run_experiment(config, run_dir=args.run_dir or None, evaluate_only=args.evaluate_only)
    except BaseException as error:
        _write_failure(args.run_dir, error)
        cleanup_distributed(synchronize=False)
        raise


if __name__ == "__main__":
    main()
