#!/usr/bin/env python3
"""ViT / DeiT structured-pruning comparison (attention heads + MLP channels)."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from frequency_pruning.orchestration import (
    ExperimentTask,
    arch_overrides,
    command_with_overrides,
    parse_floats,
    parse_ints,
    resolve_method_spec,
    run_tasks,
    sparsity_tag,
    split_csv,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run ViT-B/DeiT-B(/ViT-L) structured-pruning experiments")
    parser.add_argument("--config", default="configs/vit_v4.yaml")
    parser.add_argument("--models", default="deit_base_patch16_224,vit_b_16")
    parser.add_argument(
        "--methods",
        default="dense,dense_finetuned,random,magnitude,taylor,hap,lfs,frequency_steering,spectral_steering",
    )
    parser.add_argument("--sparsities", default="0.5")
    parser.add_argument("--seeds", default="42")
    parser.add_argument("--output-root", default="outputs/vit")
    parser.add_argument("--status-root", default="outputs/_orchestrator")
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    python = os.environ.get("FSP_PYTHON", sys.executable)
    tasks: list[ExperimentTask] = []
    for arch in split_csv(args.models):
        for target in parse_floats(args.sparsities):
            for seed in parse_ints(args.seeds):
                for spec in split_csv(args.methods):
                    run_name, method, method_overrides = resolve_method_spec(spec)
                    run_dir = root / arch / sparsity_tag(target) / f"seed{seed}" / run_name
                    overrides = [
                        f"model.arch={arch}",
                        f"experiment.seed={seed}",
                        *arch_overrides(arch),
                        *args.overrides,
                        *method_overrides,
                        f"pruning.target_sparsity={target}",
                        "pruning.sparsity_schedule=[]",
                    ]
                    tasks.append(
                        ExperimentTask(
                            name=f"vit/{arch}/{sparsity_tag(target)}/seed{seed}/{run_name}",
                            command=command_with_overrides(python, args.config, run_dir, overrides),
                            run_dir=str(run_dir),
                            metadata={"arch": arch, "method": method, "sparsity": target, "seed": seed},
                        )
                    )
    try:
        run_tasks(tasks, stage="vit", status_root=args.status_root)
    finally:
        subprocess.run(
            [python, "tools/collect_results.py", "--root", str(root), "--output", str(root / "results.csv")],
            check=False,
        )


if __name__ == "__main__":
    main()
