#!/usr/bin/env python3
"""ImageNet CNN comparison: models x target sparsities x seeds x methods.

Every run is an independent single-GPU process scheduled by
``frequency_pruning.orchestration.run_tasks``.  Run directories follow
``<output-root>/<arch>/sp<target>/seed<seed>/<method-run-name>`` so that
``tools/collect_results.py`` can group Pareto points and seeds.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from frequency_pruning.orchestration import (
    ExperimentTask,
    arch_overrides,
    command_with_overrides,
    parse_floats,
    parse_ints,
    resolve_method_spec,
    run_tasks,
    sparsity_tag,
    split_csv,
)

CONFIGS = {
    "resnet50": "configs/imagenet_resnet50_v4.yaml",
    "efficientnet_b4": "configs/imagenet_efficientnet_b4_v4.yaml",
}


def weight_overrides(model: str, args) -> list[str]:
    if model != "resnet50" or str(args.resnet50_weights).upper() in {"DEFAULT", "IMAGENET1K_V2", "V2"}:
        return []
    # V1 weights follow the classic recipe: resize 256 -> center crop 224, bilinear.
    return ["model.weights=IMAGENET1K_V1", "data.resize_size=256", "data.interpolation=bilinear"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the main ImageNet CNN pruning comparison in parallel")
    parser.add_argument("--models", default="resnet50,efficientnet_b4")
    parser.add_argument(
        "--methods",
        default="dense,dense_finetuned,random,magnitude,taylor,hap,lfs,frequency_steering,spectral_steering",
    )
    parser.add_argument("--sparsities", default="0.5,0.7")
    parser.add_argument("--seeds", default="42")
    parser.add_argument("--output-root", default="outputs/main")
    parser.add_argument("--status-root", default="outputs/_orchestrator")
    parser.add_argument("--lambda", dest="lambda_value", type=float, default=1.0)
    parser.add_argument("--profile", default="auto", help="pruning.spectral.target_profile for spectral_steering")
    parser.add_argument("--cutoff", type=float, default=0.25, help="legacy cutoff for frequency_steering/lfs")
    parser.add_argument("--imagenet-root", required=True)
    parser.add_argument("--imagenet-c-root", default="")
    parser.add_argument("--imagenet-r-root", default="")
    parser.add_argument("--imagenet-sketch-root", default="")
    parser.add_argument("--stylized-imagenet-root", default="")
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--skip-figures", action="store_true")
    parser.add_argument(
        "--resnet50-weights",
        default="DEFAULT",
        help="torchvision weight tag for ResNet-50: DEFAULT (=IMAGENET1K_V2, 80.86%%) or IMAGENET1K_V1 (76.13%%, "
        "the baseline used by most published pruning papers)",
    )
    args = parser.parse_args()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    python = os.environ.get("FSP_PYTHON", sys.executable)
    tasks: list[ExperimentTask] = []
    for model in split_csv(args.models):
        if model not in CONFIGS:
            raise ValueError(f"Unsupported main model: {model}; choose from {sorted(CONFIGS)}")
        config = CONFIGS[model]
        for target in parse_floats(args.sparsities):
            for seed in parse_ints(args.seeds):
                for spec in split_csv(args.methods):
                    run_name, method, method_overrides = resolve_method_spec(spec)
                    run_dir = root / model / sparsity_tag(target) / f"seed{seed}" / run_name
                    overrides = [
                        f"data.root={args.imagenet_root}",
                        f"data.imagenet_c_root={args.imagenet_c_root}",
                        f"data.imagenet_r_root={args.imagenet_r_root}",
                        f"data.imagenet_sketch_root={args.imagenet_sketch_root}",
                        f"data.stylized_imagenet_root={args.stylized_imagenet_root}",
                        f"experiment.seed={seed}",
                        f"pruning.target_sparsity={target}",
                        "pruning.sparsity_schedule=[]",
                        f"pruning.lambda={args.lambda_value}",
                        f"pruning.spectral.lambda={args.lambda_value}",
                        f"pruning.spectral.target_profile={args.profile}",
                        f"pruning.cutoff={args.cutoff}",
                        *arch_overrides(model),
                        *weight_overrides(model, args),
                        *args.overrides,
                        *method_overrides,
                    ]
                    tasks.append(
                        ExperimentTask(
                            name=f"{model}/{sparsity_tag(target)}/seed{seed}/{run_name}",
                            command=command_with_overrides(python, config, run_dir, overrides),
                            run_dir=str(run_dir),
                            metadata={"model": model, "method": method, "sparsity": target, "seed": seed},
                        )
                    )
    try:
        run_tasks(tasks, stage="main", status_root=args.status_root)
    finally:
        subprocess.run(
            [python, "tools/collect_results.py", "--root", str(root), "--output", str(root / "results.csv")],
            check=False,
        )
    if not args.skip_figures:
        subprocess.run(
            [python, "tools/make_figures.py", "--results", str(root / "results.csv"), "--output-dir", str(root / "figures")],
            check=False,
        )


if __name__ == "__main__":
    main()
