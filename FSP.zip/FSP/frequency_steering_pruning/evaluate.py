#!/usr/bin/env python3
from __future__ import annotations

import argparse

from frequency_pruning.config import resolve_config
from frequency_pruning.runner import run_experiment


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a dense, masked, or pruned Frequency-Steering checkpoint")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--output-dir", default="")
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()
    overrides = list(args.overrides)
    overrides.append(f"experiment.checkpoint={args.checkpoint}")
    overrides.extend(
        [
            "train.epochs_before_pruning=0",
            "train.recovery_epochs=0",
            "train.final_epochs=0",
        ]
    )
    config = resolve_config(args.config, overrides)
    run_experiment(config, run_dir=args.output_dir or None, evaluate_only=True)


if __name__ == "__main__":
    main()
