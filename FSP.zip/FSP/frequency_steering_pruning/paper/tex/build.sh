#!/bin/bash
# usage: build.sh SIZE LEAD SECSP
SIZE=${1:-10pt}; LEAD=${2:-1.12}; SECSP=${3:-0.9}
python3 - "$SIZE" "$LEAD" "$SECSP" <<'PY'
import sys, pathlib
size, lead, secsp = sys.argv[1:4]
s = pathlib.Path('paper.tex').read_text()
s = s.replace('@@SIZE@@', size).replace('@@LEAD@@', lead).replace('@@SECSP@@', secsp)
for name in ('table2.tex', 'table3.tex', 'table6.tex'):
    s = s.replace('\\input{%s}' % name, pathlib.Path(name).read_text().rstrip())
pathlib.Path('main.tex').write_text(s)
PY
for i in 1 2 3; do timeout 200 xelatex -interaction=nonstopmode -halt-on-error main.tex > build.log 2>&1 || { grep -n "^!" -A 6 build.log | head -30; exit 1; }; done
python3 -c "from pypdf import PdfReader; r=PdfReader('main.pdf'); print('pages:', len(r.pages))"
echo "overfull: $(grep -c 'Overfull' build.log)"; grep -n "Missing character\|undefined" build.log | head -5
