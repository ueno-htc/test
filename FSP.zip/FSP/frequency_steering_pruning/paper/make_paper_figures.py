#!/usr/bin/env python3
"""Regenerate the figures and table bodies of paper/tex/paper.tex.

    python paper/make_paper_figures.py --run-a /path/to/outputs_runA --run-b /path/to/outputs_runB

``run-a`` is the result tree with the band-reliance criteria (v5 run), ``run-b`` the tree with the
cross-layer calibration family, the latency-matched stage and the low-data ImageNet stage (v6 run).
Both must contain ``all_results.csv`` (tools/collect_results.py) and the per-run ``summary.json`` files.
"""
from __future__ import annotations

import argparse
import collections
import glob
import json
import re
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import font_manager
from matplotlib.patches import Patch

INK, C_NORM, C_MIX, C_AUTO, C_BAND, C_OTHER, C_BAD = "#1f2d3a", "#3b6ea5", "#1a9988", "#e08a00", "#8e5ea2", "#9aa5ad", "#c0392b"
GROUPS = [("cub_200_2011", "resnet50"), ("dtd", "resnet50"), ("cub_200_2011", "deit_base_patch16_224"), ("dtd", "deit_base_patch16_224")]


def load(root: Path, run: str) -> pd.DataFrame:
    df = pd.read_csv(root / "all_results.csv")
    df["acc"] = df["test_top1"].where(df["test_top1"].notna(), df["val_top1"])
    df["stage"] = df["run_dir"].str.extract(r"outputs/([a-z]+)/")[0]
    df["run"] = run
    return df


def paired(sub: pd.DataFrame, a: str, b: str, keys=("run", "dataset", "arch", "target_sparsity", "seed")) -> np.ndarray:
    x = sub[sub.variant == a].drop_duplicates(list(keys)).set_index(list(keys))["acc"]
    y = sub[sub.variant == b].drop_duplicates(list(keys)).set_index(list(keys))["acc"]
    idx = x.index.intersection(y.index)
    return (x.loc[idx] - y.loc[idx]).values


def stage_kept(kept: dict, arch: str) -> "collections.OrderedDict[str, float]":
    out: "collections.OrderedDict[str, list]" = collections.OrderedDict()
    for key, value in kept.items():
        if arch.startswith("resnet"):
            name = key.split(".")[0]
        else:
            block = int(re.search(r"blocks?\.(\d+)", key).group(1))
            name = ("H" if "attn" in key else "M") + ("0" if block < 4 else "1" if block < 8 else "2")
        out.setdefault(name, []).append(value)
    return collections.OrderedDict((k, float(np.mean(v))) for k, v in out.items())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-a", required=True)
    parser.add_argument("--run-b", required=True)
    parser.add_argument("--out", default=str(Path(__file__).resolve().parent))
    args = parser.parse_args()
    out = Path(args.out)
    (out / "figs").mkdir(parents=True, exist_ok=True)
    (out / "tex").mkdir(parents=True, exist_ok=True)
    jp = {f.name for f in font_manager.fontManager.ttflist}
    plt.rcParams.update({"font.family": "Noto Sans CJK JP" if "Noto Sans CJK JP" in jp else "DejaVu Sans", "font.size": 7.5,
                         "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.6})
    A, B = load(Path(args.run_a), "A"), load(Path(args.run_b), "B")
    both = pd.concat([A, B])
    T = B[B.stage == "transfer"]
    grp = T.groupby(["dataset", "arch", "variant"]).acc.mean().unstack("variant")
    mean4 = grp.mean()

    # ---- Fig. overview: mean transfer accuracy per criterion / calibration
    names = {"taylor_mean": "Taylor + mean", "taylor_mix0.25": "Taylor rank-mix α=0.25", "taylor_mix0": "Taylor 一様配分 (α=0)",
             "taylor_mix0.5": "Taylor rank-mix α=0.5", "taylor_mix0.75": "Taylor rank-mix α=0.75", "srp": "SRP（帯域依存項）",
             "taylor_auto": "Taylor 先読み選択", "taylor_lamp": "Taylor + LAMP", "taylor_global": "Taylor グローバル (α=1)",
             "taylor_sum": "Taylor + sum", "taylor_max": "Taylor + max", "lfs": "LFS（低域入力 Taylor）",
             "taylor": "Taylor + gaussian (z-score)", "random": "Random（一様配分）", "magnitude_mean": "Magnitude + mean",
             "magnitude": "Magnitude + gaussian", "taylor_std": "Taylor + standardization", "magnitude_lamp": "Magnitude + LAMP"}
    col = {"taylor_mean": C_NORM, "taylor_lamp": C_NORM, "taylor_sum": C_NORM, "taylor_max": C_NORM, "taylor": C_BAD, "taylor_std": C_BAD,
           "taylor_mix0.25": C_MIX, "taylor_mix0": C_MIX, "taylor_mix0.5": C_MIX, "taylor_mix0.75": C_MIX, "taylor_global": C_MIX,
           "taylor_auto": C_AUTO, "srp": C_BAND, "lfs": C_BAND, "random": C_OTHER, "magnitude": C_OTHER, "magnitude_mean": C_OTHER, "magnitude_lamp": C_OTHER}
    order = [n for n in mean4.sort_values().index if n in names]
    fig, ax = plt.subplots(figsize=(7.1, 3.05))
    y = np.arange(len(order))
    ax.barh(y, [mean4[n] for n in order], color=[col[n] for n in order], height=0.72)
    for i, n in enumerate(order):
        ax.text(mean4[n] + 0.08, i, f"{mean4[n]:.1f}", va="center", fontsize=6.8)
    ax.axvline(mean4["dense"], color=INK, ls="--", lw=0.8)
    ax.text(mean4["dense"] - 0.1, len(order) - 0.4, f"dense {mean4['dense']:.1f}", ha="right", va="top", fontsize=7)
    ax.set_yticks(y, [names[n] for n in order])
    ax.set_xlim(66, 79.2)
    ax.set_xlabel("転移 4 条件（CUB・DTD × ResNet-50・DeiT-B）の平均 top-1 [%]，MAC 50% 削減")
    ax.legend(handles=[Patch(color=C_MIX, label="rank-mix 族 (α)"), Patch(color=C_NORM, label="固定正規化"), Patch(color=C_BAD, label="有害な正規化"),
                       Patch(color=C_AUTO, label="先読み選択"), Patch(color=C_BAND, label="周波数系"), Patch(color=C_OTHER, label="その他")],
              loc="lower right", fontsize=6.8, frameon=False, ncol=2)
    fig.tight_layout(pad=0.4)
    fig.savefig(out / "figs/fig1_transfer_mean.png", dpi=300)
    plt.close(fig)

    # ---- Fig. alpha sweep
    alphas, an = [0, 0.25, 0.5, 0.75, 1.0], ["taylor_mix0", "taylor_mix0.25", "taylor_mix0.5", "taylor_mix0.75", "taylor_global"]
    fig, ax = plt.subplots(figsize=(3.45, 2.45))
    styles = {GROUPS[0]: ("CUB / ResNet-50", "o", "-", C_MIX), GROUPS[1]: ("DTD / ResNet-50", "s", "-", C_MIX),
              GROUPS[2]: ("CUB / DeiT-B", "o", "--", C_NORM), GROUPS[3]: ("DTD / DeiT-B", "s", "--", C_NORM)}
    for key, (lab, mk, ls, c) in styles.items():
        vals = np.array([grp.loc[key, n] for n in an])
        ax.plot(alphas, vals - vals[0], ls, marker=mk, ms=3.5, lw=1.1, color=c, label=lab)
    im = B[(B.stage == "main") & (B.arch == "resnet50")]
    ld = B[B.stage == "lowdata"]
    for sub, mk, lab, c in [(im[im.target_sparsity == 0.5], "^", "ImageNet / ResNet-50 (50%)", C_BAD), (im[im.target_sparsity == 0.7], "v", "ImageNet / ResNet-50 (70%)", C_BAD),
                            (ld, "D", "ImageNet 10% / ResNet-50", INK)]:
        vals = np.array([sub[sub.variant == v].acc.mean() for v in ["taylor_auto", "taylor_mix0.5", "taylor_global"]])
        ax.plot([0, 0.5, 1], vals - vals[0], ":", marker=mk, ms=3.6, lw=1.1, color=c, label=lab)
    ax.axhline(0, color=INK, lw=0.5)
    ax.set_xticks(alphas)
    ax.set_xlabel("rank-mix の α（0: 一様配分，1: グローバル順位）")
    ax.set_ylabel("α=0 との top-1 差 [pt]")
    ax.legend(fontsize=5.6, frameon=False, loc="lower left")
    fig.tight_layout(pad=0.3)
    fig.savefig(out / "figs/fig2_alpha.png", dpi=300)
    plt.close(fig)

    # ---- Fig. allocation
    kept, acc = collections.defaultdict(list), collections.defaultdict(list)
    for path in glob.glob(str(Path(args.run_b) / "**/summary.json"), recursive=True):
        s = json.load(open(path))
        if s["method"] in ("dense", "dense_finetuned") or not s.get("kept_fraction_by_group") or s["arch"] not in ("resnet50", "deit_base_patch16_224"):
            continue
        rel = Path(path).relative_to(args.run_b).parts
        if rel[0] != "transfer":
            continue
        key = (s["dataset"], s["arch"], rel[-2])
        kept[key].append(stage_kept(s["kept_fraction_by_group"], s["arch"]))
        acc[key].append((s["final"].get("test") or s["final"]["val"])["top1"])
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.35), gridspec_kw={"width_ratios": [1, 1, 1.15]})
    series = [("taylor", "Taylor + gaussian", C_BAD, "-"), ("taylor_std", "Taylor + standardization", C_BAD, ":"), ("taylor_mix0", "Taylor 一様 (α=0)", C_MIX, "-"),
              ("taylor_mean", "Taylor + mean", C_NORM, "-"), ("taylor_global", "Taylor グローバル (α=1)", C_MIX, "--"), ("magnitude", "Magnitude + gaussian", C_OTHER, "-")]
    for ax, (ds, title) in zip(axes[:2], [("cub_200_2011", "(a) CUB / ResNet-50"), ("dtd", "(b) DTD / ResNet-50")]):
        for v, lab, c, ls in series:
            items = kept.get((ds, "resnet50", v))
            if not items:
                continue
            stages = list(items[0].keys())
            ax.plot(range(4), np.mean([[it[n] for n in stages] for it in items], axis=0), ls, marker="o", ms=3, lw=1.1, color=c,
                    label=f"{lab}  {np.mean(acc[(ds, 'resnet50', v)]):.1f}%")
        ax.set_xticks(range(4), ["layer1", "layer2", "layer3", "layer4"], fontsize=6.5)
        ax.set_ylim(-0.45, 1.05)
        ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
        ax.set_title(title, fontsize=7.5)
        ax.legend(fontsize=5.0, frameon=False, loc="lower center", ncol=2, columnspacing=0.6, handlelength=1.4)
        ax.grid(alpha=0.25, lw=0.4)
    axes[0].set_ylabel("保持率（hidden channel）")
    axes[0].yaxis.set_label_coords(-0.2, 0.64)
    ax = axes[2]
    blocks, labels = ["H0", "M0", "H1", "M1", "H2", "M2"], ["head\n0–3", "MLP\n0–3", "head\n4–7", "MLP\n4–7", "head\n8–11", "MLP\n8–11"]
    for i, (v, lab, c) in enumerate([("taylor", "Taylor + gaussian", C_BAD), ("taylor_mix0", "Taylor 一様 (α=0)", C_MIX), ("taylor_mean", "Taylor + mean", C_NORM), ("taylor_global", "Taylor グローバル", C_OTHER)]):
        items = kept[("cub_200_2011", "deit_base_patch16_224", v)]
        ax.bar(np.arange(6) + (i - 1.5) * 0.2, np.mean([[it[n] for n in blocks] for it in items], axis=0), 0.2, color=c,
               label=f"{lab}  {np.mean(acc[('cub_200_2011', 'deit_base_patch16_224', v)]):.1f}%")
    ax.set_xticks(np.arange(6), labels, fontsize=6)
    ax.set_title("(c) CUB / DeiT-B", fontsize=7.5)
    ax.legend(fontsize=5.0, frameon=False, loc="upper center", ncol=2, columnspacing=0.6)
    ax.set_ylim(0, 1.42)
    ax.set_yticks([0, 0.5, 1.0])
    fig.tight_layout(pad=0.3)
    fig.savefig(out / "figs/fig3_allocation.png", dpi=300)
    plt.close(fig)

    # ---- Fig. budget metric
    fig, axes = plt.subplots(1, 2, figsize=(3.45, 2.3), sharey=True)
    meth, lab = ["taylor", "taylor_mix0.5", "taylor_global", "random", "magnitude"], ["Taylor\ngaussian", "Taylor\nα=0.5", "Taylor\nglobal", "Random", "Magni-\ntude"]
    Td, La = T[T.arch == "deit_base_patch16_224"], B[(B.stage == "latency") & (B.target_sparsity == 0.3)]
    for ax, (dfx, title, by_speed) in zip(axes, [(Td, "MAC 50% 削減で揃える", True), (La, "実測速度 1.44 倍で揃える", False)]):
        m = [dfx[dfx.variant == v].groupby("dataset").acc.mean().mean() for v in meth]
        ax.bar(range(5), m, color=[C_BAD, C_MIX, C_MIX, C_OTHER, C_OTHER], width=0.7)
        for i, v in enumerate(m):
            ax.text(i, v + 0.4, f"{v:.1f}", ha="center", fontsize=6)
        for i, v in enumerate(meth):
            text = f"{dfx[dfx.variant == v].speedup_vs_dense.mean():.2f}×" if by_speed else f"MAC\n−{100 * dfx[dfx.variant == v].mac_reduction.mean():.0f}%"
            ax.text(i, 61.2, text, ha="center", fontsize=5.8 if by_speed else 5.2, color="white" if i < 3 else INK)
        ax.set_xticks(range(5), lab, fontsize=5.6)
        ax.set_title(title, fontsize=7)
        ax.set_ylim(60, 82)
    axes[0].set_ylabel("top-1 [%]（CUB・DTD 平均）")
    fig.tight_layout(pad=0.3)
    fig.savefig(out / "figs/fig4_budget.png", dpi=300)
    plt.close(fig)

    # ---- Fig. frequency terms
    Tb = both[both.stage == "transfer"]
    I = both[both.stage.isin(["main", "ablations"]) & (both.arch == "resnet50")]
    items = [("SRP λ=0.25\n(転移)", "srp"), ("SRP λ=1", "srp_lambda1"), ("RFC", "rfc"), ("出力差分", "srp_od"), ("band-pass", "srp_pass"), ("低域のみ", "srp_low")]
    means, errs, labs = [], [], []
    for label, v in items:
        d = paired(Tb, v, "taylor_global")
        means.append(d.mean()); errs.append(1.96 * d.std(ddof=1) / np.sqrt(len(d))); labs.append(f"{label}\n(n={len(d)})")
    d = paired(I, "srp", "taylor_global", keys=("run", "stage", "arch", "target_sparsity", "seed"))
    means.append(d.mean()); errs.append(1.96 * d.std(ddof=1) / np.sqrt(len(d))); labs.append(f"SRP λ=0.25\n(ImageNet\nR50, n={len(d)})")
    fig, ax = plt.subplots(figsize=(3.45, 2.25))
    ax.bar(range(len(means)), means, yerr=errs, capsize=2, color=[C_BAND] * 6 + [C_BAD], width=0.7, error_kw=dict(lw=0.7))
    ax.axhline(0, color=INK, lw=0.6)
    ax.axhspan(-0.4, 0.4, color=C_OTHER, alpha=0.18, lw=0)
    ax.set_xticks(range(len(means)), labs, fontsize=5.3)
    ax.set_ylabel("Taylor グローバルとの差 [pt]")
    ax.set_ylim(-0.9, 0.9)
    fig.tight_layout(pad=0.3)
    fig.savefig(out / "figs/fig5_frequency.png", dpi=300)
    plt.close(fig)

    # ---- Fig. ImageNet ResNet-50 (full data and 10% data)
    fig, ax = plt.subplots(figsize=(3.45, 2.25))
    meth = ["taylor_auto", "magnitude", "taylor", "random", "taylor_global"]
    lab = ["Taylor 一様 (先読み α=0)", "Magnitude", "Taylor gaussian", "Random", "Taylor global"]
    sets = [("全データ・MAC 50%", im[im.target_sparsity == 0.5]), ("全データ・MAC 70%", im[im.target_sparsity == 0.7]), ("10% データ・MAC 50%", ld)]
    for j, (v, l, c) in enumerate(zip(meth, lab, [C_AUTO, C_OTHER, C_BAD, C_OTHER, C_MIX])):
        vals = [s[s.variant == v].acc.mean() for _, s in sets]
        errs = [s[s.variant == v].acc.std(ddof=1) if (s.variant == v).sum() > 1 else 0 for _, s in sets]
        ax.bar(np.arange(3) + (j - 2) * 0.16, vals, 0.16, yerr=errs, capsize=1.5, color=c, label=l, error_kw=dict(lw=0.6))
        for i, value in enumerate(vals):
            ax.text(i + (j - 2) * 0.16, value + 0.25, f"{value:.1f}", ha="center", fontsize=4.8, rotation=90)
    ax.set_xticks(range(3), [s[0] for s in sets], fontsize=6.3)
    ax.set_ylim(66, 80.5)
    ax.set_ylabel("ImageNet top-1 [%]")
    ax.legend(fontsize=5.4, frameon=False, ncol=3, loc="upper right", columnspacing=0.8, handlelength=1.0)
    fig.tight_layout(pad=0.3)
    fig.savefig(out / "figs/fig6_imagenet.png", dpi=300)
    plt.close(fig)
    print(f"figures written to {out / 'figs'}")


if __name__ == "__main__":
    main()
