#!/usr/bin/env python3
"""Hyper-parameter selection for Spectral-Steering on an ImageNet validation subset.

Grid: ``lambda`` (steering strength) x ``target_profile``.  The objective is

    objective = clean_top1 + robustness_weight * 100 * steering_gain

where ``steering_gain`` is the reduction of the L1 mismatch between the task
reliance profile and the model sensitivity profile (see pruning/spectral.py).
With the default weight (0.1) a mismatch reduction of 0.1 is worth one
accuracy point, so accuracy dominates and controllability breaks ties.
Selection uses a 10k-image validation subset and short recovery; the chosen
values are then frozen for every main/ViT/transfer run.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from frequency_pruning.config import resolve_config
from frequency_pruning.orchestration import (
    ExperimentTask,
    arch_overrides,
    command_with_overrides,
    parse_floats,
    run_tasks,
    split_csv,
)
from frequency_pruning.utils import save_json, save_yaml


def nested_get(mapping: Dict[str, Any], path: str, default=None):
    current: Any = mapping
    for key in path.split("."):
        if not isinstance(current, dict) or key not in current:
            return default
        current = current[key]
    return current


def _l1(a, b) -> float:
    return float(sum(abs(float(x) - float(y)) for x, y in zip(a, b)))


def main() -> None:
    parser = argparse.ArgumentParser(description="Grid-search lambda x target profile on ImageNet validation")
    parser.add_argument("--config", default="configs/tune_v4.yaml")
    parser.add_argument("--lambdas", default="0.5,1.0,2.0")
    parser.add_argument("--profiles", default="auto,reliance")
    parser.add_argument("--output-root", default="outputs/tuning")
    parser.add_argument("--status-root", default="outputs/_orchestrator")
    parser.add_argument("--robustness-weight", type=float, default=0.1)
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    base = resolve_config(args.config, args.overrides)
    if str(base["data"]["dataset"]).lower() not in {"imagenet", "imagenet1k", "ilsvrc2012"}:
        raise ValueError("Hyperparameter tuning is defined on ImageNet validation")
    arch = str(base["model"]["arch"])
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    base_path = output_root / "base_config.yaml"
    save_yaml(base_path, base)
    lambdas = parse_floats(args.lambdas)
    profiles = split_csv(args.profiles)
    python = os.environ.get("FSP_PYTHON", sys.executable)

    tasks: list[ExperimentTask] = []
    for lam, profile in itertools.product(lambdas, profiles):
        run_dir = output_root / f"lambda_{lam:g}_profile_{profile}"
        overrides = [
            "pruning.method=spectral_steering",
            f"pruning.spectral.lambda={lam}",
            f"pruning.spectral.target_profile={profile}",
            "evaluation.eval_imagenet_c=false",
            "evaluation.eval_imagenet_r=false",
            "evaluation.throughput=false",
            "evaluation.export_slim=false",
            "visualization.fourier_heatmap=false",
            "visualization.layer_heatmap=false",
            *arch_overrides(arch),
        ]
        tasks.append(
            ExperimentTask(
                name=f"tune/lambda_{lam:g}_profile_{profile}",
                command=command_with_overrides(python, str(base_path), run_dir, overrides),
                run_dir=str(run_dir),
                metadata={"lambda": lam, "profile": profile},
            )
        )
    run_tasks(tasks, stage="tuning", status_root=args.status_root)

    rows: list[Dict[str, Any]] = []
    for lam, profile in itertools.product(lambdas, profiles):
        run_dir = output_root / f"lambda_{lam:g}_profile_{profile}"
        summary_path = run_dir / "summary.json"
        if not summary_path.exists():
            rows.append({"lambda": lam, "profile": profile, "status": "failed"})
            continue
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        clean_top1 = float(nested_get(summary, "final.val.top1", float("nan")))
        reliance = nested_get(summary, "dense.spectral.reliance_profile")
        dense_sens = nested_get(summary, "dense.spectral.sensitivity_profile")
        final_sens = nested_get(summary, "final.spectral.sensitivity_profile")
        gain = float("nan")
        if reliance and dense_sens and final_sens:
            gain = _l1(reliance, dense_sens) - _l1(reliance, final_sens)
        objective = clean_top1 + (0.0 if np.isnan(gain) else float(args.robustness_weight) * 100.0 * gain)
        rows.append(
            {
                "lambda": lam,
                "profile": profile,
                "status": "ok" if not np.isnan(clean_top1) else "failed_missing_metrics",
                "clean_top1": clean_top1,
                "steering_gain": gain,
                "objective": objective,
                "actual_sparsity": summary.get("actual_sparsity"),
                "run_dir": str(run_dir),
            }
        )
    save_json(output_root / "grid_results.json", rows)
    successful = [row for row in rows if row.get("status") == "ok"]
    if not successful:
        raise RuntimeError("All tuning runs failed")
    best = max(successful, key=lambda row: float(row["objective"]))
    best_config = resolve_config(
        base_path,
        [f"pruning.spectral.lambda={best['lambda']}", f"pruning.spectral.target_profile={best['profile']}"],
    )
    save_yaml(output_root / "best_config.yaml", best_config)
    save_json(output_root / "best_result.json", best)

    fieldnames = sorted({key for row in rows for key in row})
    with (output_root / "grid_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    matrix = np.full((len(lambdas), len(profiles)), np.nan)
    for row in successful:
        matrix[lambdas.index(float(row["lambda"])), profiles.index(str(row["profile"]))] = float(row["objective"])
    fig, ax = plt.subplots(figsize=(6, 4.5))
    image = ax.imshow(matrix, aspect="auto", origin="lower")
    ax.set_xticks(range(len(profiles)), profiles)
    ax.set_yticks(range(len(lambdas)), [f"{value:g}" for value in lambdas])
    ax.set_xlabel("target profile")
    ax.set_ylabel("steering strength lambda")
    ax.set_title("ImageNet validation tuning objective")
    fig.colorbar(image, ax=ax)
    fig.tight_layout()
    fig.savefig(output_root / "grid_objective.png", dpi=180)
    plt.close(fig)
    print(json.dumps(best, indent=2), flush=True)


if __name__ == "__main__":
    main()
