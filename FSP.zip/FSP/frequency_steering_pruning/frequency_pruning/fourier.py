from __future__ import annotations

import math
from functools import lru_cache
from typing import Dict, Iterable, Tuple

import torch
from torch import Tensor

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def _channel_stats(x: Tensor, mean: Iterable[float], std: Iterable[float]) -> tuple[Tensor, Tensor]:
    mean_t = torch.as_tensor(tuple(mean), dtype=x.dtype, device=x.device).view(1, -1, 1, 1)
    std_t = torch.as_tensor(tuple(std), dtype=x.dtype, device=x.device).view(1, -1, 1, 1)
    return mean_t, std_t


def denormalize(
    x: Tensor,
    mean: Iterable[float] = IMAGENET_MEAN,
    std: Iterable[float] = IMAGENET_STD,
) -> Tensor:
    mean_t, std_t = _channel_stats(x, mean, std)
    return x * std_t + mean_t


def normalize(
    x: Tensor,
    mean: Iterable[float] = IMAGENET_MEAN,
    std: Iterable[float] = IMAGENET_STD,
) -> Tensor:
    mean_t, std_t = _channel_stats(x, mean, std)
    return (x - mean_t) / std_t


def radial_frequency_grid(height: int, width: int, device: torch.device, dtype: torch.dtype) -> Tensor:
    """Return an fftshift-compatible radius normalized by the axial Nyquist radius.

    A radius of one reaches the midpoint of an image edge. Corner frequencies can
    therefore have radius up to sqrt(2), which makes the cutoff geometrically
    interpretable and independent of the image resolution.
    """
    y = torch.arange(height, device=device, dtype=dtype) - height // 2
    x = torch.arange(width, device=device, dtype=dtype) - width // 2
    yy, xx = torch.meshgrid(y, x, indexing="ij")
    scale = max(1.0, float(min(height, width)) / 2.0)
    return torch.sqrt(xx.square() + yy.square()) / scale


def radial_lowpass_mask(
    height: int,
    width: int,
    cutoff: float,
    device: torch.device,
    dtype: torch.dtype,
    transition_width: float = 0.0,
    cutoff_mode: str = "relative",
) -> Tensor:
    radius = radial_frequency_grid(height, width, device, dtype)
    if cutoff_mode == "pixels":
        cutoff = float(cutoff) / max(1.0, float(min(height, width)) / 2.0)
        transition_width = float(transition_width) / max(1.0, float(min(height, width)) / 2.0)
    elif cutoff_mode != "relative":
        raise ValueError(f"Unsupported cutoff_mode: {cutoff_mode}")
    cutoff = float(cutoff)
    transition_width = max(0.0, float(transition_width))
    if transition_width <= 0:
        return (radius <= cutoff).to(dtype)
    lo = cutoff - transition_width / 2.0
    hi = cutoff + transition_width / 2.0
    mask = torch.ones_like(radius)
    mask = torch.where(radius >= hi, torch.zeros_like(mask), mask)
    middle = (radius > lo) & (radius < hi)
    t = ((radius - lo) / max(transition_width, 1e-12)).clamp(0.0, 1.0)
    rolloff = 0.5 * (1.0 + torch.cos(math.pi * t))
    return torch.where(middle, rolloff, mask).to(dtype)


def split_frequency(
    x: Tensor,
    cutoff: float,
    *,
    mean: Iterable[float] = IMAGENET_MEAN,
    std: Iterable[float] = IMAGENET_STD,
    input_is_normalized: bool = True,
    cutoff_mode: str = "relative",
    transition_width: float = 0.0,
    hp_dc_mode: str = "image_mean",
    clamp: bool = True,
) -> Tuple[Tensor, Tensor]:
    """Split an image batch into low-pass and displayable high-pass components.

    FFT operations are always performed in float32 for stable saliency under AMP.
    The high-pass residual is re-centered before passing it to an ImageNet model:
    ``image_mean`` restores each input's per-channel DC component, while
    ``dataset_mean`` adds the normalization mean. ``zero`` leaves signed residuals
    and is useful for diagnostic experiments.
    """
    if x.ndim != 4:
        raise ValueError(f"Expected BCHW input, got {tuple(x.shape)}")
    original_dtype = x.dtype
    raw = denormalize(x.float(), mean, std) if input_is_normalized else x.float()
    spectrum = torch.fft.fftshift(torch.fft.fft2(raw, dim=(-2, -1), norm="ortho"), dim=(-2, -1))
    mask = radial_lowpass_mask(
        raw.shape[-2],
        raw.shape[-1],
        cutoff,
        raw.device,
        raw.dtype,
        transition_width,
        cutoff_mode,
    ).view(1, 1, raw.shape[-2], raw.shape[-1])
    lp = torch.fft.ifft2(torch.fft.ifftshift(spectrum * mask, dim=(-2, -1)), dim=(-2, -1), norm="ortho").real
    residual = raw - lp
    hp_dc_mode = str(hp_dc_mode).lower()
    if hp_dc_mode == "image_mean":
        hp = residual + raw.mean(dim=(-2, -1), keepdim=True)
    elif hp_dc_mode == "dataset_mean":
        mean_t, _ = _channel_stats(raw, mean, std)
        hp = residual + mean_t
    elif hp_dc_mode == "zero":
        hp = residual
    else:
        raise ValueError(f"Unsupported hp_dc_mode: {hp_dc_mode}")
    if clamp:
        lp = lp.clamp(0.0, 1.0)
        if hp_dc_mode != "zero":
            hp = hp.clamp(0.0, 1.0)
    if input_is_normalized:
        lp = normalize(lp, mean, std)
        hp = normalize(hp, mean, std)
    return lp.to(original_dtype), hp.to(original_dtype)


def frequency_energy_statistics(
    x: Tensor,
    cutoff: float,
    *,
    mean: Iterable[float] = IMAGENET_MEAN,
    std: Iterable[float] = IMAGENET_STD,
    input_is_normalized: bool = True,
    cutoff_mode: str = "relative",
) -> Dict[str, Tensor]:
    raw = denormalize(x.float(), mean, std) if input_is_normalized else x.float()
    raw = raw - raw.mean(dim=(-2, -1), keepdim=True)
    spectrum = torch.fft.fftshift(torch.fft.fft2(raw, dim=(-2, -1), norm="ortho"), dim=(-2, -1))
    power = spectrum.abs().square()
    mask = radial_lowpass_mask(
        raw.shape[-2], raw.shape[-1], cutoff, raw.device, raw.dtype, 0.0, cutoff_mode
    ).view(1, 1, raw.shape[-2], raw.shape[-1])
    low = (power * mask).sum(dim=(1, 2, 3))
    high = (power * (1.0 - mask)).sum(dim=(1, 2, 3))
    total = (low + high).clamp_min(1e-12)
    return {
        "low_l2": low.clamp_min(0).sqrt(),
        "high_l2": high.clamp_min(0).sqrt(),
        "low_ratio": low / total,
        "high_ratio": high / total,
    }


def radial_profile(power_map: Tensor) -> Tensor:
    """Average a 2-D shifted power map over integer radial shells."""
    if power_map.ndim != 2:
        raise ValueError("radial_profile expects a 2-D tensor")
    h, w = power_map.shape
    radius = radial_frequency_grid(h, w, power_map.device, power_map.dtype)
    bins = torch.floor(radius * (min(h, w) / 2.0)).to(torch.long)
    max_bin = int(bins.max().item())
    sums = torch.zeros(max_bin + 1, device=power_map.device, dtype=power_map.dtype)
    counts = torch.zeros_like(sums)
    sums.scatter_add_(0, bins.flatten(), power_map.flatten())
    counts.scatter_add_(0, bins.flatten(), torch.ones_like(power_map).flatten())
    return sums / counts.clamp_min(1)
