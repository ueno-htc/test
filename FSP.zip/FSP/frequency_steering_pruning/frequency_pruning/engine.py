from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping, Sequence

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader, DistributedSampler

from .distributed import all_gather_object, all_reduce_, is_distributed, unwrap_model
from .fourier import frequency_energy_statistics, split_frequency
from .pruning.spectral import random_band_augment
from .utils import AverageMeter, autocast_context, move_batch_to_device


def topk_correct(logits: Tensor, target: Tensor, topk: Sequence[int] = (1, 5)) -> list[Tensor]:
    max_k = min(max(topk), logits.shape[1])
    predictions = logits.topk(max_k, dim=1, largest=True, sorted=True).indices
    correct = predictions.eq(target.view(-1, 1))
    return [correct[:, : min(k, max_k)].any(dim=1).sum() for k in topk]


def soft_target_cross_entropy(logits: Tensor, target: Tensor) -> Tensor:
    return torch.sum(-target * F.log_softmax(logits, dim=-1), dim=-1).mean()


def one_hot(target: Tensor, num_classes: int, smoothing: float = 0.0) -> Tensor:
    off = smoothing / max(1, num_classes - 1)
    on = 1.0 - smoothing
    output = torch.full((target.shape[0], num_classes), off, dtype=torch.float32, device=target.device)
    output.scatter_(1, target[:, None], on)
    return output


def _sample_beta(alpha: float) -> float:
    if alpha <= 0:
        return 1.0
    return float(np.random.beta(alpha, alpha))


def apply_mixup_cutmix(
    images: Tensor,
    targets: Tensor,
    num_classes: int,
    mixup_alpha: float,
    cutmix_alpha: float,
    label_smoothing: float,
) -> tuple[Tensor, Tensor]:
    if mixup_alpha <= 0 and cutmix_alpha <= 0:
        return images, one_hot(targets, num_classes, label_smoothing)
    perm = torch.randperm(images.shape[0], device=images.device)
    target_a = one_hot(targets, num_classes, label_smoothing)
    target_b = target_a.index_select(0, perm)
    use_cutmix = cutmix_alpha > 0 and (mixup_alpha <= 0 or random.random() < 0.5)
    alpha = cutmix_alpha if use_cutmix else mixup_alpha
    lam = _sample_beta(alpha)
    if use_cutmix:
        _, _, height, width = images.shape
        ratio = math.sqrt(1.0 - lam)
        cut_w, cut_h = int(width * ratio), int(height * ratio)
        center_x = random.randrange(width)
        center_y = random.randrange(height)
        x1 = max(0, center_x - cut_w // 2)
        x2 = min(width, center_x + cut_w // 2)
        y1 = max(0, center_y - cut_h // 2)
        y2 = min(height, center_y + cut_h // 2)
        mixed = images.clone()
        mixed[:, :, y1:y2, x1:x2] = images.index_select(0, perm)[:, :, y1:y2, x1:x2]
        lam = 1.0 - ((x2 - x1) * (y2 - y1) / max(1, width * height))
    else:
        mixed = images * lam + images.index_select(0, perm) * (1.0 - lam)
    return mixed, target_a * lam + target_b * (1.0 - lam)


@dataclass
class TrainState:
    epoch: int = 0
    global_step: int = 0


class ModelEma:
    def __init__(self, model: nn.Module, decay: float) -> None:
        import copy

        self.decay = float(decay)
        self.module = copy.deepcopy(unwrap_model(model)).eval()
        for parameter in self.module.parameters():
            parameter.requires_grad_(False)

    @torch.no_grad()
    def update(self, model: nn.Module) -> None:
        raw = unwrap_model(model)
        source = raw.state_dict()
        destination = self.module.state_dict()
        parameter_names = set(dict(raw.named_parameters()))
        for key, value in destination.items():
            source_value = source[key].detach().to(value.device)
            if key in parameter_names and value.dtype.is_floating_point:
                value.mul_(self.decay).add_(source_value, alpha=1.0 - self.decay)
            else:
                # BatchNorm statistics and pruning gates must stay exact buffers.
                value.copy_(source_value)


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    config: Mapping[str, Any],
    state: TrainState,
    scheduler: Any | None = None,
    teacher: nn.Module | None = None,
    ema: ModelEma | None = None,
    logger=None,
) -> Dict[str, float]:
    model.train()
    train_cfg = config["train"]
    model_cfg = config["model"]
    pruning_cfg = config["pruning"]
    dtype = _resolve_amp_dtype(str(train_cfg["amp"]), device)
    accumulation = max(1, int(train_cfg.get("accumulation_steps", 1)))
    clip = float(train_cfg.get("gradient_clip", 0.0))
    label_smoothing = float(train_cfg.get("label_smoothing", 0.0))
    mixup_alpha = float(train_cfg.get("mixup_alpha", 0.0))
    cutmix_alpha = float(train_cfg.get("cutmix_alpha", 0.0))
    channels_last = bool(model_cfg.get("channels_last", False)) and device.type == "cuda"
    num_classes = int(model_cfg["num_classes"])
    distill = bool(train_cfg.get("distill_frequency", False)) and teacher is not None
    distill_alpha = float(train_cfg.get("distill_alpha", 0.0))
    temperature = float(train_cfg.get("distill_temperature", 2.0))
    # Standard logit distillation from the dense model (fair recovery protocol).
    distill_dense = bool(train_cfg.get("distill_dense", False)) and teacher is not None
    dense_alpha = float(train_cfg.get("dense_distill_alpha", 0.5))
    dense_temperature = float(train_cfg.get("dense_distill_temperature", 2.0))
    if distill_dense:
        distill = False  # the two distillation modes are mutually exclusive
    frequency_augment = bool(train_cfg.get("frequency_augment", False))
    frequency_augment_prob = float(train_cfg.get("frequency_augment_prob", 0.5))
    band_edges = list((pruning_cfg.get("spectral", {}) or {}).get("band_edges", [0.0, 0.125, 0.25, 0.5, 2.0]))
    use_scaler = device.type == "cuda" and dtype == torch.float16
    scaler = torch.amp.GradScaler("cuda", enabled=use_scaler)

    if isinstance(loader.sampler, DistributedSampler):
        loader.sampler.set_epoch(state.epoch)

    optimizer.zero_grad(set_to_none=True)
    loss_sum = torch.zeros(1, device=device, dtype=torch.float64)
    correct1 = torch.zeros(1, device=device, dtype=torch.float64)
    samples = torch.zeros(1, device=device, dtype=torch.float64)
    start = time.perf_counter()

    for batch_index, batch in enumerate(loader):
        images, target = batch[:2]
        images = move_batch_to_device(images, device, channels_last)
        target = target.to(device, non_blocking=True)
        if frequency_augment:
            images = random_band_augment(images, band_edges, frequency_augment_prob)
        mixed, soft_target = apply_mixup_cutmix(
            images,
            target,
            num_classes,
            mixup_alpha,
            cutmix_alpha,
            label_smoothing,
        )
        with autocast_context(device, dtype):
            logits = model(mixed)
            loss = soft_target_cross_entropy(logits, soft_target)
            if distill_dense and dense_alpha > 0:
                with torch.no_grad():
                    teacher.eval()
                    teacher_logits = teacher(mixed)
                kd = F.kl_div(
                    F.log_softmax(logits.float() / dense_temperature, dim=-1),
                    F.softmax(teacher_logits.float() / dense_temperature, dim=-1),
                    reduction="batchmean",
                )
                loss = (1.0 - dense_alpha) * loss + dense_alpha * kd * (dense_temperature**2)
            if distill and distill_alpha > 0:
                with torch.no_grad():
                    teacher.eval()
                    teacher_logits = teacher(images)
                    lp, hp = split_frequency(
                        images,
                        float(pruning_cfg["cutoff"]),
                        cutoff_mode=str(pruning_cfg.get("cutoff_mode", "relative")),
                        transition_width=float(pruning_cfg.get("transition_width", 0.0)),
                        hp_dc_mode=str(pruning_cfg.get("hp_dc_mode", "image_mean")),
                    )
                    teacher_lp = teacher(lp)
                    teacher_hp = teacher(hp)
                student_clean = model(images)
                student_lp = model(lp)
                student_hp = model(hp)
                kd = (
                    F.kl_div(
                        F.log_softmax(student_clean / temperature, dim=-1),
                        F.softmax(teacher_logits / temperature, dim=-1),
                        reduction="batchmean",
                    )
                    + F.kl_div(
                        F.log_softmax(student_lp / temperature, dim=-1),
                        F.softmax(teacher_lp / temperature, dim=-1),
                        reduction="batchmean",
                    )
                    + F.kl_div(
                        F.log_softmax(student_hp / temperature, dim=-1),
                        F.softmax(teacher_hp / temperature, dim=-1),
                        reduction="batchmean",
                    )
                ) / 3.0
                loss = (1.0 - distill_alpha) * loss + distill_alpha * kd * (temperature**2)
            scaled_loss = loss / accumulation

        scaler.scale(scaled_loss).backward()
        should_step = (batch_index + 1) % accumulation == 0 or batch_index + 1 == len(loader)
        if should_step:
            if clip > 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
            if scheduler is not None and getattr(scheduler, "step_per_batch", False):
                scheduler.step()
            if ema is not None:
                ema.update(model)
            state.global_step += 1

        with torch.no_grad():
            hard_logits = logits.detach()
            c1 = topk_correct(hard_logits, target, (1,))[0]
            loss_sum += float(loss.detach()) * images.shape[0]
            correct1 += c1
            samples += images.shape[0]

        if logger is not None and batch_index % 50 == 0:
            logger.info(
                "train epoch=%d batch=%d/%d loss=%.4f top1=%.2f lr=%.3e",
                state.epoch,
                batch_index,
                len(loader),
                float(loss.detach()),
                100.0 * float(c1) / max(1, images.shape[0]),
                optimizer.param_groups[0]["lr"],
            )

    if scheduler is not None and not getattr(scheduler, "step_per_batch", False):
        scheduler.step()
    packed = torch.cat([loss_sum, correct1, samples])
    all_reduce_(packed)
    elapsed = time.perf_counter() - start
    state.epoch += 1
    return {
        "loss": float(packed[0] / packed[2].clamp_min(1)),
        "top1": 100.0 * float(packed[1] / packed[2].clamp_min(1)),
        "samples": float(packed[2]),
        "epoch_seconds": elapsed,
        "lr": float(optimizer.param_groups[0]["lr"]),
    }


@torch.inference_mode()
def evaluate_classification(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    amp: str | torch.dtype | None = None,
    channels_last: bool = False,
    input_mode: str = "clean",
    cutoff: float = 0.25,
    cutoff_mode: str = "relative",
    transition_width: float = 0.0,
    hp_dc_mode: str = "image_mean",
) -> Dict[str, float]:
    model.eval()
    dtype = amp if isinstance(amp, torch.dtype) else _resolve_amp_dtype(str(amp or "none"), device)
    totals = torch.zeros(4, device=device, dtype=torch.float64)
    # loss sum, top1, top5, sample count
    for batch in loader:
        images, target = batch[:2]
        images = move_batch_to_device(images, device, channels_last and device.type == "cuda")
        target = target.to(device, non_blocking=True)
        if input_mode != "clean":
            lp, hp = split_frequency(
                images,
                cutoff,
                cutoff_mode=cutoff_mode,
                transition_width=transition_width,
                hp_dc_mode=hp_dc_mode,
            )
            images = lp if input_mode == "lowpass" else hp
        with autocast_context(device, dtype):
            logits = model(images)
            loss = F.cross_entropy(logits, target, reduction="sum")
        c1, c5 = topk_correct(logits, target, (1, 5))
        totals += torch.tensor([float(loss), float(c1), float(c5), target.numel()], device=device, dtype=torch.float64)
    all_reduce_(totals)
    n = totals[3].clamp_min(1)
    return {
        "loss": float(totals[0] / n),
        "top1": 100.0 * float(totals[1] / n),
        "top5": 100.0 * float(totals[2] / n),
        "error": 100.0 * (1.0 - float(totals[1] / n)),
        "samples": float(totals[3]),
    }


@torch.inference_mode()
def evaluate_frequency_regions(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    cutoff: float,
    amp: str | torch.dtype | None = None,
    channels_last: bool = False,
    low_quantile: float = 0.25,
    high_quantile: float = 0.75,
    cutoff_mode: str = "relative",
    transition_width: float = 0.0,
    hp_dc_mode: str = "image_mean",
) -> Dict[str, float]:
    """Evaluate LP/HP images and L2-defined low/high-frequency sample regions."""
    model.eval()
    dtype = amp if isinstance(amp, torch.dtype) else _resolve_amp_dtype(str(amp or "none"), device)
    # (high-frequency L2 energy ratio, low_l2, high_l2, clean_ok, lp_ok, hp_ok)
    local_records: list[tuple[float, float, float, int, int, int]] = []
    lp_correct = hp_correct = clean_correct = total = 0
    for batch in loader:
        images, target = batch[:2]
        images = move_batch_to_device(images, device, channels_last and device.type == "cuda")
        target = target.to(device, non_blocking=True)
        stats = frequency_energy_statistics(images, cutoff, cutoff_mode=cutoff_mode)
        lp, hp = split_frequency(
            images,
            cutoff,
            cutoff_mode=cutoff_mode,
            transition_width=transition_width,
            hp_dc_mode=hp_dc_mode,
        )
        with autocast_context(device, dtype):
            clean_pred = model(images).argmax(dim=1)
            lp_pred = model(lp).argmax(dim=1)
            hp_pred = model(hp).argmax(dim=1)
        clean_ok = clean_pred.eq(target)
        lp_ok = lp_pred.eq(target)
        hp_ok = hp_pred.eq(target)
        clean_correct += int(clean_ok.sum())
        lp_correct += int(lp_ok.sum())
        hp_correct += int(hp_ok.sum())
        total += int(target.numel())
        for high_ratio, low_l2, high_l2, c, l, h in zip(
            stats["high_ratio"].cpu().tolist(),
            stats["low_l2"].cpu().tolist(),
            stats["high_l2"].cpu().tolist(),
            clean_ok.cpu().tolist(),
            lp_ok.cpu().tolist(),
            hp_ok.cpu().tolist(),
        ):
            local_records.append((float(high_ratio), float(low_l2), float(high_l2), int(c), int(l), int(h)))

    records = [item for chunk in all_gather_object(local_records) for item in chunk]
    count_tensor = torch.tensor([clean_correct, lp_correct, hp_correct, total], device=device, dtype=torch.float64)
    all_reduce_(count_tensor)
    if not records:
        return {}
    high_ratio_values = np.asarray([record[0] for record in records], dtype=np.float64)
    low_threshold = float(np.quantile(high_ratio_values, low_quantile))
    high_threshold = float(np.quantile(high_ratio_values, high_quantile))
    # Low-frequency-dominant examples have the smallest high-frequency L2 energy
    # ratio; high-frequency-dominant examples have the largest ratio.
    low_group = [record for record in records if record[0] <= low_threshold]
    high_group = [record for record in records if record[0] >= high_threshold]

    def error(group: list[tuple[float, float, float, int, int, int]], correct_index: int) -> float:
        if not group:
            return float("nan")
        return 100.0 * (1.0 - sum(row[correct_index] for row in group) / len(group))

    n = max(1.0, float(count_tensor[3]))
    return {
        "cutoff": float(cutoff),
        "clean_error": 100.0 * (1.0 - float(count_tensor[0]) / n),
        "lowpass_error": 100.0 * (1.0 - float(count_tensor[1]) / n),
        "highpass_error": 100.0 * (1.0 - float(count_tensor[2]) / n),
        "high_frequency_ratio_low_threshold": low_threshold,
        "high_frequency_ratio_high_threshold": high_threshold,
        "low_frequency_region_error": error(low_group, 3),
        "high_frequency_region_error": error(high_group, 3),
        "low_region_lp_error": error(low_group, 4),
        "high_region_hp_error": error(high_group, 5),
        "low_region_samples": len(low_group),
        "high_region_samples": len(high_group),
    }


def _resolve_amp_dtype(name: str, device: torch.device) -> torch.dtype | None:
    name = str(name).lower()
    if name in {"none", "", "null"}:
        return None
    if device.type == "cuda":
        return torch.bfloat16 if name == "bf16" else torch.float16
    if device.type == "cpu" and name == "bf16":
        return torch.bfloat16
    return None
