from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, MutableMapping

import yaml


DEFAULT_CONFIG: Dict[str, Any] = {
    "experiment": {
        "name": "frequency_steering",
        "output_root": "outputs",
        "seed": 42,
        "deterministic": False,
        "device": "auto",
        "resume": "",
        "checkpoint": "",
        "overwrite": False,
    },
    "model": {
        "arch": "resnet50",
        "weights": "DEFAULT",
        "num_classes": 1000,
        "image_size": 224,
        "channels_last": True,
        "compile": False,
    },
    "data": {
        "dataset": "imagenet",
        "root": "",
        "train_root": "",
        "val_root": "",
        "calibration_root": "",
        "imagenet_c_root": "",
        "imagenet_r_root": "",
        "imagenet_sketch_root": "",
        "stylized_imagenet_root": "",
        "neu_root": "",
        "dtd_root": "",
        "dtd_partition": 1,
        "cub_root": "",
        "folder_root": "",
        "download": False,
        "resize_size": 256,
        "batch_size": 128,
        "eval_batch_size": 256,
        "calibration_batch_size": 0,
        "batch_size_scope": "per_process",
        "workers": 8,
        "calibration_size": 2048,
        "eval_subset_size": 0,
        "train_fraction": 1.0,
        "val_fraction": 1.0,
        "split_seed": 42,
        "neu_val_fraction": 0.2,
        "cub_train": True,
        "normalization": "imagenet",
        "interpolation": "bicubic",
    },
    "pruning": {
        "method": "frequency_steering",
        "target_sparsity": 0.7,
        "sparsity_schedule": [],
        "num_rounds": 7,
        "prune_fraction_per_round": 0.1,
        "global_pruning": True,
        "min_units": 8,
        "min_unit_fraction": 0.05,
        "score_reduction": "mean",
        "layer_normalization": "zscore",
        "score_batches": 8,
        "lambda": 1.0,
        "cutoff": 0.25,
        "cutoff_mode": "relative",
        "transition_width": 0.02,
        "steering": "high",
        "low_steering_formula": "swap",
        "hp_dc_mode": "image_mean",
        "saliency_abs_after_combine": True,
        "random_seed": 123,
        "hap_samples": 1,
        "hap_mode": "gate_empirical_fisher",
        "hap_microbatch_size": 8,
        "saliency_execution": "all_ranks",
        "saliency_reduce_bucket_mb": 64.0,
        "kind_quotas": {},
        # Post-pruning BatchNorm statistics recalibration (0 disables). Applied
        # to every method identically; ViTs have no BatchNorm and are unaffected.
        "bn_recalibration_batches": 0,
        # Budget definition for the target: "units" (fraction of structural units,
        # legacy) or "macs" (fraction of physical MACs removed, comparable across
        # criteria). Channel counts kept per group are rounded to a multiple of
        # channel_alignment (1 = off) so pruned networks map well onto GPU kernels.
        "budget": "units",
        "channel_alignment": 1,
        # Spectral-Steering (FSP v4) settings. See pruning/spectral.py.
        "spectral": {
            "estimator": "exact",  # exact | noise | filtered
            "band_edges": [0.0, 0.125, 0.25, 0.5, 2.0],
            "target_profile": "auto",  # auto | reliance | high | low | flat | manual
            "manual_weights": [],
            "lambda": 1.0,
            "signed": True,
            "microbatch_size": 16,
            "taylor_reduction": "abs",
            "reliance_batches": 8,
            "reliance_source": "dense",  # dense | current
            "noise_samples_per_band": 4,
            "noise_amplitude": 0.1,
            "keep_dc": True,
            "profile_normalization": "extensive",  # extensive | density
        },
    },
    "train": {
        "optimizer": "sgd",
        "epochs_before_pruning": 0,
        "recovery_epochs": 1,
        "final_epochs": 1,
        "lr": 0.01,
        "min_lr": 1.0e-6,
        "weight_decay": 1.0e-4,
        "momentum": 0.9,
        "nesterov": True,
        "scheduler": "cosine",
        "warmup_epochs": 0,
        "label_smoothing": 0.1,
        "mixup_alpha": 0.0,
        "cutmix_alpha": 0.0,
        "gradient_clip": 0.0,
        "accumulation_steps": 1,
        "amp": "bf16",
        "ema_decay": 0.0,
        "distill_frequency": False,
        "distill_alpha": 0.0,
        "distill_temperature": 2.0,
        # Standard logit distillation from the (task-adapted) dense model during
        # recovery. Identical for every pruning method, so it is part of the fair
        # recovery protocol rather than part of any single criterion.
        "distill_dense": False,
        "dense_distill_alpha": 0.5,
        "dense_distill_temperature": 2.0,
        # Frequency data augmentation (random band-pass/band-stop). Used only for
        # the ``taylor_fourier_aug`` ablation that asks whether exposing the
        # network to filtered inputs, rather than the criterion, explains gains.
        "frequency_augment": False,
        "frequency_augment_prob": 0.5,
        "freeze_backbone_epochs": 0,
    },
    "evaluation": {
        "eval_each_round": True,
        "round_eval_mode": "clean",
        "eval_dense": True,
        "eval_filtered": True,
        "eval_imagenet_c": True,
        "eval_imagenet_r": True,
        "imagenet_c_corruptions": "all",
        "imagenet_c_severities": [1, 2, 3, 4, 5],
        "frequency_cutoffs": [0.125, 0.25, 0.5],
        "l2_low_quantile": 0.25,
        "l2_high_quantile": 0.75,
        "throughput": True,
        "throughput_batch_size": 64,
        "throughput_warmup": 10,
        "throughput_steps": 30,
        "export_slim": True,
        "torchscript": True,
        "export_equivalence_atol": 1.0e-4,
        "export_equivalence_rtol": 1.0e-4,
        # Band-wise sensitivity/reliance profiles of the dense and final models
        # (controllability metrics). Cheap: a few calibration batches.
        "spectral_profiles": True,
        "spectral_profile_batches": 8,
        "spectral_profile_microbatch": 32,
        # Sensitivity profile after each pruning step and after each recovery
        # phase (tests the first-order prediction and the re-sensitisation
        # hypothesis). Cheap: a few calibration batches per measurement.
        "spectral_trajectory": True,
        "spectral_trajectory_batches": 4,
        # Extra batch sizes for the slim-model throughput benchmark.
        "throughput_batch_sizes": [1, 32],
    },
    "visualization": {
        "fourier_heatmap": True,
        "heatmap_resolution": 17,
        "heatmap_amplitude": 0.15,
        "heatmap_batches": 4,
        "layer_heatmap": True,
        "layer_batches": 4,
        "max_layers": 0,
        "save_examples": 16,
    },
}


def deep_update(base: MutableMapping[str, Any], update: Mapping[str, Any]) -> MutableMapping[str, Any]:
    for key, value in update.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), MutableMapping):
            deep_update(base[key], value)  # type: ignore[index]
        else:
            base[key] = copy.deepcopy(value)
    return base


def load_config_file(path: str | Path) -> Dict[str, Any]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as handle:
        if path.suffix.lower() == ".json":
            loaded = json.load(handle)
        else:
            loaded = yaml.safe_load(handle)
    if loaded is None:
        return {}
    if not isinstance(loaded, dict):
        raise TypeError(f"Configuration root must be a mapping: {path}")
    return loaded


def _parse_override_value(raw: str) -> Any:
    if raw == "":
        return ""
    try:
        return yaml.safe_load(raw)
    except yaml.YAMLError:
        return raw


def set_by_dotted_key(config: MutableMapping[str, Any], key: str, value: Any) -> None:
    parts = key.split(".")
    current: MutableMapping[str, Any] = config
    for part in parts[:-1]:
        child = current.get(part)
        if not isinstance(child, MutableMapping):
            child = {}
            current[part] = child
        current = child
    current[parts[-1]] = value


def resolve_config(path: str | Path | None = None, overrides: Iterable[str] = ()) -> Dict[str, Any]:
    config = copy.deepcopy(DEFAULT_CONFIG)
    if path:
        deep_update(config, load_config_file(path))
    for item in overrides:
        if "=" not in item:
            raise ValueError(f"Override must be KEY=VALUE, got: {item}")
        key, raw = item.split("=", 1)
        set_by_dotted_key(config, key.strip(), _parse_override_value(raw))
    validate_config(config)
    return config


def validate_config(config: Mapping[str, Any]) -> None:
    pruning = config["pruning"]
    target = float(pruning["target_sparsity"])
    if not 0.0 <= target < 1.0:
        raise ValueError("pruning.target_sparsity must be in [0, 1)")
    cutoff = float(pruning["cutoff"])
    if cutoff < 0.0:
        raise ValueError("pruning.cutoff must be non-negative")
    method = str(pruning["method"]).lower().replace("-", "_")
    if isinstance(pruning, MutableMapping):
        pruning["method"] = method
    supported = {
        "dense",
        "dense_finetuned",
        "random",
        "magnitude",
        "snip",
        "taylor",
        "hap",
        "lfs",
        "steering_only",
        "frequency_steering",
        "spectral_steering",
    }
    if method not in supported:
        raise ValueError(f"Unsupported pruning method {method}; choose from {sorted(supported)}")
    if str(pruning["steering"]).lower() not in {"high", "low"}:
        raise ValueError("pruning.steering must be 'high' or 'low'")
    if str(config["train"]["amp"]).lower() not in {"none", "fp16", "bf16"}:
        raise ValueError("train.amp must be none/fp16/bf16")
    saliency_execution = str(pruning.get("saliency_execution", "all_ranks")).lower()
    if saliency_execution not in {"all", "all_ranks", "sharded", "all_rank_sharded"}:
        raise ValueError(
            "pruning.saliency_execution must be all_ranks. Distributed rank-0-only "
            "saliency is disabled because it can violate collective ordering."
        )
    if float(pruning.get("saliency_reduce_bucket_mb", 64.0)) <= 0:
        raise ValueError("pruning.saliency_reduce_bucket_mb must be positive")
    hap_mode = str(pruning.get("hap_mode", "gate_empirical_fisher")).lower().replace("-", "_")
    supported_hap = {
        "fisher",
        "empirical_fisher",
        "gate_fisher",
        "minibatch_empirical_fisher",
        "gate_empirical_fisher",
        "hutchinson",
        "gate_hutchinson",
    }
    if hap_mode not in supported_hap:
        raise ValueError(f"Unsupported pruning.hap_mode: {hap_mode}")
    if int(pruning.get("hap_microbatch_size", 8)) < 1:
        raise ValueError("pruning.hap_microbatch_size must be >= 1")
    spectral = pruning.get("spectral", {}) or {}
    if str(spectral.get("estimator", "exact")).lower() not in {"exact", "noise", "filtered"}:
        raise ValueError("pruning.spectral.estimator must be exact/noise/filtered")
    if str(spectral.get("target_profile", "auto")).lower() not in {
        "auto", "mismatch", "reliance", "high", "low", "flat", "manual", "legacy",
    }:
        raise ValueError("pruning.spectral.target_profile must be auto/reliance/high/low/flat/manual")
    if int(pruning.get("bn_recalibration_batches", 0)) < 0:
        raise ValueError("pruning.bn_recalibration_batches must be >= 0")
    if str(pruning.get("budget", "units")).lower() not in {"units", "macs"}:
        raise ValueError("pruning.budget must be units or macs")
    if int(pruning.get("channel_alignment", 1)) < 1:
        raise ValueError("pruning.channel_alignment must be >= 1")
    if str(spectral.get("profile_normalization", "extensive")).lower() not in {"extensive", "density"}:
        raise ValueError("pruning.spectral.profile_normalization must be extensive or density")
    train = config["train"]
    if not 0.0 <= float(train.get("dense_distill_alpha", 0.5)) <= 1.0:
        raise ValueError("train.dense_distill_alpha must be in [0, 1]")
    if not 0.0 <= float(train.get("frequency_augment_prob", 0.5)) <= 1.0:
        raise ValueError("train.frequency_augment_prob must be in [0, 1]")
    if str(config["evaluation"].get("round_eval_mode", "clean")).lower() not in {"clean", "full", "none"}:
        raise ValueError("evaluation.round_eval_mode must be clean/full/none")
    if str(config["data"].get("batch_size_scope", "per_process")).lower() not in {"per_process", "global"}:
        raise ValueError("data.batch_size_scope must be per_process/global")


def flatten_config(config: Mapping[str, Any], prefix: str = "") -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for key, value in config.items():
        dotted = f"{prefix}.{key}" if prefix else key
        if isinstance(value, Mapping):
            result.update(flatten_config(value, dotted))
        else:
            result[dotted] = value
    return result
