from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .h200_runtime import atomic_json_dump, env_bool, env_int
from .version import PIPELINE_VERSION


@dataclass(frozen=True)
class ExperimentTask:
    name: str
    command: tuple[str, ...]
    run_dir: str
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class TaskResult:
    name: str
    run_dir: str
    status: str
    returncode: int
    gpu: str
    attempts: int
    elapsed_seconds: float
    log_path: str
    error_hint: str = ""


def available_gpu_ids() -> list[str]:
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if visible and visible not in {"-1", "none", "None"}:
        return [item.strip() for item in visible.split(",") if item.strip()]
    try:
        import torch

        count = torch.cuda.device_count()
    except Exception:
        count = 0
    if count > 0:
        return [str(index) for index in range(count)]
    if env_bool("FSP_ALLOW_CPU", False):
        return ["cpu"]
    raise RuntimeError("No CUDA GPU is visible; set FSP_ALLOW_CPU=1 only for smoke testing")


def is_complete(run_dir: str | Path) -> bool:
    """Validate the versioned two-file completion contract.

    Directory existence or a partially written summary is never considered
    success.  This makes rerunning ``run_all.sh`` safe after SIGTERM, NCCL aborts,
    node preemption, or a failed final visualization/export.
    """

    path = Path(run_dir)
    summary = path / "summary.json"
    marker = path / "COMPLETED"
    if not summary.is_file() or not marker.is_file():
        return False
    try:
        payload = json.loads(summary.read_text(encoding="utf-8"))
        marker_value = marker.read_text(encoding="utf-8").strip()
    except (OSError, json.JSONDecodeError):
        return False
    return bool(
        isinstance(payload, dict)
        and payload.get("pipeline_version") == PIPELINE_VERSION
        and "final" in payload
        and "actual_sparsity" in payload
        and marker_value == PIPELINE_VERSION
    )


def _archive_incomplete(run_dir: Path) -> None:
    if not run_dir.exists() or not any(run_dir.iterdir()) or is_complete(run_dir):
        return
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    candidate = run_dir.with_name(f"{run_dir.name}.failed-{timestamp}")
    index = 1
    while candidate.exists():
        candidate = run_dir.with_name(f"{run_dir.name}.failed-{timestamp}-{index:02d}")
        index += 1
    run_dir.rename(candidate)


def _error_hint(log_path: Path) -> str:
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")[-200_000:]
    except OSError:
        return "log unavailable"
    patterns = [
        ("Too many open files", "file_descriptor_exhaustion"),
        ("CUDA out of memory", "cuda_out_of_memory"),
        ("OutOfMemoryError", "cuda_out_of_memory"),
        ("NCCL", "distributed_or_nccl_failure"),
        ("timed out", "timeout"),
        ("FileNotFoundError", "missing_path_or_dataset"),
        ("undefined symbol", "binary_compatibility_warning"),
    ]
    for pattern, hint in patterns:
        if pattern.lower() in text.lower():
            return hint
    return "unclassified_failure"


def _child_environment(
    gpu: str,
    parallel_jobs: int,
    attempt: int,
    hint: str = "",
    *,
    mpl_config_dir: str | None = None,
) -> dict[str, str]:
    env = dict(os.environ)
    for key in (
        "RANK",
        "WORLD_SIZE",
        "LOCAL_RANK",
        "LOCAL_WORLD_SIZE",
        "GROUP_RANK",
        "ROLE_RANK",
        "MASTER_ADDR",
        "MASTER_PORT",
        "TORCHELASTIC_RUN_ID",
    ):
        env.pop(key, None)
    if gpu != "cpu":
        env["CUDA_VISIBLE_DEVICES"] = gpu
    else:
        env["CUDA_VISIBLE_DEVICES"] = ""
    env["FSP_CONCURRENT_JOBS"] = str(max(1, parallel_jobs))
    env["FSP_RETRY_ATTEMPT"] = str(attempt)
    env["MPLBACKEND"] = "Agg"
    if mpl_config_dir:
        env["MPLCONFIGDIR"] = mpl_config_dir
    if attempt > 1 and hint == "file_descriptor_exhaustion":
        env["FSP_MAX_WORKERS_PER_JOB"] = "0"
        env["FSP_ALLOW_PERSISTENT_WORKERS"] = "0"
    if attempt > 1 and hint == "cuda_out_of_memory":
        # This affects only the gate-level HAP calibration microbatch.  It does
        # not change the training batch, optimizer, or FSP objective.
        env["FSP_HAP_MICROBATCH_SIZE"] = "1"
    return env


def run_tasks(
    tasks: Sequence[ExperimentTask],
    *,
    stage: str,
    status_root: str | Path,
    max_parallel: int | None = None,
    retry_count: int | None = None,
) -> list[TaskResult]:
    """Run independent experiments concurrently, one process per GPU."""

    status_root = Path(status_root)
    log_root = status_root / "logs" / stage
    log_root.mkdir(parents=True, exist_ok=True)
    gpu_ids = available_gpu_ids()
    requested_parallel = max_parallel or env_int("FSP_MAX_PARALLEL_JOBS", len(gpu_ids), 1)
    parallel = max(1, min(len(gpu_ids), int(requested_parallel)))
    retries = env_int("FSP_TASK_RETRIES", 1, 0) if retry_count is None else max(0, retry_count)

    pending = list(tasks)
    results: list[TaskResult] = []
    running: dict[subprocess.Popen[Any], dict[str, Any]] = {}
    free_gpus = gpu_ids[:parallel]

    # Skip previously completed tasks before allocating a GPU.
    remaining: list[ExperimentTask] = []
    for task in pending:
        if is_complete(task.run_dir):
            results.append(
                TaskResult(
                    task.name,
                    task.run_dir,
                    "skipped_complete",
                    0,
                    "",
                    0,
                    0.0,
                    "",
                )
            )
        else:
            remaining.append(task)
    pending = remaining

    def launch(task: ExperimentTask, gpu: str, attempt: int, previous_hint: str = "") -> None:
        run_path = Path(task.run_dir)
        _archive_incomplete(run_path)
        log_path = log_root / f"{task.name.replace('/', '__')}.attempt-{attempt}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handle = log_path.open("w", encoding="utf-8")
        safe_name = task.name.replace("/", "__").replace(" ", "_")
        mpl_dir = status_root / "matplotlib" / stage / safe_name / f"attempt-{attempt}"
        mpl_dir.mkdir(parents=True, exist_ok=True)
        env = _child_environment(
            gpu,
            parallel,
            attempt,
            previous_hint,
            mpl_config_dir=str(mpl_dir),
        )
        print(
            f"[orchestrator] stage={stage} task={task.name} gpu={gpu} attempt={attempt}",
            flush=True,
        )
        command = list(task.command)
        setsid = shutil.which("setsid")
        if setsid:
            # Launch through the external setsid utility instead of asking
            # subprocess.Popen to fork with start_new_session=True.  The latter
            # can deadlock when the long-lived orchestrator process has already
            # initialized OpenMP/PyTorch worker threads.  External setsid keeps
            # the child in a killable process group while allowing Python's
            # posix_spawn fast path.
            command = [setsid, *command]
        process = subprocess.Popen(
            command,
            stdout=handle,
            stderr=subprocess.STDOUT,
            env=env,
            cwd=str(Path(__file__).resolve().parents[1]),
            start_new_session=not bool(setsid),
        )
        running[process] = {
            "task": task,
            "gpu": gpu,
            "attempt": attempt,
            "start": time.monotonic(),
            "log_path": log_path,
            "handle": handle,
            "previous_hint": previous_hint,
        }

    def terminate_running(reason: str) -> None:
        if not running:
            return
        print(f"[orchestrator] terminating {len(running)} child process groups: {reason}", flush=True)
        for process, state in list(running.items()):
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        deadline = time.monotonic() + float(os.environ.get("FSP_CHILD_TERM_GRACE_SECONDS", "15"))
        while time.monotonic() < deadline and any(process.poll() is None for process in running):
            time.sleep(0.1)
        for process, state in list(running.items()):
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=5)
            except Exception:
                pass
            handle = state.get("handle")
            if handle is not None and not handle.closed:
                handle.flush()
                handle.close()

    previous_sigterm = signal.getsignal(signal.SIGTERM)
    previous_sigint = signal.getsignal(signal.SIGINT)

    def _raise_interrupt(signum, frame):
        raise KeyboardInterrupt(f"orchestrator received signal {signum}")

    signal.signal(signal.SIGTERM, _raise_interrupt)
    signal.signal(signal.SIGINT, _raise_interrupt)
    try:
        while pending or running:
            while pending and free_gpus:
                task = pending.pop(0)
                gpu = free_gpus.pop(0)
                launch(task, gpu, 1)
            if not running:
                continue
            time.sleep(0.2)
            for process, state in list(running.items()):
                returncode = process.poll()
                if returncode is None:
                    continue
                state["handle"].flush()
                state["handle"].close()
                del running[process]
                task: ExperimentTask = state["task"]
                gpu = str(state["gpu"])
                attempt = int(state["attempt"])
                elapsed = time.monotonic() - float(state["start"])
                log_path: Path = state["log_path"]
                completed = returncode == 0 and is_complete(task.run_dir)
                if completed:
                    hint = ""
                elif returncode == 0:
                    hint = "missing_or_invalid_completion_summary"
                else:
                    hint = _error_hint(log_path)
                if completed:
                    result = TaskResult(
                        task.name,
                        task.run_dir,
                        "ok",
                        0,
                        gpu,
                        attempt,
                        elapsed,
                        str(log_path),
                    )
                    results.append(result)
                    free_gpus.append(gpu)
                elif attempt <= retries:
                    print(
                        f"[orchestrator] retry task={task.name} reason={hint} "
                        f"attempt={attempt + 1}",
                        flush=True,
                    )
                    launch(task, gpu, attempt + 1, hint)
                else:
                    results.append(
                        TaskResult(
                            task.name,
                            task.run_dir,
                            "failed",
                            int(returncode) if int(returncode) != 0 else 1,
                            gpu,
                            attempt,
                            elapsed,
                            str(log_path),
                            hint,
                        )
                    )
                    free_gpus.append(gpu)
                atomic_json_dump(
                    {
                        "stage": stage,
                        "updated_at": time.time(),
                        "pipeline_version": PIPELINE_VERSION,
                        "parallel_jobs": parallel,
                        "results": [asdict(result) for result in results],
                        "pending": [task.name for task in pending],
                        "running": [entry["task"].name for entry in running.values()],
                    },
                    status_root / f"{stage}.json",
                )
    except BaseException:
        terminate_running("orchestrator exception or signal")
        raise
    finally:
        signal.signal(signal.SIGTERM, previous_sigterm)
        signal.signal(signal.SIGINT, previous_sigint)

    results.sort(key=lambda item: item.name)
    atomic_json_dump(
        {
            "stage": stage,
            "pipeline_version": PIPELINE_VERSION,
            "completed_at": time.time(),
            "parallel_jobs": parallel,
            "results": [asdict(result) for result in results],
        },
        status_root / f"{stage}.json",
    )
    failures = [result for result in results if result.status == "failed"]
    if failures:
        summary = ", ".join(
            f"{result.name}({result.error_hint}, log={result.log_path})" for result in failures
        )
        raise RuntimeError(f"Stage {stage} failed: {summary}")
    return results


def command_with_overrides(
    python: str,
    config: str,
    run_dir: str | Path,
    overrides: Iterable[str],
) -> tuple[str, ...]:
    command = [
        python,
        str(Path(__file__).resolve().parents[1] / "train.py"),
        "--config",
        config,
        "--run-dir",
        str(run_dir),
        "--set",
        "experiment.overwrite=true",
    ]
    for override in overrides:
        command.extend(["--set", str(override)])
    return tuple(command)


# ---------------------------------------------------------------------------
# Method specifications shared by every stage script (FSP v4)
# ---------------------------------------------------------------------------
# A method spec is ``<method>[@key=value[,key=value...]]``.  Keys that start with
# ``spectral.`` are expanded to ``pruning.spectral.``; keys without a section are
# treated as ``pruning.<key>``.  Named aliases cover the standard ablations so
# that run_all.sh can list them as plain words.
METHOD_ALIASES: Mapping[str, tuple[str, tuple[str, ...]]] = {
    # name -> (base method, overrides)
    "spectral_noise": ("spectral_steering", ("pruning.spectral.estimator=noise",)),
    "spectral_filtered": ("spectral_steering", ("pruning.spectral.estimator=filtered",)),
    "spectral_unsigned": ("spectral_steering", ("pruning.spectral.signed=false",)),
    "spectral_high": ("spectral_steering", ("pruning.spectral.target_profile=high",)),
    "spectral_low": ("spectral_steering", ("pruning.spectral.target_profile=low",)),
    "spectral_reliance": ("spectral_steering", ("pruning.spectral.target_profile=reliance",)),
    "spectral_flat": ("spectral_steering", ("pruning.spectral.target_profile=flat",)),
    "spectral_lambda0.1": ("spectral_steering", ("pruning.spectral.lambda=0.1",)),
    "spectral_lambda0.25": ("spectral_steering", ("pruning.spectral.lambda=0.25",)),
    "spectral_lambda0.5": ("spectral_steering", ("pruning.spectral.lambda=0.5",)),
    "spectral_lambda1": ("spectral_steering", ("pruning.spectral.lambda=1.0",)),
    "spectral_lambda2": ("spectral_steering", ("pruning.spectral.lambda=2.0",)),
    "spectral_lambda4": ("spectral_steering", ("pruning.spectral.lambda=4.0",)),
    "spectral_density": ("spectral_steering", ("pruning.spectral.profile_normalization=density",)),
    "spectral_current": ("spectral_steering", ("pruning.spectral.reliance_source=current",)),
    "spectral_kd": ("spectral_steering", ("train.distill_dense=true",)),
    "spectral_units": ("spectral_steering", ("pruning.budget=units",)),
    "spectral_align1": ("spectral_steering", ("pruning.channel_alignment=1",)),
    "taylor_kd": ("taylor", ("train.distill_dense=true",)),
    "taylor_units": ("taylor", ("pruning.budget=units",)),
    "magnitude_units": ("magnitude", ("pruning.budget=units",)),
    "spectral_nokd": ("spectral_steering", ("train.distill_dense=false",)),
    "spectral_norecal": ("spectral_steering", ("pruning.bn_recalibration_batches=0",)),
    "spectral_bands8": (
        "spectral_steering",
        ("pruning.spectral.band_edges=[0.0,0.0625,0.125,0.1875,0.25,0.375,0.5,0.75,2.0]",),
    ),
    "taylor_fourier_aug": ("taylor", ("train.frequency_augment=true",)),
    "taylor_nokd": ("taylor", ("train.distill_dense=false",)),
}


def resolve_method_spec(spec: str) -> tuple[str, str, list[str]]:
    """Return ``(run_name, config_method, overrides)`` for a method spec."""
    spec = str(spec).strip()
    if not spec:
        raise ValueError("empty method spec")
    name, _, extra = spec.partition("@")
    name = name.strip().lower().replace("-", "_")
    overrides: list[str] = []
    if name in METHOD_ALIASES:
        base, alias_overrides = METHOD_ALIASES[name]
        overrides.extend(alias_overrides)
    else:
        base = name
    run_name = name
    if extra:
        for item in extra.split(","):
            item = item.strip()
            if not item:
                continue
            if "=" not in item:
                raise ValueError(f"method spec override must be key=value: {item!r} in {spec!r}")
            key, value = item.split("=", 1)
            key = key.strip()
            if key.startswith("spectral."):
                key = "pruning." + key
            elif "." not in key:
                key = "pruning." + key
            overrides.append(f"{key}={value.strip()}")
            run_name += "_" + key.split(".")[-1] + str(value).strip().replace("[", "").replace("]", "").replace(",", "-")
    overrides.insert(0, f"pruning.method={base}")
    return run_name, base, overrides


def split_csv(value: str) -> list[str]:
    return [item.strip() for item in str(value).split(",") if item.strip()]


def parse_floats(value: str) -> list[float]:
    return [float(item) for item in split_csv(value)]


def parse_ints(value: str) -> list[int]:
    return [int(float(item)) for item in split_csv(value)]


def sparsity_tag(target: float) -> str:
    return f"sp{int(round(float(target) * 100)):02d}"


ARCH_TRAIN_OVERRIDES: Mapping[str, tuple[str, ...]] = {
    # Architecture-specific optimiser settings used when a stage mixes CNNs and
    # ViTs under one base config (transfer stage).
    "resnet50": ("train.optimizer=sgd", "train.lr=0.01", "train.weight_decay=0.0001", "model.channels_last=true"),
    "resnet18": ("train.optimizer=sgd", "train.lr=0.01", "train.weight_decay=0.0001", "model.channels_last=true"),
    "efficientnet_b4": (
        "train.optimizer=sgd",
        "train.lr=0.005",
        "train.weight_decay=0.00001",
        "model.image_size=380",
        "data.resize_size=384",
        "data.interpolation=bicubic",
        "model.channels_last=true",
    ),
    "vit_b_16": (
        "train.optimizer=adamw",
        "train.lr=0.00002",
        "train.weight_decay=0.05",
        "train.gradient_clip=1.0",
        "train.warmup_epochs=1",
        "model.channels_last=false",
        "pruning.bn_recalibration_batches=0",
        "pruning.spectral.microbatch_size=8",
        "data.interpolation=bilinear",
    ),
    "vit_l_16": (
        "train.optimizer=adamw",
        "train.lr=0.00001",
        "train.weight_decay=0.05",
        "train.gradient_clip=1.0",
        "train.warmup_epochs=1",
        "model.channels_last=false",
        "pruning.bn_recalibration_batches=0",
        "pruning.spectral.microbatch_size=4",
        "data.interpolation=bilinear",
    ),
    "deit_base_patch16_224": (
        "train.optimizer=adamw",
        "train.lr=0.00002",
        "train.weight_decay=0.05",
        "train.gradient_clip=1.0",
        "train.warmup_epochs=1",
        "model.channels_last=false",
        "pruning.bn_recalibration_batches=0",
        "pruning.spectral.microbatch_size=8",
        "data.interpolation=bicubic",
    ),
}


def arch_overrides(arch: str) -> list[str]:
    return list(ARCH_TRAIN_OVERRIDES.get(str(arch).strip().lower(), ()))
