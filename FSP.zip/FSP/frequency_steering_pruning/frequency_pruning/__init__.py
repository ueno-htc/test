"""Frequency-Steering Pruning research code."""

from .version import RELEASE_VERSION

__version__ = RELEASE_VERSION
