from __future__ import annotations

import csv
import hashlib
import json
import logging
import math
import os
import random
import shutil
import time
from contextlib import nullcontext
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, MutableMapping, Sequence

import numpy as np
import torch
import torch.nn as nn
import yaml

from .distributed import barrier, broadcast_object, is_main_process, unwrap_model


class AverageMeter:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.sum = 0.0
        self.count = 0

    @property
    def avg(self) -> float:
        return self.sum / max(1, self.count)

    def update(self, value: float, n: int = 1) -> None:
        self.sum += float(value) * int(n)
        self.count += int(n)


def set_seed(seed: int, deterministic: bool = False, rank: int = 0) -> None:
    actual = int(seed) + int(rank)
    random.seed(actual)
    np.random.seed(actual)
    torch.manual_seed(actual)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(actual)
    if deterministic:
        torch.use_deterministic_algorithms(True, warn_only=True)
        torch.backends.cudnn.benchmark = False
    else:
        torch.backends.cudnn.benchmark = torch.cuda.is_available()
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True


def json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, torch.Tensor):
        if value.numel() == 1:
            return value.item()
        return value.detach().cpu().tolist()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Mapping):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def save_json(path: str | Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(json_safe(value), indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(path)


def save_yaml(path: str | Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(json_safe(value), handle, sort_keys=False, allow_unicode=True)
    temp.replace(path)


def append_jsonl(path: str | Path, row: Mapping[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(json_safe(row), ensure_ascii=False) + "\n")


def write_csv(path: str | Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                keys.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json_safe(row.get(key)) for key in keys})


def config_signature(config: Mapping[str, Any], length: int = 10) -> str:
    payload = json.dumps(json_safe(config), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:length]


def create_run_dir(config: Mapping[str, Any], exact: str | Path | None = None) -> Path:
    if exact is not None:
        requested = str(exact)
    else:
        exp = config["experiment"]
        root = Path(str(exp["output_root"]))
        model = str(config["model"]["arch"])
        method = str(config["pruning"]["method"])
        sparsity = float(config["pruning"]["target_sparsity"])
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        requested = str(root / f"{exp['name']}_{model}_{method}_s{sparsity:.2f}_{stamp}_{config_signature(config)}")

    path: Path | None = None
    if is_main_process():
        candidate = Path(requested)
        if candidate.exists() and any(candidate.iterdir()):
            if bool(config["experiment"].get("overwrite", False)):
                shutil.rmtree(candidate)
            else:
                base = candidate
                index = 1
                while candidate.exists():
                    candidate = Path(f"{base}_{index:02d}")
                    index += 1
        candidate.mkdir(parents=True, exist_ok=True)
        path = candidate.resolve()
    path = Path(str(broadcast_object(str(path) if path is not None else None)))
    barrier()
    return path


def setup_logger(run_dir: str | Path | None = None, name: str = "frequency_pruning") -> logging.Logger:
    logger_name = name if run_dir is None else f"{name}.{abs(hash(str(Path(run_dir).resolve())))}"
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if logger.handlers:
        return logger
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    if run_dir is not None and is_main_process():
        file_handler = logging.FileHandler(Path(run_dir) / "run.log", encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger


def amp_dtype(name: str, device: torch.device) -> torch.dtype | None:
    name = str(name).lower()
    if name == "none":
        return None
    if device.type == "cuda":
        return torch.bfloat16 if name == "bf16" else torch.float16
    if device.type == "cpu" and name == "bf16":
        return torch.bfloat16
    return None


def autocast_context(device: torch.device, dtype: torch.dtype | None):
    if dtype is None:
        return nullcontext()
    return torch.autocast(device_type=device.type, dtype=dtype)


def count_parameters(model: nn.Module, trainable_only: bool = False) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad or not trainable_only)


def profile_macs(model: nn.Module, input_shape: Sequence[int], device: torch.device) -> int:
    """Count multiply-accumulate operations for Conv2d and Linear modules."""
    total = 0
    hooks = []

    def conv_hook(module: nn.Conv2d, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        nonlocal total
        batch = int(output.shape[0])
        out_h, out_w = int(output.shape[-2]), int(output.shape[-1])
        kernel = int(module.kernel_size[0] * module.kernel_size[1])
        per_output = kernel * (module.in_channels // module.groups)
        total += batch * out_h * out_w * module.out_channels * per_output

    def linear_hook(module: nn.Linear, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        nonlocal total
        elements = output.numel() // output.shape[-1]
        total += int(elements * module.in_features * module.out_features)

    def attention_hook(module: nn.Module, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        nonlocal total
        if not inputs or not isinstance(inputs[0], torch.Tensor) or inputs[0].ndim != 3:
            return
        batch, tokens, _ = inputs[0].shape
        heads = int(getattr(module, "num_heads", getattr(module, "original_num_heads", 0)))
        head_dim = int(getattr(module, "head_dim", 0))
        if heads > 0 and head_dim > 0:
            # QK^T and attention-value products. Projection linears are counted by
            # their own hooks.
            total += int(2 * batch * heads * tokens * tokens * head_dim)

    for module in model.modules():
        if isinstance(module, nn.Conv2d):
            hooks.append(module.register_forward_hook(conv_hook))
        elif isinstance(module, nn.Linear):
            hooks.append(module.register_forward_hook(linear_hook))
        elif module.__class__.__name__ in {"PrunableAttention", "SlimAttention"}:
            hooks.append(module.register_forward_hook(attention_hook))

    was_training = model.training
    model.eval()
    sample = torch.randn(*input_shape, device=device)
    try:
        with torch.inference_mode():
            model(sample)
    finally:
        for hook in hooks:
            hook.remove()
        model.train(was_training)
    return int(total / max(1, int(input_shape[0])))


def benchmark_throughput(
    model: nn.Module,
    input_shape: Sequence[int],
    device: torch.device,
    warmup: int = 10,
    steps: int = 30,
    amp: torch.dtype | None = None,
    channels_last: bool = False,
) -> Dict[str, float]:
    model = model.to(device).eval()
    sample = torch.randn(*input_shape, device=device)
    if channels_last and sample.ndim == 4:
        sample = sample.contiguous(memory_format=torch.channels_last)
        model = model.to(memory_format=torch.channels_last)
    with torch.inference_mode():
        for _ in range(max(0, warmup)):
            with autocast_context(device, amp):
                model(sample)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        start = time.perf_counter()
        for _ in range(max(1, steps)):
            with autocast_context(device, amp):
                model(sample)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        elapsed = time.perf_counter() - start
    batch = int(input_shape[0])
    images = batch * max(1, steps)
    return {
        "throughput_images_per_s": images / max(elapsed, 1e-12),
        "latency_ms_per_batch": 1000.0 * elapsed / max(1, steps),
        "latency_ms_per_image": 1000.0 * elapsed / max(1, images),
    }


def enable_channels_last(model: nn.Module) -> nn.Module:
    return model.to(memory_format=torch.channels_last)


def move_batch_to_device(batch: Any, device: torch.device, channels_last: bool = False) -> Any:
    if isinstance(batch, torch.Tensor):
        tensor = batch.to(device, non_blocking=True)
        if channels_last and tensor.ndim == 4:
            tensor = tensor.contiguous(memory_format=torch.channels_last)
        return tensor
    if isinstance(batch, Mapping):
        return {key: move_batch_to_device(value, device, channels_last) for key, value in batch.items()}
    if isinstance(batch, tuple):
        return tuple(move_batch_to_device(value, device, channels_last) for value in batch)
    if isinstance(batch, list):
        return [move_batch_to_device(value, device, channels_last) for value in batch]
    return batch
