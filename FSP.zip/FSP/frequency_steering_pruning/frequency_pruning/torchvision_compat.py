from __future__ import annotations

import importlib
import sys

import torch

_TV_LIBRARY = None


def ensure_torchvision_nms_stub() -> None:
    """Import torchvision, adding a schema stub only for genuinely operator-less builds.

    Some CPU research containers ship torchvision without its custom C++ ops. In
    that case torchvision's fake NMS registration fails during import. Defining the
    schema unconditionally is unsafe in normal builds because the compiled extension
    later registers the same operator, so we first attempt an ordinary import.
    """
    global _TV_LIBRARY
    if _TV_LIBRARY is not None:
        return
    try:
        importlib.import_module("torchvision")
        _TV_LIBRARY = object()
        return
    except RuntimeError as error:
        if "operator torchvision::nms does not exist" not in str(error):
            raise
        # Remove the partially initialized package before retrying.
        for name in [key for key in sys.modules if key == "torchvision" or key.startswith("torchvision.")]:
            sys.modules.pop(name, None)
        library = torch.library.Library("torchvision", "DEF")
        library.define("nms(Tensor boxes, Tensor scores, float iou_threshold) -> Tensor")
        _TV_LIBRARY = library
        importlib.import_module("torchvision")
