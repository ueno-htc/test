from __future__ import annotations

import hashlib
import json
import os
import sys
import traceback
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Dict, Iterable, Mapping, Sequence

import torch
import torch.distributed as dist
import torch.nn as nn
from torch._utils import _flatten_dense_tensors, _unflatten_dense_tensors


_CONTROL_GROUP: dist.ProcessGroup | None = None
_CONTROL_BACKEND = "none"


class DistributedPhaseError(RuntimeError):
    """A caught rank-local error propagated through the control plane."""


@dataclass(frozen=True)
class DistributedContext:
    distributed: bool
    rank: int
    world_size: int
    local_rank: int
    device: torch.device
    backend: str
    control_backend: str = "none"

    @property
    def is_main(self) -> bool:
        return self.rank == 0


def setup_distributed(device_arg: str | None = None) -> DistributedContext:
    """Initialize data and control process groups from a ``torchrun`` environment.

    CUDA tensor collectives use NCCL.  A second CPU/Gloo group is created on NCCL
    jobs for phase status, compact plans, and error propagation.  This separation
    prevents a long CPU/Python phase on one rank from being confused with the next
    NCCL model collective, which was the direct cause of the supplied watchdog
    timeout.
    """

    global _CONTROL_GROUP, _CONTROL_BACKEND

    world = max(1, int(os.environ.get("WORLD_SIZE", "1")))
    process_rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    distributed = world > 1

    if device_arg and device_arg.lower() not in {"auto", ""}:
        device = torch.device(device_arg)
        if device.type == "cuda" and device.index is None:
            device = torch.device("cuda", local_rank)
    elif torch.cuda.is_available():
        device = torch.device("cuda", local_rank)
    else:
        device = torch.device("cpu")

    if device.type == "cuda":
        torch.cuda.set_device(device)
    backend = "nccl" if device.type == "cuda" else "gloo"
    timeout_seconds = max(60, int(os.environ.get("FSP_DISTRIBUTED_TIMEOUT_SECONDS", "3600")))
    if distributed and not dist.is_initialized():
        dist.init_process_group(
            backend=backend,
            init_method="env://",
            timeout=timedelta(seconds=timeout_seconds),
        )
    if dist.is_initialized():
        backend = str(dist.get_backend())

    _CONTROL_GROUP = None
    _CONTROL_BACKEND = "none"
    if distributed:
        if backend.lower() == "gloo":
            _CONTROL_GROUP = dist.group.WORLD
            _CONTROL_BACKEND = "gloo"
        else:
            control_backend = os.environ.get("FSP_CONTROL_BACKEND", "gloo").strip().lower()
            if control_backend != "gloo":
                raise ValueError(
                    "NCCL jobs require FSP_CONTROL_BACKEND=gloo so status/error "
                    "traffic cannot collide with CUDA tensor collectives"
                )
            control_timeout = max(
                timeout_seconds,
                int(os.environ.get("FSP_CONTROL_TIMEOUT_SECONDS", str(timeout_seconds))),
            )
            # Every rank executes new_group in the same initialization sequence.
            _CONTROL_GROUP = dist.new_group(
                backend="gloo",
                timeout=timedelta(seconds=control_timeout),
            )
            _CONTROL_BACKEND = "gloo"

    return DistributedContext(
        distributed=distributed,
        rank=process_rank,
        world_size=world,
        local_rank=local_rank,
        device=device,
        backend=backend,
        control_backend=_CONTROL_BACKEND,
    )


def cleanup_distributed(*, synchronize: bool = False) -> None:
    """Destroy process groups without hiding an original rank failure."""

    global _CONTROL_GROUP, _CONTROL_BACKEND
    if not (dist.is_available() and dist.is_initialized()):
        return
    if synchronize:
        try:
            barrier(phase="cleanup")
        except Exception as error:  # pragma: no cover - only exercised on broken clusters
            print(
                f"WARNING: distributed synchronization during cleanup failed: "
                f"{type(error).__name__}: {error}",
                file=sys.stderr,
                flush=True,
            )
    try:
        if _CONTROL_GROUP is not None and _CONTROL_GROUP is not dist.group.WORLD:
            dist.destroy_process_group(_CONTROL_GROUP)
    except Exception as error:  # pragma: no cover - defensive teardown
        print(
            f"WARNING: control process-group destruction failed: {type(error).__name__}: {error}",
            file=sys.stderr,
            flush=True,
        )
    finally:
        _CONTROL_GROUP = None
        _CONTROL_BACKEND = "none"
    try:
        dist.destroy_process_group()
    except Exception as error:  # pragma: no cover - defensive teardown
        print(
            f"WARNING: destroy_process_group failed: {type(error).__name__}: {error}",
            file=sys.stderr,
            flush=True,
        )


def is_distributed() -> bool:
    return bool(dist.is_available() and dist.is_initialized())


def rank() -> int:
    return dist.get_rank() if is_distributed() else 0


def world_size() -> int:
    return dist.get_world_size() if is_distributed() else 1


def is_main_process() -> bool:
    return rank() == 0


def unwrap_model(model: nn.Module) -> nn.Module:
    while hasattr(model, "module"):
        model = model.module  # type: ignore[assignment]
    return model


def control_group() -> dist.ProcessGroup | None:
    if not is_distributed():
        return None
    return _CONTROL_GROUP if _CONTROL_GROUP is not None else dist.group.WORLD


def barrier(*, phase: str = "barrier") -> None:
    if not is_distributed():
        return
    group = control_group()
    timeout_seconds = max(60, int(os.environ.get("FSP_BARRIER_TIMEOUT_SECONDS", "600")))
    if _CONTROL_BACKEND == "gloo" and hasattr(dist, "monitored_barrier"):
        dist.monitored_barrier(
            group=group,
            timeout=timedelta(seconds=timeout_seconds),
            wait_all_ranks=True,
        )
    else:  # pragma: no cover - control group is Gloo in supported distributed jobs
        dist.barrier(group=group)


def collective_device(fallback: torch.device | None = None) -> torch.device:
    if not is_distributed():
        return fallback or torch.device("cpu")
    if str(dist.get_backend()).lower() == "nccl":
        if fallback is not None and fallback.type == "cuda":
            return fallback
        return torch.device("cuda", torch.cuda.current_device())
    return torch.device("cpu")


def all_reduce_(
    tensor: torch.Tensor,
    average: bool = False,
    *,
    enabled: bool = True,
) -> torch.Tensor:
    if enabled and is_distributed():
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
        if average:
            tensor.div_(dist.get_world_size())
    return tensor


def coalesced_all_reduce_(
    tensors: Iterable[torch.Tensor],
    *,
    average: bool = False,
    enabled: bool = True,
    bucket_mb: float = 64.0,
) -> None:
    """Reduce dense tensors in bounded flat buckets.

    Saliency exposes many parameter tensors.  Issuing one NCCL collective for
    every parameter is slow and makes collective-order failures difficult to
    diagnose.  Bucketed reduction preserves values while reducing the number of
    synchronization points by orders of magnitude.
    """

    if not (enabled and is_distributed()):
        return
    values = [tensor for tensor in tensors if tensor.numel() > 0]
    if not values:
        return
    byte_limit = max(1, int(float(bucket_mb) * 1024 * 1024))
    grouped: dict[tuple[torch.device, torch.dtype], list[torch.Tensor]] = {}
    for tensor in values:
        grouped.setdefault((tensor.device, tensor.dtype), []).append(tensor)

    for group_values in grouped.values():
        bucket: list[torch.Tensor] = []
        bucket_bytes = 0

        def flush() -> None:
            nonlocal bucket, bucket_bytes
            if not bucket:
                return
            contiguous = [tensor.contiguous() for tensor in bucket]
            flat = _flatten_dense_tensors(contiguous)
            dist.all_reduce(flat, op=dist.ReduceOp.SUM)
            if average:
                flat.div_(dist.get_world_size())
            reduced = _unflatten_dense_tensors(flat, contiguous)
            for destination, source in zip(bucket, reduced):
                destination.copy_(source)
            bucket = []
            bucket_bytes = 0

        for tensor in group_values:
            tensor_bytes = tensor.numel() * tensor.element_size()
            if bucket and bucket_bytes + tensor_bytes > byte_limit:
                flush()
            bucket.append(tensor)
            bucket_bytes += tensor_bytes
        flush()


def reduce_scalar_dict(values: Mapping[str, float], average: bool = True) -> Dict[str, float]:
    if not values:
        return {}
    keys = sorted(values)
    device = collective_device()
    tensor = torch.tensor([float(values[key]) for key in keys], dtype=torch.float64, device=device)
    all_reduce_(tensor, average=average)
    return {key: float(value) for key, value in zip(keys, tensor.cpu().tolist())}


def all_gather_object(obj: Any) -> list[Any]:
    """Gather compact Python metadata over the CPU control plane."""

    if not is_distributed():
        return [obj]
    output: list[Any] = [None for _ in range(dist.get_world_size())]
    dist.all_gather_object(output, obj, group=control_group())
    return output


def broadcast_object(obj: Any, src: int = 0) -> Any:
    """Broadcast compact metadata over Gloo, never over the NCCL data plane."""

    if not is_distributed():
        return obj
    objects = [obj if rank() == src else None]
    dist.broadcast_object_list(objects, src=src, group=control_group())
    return objects[0]


def synchronize_failures(
    local_error: BaseException | None,
    *,
    phase: str,
    local_traceback: str = "",
) -> None:
    """Propagate a caught local error before the next tensor collective.

    All ranks must call this function at the same phase boundary.  A rank that
    failed local saliency waits on the Gloo control plane; healthy ranks finish
    their local shard and then receive the same descriptive error.  No rank enters
    an NCCL all-reduce until the status consensus succeeds.
    """

    if local_error is None:
        payload: dict[str, Any] = {
            "ok": True,
            "rank": rank(),
            "phase": phase,
        }
    else:
        payload = {
            "ok": False,
            "rank": rank(),
            "phase": phase,
            "error_type": type(local_error).__name__,
            "error": str(local_error),
            "traceback": local_traceback or "".join(
                traceback.format_exception(
                    type(local_error), local_error, local_error.__traceback__
                )
            ),
        }
    if not is_distributed():
        if local_error is not None:
            raise local_error
        return
    statuses = all_gather_object(payload)
    failures = [status for status in statuses if not bool(status.get("ok", False))]
    if failures:
        details = "\n\n".join(
            f"rank={item.get('rank')} phase={item.get('phase')} "
            f"{item.get('error_type')}: {item.get('error')}\n{item.get('traceback', '')}"
            for item in failures
        )
        raise DistributedPhaseError(
            f"Distributed phase {phase!r} failed before tensor collectives:\n{details}"
        )


def assert_consensus(value: Any, *, phase: str) -> None:
    """Raise on every rank when a small deterministic state differs."""

    if not is_distributed():
        return
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    digest = hashlib.sha256(encoded).hexdigest()
    digests = all_gather_object({"rank": rank(), "digest": digest})
    unique = {item["digest"] for item in digests}
    if len(unique) != 1:
        raise DistributedPhaseError(
            f"Distributed state diverged in phase {phase!r}: {digests}"
        )


def broadcast_json(
    payload: Mapping[str, Any] | None,
    *,
    src: int = 0,
    device: torch.device | None = None,
) -> Dict[str, Any]:
    """Backward-compatible compact metadata broadcast over the control plane."""

    del device
    value = broadcast_object(dict(payload or {}) if rank() == src else None, src=src)
    return dict(value or {})


def broadcast_tensor(
    tensor: torch.Tensor | None,
    *,
    numel: int,
    dtype: torch.dtype = torch.float32,
    src: int = 0,
    device: torch.device | None = None,
) -> torch.Tensor:
    """Broadcast a fixed-size tensor on the data plane and return CPU values."""

    if not is_distributed():
        if tensor is None:
            raise ValueError("tensor cannot be None outside distributed execution")
        return tensor.detach().to(device="cpu", dtype=dtype).reshape(numel)
    comm_device = collective_device(device)
    if rank() == src:
        if tensor is None:
            raise ValueError("source rank must provide a tensor")
        value = tensor.detach().to(device=comm_device, dtype=dtype).contiguous().reshape(-1)
        if value.numel() != numel:
            raise ValueError(f"Expected {numel} broadcast values, got {value.numel()}")
    else:
        value = torch.empty(numel, dtype=dtype, device=comm_device)
    if numel:
        dist.broadcast(value, src=src)
    return value.cpu()
