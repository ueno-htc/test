from __future__ import annotations

"""Explicit runtime controls for large single-node GPU experiments.

This module deliberately avoids monkey-patching :class:`DataLoader`, DDP, or
``torch.autocast``.  Callers opt into every behavior through normal function
arguments so scientific settings remain inspectable and reproducible.
"""

import contextlib
import json
import os
import resource
import shutil
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, MutableMapping, Optional


@dataclass(frozen=True)
class LoaderRuntime:
    workers: int
    prefetch_factor: int | None
    persistent_workers: bool
    pin_memory: bool
    sharing_strategy: str
    fd_soft_limit: int
    estimated_fd_budget_per_worker: int
    effective_parallel_processes: int


@dataclass(frozen=True)
class RuntimeReport:
    nofile: dict[str, Any]
    torch: dict[str, Any]
    loader: dict[str, Any]


def env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return bool(default)
    return value.strip().lower() not in {"0", "false", "no", "off", ""}


def env_int(name: str, default: int, minimum: int = 0) -> int:
    try:
        return max(minimum, int(os.environ.get(name, default)))
    except (TypeError, ValueError):
        return max(minimum, int(default))


def raise_nofile_limit(target: Optional[int] = None) -> dict[str, Any]:
    """Raise ``RLIMIT_NOFILE`` without ever decreasing the current limit."""

    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    requested = int(target if target is not None else env_int("FSP_NOFILE_LIMIT", 1_048_576, 1024))
    desired = requested if hard == resource.RLIM_INFINITY else min(requested, int(hard))
    desired = max(int(soft), int(desired))
    changed = False
    error = ""
    if int(soft) < desired:
        try:
            resource.setrlimit(resource.RLIMIT_NOFILE, (desired, hard))
            changed = True
        except (OSError, ValueError) as exc:
            error = f"{type(exc).__name__}: {exc}"
    new_soft, new_hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    return {
        "old_soft": int(soft),
        "old_hard": "unlimited" if hard == resource.RLIM_INFINITY else int(hard),
        "requested": requested,
        "new_soft": int(new_soft),
        "new_hard": "unlimited" if new_hard == resource.RLIM_INFINITY else int(new_hard),
        "changed": changed,
        "error": error,
    }


def _effective_parallel_processes(world_size: int | None = None) -> int:
    world = max(1, int(world_size or os.environ.get("WORLD_SIZE", "1")))
    concurrent = env_int("FSP_CONCURRENT_JOBS", 1, 1)
    return max(world, concurrent)


def _shared_memory_bytes() -> int:
    try:
        return int(shutil.disk_usage("/dev/shm").free)
    except OSError:
        return 0


def recommended_workers_per_rank(
    requested: Optional[int] = None,
    world_size: Optional[int] = None,
    *,
    prefetch_factor: Optional[int] = None,
) -> int:
    """Bound workers by CPU, FD, concurrency, and shared-memory budgets.

    The estimate is intentionally conservative.  It prevents eight concurrent
    experiments from each inheriting a loader configuration intended for one
    process, which is a common source of ``OSError: [Errno 24] Too many open
    files`` and exhausted shared memory.
    """

    parallel = _effective_parallel_processes(world_size)
    cpus = max(1, os.cpu_count() or 1)
    hard_cap = env_int("FSP_MAX_WORKERS_PER_JOB", env_int("FSP_MAX_WORKERS_PER_RANK", 4, 0), 0)
    cpu_reserve = env_int("FSP_CPU_RESERVE", 4, 0)
    usable_cpus = max(1, cpus - cpu_reserve)
    cpu_cap = max(0, usable_cpus // parallel)

    soft, _ = resource.getrlimit(resource.RLIMIT_NOFILE)
    fd_reserve = max(1024, parallel * env_int("FSP_FD_RESERVE_PER_PROCESS", 256, 64))
    fd_per_worker = env_int("FSP_ESTIMATED_FDS_PER_WORKER", 32, 8)
    fd_cap_total = max(0, (int(soft) - fd_reserve) // fd_per_worker)
    fd_cap = max(0, fd_cap_total // parallel)

    prefetch = int(prefetch_factor or env_int("FSP_PREFETCH_FACTOR", 2, 1))
    shm_free = _shared_memory_bytes()
    # The actual tensors depend on batch/image size.  This is only a process and
    # queue overhead guard; file_system sharing further reduces FD pressure.
    shm_per_worker = env_int("FSP_ESTIMATED_SHM_PER_WORKER_MB", 64, 8) * 1024 * 1024 * max(1, prefetch)
    shm_cap = hard_cap if shm_free <= 0 else max(0, int(shm_free // max(1, shm_per_worker * parallel)))

    cap = max(0, min(hard_cap, cpu_cap, fd_cap, shm_cap))
    if requested is None:
        return cap
    return max(0, min(int(requested), cap))


def resolve_loader_runtime(
    requested_workers: int,
    *,
    world_size: int = 1,
    persistent: bool = False,
    pin_memory: Optional[bool] = None,
    prefetch_factor: Optional[int] = None,
) -> LoaderRuntime:
    prefetch = int(prefetch_factor or env_int("FSP_PREFETCH_FACTOR", 2, 1))
    workers = recommended_workers_per_rank(
        requested_workers,
        world_size,
        prefetch_factor=prefetch,
    )
    strategy = os.environ.get("FSP_SHARING_STRATEGY", "file_system")
    soft, _ = resource.getrlimit(resource.RLIMIT_NOFILE)
    return LoaderRuntime(
        workers=workers,
        prefetch_factor=prefetch if workers > 0 else None,
        persistent_workers=bool(
            workers > 0
            and persistent
            and env_bool("FSP_ALLOW_PERSISTENT_WORKERS", True)
        ),
        pin_memory=bool(env_bool("FSP_PIN_MEMORY", True) if pin_memory is None else pin_memory),
        sharing_strategy=strategy,
        fd_soft_limit=int(soft),
        estimated_fd_budget_per_worker=env_int("FSP_ESTIMATED_FDS_PER_WORKER", 32, 8),
        effective_parallel_processes=_effective_parallel_processes(world_size),
    )


def configure_torch_runtime() -> dict[str, Any]:
    """Apply explicit, numerically safe PyTorch process settings."""

    report: dict[str, Any] = {}
    try:
        import torch
        import torch.multiprocessing as mp

        deterministic = env_bool("FSP_DETERMINISTIC", False)
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.benchmark = bool(
                env_bool("FSP_CUDNN_BENCHMARK", not deterministic) and not deterministic
            )
            report["cudnn_benchmark"] = bool(torch.backends.cudnn.benchmark)
        allow_tf32 = env_bool("FSP_ALLOW_TF32", True)
        if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
            torch.backends.cuda.matmul.allow_tf32 = allow_tf32
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.allow_tf32 = allow_tf32
        if hasattr(torch, "set_float32_matmul_precision"):
            torch.set_float32_matmul_precision(os.environ.get("FSP_MATMUL_PRECISION", "high"))
        report["tf32"] = allow_tf32

        requested_strategy = os.environ.get("FSP_SHARING_STRATEGY", "file_system")
        available = set(mp.get_all_sharing_strategies())
        if requested_strategy not in available:
            raise RuntimeError(
                f"Unsupported multiprocessing sharing strategy {requested_strategy!r}; "
                f"available={sorted(available)}"
            )
        mp.set_sharing_strategy(requested_strategy)
        report["sharing_strategy"] = mp.get_sharing_strategy()
        report["torch_version"] = torch.__version__
        report["cuda_version"] = torch.version.cuda
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        if env_bool("FSP_RUNTIME_STRICT", True):
            raise
    return report


def apply_h200_config(config: Any) -> Any:
    """Apply only explicit environment overrides and attach runtime metadata.

    Unlike the previous implementation, this function does not recursively
    rewrite arbitrary keys and does not replace a requested HAP estimator behind
    the user's back.
    """

    if not isinstance(config, MutableMapping):
        return config
    precision = os.environ.get("FSP_PRECISION")
    if precision:
        normalized = precision.lower()
        if normalized in {"fp32", "float32", "none"}:
            config.setdefault("train", {})["amp"] = "none"
        elif normalized in {"bf16", "bfloat16"}:
            config.setdefault("train", {})["amp"] = "bf16"
        elif normalized in {"fp16", "float16"}:
            config.setdefault("train", {})["amp"] = "fp16"
        else:
            raise ValueError(f"Unsupported FSP_PRECISION={precision!r}")

    hap_mode = os.environ.get("FSP_HAP_MODE")
    if hap_mode:
        config.setdefault("pruning", {})["hap_mode"] = hap_mode
    if "FSP_HAP_MICROBATCH_SIZE" in os.environ:
        config.setdefault("pruning", {})["hap_microbatch_size"] = env_int(
            "FSP_HAP_MICROBATCH_SIZE", 8, 1
        )
    if "FSP_SALIENCY_EXECUTION" in os.environ:
        execution = os.environ["FSP_SALIENCY_EXECUTION"].strip().lower()
        if execution not in {"all", "all_ranks", "sharded", "all_rank_sharded"}:
            raise ValueError(
                "FSP_SALIENCY_EXECUTION must be all_ranks. Rank-0-only saliency "
                "is disabled because it can violate distributed collective ordering."
            )
        config.setdefault("pruning", {})["saliency_execution"] = execution

    runtime = config.setdefault("runtime", {})
    if isinstance(runtime, MutableMapping):
        runtime.update(
            {
                "precision": str(config.get("train", {}).get("amp", "none")),
                "sharing_strategy": os.environ.get("FSP_SHARING_STRATEGY", "file_system"),
                "workers_per_job_cap": env_int("FSP_MAX_WORKERS_PER_JOB", 4, 0),
                "prefetch_factor": env_int("FSP_PREFETCH_FACTOR", 2, 1),
                "saliency_execution": str(
                    config.get("pruning", {}).get("saliency_execution", "all_ranks")
                ),
            }
        )
    return config


def initialize_runtime(config: Any | None = None) -> RuntimeReport:
    nofile = raise_nofile_limit()
    torch_report = configure_torch_runtime()
    if config is not None:
        apply_h200_config(config)
    loader = resolve_loader_runtime(
        requested_workers=int(
            (config or {}).get("data", {}).get("workers", 0)
            if isinstance(config, MutableMapping)
            else 0
        ),
        world_size=max(1, int(os.environ.get("WORLD_SIZE", "1"))),
        persistent=True,
    )
    return RuntimeReport(nofile=nofile, torch=torch_report, loader=asdict(loader))


def install_h200_runtime() -> dict[str, Any]:
    """Backward-compatible explicit initializer; no monkey patches are installed."""

    return asdict(initialize_runtime())


def atomic_json_dump(data: Any, destination: str | os.PathLike[str], *, indent: int = 2) -> None:
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=indent, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp_name)


def cleanup_loader(loader: Any) -> None:
    """Best-effort immediate shutdown of DataLoader workers."""

    iterator = getattr(loader, "_iterator", None)
    if iterator is not None:
        shutdown = getattr(iterator, "_shutdown_workers", None)
        if callable(shutdown):
            with contextlib.suppress(Exception):
                shutdown()
        with contextlib.suppress(Exception):
            loader._iterator = None


def runtime_snapshot() -> dict[str, Any]:
    result: dict[str, Any] = {
        "pid": os.getpid(),
        "world_size_env": max(1, int(os.environ.get("WORLD_SIZE", "1"))),
        "concurrent_jobs": env_int("FSP_CONCURRENT_JOBS", 1, 1),
        "precision": os.environ.get("FSP_PRECISION", "config"),
        "hap_mode_override": os.environ.get("FSP_HAP_MODE", ""),
        "saliency_execution_override": os.environ.get("FSP_SALIENCY_EXECUTION", ""),
        "nofile": raise_nofile_limit(),
        "shared_memory_free_bytes": _shared_memory_bytes(),
    }
    try:
        import torch

        result.update(
            {
                "torch": torch.__version__,
                "cuda_available": torch.cuda.is_available(),
                "cuda_device_count": torch.cuda.device_count(),
            }
        )
        if torch.cuda.is_available():
            result["devices"] = [
                {
                    "index": index,
                    "name": torch.cuda.get_device_name(index),
                    "total_memory": int(torch.cuda.get_device_properties(index).total_memory),
                    "capability": list(torch.cuda.get_device_capability(index)),
                    "bf16_supported": bool(torch.cuda.is_bf16_supported()),
                }
                for index in range(torch.cuda.device_count())
            ]
    except Exception as exc:
        result["torch_error"] = f"{type(exc).__name__}: {exc}"
    return result
