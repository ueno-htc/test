from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Mapping

import torch
import torch.nn as nn

from .distributed import unwrap_model
from .pruning.iterative import load_mask_state_dict, mask_state_dict


def _strip_module_prefix(state: Mapping[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    if not state:
        return {}
    if all(key.startswith("module.") for key in state):
        return {key[len("module.") :]: value for key, value in state.items()}
    return dict(state)


def save_checkpoint(
    path: str | Path,
    model: nn.Module,
    *,
    optimizer: torch.optim.Optimizer | None = None,
    scheduler: Any | None = None,
    epoch: int = 0,
    global_step: int = 0,
    round_index: int = 0,
    config: Mapping[str, Any] | None = None,
    metrics: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload: Dict[str, Any] = {
        "model": unwrap_model(model).state_dict(),
        "mask_state": mask_state_dict(model),
        "epoch": int(epoch),
        "global_step": int(global_step),
        "round_index": int(round_index),
        "config": dict(config or {}),
        "metrics": dict(metrics or {}),
        "extra": dict(extra or {}),
    }
    if optimizer is not None:
        payload["optimizer"] = optimizer.state_dict()
    if scheduler is not None and hasattr(scheduler, "state_dict"):
        payload["scheduler"] = scheduler.state_dict()
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def load_checkpoint(
    path: str | Path,
    model: nn.Module,
    *,
    optimizer: torch.optim.Optimizer | None = None,
    scheduler: Any | None = None,
    map_location: str | torch.device = "cpu",
    strict_model: bool = True,
    strict_masks: bool = False,
) -> Dict[str, Any]:
    checkpoint = torch.load(path, map_location=map_location, weights_only=False)
    if not isinstance(checkpoint, dict):
        checkpoint = {"model": checkpoint}
    state = checkpoint.get("model", checkpoint.get("state_dict", checkpoint))
    state = _strip_module_prefix(state)
    missing, unexpected = unwrap_model(model).load_state_dict(state, strict=False)
    # Gate buffers may be supplied separately by older checkpoints.
    non_gate_missing = [key for key in missing if not key.endswith("gate")]
    if strict_model and (non_gate_missing or unexpected):
        raise RuntimeError(f"Checkpoint model mismatch: missing={non_gate_missing}, unexpected={unexpected}")
    mask = checkpoint.get("mask_state", checkpoint.get("gate_state"))
    if mask is not None:
        load_mask_state_dict(model, mask, strict=strict_masks)
    if optimizer is not None and "optimizer" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer"])
    if scheduler is not None and "scheduler" in checkpoint and hasattr(scheduler, "load_state_dict"):
        scheduler.load_state_dict(checkpoint["scheduler"])
    return checkpoint
