"""Spectral-Steering saliency for structured pruning (FSP v4).

This module replaces the heuristic ``|(g_HP - lambda g_LP) w|`` score with a
formulation that separates two quantities that the earlier pipeline conflated:

* **Band sensitivity** ``S_b`` -- how strongly the loss reacts to perturbations
  in radial frequency band ``b``.  For an infinitesimal Fourier-basis
  perturbation ``eps * U_f`` the first-order loss change is ``eps * <dL/dx, U_f>``,
  i.e. the DFT coefficient of the input gradient.  Band sensitivity is therefore
  the input-gradient spectral power inside the band::

      S_b = (1/N) * sum_n sum_c sum_{f in b} |F[dL/dx_n](f)|^2

  This is exact (no noise sampling) and differentiable, so the first-order
  effect of removing structural unit ``g`` (gate ``g`` -> 0) on ``S_b`` is::

      delta S_b ~= -dS_b/dgate_g            (gate_g = 1 for an active unit)
      c_{g,b}   = (dS_b/dgate_g) / S_b       relative share of band-b sensitivity

  computed with double back-propagation.

* **Task reliance** ``r_b`` -- how much the task needs band ``b``: the loss
  increase (or accuracy drop) when band ``b`` is removed from the input by a
  band-stop filter.  A model can be *sensitive* to a band it does not *rely on*
  (classic high-frequency fragility), which is exactly what pruning should
  remove first.

The steering target ``w`` (zero-sum weights over bands) is derived from the
mismatch between the task reliance profile and the model sensitivity profile
(``target_profile=auto``), or set to ``high``/``low``/``flat``/manual weights.
The keep-importance of a unit is::

      score_g = I_0(g)/mean(I_0) + lambda * T_g/mean|T|,
      I_0(g)  = mean_batches |dL/dgate_g|            (gate-level Taylor-FO)
      T_g     = sum_b w_b * c_{g,b}

Units whose removal lowers sensitivity in over-sensitive bands (``w_b < 0``,
``c_{g,b} > 0``) receive a lower score and are pruned first; units that carry
sensitivity the task relies on (``w_b > 0``) are protected.

Two alternative estimators of ``c_{g,b}`` are provided for ablations:

* ``noise``    -- the original FSP proposal: Taylor importance change under
                  finite-amplitude Fourier-basis noise sampled inside each band.
* ``filtered`` -- Taylor importance on band-pass filtered inputs, a multi-band
                  generalisation of VTC-LFC's low-frequency sensitivity (LFS).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader

from frequency_pruning.distributed import coalesced_all_reduce_, synchronize_failures
from frequency_pruning.fourier import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    denormalize,
    normalize,
    radial_frequency_grid,
)
from frequency_pruning.models.common import StructuredPruningUnit
from frequency_pruning.utils import autocast_context, move_batch_to_device

DEFAULT_BAND_EDGES: tuple[float, ...] = (0.0, 0.125, 0.25, 0.5, 2.0)
BAND_NAMES_4 = ("low", "low_mid", "mid_high", "high")


# ---------------------------------------------------------------------------
# Band geometry and filtering
# ---------------------------------------------------------------------------
def normalize_band_edges(edges: Sequence[float] | None) -> list[float]:
    values = [float(v) for v in (edges if edges else DEFAULT_BAND_EDGES)]
    if len(values) < 3:
        raise ValueError("spectral.band_edges needs at least two bands (three edges)")
    if any(b <= a for a, b in zip(values[:-1], values[1:])):
        raise ValueError("spectral.band_edges must be strictly increasing")
    if values[0] != 0.0:
        raise ValueError("spectral.band_edges must start at 0.0")
    # The radial grid reaches sqrt(2) in the corners; make the last band cover it.
    values[-1] = max(values[-1], 1.5)
    return values


def band_names(edges: Sequence[float]) -> list[str]:
    count = len(edges) - 1
    if count == 4:
        return list(BAND_NAMES_4)
    return [f"band{i}_{edges[i]:g}-{edges[i + 1]:g}" for i in range(count)]


def band_masks(
    height: int,
    width: int,
    edges: Sequence[float],
    device: torch.device,
    dtype: torch.dtype = torch.float32,
) -> Tensor:
    """Return fftshift-aligned hard radial band masks with shape [B, H, W].

    Every frequency belongs to exactly one band, so the masks sum to one.
    """
    radius = radial_frequency_grid(height, width, device, dtype)
    masks = []
    for index in range(len(edges) - 1):
        lo, hi = float(edges[index]), float(edges[index + 1])
        if index == 0:
            mask = radius < hi
        elif index == len(edges) - 2:
            mask = radius >= lo
        else:
            mask = (radius >= lo) & (radius < hi)
        masks.append(mask.to(dtype))
    return torch.stack(masks, dim=0)


def band_area_fractions(masks: Tensor) -> list[float]:
    """Fraction of the frequency plane covered by each band (sums to one)."""
    total = float(masks.shape[-2] * masks.shape[-1])
    return [float(m.sum().item()) / total for m in masks]


def density_profile(values: Sequence[float], area: Sequence[float]) -> list[float]:
    """Convert an extensive band profile (sum over the band) into a per-frequency
    density profile (divide by the band's area fraction) and renormalise.

    The outer band covers ~80% of the plane, so extensive profiles are dominated
    by it even for a spectrally flat response; density profiles answer the
    complementary question "how sensitive / reliant is the model *per unit
    frequency*?".
    """
    dens = [max(0.0, float(v)) / max(float(a), 1e-12) for v, a in zip(values, area)]
    total = sum(dens)
    return [d / total for d in dens] if total > 0 else [1.0 / len(dens)] * len(dens)


def dc_mask(height: int, width: int, device: torch.device, dtype: torch.dtype = torch.float32) -> Tensor:
    mask = torch.zeros((height, width), device=device, dtype=dtype)
    mask[height // 2, width // 2] = 1.0
    return mask


def band_filter(
    x: Tensor,
    keep: Tensor,
    *,
    mean: Iterable[float] = IMAGENET_MEAN,
    std: Iterable[float] = IMAGENET_STD,
    input_is_normalized: bool = True,
    keep_dc: bool = True,
    clamp: bool = True,
) -> Tensor:
    """Apply a spectral keep-mask ([H, W], fftshift-aligned) to an image batch.

    The DC coefficient is always kept when ``keep_dc`` is set so that removing the
    lowest band removes coarse structure without destroying the image mean,
    which ImageNet classifiers were never trained on.
    """
    if x.ndim != 4:
        raise ValueError(f"Expected BCHW input, got {tuple(x.shape)}")
    original_dtype = x.dtype
    raw = denormalize(x.float(), mean, std) if input_is_normalized else x.float()
    h, w = raw.shape[-2:]
    keep = keep.to(device=raw.device, dtype=raw.dtype)
    if keep_dc:
        keep = torch.clamp(keep + dc_mask(h, w, raw.device, raw.dtype), max=1.0)
    spectrum = torch.fft.fftshift(torch.fft.fft2(raw, dim=(-2, -1), norm="ortho"), dim=(-2, -1))
    filtered = torch.fft.ifft2(
        torch.fft.ifftshift(spectrum * keep.view(1, 1, h, w), dim=(-2, -1)),
        dim=(-2, -1),
        norm="ortho",
    ).real
    if clamp:
        filtered = filtered.clamp(0.0, 1.0)
    if input_is_normalized:
        filtered = normalize(filtered, mean, std)
    return filtered.to(original_dtype)


def band_stop(x: Tensor, masks: Tensor, band: int, **kwargs: Any) -> Tensor:
    return band_filter(x, 1.0 - masks[band], **kwargs)


def band_pass(x: Tensor, masks: Tensor, band: int, **kwargs: Any) -> Tensor:
    return band_filter(x, masks[band], **kwargs)


def add_band_noise(
    x: Tensor,
    masks: Tensor,
    bands: Sequence[int],
    amplitude: float,
    generator: torch.Generator | None = None,
) -> Tensor:
    """Add white noise restricted to the given radial bands.

    ``amplitude`` is the per-pixel RMS of the added noise in [0, 1] image units
    (ImageNet-C Gaussian noise uses 0.08-0.38).  The noise has no DC component,
    so brightness is unchanged.  Input and output are normalised image batches.
    """
    raw = denormalize(x.detach().float())
    if generator is not None:
        noise = torch.randn(raw.shape, generator=generator, device=raw.device)
    else:
        noise = torch.randn(raw.shape, device=raw.device)
    h, w = raw.shape[-2:]
    keep = masks[[int(b) for b in bands]].sum(dim=0).clamp(0.0, 1.0) * (1.0 - dc_mask(h, w, raw.device))
    spectrum = torch.fft.fftshift(torch.fft.fft2(noise, norm="ortho"), dim=(-2, -1)) * keep
    shaped = torch.fft.ifft2(torch.fft.ifftshift(spectrum, dim=(-2, -1)), norm="ortho").real
    rms = shaped.pow(2).mean(dim=(1, 2, 3), keepdim=True).sqrt().clamp_min(1e-12)
    return normalize((raw + float(amplitude) * shaped / rms).clamp(0.0, 1.0)).to(x.dtype)


def random_band_augment(
    x: Tensor,
    edges: Sequence[float],
    probability: float,
    generator: torch.Generator | None = None,
    mode: str = "mixed",
    bands: Sequence[int] | None = None,
    noise_std: float = 0.1,
) -> Tensor:
    """Frequency data augmentation applied to training batches during recovery.

    With probability ``probability`` the batch is filtered:

    * ``mixed``    (default, the original ``taylor_fourier_aug`` ablation): one
      uniformly chosen band is either removed or kept alone;
    * ``stop_set`` : every band listed in ``bands`` is removed at once (DC kept),
      e.g. ``[2, 3]`` trains on images without fine detail and ``[0]`` on images
      without the coarsest structure;
    * ``stop_one`` : one band drawn from ``bands`` is removed;
    * ``noise``    : white noise restricted to ``bands`` is added, with a per-pixel
      RMS drawn uniformly from [0.5, 1.5] x ``noise_std``.

    The targeted modes are used to specialise a pruned network to one family of
    corruptions (local/high-frequency vs. global/low-frequency).
    """
    if probability <= 0.0:
        return x
    draw = torch.rand((), generator=generator).item() if generator is not None else torch.rand(()).item()
    if draw >= probability:
        return x
    masks = band_masks(x.shape[-2], x.shape[-1], edges, x.device)
    mode = str(mode).lower()
    num_bands = int(masks.shape[0])
    chosen = [int(b) for b in (bands or range(num_bands))]
    if any(b < 0 or b >= num_bands for b in chosen):
        raise ValueError(f"frequency_augment_bands must index the {num_bands} bands")
    if mode == "stop_set":
        remove = masks[chosen].sum(dim=0)
        keep = (1.0 - remove).clamp(0.0, 1.0)
        return band_filter(x, keep, keep_dc=True)
    if mode == "stop_one":
        band = chosen[int(torch.randint(0, len(chosen), (1,), generator=generator).item())]
        return band_stop(x, masks, band)
    if mode == "noise":
        scale = 0.5 + (torch.rand((), generator=generator).item() if generator is not None else torch.rand(()).item())
        return add_band_noise(x, masks, chosen, float(noise_std) * scale)
    if mode != "mixed":
        raise ValueError("train.frequency_augment_mode must be mixed, stop_set, stop_one or noise")
    band = int(torch.randint(0, num_bands, (1,), generator=generator).item())
    which = int(torch.randint(0, 2, (1,), generator=generator).item())
    return band_stop(x, masks, band) if which == 0 else band_pass(x, masks, band)


# ---------------------------------------------------------------------------
# Profiles and steering targets
# ---------------------------------------------------------------------------
@dataclass
class SpectralProfiles:
    band_edges: list[float]
    band_names: list[str]
    sensitivity: list[float]  # S_b (absolute)
    sensitivity_profile: list[float]  # S_b / sum S
    reliance_loss: list[float]  # loss increase when band b removed
    reliance_accuracy_drop: list[float]  # top-1 drop (points) when band b removed
    reliance_profile: list[float]  # normalised reliance
    clean_loss: float
    clean_top1: float
    samples: int
    extra: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "band_edges": list(self.band_edges),
            "band_names": list(self.band_names),
            "sensitivity": list(self.sensitivity),
            "sensitivity_profile": list(self.sensitivity_profile),
            "reliance_loss": list(self.reliance_loss),
            "reliance_accuracy_drop": list(self.reliance_accuracy_drop),
            "reliance_profile": list(self.reliance_profile),
            "clean_loss": float(self.clean_loss),
            "clean_top1": float(self.clean_top1),
            "samples": int(self.samples),
            "profile_mismatch_l1": profile_mismatch(self.reliance_profile, self.sensitivity_profile),
            "band_area": list(self.extra.get("band_area", [])),
            "sensitivity_density": (
                density_profile(self.sensitivity, self.extra["band_area"]) if self.extra.get("band_area") else []
            ),
            "reliance_density": (
                density_profile(self.reliance_loss, self.extra["band_area"]) if self.extra.get("band_area") else []
            ),
            **{k: v for k, v in self.extra.items() if k != "band_area"},
        }


def profile_mismatch(reliance: Sequence[float], sensitivity: Sequence[float]) -> float:
    return float(sum(abs(float(r) - float(s)) for r, s in zip(reliance, sensitivity)))


def _normalize_profile(values: Sequence[float]) -> list[float]:
    arr = [max(0.0, float(v)) for v in values]
    total = sum(arr)
    if total <= 0:
        return [1.0 / len(arr)] * len(arr)
    return [v / total for v in arr]


def steering_weights(
    mode: str,
    num_bands: int,
    *,
    reliance_profile: Sequence[float] | None = None,
    sensitivity_profile: Sequence[float] | None = None,
    manual: Sequence[float] | None = None,
) -> list[float]:
    """Zero-sum band weights w (positive: retain/enhance, negative: suppress).

    ``auto``/``mismatch``: w = r_hat - s_hat (steer the sensitivity profile toward
    the task reliance profile; vanishes when they already match).
    ``reliance``: w = r_hat - 1/B.
    ``high``/``low``: linear ramp (legacy steering directions).
    ``flat``: zeros (pure Taylor-FO).
    ``manual``: user supplied, re-centred to zero mean.
    """
    mode = str(mode).lower()
    if mode in {"auto", "mismatch"}:
        if reliance_profile is None or sensitivity_profile is None:
            raise ValueError("auto steering requires reliance and sensitivity profiles")
        w = [float(r) - float(s) for r, s in zip(reliance_profile, sensitivity_profile)]
    elif mode == "reliance":
        if reliance_profile is None:
            raise ValueError("reliance steering requires a reliance profile")
        w = [float(r) - 1.0 / num_bands for r in reliance_profile]
    elif mode == "high":
        w = [(-1.0 + 2.0 * i / max(1, num_bands - 1)) for i in range(num_bands)]
    elif mode == "low":
        w = [(1.0 - 2.0 * i / max(1, num_bands - 1)) for i in range(num_bands)]
    elif mode in {"flat", "none", "off"}:
        w = [0.0] * num_bands
    elif mode == "manual":
        if not manual or len(manual) != num_bands:
            raise ValueError("manual steering requires spectral.manual_weights with one value per band")
        w = [float(v) for v in manual]
    else:
        raise ValueError(f"Unsupported spectral.target_profile: {mode}")
    centre = sum(w) / len(w)
    w = [v - centre for v in w]
    scale = sum(abs(v) for v in w)
    if scale > 0:
        w = [v / scale for v in w]
    return w


# ---------------------------------------------------------------------------
# Core measurements
# ---------------------------------------------------------------------------
def _pixel_std(device: torch.device, dtype: torch.dtype) -> Tensor:
    return torch.as_tensor(IMAGENET_STD, dtype=dtype, device=device).view(1, -1, 1, 1)


def input_gradient_band_power(
    gx: Tensor,
    masks: Tensor,
    *,
    input_is_normalized: bool = True,
) -> Tensor:
    """Band power of the (pixel-space) input gradient summed over the batch -> [B]."""
    g = gx.float()
    if input_is_normalized:
        # x_norm = (x_pix - mean)/std  =>  dL/dx_pix = dL/dx_norm / std
        g = g / _pixel_std(g.device, g.dtype)
    spectrum = torch.fft.fftshift(torch.fft.fft2(g, dim=(-2, -1), norm="ortho"), dim=(-2, -1))
    power = spectrum.real.square() + spectrum.imag.square()  # [N, C, H, W]
    return torch.einsum("nchw,bhw->b", power, masks.to(power.dtype))


def _iter_microbatches(images: Tensor, target: Tensor, size: int):
    size = max(1, int(size))
    for start in range(0, int(target.shape[0]), size):
        stop = min(int(target.shape[0]), start + size)
        yield images[start:stop], target[start:stop]


@torch.no_grad()
def _topk1(logits: Tensor, target: Tensor) -> Tensor:
    return logits.argmax(dim=1).eq(target).sum()


def measure_reliance(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    edges: Sequence[float],
    *,
    max_batches: int,
    channels_last: bool,
    keep_dc: bool = True,
    distributed_reduce: bool = False,
) -> Dict[str, Any]:
    """Loss increase and accuracy drop when each band is removed (band-stop)."""
    model.eval()
    num_bands = len(edges) - 1
    # [0]=count, [1]=clean loss, [2]=clean correct, then per band: loss, correct
    totals = torch.zeros(3 + 2 * num_bands, dtype=torch.float64, device=device)
    local_error: BaseException | None = None
    local_trace = ""
    try:
        with torch.inference_mode():
            masks: Tensor | None = None
            for batch_index, batch in enumerate(loader):
                if max_batches > 0 and batch_index >= max_batches:
                    break
                images, target = batch[:2]
                images = move_batch_to_device(images, device, channels_last)
                target = target.to(device, non_blocking=True)
                if masks is None or masks.shape[-2:] != images.shape[-2:]:
                    masks = band_masks(images.shape[-2], images.shape[-1], edges, device)
                logits = model(images).float()
                totals[0] += target.numel()
                totals[1] += F.cross_entropy(logits, target, reduction="sum").double()
                totals[2] += _topk1(logits, target).double()
                for band in range(num_bands):
                    filtered = band_stop(images, masks, band, keep_dc=keep_dc)
                    logits_b = model(filtered).float()
                    totals[3 + 2 * band] += F.cross_entropy(logits_b, target, reduction="sum").double()
                    totals[4 + 2 * band] += _topk1(logits_b, target).double()
        if totals[0].item() <= 0:
            raise RuntimeError("Reliance measurement consumed zero samples")
    except BaseException as error:  # noqa: BLE001 - re-raised through the collective barrier
        import traceback

        local_error, local_trace = error, traceback.format_exc()
    synchronize_failures(local_error, phase="spectral_reliance", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(totals, op=torch.distributed.ReduceOp.SUM)
    n = float(totals[0].item())
    clean_loss = float(totals[1].item()) / n
    clean_top1 = 100.0 * float(totals[2].item()) / n
    loss_increase = [max(0.0, float(totals[3 + 2 * b].item()) / n - clean_loss) for b in range(num_bands)]
    acc_drop = [max(0.0, clean_top1 - 100.0 * float(totals[4 + 2 * b].item()) / n) for b in range(num_bands)]
    return {
        "samples": int(n),
        "clean_loss": clean_loss,
        "clean_top1": clean_top1,
        "reliance_loss": loss_increase,
        "reliance_accuracy_drop": acc_drop,
        "band_stop_loss": [float(totals[3 + 2 * b].item()) / n for b in range(num_bands)],
        "band_stop_top1": [100.0 * float(totals[4 + 2 * b].item()) / n for b in range(num_bands)],
    }


def measure_band_noise_accuracy(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    edges: Sequence[float],
    *,
    amplitude: float = 0.1,
    max_batches: int = 8,
    channels_last: bool = False,
) -> Dict[str, Any]:
    """Top-1 when white noise of a fixed RMS is added to one band at a time.

    A direct read-out of the robustness to perturbations of each band; used to
    judge specialisation per band instead of on an average.
    """
    model.eval()
    num_bands = len(edges) - 1
    correct = torch.zeros(num_bands + 1, dtype=torch.float64)
    count = 0
    generator = torch.Generator(device=device).manual_seed(20261125)
    with torch.inference_mode():
        masks: Tensor | None = None
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            if masks is None or masks.shape[-2:] != images.shape[-2:]:
                masks = band_masks(images.shape[-2], images.shape[-1], edges, device)
            count += int(target.numel())
            correct[0] += float(_topk1(model(images).float(), target).item())
            for band in range(num_bands):
                noisy = add_band_noise(images, masks, [band], amplitude, generator)
                correct[band + 1] += float(_topk1(model(noisy).float(), target).item())
    count = max(1, count)
    return {
        "amplitude": float(amplitude),
        "clean_top1": 100.0 * float(correct[0]) / count,
        "band_noise_top1": [100.0 * float(correct[b + 1]) / count for b in range(num_bands)],
        "samples": count,
    }


def measure_sensitivity(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    edges: Sequence[float],
    *,
    max_batches: int,
    channels_last: bool,
    microbatch_size: int = 32,
    distributed_reduce: bool = False,
) -> Dict[str, Any]:
    """Input-gradient band power S_b (exact first-order Fourier sensitivity)."""
    model.eval()
    num_bands = len(edges) - 1
    totals = torch.zeros(1 + num_bands, dtype=torch.float64, device=device)
    local_error: BaseException | None = None
    local_trace = ""
    requires = [(p, p.requires_grad) for p in model.parameters()]
    try:
        for p, _ in requires:
            p.requires_grad_(False)
        masks: Tensor | None = None
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            if masks is None or masks.shape[-2:] != images.shape[-2:]:
                masks = band_masks(images.shape[-2], images.shape[-1], edges, device)
            for chunk, chunk_target in _iter_microbatches(images, target, microbatch_size):
                with torch.autocast(device_type=device.type, enabled=False):
                    x = chunk.detach().float().requires_grad_(True)
                    loss = F.cross_entropy(model(x), chunk_target, reduction="sum")
                    (gx,) = torch.autograd.grad(loss, [x])
                totals[1:] += input_gradient_band_power(gx.detach(), masks).double()
                totals[0] += chunk_target.numel()
        if totals[0].item() <= 0:
            raise RuntimeError("Sensitivity measurement consumed zero samples")
    except BaseException as error:  # noqa: BLE001
        import traceback

        local_error, local_trace = error, traceback.format_exc()
    finally:
        for p, state in requires:
            p.requires_grad_(state)
    synchronize_failures(local_error, phase="spectral_sensitivity", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(totals, op=torch.distributed.ReduceOp.SUM)
    n = float(totals[0].item())
    sensitivity = [float(v) / n for v in totals[1:].tolist()]
    return {"samples": int(n), "sensitivity": sensitivity, "sensitivity_profile": _normalize_profile(sensitivity)}


def compute_spectral_profiles(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    *,
    edges: Sequence[float] | None = None,
    max_batches: int = 8,
    channels_last: bool = False,
    microbatch_size: int = 32,
    distributed_reduce: bool = False,
) -> SpectralProfiles:
    edges = normalize_band_edges(edges)
    reliance = measure_reliance(
        model, loader, device, edges, max_batches=max_batches, channels_last=channels_last,
        distributed_reduce=distributed_reduce,
    )
    first = next(iter(loader))[0]
    area = band_area_fractions(band_masks(int(first.shape[-2]), int(first.shape[-1]), edges, torch.device("cpu")))
    sensitivity = measure_sensitivity(
        model, loader, device, edges, max_batches=max_batches, channels_last=channels_last,
        microbatch_size=microbatch_size, distributed_reduce=distributed_reduce,
    )
    noise_eval: Dict[str, Any] | None = None
    if not distributed_reduce:
        try:
            noise_eval = measure_band_noise_accuracy(
                model, loader, device, edges, amplitude=0.1, max_batches=max_batches, channels_last=channels_last
            )
        except Exception:  # pragma: no cover - a diagnostic must not abort a run
            noise_eval = None
    return SpectralProfiles(
        band_edges=edges,
        band_names=band_names(edges),
        sensitivity=sensitivity["sensitivity"],
        sensitivity_profile=sensitivity["sensitivity_profile"],
        reliance_loss=reliance["reliance_loss"],
        reliance_accuracy_drop=reliance["reliance_accuracy_drop"],
        reliance_profile=_normalize_profile(reliance["reliance_loss"]),
        clean_loss=reliance["clean_loss"],
        clean_top1=reliance["clean_top1"],
        samples=reliance["samples"],
        extra={
            "band_area": area,
            **(
                {"band_noise_top1": noise_eval["band_noise_top1"], "band_noise_amplitude": noise_eval["amplitude"]}
                if noise_eval is not None else {}
            ),
            "band_stop_top1": reliance["band_stop_top1"],
            "band_stop_loss": reliance["band_stop_loss"],
            "reliance_profile_accuracy": _normalize_profile(reliance["reliance_accuracy_drop"]),
        },
    )


# ---------------------------------------------------------------------------
# Saliency estimators
# ---------------------------------------------------------------------------
@dataclass
class SpectralAccumulators:
    names: list[str]
    taylor: Dict[str, Tensor]  # I_0 sums per unit
    contribution: Dict[str, Tensor]  # [units, B] dS_b/dgate sums (or estimator analogue)
    band_power: Tensor  # [B]
    scalar: Tensor  # [count, loss, microbatches]
    band_area: list[float] = field(default_factory=list)  # area fraction of each band


def _new_accumulators(
    named_units: Sequence[tuple[str, StructuredPruningUnit]], num_bands: int, device: torch.device
) -> SpectralAccumulators:
    names = [name for name, _ in named_units]
    return SpectralAccumulators(
        names=names,
        taylor={name: torch.zeros(unit.num_units, dtype=torch.float32, device=device) for name, unit in named_units},
        contribution={
            name: torch.zeros(unit.num_units, num_bands, dtype=torch.float32, device=device)
            for name, unit in named_units
        },
        band_power=torch.zeros(num_bands, dtype=torch.float64, device=device),
        scalar=torch.zeros(3, dtype=torch.float64, device=device),
    )


def _taylor_term(gate_grad: Tensor, reduction: str) -> Tensor:
    value = gate_grad.detach().float()
    return value.square() if reduction == "square" else value.abs()


def _accumulate_exact(
    model: nn.Module,
    gates: Sequence[Tensor],
    acc: SpectralAccumulators,
    images: Tensor,
    target: Tensor,
    masks: Tensor,
    device: torch.device,
    *,
    taylor_reduction: str,
) -> None:
    """Exact estimator: double back-propagation through the input-gradient spectrum."""
    with torch.autocast(device_type=device.type, enabled=False):
        x = images.detach().float().requires_grad_(True)
        logits = model(x)
        loss = F.cross_entropy(logits, target, reduction="sum")
        grads = torch.autograd.grad(loss, [x, *gates], create_graph=True, allow_unused=True)
        gx, gate_grads = grads[0], grads[1:]
        for name, gate_grad in zip(acc.names, gate_grads):
            if gate_grad is not None:
                acc.taylor[name].add_(_taylor_term(gate_grad, taylor_reduction))
        band_power = input_gradient_band_power(gx, masks)  # differentiable [B]
        acc.band_power.add_(band_power.detach().double())
        num_bands = int(band_power.shape[0])
        for band in range(num_bands):
            d_band = torch.autograd.grad(
                band_power[band],
                gates,
                retain_graph=band + 1 < num_bands,
                allow_unused=True,
            )
            for name, value in zip(acc.names, d_band):
                if value is not None:
                    acc.contribution[name][:, band].add_(value.detach().float())
        acc.scalar[1] += loss.detach().double()
        del grads, gx, gate_grads, band_power, loss, logits, x


def _gate_taylor(
    model: nn.Module,
    gates: Sequence[Tensor],
    x: Tensor,
    target: Tensor,
    device: torch.device,
    amp_dtype: torch.dtype | None,
) -> tuple[list[Tensor | None], Tensor]:
    with autocast_context(device, amp_dtype):
        loss = F.cross_entropy(model(x), target, reduction="sum")
    grads = torch.autograd.grad(loss, gates, allow_unused=True)
    return list(grads), loss.detach().float()


def _accumulate_noise(
    model: nn.Module,
    gates: Sequence[Tensor],
    acc: SpectralAccumulators,
    images: Tensor,
    target: Tensor,
    masks: Tensor,
    edges: Sequence[float],
    device: torch.device,
    *,
    taylor_reduction: str,
    samples_per_band: int,
    amplitude: float,
    amp_dtype: torch.dtype | None,
    generator: torch.Generator,
) -> None:
    """Original FSP estimator: Taylor change under finite Fourier-basis noise per band."""
    clean_grads, loss = _gate_taylor(model, gates, images, target, device, amp_dtype)
    clean_terms = [None if g is None else _taylor_term(g, taylor_reduction) for g in clean_grads]
    for name, term in zip(acc.names, clean_terms):
        if term is not None:
            acc.taylor[name].add_(term)
    acc.scalar[1] += loss.double()
    # Band power of the input gradient is still recorded so that the ``auto``
    # steering target is defined identically for every estimator.
    with torch.autocast(device_type=device.type, enabled=False):
        x_grad = images.detach().float().requires_grad_(True)
        loss_g = F.cross_entropy(model(x_grad), target, reduction="sum")
        (gx,) = torch.autograd.grad(loss_g, [x_grad])
    acc.band_power.add_(input_gradient_band_power(gx.detach(), masks).double())
    del gx, loss_g, x_grad

    h, w = images.shape[-2:]
    num_bands = len(edges) - 1
    raw = denormalize(images.detach().float())
    # ``amplitude`` is the per-pixel RMS amplitude of the perturbation; a unit-norm
    # Fourier basis vector has per-pixel RMS 1/sqrt(HW).
    scale = float(amplitude) * math.sqrt(h * w)
    for band in range(num_bands):
        candidates = torch.nonzero(masks[band] > 0, as_tuple=False)
        if candidates.numel() == 0:
            continue
        for _ in range(max(1, samples_per_band)):
            pick = candidates[
                int(torch.randint(0, candidates.shape[0], (1,), generator=generator, device=device).item())
            ]
            basis = torch.zeros((h, w), dtype=torch.complex64, device=device)
            basis[pick[0], pick[1]] = 1.0
            wave = torch.fft.ifft2(torch.fft.ifftshift(basis), norm="ortho").real
            wave = wave / wave.norm().clamp_min(1e-12)
            sign = torch.where(
                torch.rand((images.shape[0], images.shape[1], 1, 1), generator=generator, device=device) < 0.5,
                torch.tensor(-1.0, device=device),
                torch.tensor(1.0, device=device),
            )
            perturbed = normalize((raw + scale * sign * wave.view(1, 1, h, w)).clamp(0.0, 1.0))
            noisy_grads, _ = _gate_taylor(model, gates, perturbed, target, device, amp_dtype)
            for name, clean_term, noisy in zip(acc.names, clean_terms, noisy_grads):
                if noisy is None or clean_term is None:
                    continue
                delta = _taylor_term(noisy, taylor_reduction) - clean_term
                acc.contribution[name][:, band].add_(delta / float(max(1, samples_per_band)))


def _accumulate_filtered(
    model: nn.Module,
    gates: Sequence[Tensor],
    acc: SpectralAccumulators,
    images: Tensor,
    target: Tensor,
    masks: Tensor,
    device: torch.device,
    *,
    taylor_reduction: str,
    amp_dtype: torch.dtype | None,
) -> None:
    """VTC-LFC-style estimator generalised to B bands: Taylor on band-pass inputs."""
    clean_grads, loss = _gate_taylor(model, gates, images, target, device, amp_dtype)
    for name, g in zip(acc.names, clean_grads):
        if g is not None:
            acc.taylor[name].add_(_taylor_term(g, taylor_reduction))
    acc.scalar[1] += loss.double()
    with torch.autocast(device_type=device.type, enabled=False):
        x_grad = images.detach().float().requires_grad_(True)
        loss_g = F.cross_entropy(model(x_grad), target, reduction="sum")
        (gx,) = torch.autograd.grad(loss_g, [x_grad])
    acc.band_power.add_(input_gradient_band_power(gx.detach(), masks).double())
    for band in range(int(masks.shape[0])):
        filtered = band_pass(images, masks, band)
        grads, _ = _gate_taylor(model, gates, filtered, target, device, amp_dtype)
        for name, g in zip(acc.names, grads):
            if g is not None:
                acc.contribution[name][:, band].add_(_taylor_term(g, taylor_reduction))


def _accumulate_reliance_derivative(
    model: nn.Module,
    gates: Sequence[Tensor],
    acc: SpectralAccumulators,
    images: Tensor,
    target: Tensor,
    masks: Tensor,
    device: torch.device,
    *,
    taylor_reduction: str,
    amp_dtype: torch.dtype | None,
    keep_dc: bool = True,
) -> None:
    """First-order attribution of band reliance to structural units (v5).

    Band reliance of the model is R_b = L(x_{-b}) - L(x): the loss increase when
    band b is removed from the input (band-stop).  Its derivative with respect to
    the gate of unit g,

        dR_b/dgate_g = dL(x_{-b})/dgate_g - dL(x)/dgate_g,

    is the first-order change of R_b when g is removed (up to sign).  A unit with
    large |dR_b/dgate_g| is one through which the model exploits band b; pruning
    it distorts the reliance profile.  ``acc.taylor`` accumulates |dL/dgate_g|
    (preserve the loss) and ``acc.contribution[:, b]`` accumulates |dR_b/dgate_g|
    (preserve the reliance on band b), both per micro-batch and in loss units, so
    they are directly comparable across layers and with each other.
    """
    clean_grads, loss = _gate_taylor(model, gates, images, target, device, amp_dtype)
    for name, g in zip(acc.names, clean_grads):
        if g is not None:
            acc.taylor[name].add_(_taylor_term(g, taylor_reduction))
    acc.scalar[1] += loss.double()
    for band in range(int(masks.shape[0])):
        stopped = band_stop(images, masks, band, keep_dc=keep_dc)
        grads, loss_b = _gate_taylor(model, gates, stopped, target, device, amp_dtype)
        acc.band_power[band] += (loss_b.double() - loss.double())  # sum of R_b over samples
        for name, g_clean, g_stop in zip(acc.names, clean_grads, grads):
            if g_stop is None or g_clean is None:
                continue
            acc.contribution[name][:, band].add_(_taylor_term(g_stop.detach().float() - g_clean.detach().float(), taylor_reduction))


def _accumulate_robust_gap(
    model: nn.Module,
    gates: Sequence[Tensor],
    acc: SpectralAccumulators,
    images: Tensor,
    target: Tensor,
    masks: Tensor,
    device: torch.device,
    *,
    taylor_reduction: str,
    amp_dtype: torch.dtype | None,
    amplitude: float,
    generator: torch.Generator,
) -> None:
    """First-order effect of removing a unit on the robustness to band noise.

    The robustness gap of band b is G_b = L(x + n_b) - L(x), where n_b is white
    noise restricted to band b.  ``acc.contribution[:, b]`` accumulates
    |dG_b/dgate_g| = |dL(x + n_b)/dgate_g - dL(x)/dgate_g|, the first-order change
    of that gap when unit g is removed; ``acc.taylor`` accumulates |dL/dgate_g|
    and ``acc.band_power[b]`` the gap itself.
    """
    clean_grads, loss = _gate_taylor(model, gates, images, target, device, amp_dtype)
    for name, g in zip(acc.names, clean_grads):
        if g is not None:
            acc.taylor[name].add_(_taylor_term(g, taylor_reduction))
    acc.scalar[1] += loss.double()
    for band in range(int(masks.shape[0])):
        noisy = add_band_noise(images, masks, [band], amplitude, generator)
        grads, loss_b = _gate_taylor(model, gates, noisy, target, device, amp_dtype)
        acc.band_power[band] += (loss_b.double() - loss.double())
        for name, g_clean, g_noisy in zip(acc.names, clean_grads, grads):
            if g_noisy is None or g_clean is None:
                continue
            acc.contribution[name][:, band].add_(_taylor_term(g_noisy.detach().float() - g_clean.detach().float(), taylor_reduction))


def _accumulate_output_difference(
    model: nn.Module,
    gates: Sequence[Tensor],
    acc: SpectralAccumulators,
    images: Tensor,
    target: Tensor,
    masks: Tensor,
    device: torch.device,
    *,
    taylor_reduction: str,
    keep_dc: bool = True,
) -> None:
    """Label-free attribution of *band signal flow* to structural units.

    For band b let O_b = || f(x) - sg[f(x_{-b})] ||^2 (logits, sg = stop-gradient):
    how much the output changes when band b is removed, i.e. how much band-b
    information reaches the output.  dO_b/dgate_g measures how much of that
    band-specific output component is produced through unit g.  Unlike loss gradients it does not vanish on a calibration
    set the model has memorised, and unlike gradients taken on band-stop inputs
    alone it does not describe the behaviour of a model that has lost its key
    band: it is the difference signal that matters.

    ``acc.taylor`` accumulates the clean gate-level Taylor term |dL/dgate_g| and
    ``acc.contribution[:, b]`` accumulates |dO_b/dgate_g|; ``acc.band_power[b]``
    accumulates O_b (the output-level effect of removing band b).
    """
    with torch.autocast(device_type=device.type, enabled=False):
        x = images.detach().float()
        logits = model(x).float()
        loss = F.cross_entropy(logits, target, reduction="sum")
        clean_grads = torch.autograd.grad(loss, gates, retain_graph=True, allow_unused=True)
        for name, g in zip(acc.names, clean_grads):
            if g is not None:
                acc.taylor[name].add_(_taylor_term(g, taylor_reduction))
        acc.scalar[1] += loss.detach().double()
        num_bands = int(masks.shape[0])
        for band in range(num_bands):
            stopped = band_stop(x, masks, band, keep_dc=keep_dc)
            # The band-stop output is a constant target: only the clean pathway is
            # differentiated, so the attribution is the clean-output Jacobian projected
            # on the direction that band b contributes, 2 (f(x) - f(x_{-b})) . df(x)/dgate.
            # (Differentiating through f(x_{-b}) as well attributes the behaviour of a
            # model that has lost its key band and was harmful in the controlled test.)
            with torch.no_grad():
                logits_b = model(stopped).float()
            effect = (logits - logits_b).square().sum()
            acc.band_power[band] += effect.detach().double()
            grads = torch.autograd.grad(effect, gates, retain_graph=band + 1 < num_bands, allow_unused=True)
            for name, g in zip(acc.names, grads):
                if g is not None:
                    acc.contribution[name][:, band].add_(_taylor_term(g, taylor_reduction))
            del logits_b, effect, grads
        del logits, loss


def accumulate_spectral_statistics(
    model: nn.Module,
    loader: DataLoader,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    device: torch.device,
    *,
    estimator: str,
    edges: Sequence[float],
    max_batches: int,
    microbatch_size: int,
    taylor_reduction: str,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    noise_samples_per_band: int,
    noise_amplitude: float,
    distributed_reduce: bool,
    bucket_mb: float,
    input_transform=None,
) -> SpectralAccumulators:
    estimator = str(estimator).lower()
    if estimator not in {"exact", "noise", "filtered", "taylor_only", "stop", "outdiff", "robust_noise"}:
        raise ValueError(f"Unsupported spectral.estimator: {estimator}")
    num_bands = len(edges) - 1
    gates = [unit.gate for _, unit in named_units]
    acc = _new_accumulators(named_units, num_bands, device)
    generator = torch.Generator(device=device).manual_seed(20261031)
    local_error: BaseException | None = None
    local_trace = ""
    try:
        masks: Tensor | None = None
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            if input_transform is not None:
                images = input_transform(images)
            if masks is None or masks.shape[-2:] != images.shape[-2:]:
                masks = band_masks(images.shape[-2], images.shape[-1], edges, device)
                acc.band_area = band_area_fractions(masks)
            for chunk, chunk_target in _iter_microbatches(images, target, microbatch_size):
                if estimator == "exact":
                    _accumulate_exact(
                        model, gates, acc, chunk, chunk_target, masks, device, taylor_reduction=taylor_reduction
                    )
                elif estimator == "noise":
                    _accumulate_noise(
                        model, gates, acc, chunk, chunk_target, masks, edges, device,
                        taylor_reduction=taylor_reduction, samples_per_band=noise_samples_per_band,
                        amplitude=noise_amplitude, amp_dtype=amp_dtype, generator=generator,
                    )
                elif estimator == "filtered":
                    _accumulate_filtered(
                        model, gates, acc, chunk, chunk_target, masks, device,
                        taylor_reduction=taylor_reduction, amp_dtype=amp_dtype,
                    )
                elif estimator == "robust_noise":
                    _accumulate_robust_gap(
                        model, gates, acc, chunk, chunk_target, masks, device,
                        taylor_reduction=taylor_reduction, amp_dtype=amp_dtype,
                        amplitude=noise_amplitude, generator=generator,
                    )
                elif estimator == "outdiff":
                    _accumulate_output_difference(
                        model, gates, acc, chunk, chunk_target, masks, device, taylor_reduction=taylor_reduction,
                    )
                elif estimator == "stop":
                    _accumulate_reliance_derivative(
                        model, gates, acc, chunk, chunk_target, masks, device,
                        taylor_reduction=taylor_reduction, amp_dtype=amp_dtype,
                    )
                else:  # taylor_only
                    grads, loss = _gate_taylor(model, gates, chunk, chunk_target, device, amp_dtype)
                    for name, g in zip(acc.names, grads):
                        if g is not None:
                            acc.taylor[name].add_(_taylor_term(g, taylor_reduction))
                    acc.scalar[1] += loss.double()
                acc.scalar[0] += chunk_target.numel()
                acc.scalar[2] += 1
        if acc.scalar[0].item() <= 0:
            raise RuntimeError("Spectral saliency consumed zero calibration samples")
    except BaseException as error:  # noqa: BLE001
        import traceback

        local_error, local_trace = error, traceback.format_exc()
        if isinstance(error, torch.OutOfMemoryError) and device.type == "cuda":
            torch.cuda.empty_cache()
    synchronize_failures(local_error, phase=f"spectral_saliency_local/{estimator}", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(acc.scalar, op=torch.distributed.ReduceOp.SUM)
        torch.distributed.all_reduce(acc.band_power, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(acc.taylor.values(), enabled=True, bucket_mb=bucket_mb)
        coalesced_all_reduce_(acc.contribution.values(), enabled=True, bucket_mb=bucket_mb)
    return acc


def combine_spectral_scores(
    acc: SpectralAccumulators,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    *,
    weights: Sequence[float],
    lam: float,
    signed: bool,
    estimator: str,
) -> tuple[Dict[str, Tensor], Dict[str, Any]]:
    """Combine Taylor importance and band contributions into keep-scores."""
    microbatches = max(1.0, float(acc.scalar[2].item()))
    samples = max(1.0, float(acc.scalar[0].item()))
    band_power = acc.band_power / samples  # S_b per sample
    w = torch.as_tensor(list(weights), dtype=torch.float32, device=band_power.device)

    taylor_all = torch.cat([acc.taylor[name] for name in acc.names]) / microbatches
    taylor_scale = taylor_all.abs().mean().clamp_min(1e-12)

    contributions: Dict[str, Tensor] = {}
    for name in acc.names:
        c = acc.contribution[name] / samples  # [units, B]
        if estimator == "exact":
            # relative share of band sensitivity: (dS_b/dgate)/S_b
            c = c / band_power.float().clamp_min(1e-12).view(1, -1)
        else:
            # estimators without a differentiable S_b: normalise each band's
            # contribution by its mean absolute value over all units.
            pass
        contributions[name] = c
    if estimator != "exact":
        stacked = torch.cat(list(contributions.values()), dim=0)
        band_scale = stacked.abs().mean(dim=0).clamp_min(1e-12)
        contributions = {name: c / band_scale.view(1, -1) for name, c in contributions.items()}

    steering: Dict[str, Tensor] = {}
    for name in acc.names:
        c = contributions[name]
        if not signed:
            c = c.abs()
        steering[name] = (c * w.view(1, -1)).sum(dim=1)
    steering_all = torch.cat([steering[name] for name in acc.names])
    steering_scale = steering_all.abs().mean().clamp_min(1e-12)

    raw: Dict[str, Tensor] = {}
    for name, unit in named_units:
        taylor_norm = (acc.taylor[name] / microbatches) / taylor_scale
        steer_norm = steering[name] / steering_scale if float(lam) != 0.0 and w.abs().sum() > 0 else torch.zeros_like(taylor_norm)
        raw[name] = (taylor_norm + float(lam) * steer_norm).detach().cpu()

    # First-order prediction of the sensitivity-profile change if every unit
    # were removed with equal probability: used as a sanity diagnostic only.
    total_share = torch.stack([contributions[name].sum(dim=0) for name in acc.names]).sum(dim=0)
    diagnostics = {
        "band_power": [float(v) for v in band_power.tolist()],
        "band_power_profile": _normalize_profile([float(v) for v in band_power.tolist()]),
        "steering_weights": [float(v) for v in w.tolist()],
        "lambda": float(lam),
        "signed": bool(signed),
        "estimator": estimator,
        "taylor_scale": float(taylor_scale),
        "steering_scale": float(steering_scale),
        "total_band_share": [float(v) for v in total_share.tolist()],
        "calibration_samples": int(samples),
        "calibration_microbatches": int(microbatches),
        "clean_loss": float(acc.scalar[1].item() / samples),
    }
    return raw, diagnostics


def reliance_weights(
    mode: str,
    num_bands: int,
    *,
    task_reliance: Sequence[float] | None = None,
    source_reliance: Sequence[float] | None = None,
    manual: Sequence[float] | None = None,
) -> list[float]:
    """Band weights rho for Spectral Reliance Pruning (v5).

    ``task``    : the task's measured reliance profile r_hat (default).
    ``uniform`` : 1/B for every band (ablation: is task-specific weighting needed?).
    ``source``  : the pre-training task's reliance profile (ablation: task-agnostic prior).
    ``shift``   : r_task - r_source, L1-normalised and zero-sum. Protects bands the
                  downstream task relies on *more* than the source task did; vanishes
                  on the source task itself.
    ``low``     : all weight on the lowest band (VTC-LFC's low-frequency prior).
    ``manual``  : user supplied.
    Non-negative modes are normalised to sum to one.
    """
    mode = str(mode).lower()
    if mode == "task":
        if task_reliance is None:
            raise ValueError("task reliance weights require a measured reliance profile")
        w = [max(0.0, float(v)) for v in task_reliance]
    elif mode == "uniform":
        w = [1.0] * num_bands
    elif mode == "source":
        if not source_reliance or len(source_reliance) != num_bands:
            raise ValueError("source reliance weights require spectral.source_reliance with one value per band")
        w = [max(0.0, float(v)) for v in source_reliance]
    elif mode == "shift":
        if task_reliance is None or not source_reliance or len(source_reliance) != num_bands:
            raise ValueError("shift weights require task reliance and spectral.source_reliance")
        t = _normalize_profile(task_reliance)
        src = _normalize_profile(source_reliance)
        w = [a - b for a, b in zip(t, src)]
        scale = sum(abs(v) for v in w)
        return [v / scale for v in w] if scale > 1e-9 else [0.0] * num_bands
    elif mode == "low":
        w = [1.0] + [0.0] * (num_bands - 1)
    elif mode == "manual":
        if not manual or len(manual) != num_bands:
            raise ValueError("manual reliance weights require spectral.manual_weights with one value per band")
        return [float(v) for v in manual]
    else:
        raise ValueError(f"Unsupported spectral.reliance_weights: {mode}")
    total = sum(w)
    return [v / total for v in w] if total > 0 else [1.0 / num_bands] * num_bands


def combine_reliance_scores(
    acc: SpectralAccumulators,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    *,
    weights: Sequence[float],
    lam: float,
    scale: str = "raw",
    clean_weight: float = 1.0,
) -> tuple[Dict[str, Tensor], Dict[str, Any]]:
    """Spectral Reliance Pruning keep-scores.

    ``scale="raw"`` (default, with the ``stop`` estimator): everything stays in
    loss units,

        score_g = E|dL/dgate_g| + lambda * sum_b rho_b * E|dR_b/dgate_g|,   sum_b rho_b = 1,

    i.e. the first-order cost of removing g in terms of the loss *and* of the
    (band-averaged) distortion of the reliance profile, so lambda = 1 weighs
    one unit of loss change equally with one unit of mean reliance change.
    lambda = 0 is global gate-level Taylor-FO.

    ``scale="share"``: every term is first converted into a global share (sums
    to one over all units), ``score_g = N (I0_g/sum I0 + lambda sum_b rho_b
    I_b(g)/sum_g I_b)``; used with the band-pass estimator, where the band
    terms are not in the same units as the clean term.
    """
    scale = str(scale).lower()
    if scale not in {"raw", "share"}:
        raise ValueError("spectral.reliance_scale must be raw or share")
    w = torch.as_tensor(list(weights), dtype=torch.float32)
    num_bands = len(weights)
    microbatches = max(1.0, float(acc.scalar[2].item()))
    samples = max(1.0, float(acc.scalar[0].item()))
    num_units = sum(int(acc.taylor[name].numel()) for name in acc.names)
    clean_total = float(sum(float(acc.taylor[name].sum().item()) for name in acc.names))
    band_totals = torch.zeros(num_bands, dtype=torch.float64)
    for name in acc.names:
        band_totals += acc.contribution[name].double().sum(dim=0).cpu()
    raw: Dict[str, Tensor] = {}
    clean_by_group: Dict[str, float] = {}
    carried_by_group: Dict[str, float] = {}
    band_by_group: Dict[str, list[float]] = {}
    for name, _unit in named_units:
        clean = acc.taylor[name].detach().float().cpu()
        band = acc.contribution[name].detach().float().cpu()
        if scale == "share":
            clean_term = float(num_units) * clean / max(clean_total, 1e-30)
            band_term = float(num_units) * band / band_totals.float().clamp_min(1e-30).view(1, -1)
            rho = w
        else:
            clean_term = clean / microbatches
            band_term = band / microbatches
            rho = w  # weights sum to one: the band term is a weighted mean over bands
        carried = (band_term * rho.view(1, -1)).sum(dim=1)
        raw[name] = float(clean_weight) * clean_term + float(lam) * carried
        clean_by_group[name] = float(clean.sum().item()) / max(clean_total, 1e-30)
        carried_by_group[name] = float((band * w.view(1, -1)).sum().item())
        band_by_group[name] = [float(v) for v in (band.sum(dim=0) / band_totals.float().clamp_min(1e-30)).tolist()]
    total_carried = sum(carried_by_group.values())
    if total_carried != 0:
        carried_by_group = {k: v / total_carried for k, v in carried_by_group.items()}
    diagnostics = {
        "reliance_weights": [float(v) for v in w.tolist()],
        "lambda": float(lam),
        "reliance_scale": scale,
        "clean_weight": float(clean_weight),
        "clean_share_by_group": clean_by_group,
        "carried_share_by_group": carried_by_group,
        "band_share_by_group": band_by_group,
        "band_totals": [float(v) / microbatches for v in band_totals.tolist()],
        "clean_total": clean_total / microbatches,
        "calibration_samples": int(samples),
        "calibration_microbatches": int(microbatches),
        "clean_loss": float(acc.scalar[1].item() / samples),
        "formula": (
            "E|dL/dg| + lambda * sum_b rho_b E|dR_b/dg|" if scale == "raw"
            else "N * (I0_g/sum I0 + lambda * sum_b rho_b * I_b(g)/sum_g I_b)"
        ),
    }
    return raw, diagnostics


def unit_contribution_table(acc: SpectralAccumulators) -> Dict[str, Tensor]:
    samples = max(1.0, float(acc.scalar[0].item()))
    return {name: (acc.contribution[name] / samples).detach().cpu() for name in acc.names}


def spectral_config(pruning_cfg: Mapping[str, Any]) -> Dict[str, Any]:
    """Resolve pruning.spectral.* with defaults and legacy fallbacks."""
    spectral = dict(pruning_cfg.get("spectral", {}) or {})
    out: Dict[str, Any] = {
        "estimator": str(spectral.get("estimator", "exact")).lower(),
        "band_edges": normalize_band_edges(spectral.get("band_edges")),
        "target_profile": str(spectral.get("target_profile", "auto")).lower(),
        "manual_weights": list(spectral.get("manual_weights", []) or []),
        "lambda": float(spectral.get("lambda", pruning_cfg.get("lambda", 1.0))),
        "signed": bool(spectral.get("signed", True)),
        "microbatch_size": int(spectral.get("microbatch_size", 16)),
        "taylor_reduction": str(spectral.get("taylor_reduction", "abs")).lower(),
        "reliance_batches": int(spectral.get("reliance_batches", 8)),
        "noise_samples_per_band": int(spectral.get("noise_samples_per_band", 4)),
        "noise_amplitude": float(spectral.get("noise_amplitude", 0.1)),
        "keep_dc": bool(spectral.get("keep_dc", True)),
        "reliance_source": str(spectral.get("reliance_source", "dense")).lower(),
        "profile_normalization": str(spectral.get("profile_normalization", "extensive")).lower(),
        # --- Spectral Reliance Pruning (v5) ---
        "reliance_weights": str(spectral.get("reliance_weights", "uniform")).lower(),
        "reliance_estimator": str(spectral.get("reliance_estimator", "stop")).lower(),
        "reliance_scale": str(spectral.get("reliance_scale", "")).lower(),
        "source_reliance": list(spectral.get("source_reliance", []) or []),
        "layer_normalization": str(spectral.get("layer_normalization", "none")).lower(),
    }
    if out["reliance_weights"] not in {"task", "uniform", "source", "shift", "low", "manual"}:
        raise ValueError("spectral.reliance_weights must be task/uniform/source/shift/low/manual")
    if out["reliance_estimator"] not in {"stop", "pass", "outdiff"}:
        raise ValueError("spectral.reliance_estimator must be stop, pass or outdiff")
    if not out["reliance_scale"]:
        out["reliance_scale"] = "raw" if out["reliance_estimator"] == "stop" else "share"
    out["clean_weight"] = float(spectral.get("clean_weight", 1.0))
    if out["reliance_scale"] not in {"raw", "share"}:
        raise ValueError("spectral.reliance_scale must be raw or share")
    if out["profile_normalization"] not in {"extensive", "density"}:
        raise ValueError("spectral.profile_normalization must be extensive or density")
    if out["taylor_reduction"] not in {"abs", "square"}:
        raise ValueError("spectral.taylor_reduction must be abs or square")
    if out["estimator"] not in {"exact", "noise", "filtered"}:
        raise ValueError("spectral.estimator must be exact, noise or filtered")
    if out["reliance_source"] not in {"dense", "current"}:
        raise ValueError("spectral.reliance_source must be dense or current")
    legacy_direction = str(pruning_cfg.get("steering", "")).lower()
    if out["target_profile"] == "legacy":
        out["target_profile"] = "high" if legacy_direction != "low" else "low"
    return out
