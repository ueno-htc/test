from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import torch
import torch.nn as nn

from frequency_pruning.models import iter_prunable_units
from frequency_pruning.models.common import StructuredPruningUnit
from .saliency import SaliencyResult


@dataclass
class PrunedUnitRecord:
    round: int
    group: str
    kind: str
    index: int
    score: float
    raw_score: float
    active_before: int
    active_after: int


def current_sparsity(model: nn.Module) -> float:
    units = iter_prunable_units(model)
    total = sum(unit.num_units for unit in units)
    active = sum(unit.active_count() for unit in units)
    return 0.0 if total == 0 else 1.0 - active / total


def total_unit_count(model: nn.Module) -> int:
    return sum(unit.num_units for unit in iter_prunable_units(model))


def active_unit_count(model: nn.Module) -> int:
    return sum(unit.active_count() for unit in iter_prunable_units(model))


def target_schedule(config: Mapping[str, Any]) -> list[float]:
    pruning = config["pruning"]
    explicit = pruning.get("sparsity_schedule", [])
    target = float(pruning["target_sparsity"])
    if explicit:
        values = sorted({float(value) for value in explicit if 0 < float(value) <= target})
        if not values or values[-1] < target:
            values.append(target)
        return values
    rounds = max(1, int(pruning.get("num_rounds", 1)))
    # Equal multiplicative retention steps are gentler near high sparsity than
    # equal additive sparsity steps.
    final_keep = 1.0 - target
    return [1.0 - final_keep ** ((index + 1) / rounds) for index in range(rounds)]


def prune_count_for_target(model: nn.Module, target_sparsity: float) -> int:
    total = total_unit_count(model)
    active = active_unit_count(model)
    target_active = max(1, int(round(total * (1.0 - float(target_sparsity)))))
    return max(0, active - target_active)


def select_pruning_plan(
    model: nn.Module,
    result: SaliencyResult,
    count: int,
    config: Mapping[str, Any],
) -> List[Dict[str, Any]]:
    """Select a deterministic structured pruning plan without mutating the model."""

    if count <= 0:
        return []
    named_units: list[tuple[str, StructuredPruningUnit]] = iter_prunable_units(model, named=True)
    min_units_global = int(config["pruning"].get("min_units", 1))
    min_fraction = float(config["pruning"].get("min_unit_fraction", 0.0))
    quotas = {
        str(key): float(value)
        for key, value in dict(config["pruning"].get("kind_quotas", {})).items()
    }

    candidates: list[tuple[float, str, int, StructuredPruningUnit, float]] = []
    capacity_by_group: Dict[str, int] = {}
    for name, unit in named_units:
        minimum = max(
            unit.min_units_default,
            min_units_global,
            int(math.ceil(unit.num_units * min_fraction)),
        )
        capacity = max(0, unit.active_count() - minimum)
        capacity_by_group[name] = capacity
        if capacity == 0:
            continue
        normalized = result.scores[name]
        raw = result.raw_scores[name]
        for index in unit.active_indices().cpu().tolist():
            score = float(normalized[index])
            if math.isfinite(score):
                candidates.append((score, name, int(index), unit, float(raw[index])))
    candidates.sort(key=lambda item: (item[0], item[1], item[2]))

    requested = min(int(count), sum(capacity_by_group.values()))
    if requested <= 0:
        return []
    selected_by_group: Dict[str, int] = {}
    selected_by_kind: Dict[str, int] = {}
    selected: list[tuple[float, str, int, StructuredPruningUnit, float]] = []
    for candidate in candidates:
        score, name, index, unit, raw_score = candidate
        if selected_by_group.get(name, 0) >= capacity_by_group[name]:
            continue
        kind = unit.unit_kind
        quota = quotas.get(kind)
        if quota is not None:
            kind_limit = max(0, int(round(requested * quota)))
            if selected_by_kind.get(kind, 0) >= kind_limit:
                continue
        selected.append(candidate)
        selected_by_group[name] = selected_by_group.get(name, 0) + 1
        selected_by_kind[kind] = selected_by_kind.get(kind, 0) + 1
        if len(selected) >= requested:
            break

    # Quotas are soft: fill any remaining slots globally while respecting each
    # structural group's minimum width.
    if len(selected) < requested:
        selected_keys = {(name, index) for _, name, index, _, _ in selected}
        for candidate in candidates:
            _, name, index, unit, _ = candidate
            if (name, index) in selected_keys:
                continue
            if selected_by_group.get(name, 0) >= capacity_by_group[name]:
                continue
            selected.append(candidate)
            selected_by_group[name] = selected_by_group.get(name, 0) + 1
            selected_keys.add((name, index))
            if len(selected) >= requested:
                break

    plan = [
        {
            "group": name,
            "kind": unit.unit_kind,
            "index": int(index),
            "score": float(score),
            "raw_score": float(raw_score),
        }
        for score, name, index, unit, raw_score in selected
    ]
    plan.sort(key=lambda row: (row["score"], row["group"], row["index"]))
    return plan


def apply_pruning_plan(
    model: nn.Module,
    plan: Sequence[Mapping[str, Any]],
    *,
    round_index: int = 0,
) -> List[Dict[str, Any]]:
    """Apply a validated plan and return the historical pruning-step schema."""

    if not plan:
        return []
    unit_lookup = dict(iter_prunable_units(model, named=True))
    grouped_indices: Dict[str, List[int]] = {}
    metadata: Dict[tuple[str, int], Mapping[str, Any]] = {}
    for row in plan:
        name = str(row["group"])
        index = int(row["index"])
        if name not in unit_lookup:
            raise KeyError(f"Pruning plan references unknown structured group {name!r}")
        unit = unit_lookup[name]
        if index < 0 or index >= unit.num_units:
            raise IndexError(f"Pruning plan index out of range: {name}[{index}]")
        if not bool(unit.active_mask()[index].item()):
            raise ValueError(f"Pruning plan attempts to prune inactive unit: {name}[{index}]")
        key = (name, index)
        if key in metadata:
            raise ValueError(f"Duplicate pruning plan entry: {name}[{index}]")
        metadata[key] = row
        grouped_indices.setdefault(name, []).append(index)

    records: List[Dict[str, Any]] = []
    for name in sorted(grouped_indices):
        indices = sorted(grouped_indices[name])
        unit = unit_lookup[name]
        before = unit.active_count()
        unit.prune(indices)
        after = unit.active_count()
        for index in indices:
            row = metadata[(name, index)]
            records.append(
                asdict(
                    PrunedUnitRecord(
                        round=int(round_index),
                        group=name,
                        kind=str(row.get("kind", unit.unit_kind)),
                        index=index,
                        score=float(row["score"]),
                        raw_score=float(row["raw_score"]),
                        active_before=before,
                        active_after=after,
                    )
                )
            )
    records.sort(key=lambda row: (row["score"], row["group"], row["index"]))
    return records


def prune_lowest_scoring_units(
    model: nn.Module,
    result: SaliencyResult,
    count: int,
    config: Mapping[str, Any],
    round_index: int = 0,
) -> List[Dict[str, Any]]:
    """Backward-compatible select-and-apply helper for single-process callers."""

    plan = select_pruning_plan(model, result, count, config)
    return apply_pruning_plan(model, plan, round_index=round_index)


def mask_state_dict(model: nn.Module) -> Dict[str, torch.Tensor]:
    return {name: unit.gate.detach().cpu().clone() for name, unit in iter_prunable_units(model, named=True)}


def load_mask_state_dict(model: nn.Module, state: Mapping[str, torch.Tensor], strict: bool = True) -> None:
    units = dict(iter_prunable_units(model, named=True))
    missing = []
    for name, unit in units.items():
        if name not in state:
            missing.append(name)
            continue
        value = state[name]
        if value.numel() != unit.num_units:
            raise ValueError(f"Mask shape mismatch for {name}: {value.numel()} vs {unit.num_units}")
        unit.gate.copy_(value.to(device=unit.gate.device, dtype=unit.gate.dtype))
    unexpected = sorted(set(state) - set(units))
    if strict and (missing or unexpected):
        raise KeyError(f"Mask state mismatch; missing={missing}, unexpected={unexpected}")


# ---------------------------------------------------------------------------
# Hardware-aware plan post-processing and MAC-budget selection (v4.1)
# ---------------------------------------------------------------------------
ALIGNABLE_KINDS = {"channel", "hidden_channel", "mbconv_channel", "expanded_channel", "mlp_hidden", "mlp"}


def align_plan_to_multiple(
    model: nn.Module,
    result: SaliencyResult,
    plan: List[Dict[str, Any]],
    alignment: int,
    config: Mapping[str, Any],
) -> List[Dict[str, Any]]:
    """Adjust a plan so that every channel-like group keeps a multiple of ``alignment`` units.

    GPU convolution kernels run at full efficiency only when channel counts are
    multiples of 8 (tensor cores) or 32; irregular widths produced by global
    pruning can be *slower* than the dense network despite fewer MACs. The
    kept count is rounded down (pruning a few more lowest-scoring units) when
    the group minimum allows it, otherwise up (pruning fewer).
    Attention heads and other non-channel units are left untouched.
    """
    alignment = int(alignment)
    if alignment <= 1 or not plan:
        return plan
    named_units = dict(iter_prunable_units(model, named=True))
    min_units_global = int(config["pruning"].get("min_units", 1))
    min_fraction = float(config["pruning"].get("min_unit_fraction", 0.0))
    by_group: Dict[str, List[Dict[str, Any]]] = {}
    for row in plan:
        by_group.setdefault(str(row["group"]), []).append(dict(row))
    aligned: List[Dict[str, Any]] = []
    for name, unit in named_units.items():
        rows = by_group.get(name, [])
        kind = str(unit.unit_kind)
        if not any(token in kind for token in ALIGNABLE_KINDS) or "head" in kind:
            aligned.extend(rows)
            continue
        active = unit.active_count()
        minimum = max(unit.min_units_default, min_units_global, int(math.ceil(unit.num_units * min_fraction)))
        kept = active - len(rows)
        if kept % alignment == 0:
            aligned.extend(rows)
            continue
        down = (kept // alignment) * alignment
        up = down + alignment
        target_kept = down if down >= max(minimum, alignment) else min(up, active)
        if target_kept < kept:
            # prune additional lowest-scoring active units of this group
            chosen = {int(r["index"]) for r in rows}
            scores = result.scores[name]
            raw = result.raw_scores[name]
            order = sorted(
                (int(i) for i in unit.active_indices().cpu().tolist() if int(i) not in chosen),
                key=lambda i: (float(scores[i]), i),
            )
            for index in order[: kept - target_kept]:
                rows.append(
                    {"group": name, "kind": unit.unit_kind, "index": index,
                     "score": float(scores[index]), "raw_score": float(raw[index]), "alignment_fill": True}
                )
        elif target_kept > kept:
            # keep back the highest-scoring units that were going to be pruned
            rows.sort(key=lambda r: (float(r["score"]), int(r["index"])))
            rows = rows[: max(0, len(rows) - (target_kept - kept))]
        aligned.extend(rows)
    aligned.sort(key=lambda row: (row["score"], row["group"], row["index"]))
    return aligned


def _snapshot_gates(model: nn.Module) -> Dict[str, torch.Tensor]:
    return {name: unit.gate.detach().clone() for name, unit in iter_prunable_units(model, named=True)}


def _restore_gates(model: nn.Module, snapshot: Mapping[str, torch.Tensor]) -> None:
    for name, unit in iter_prunable_units(model, named=True):
        unit.gate.copy_(snapshot[name])


def macs_for_plan(model: nn.Module, plan: Sequence[Mapping[str, Any]], input_shape: Sequence[int]) -> int:
    """MACs of the physically exported network after applying ``plan`` (model left unchanged)."""
    from frequency_pruning.models import export_slim_model
    from frequency_pruning.utils import profile_macs

    snapshot = _snapshot_gates(model)
    try:
        if plan:
            apply_pruning_plan(model, plan, round_index=-1)
        slim = export_slim_model(model)
        device = next(model.parameters()).device
        slim = slim.to(device).eval()
        with torch.no_grad():
            macs = int(profile_macs(slim, tuple(input_shape), device))
        del slim
    finally:
        _restore_gates(model, snapshot)
    return macs


def select_pruning_plan_for_mac_target(
    model: nn.Module,
    result: SaliencyResult,
    target_mac_reduction: float,
    config: Mapping[str, Any],
    *,
    dense_macs: int,
    input_shape: Sequence[int],
    alignment: int = 1,
    tolerance: float = 0.002,
    max_iterations: int = 14,
) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Select the smallest prefix of the global ranking whose physical MAC
    reduction reaches ``target_mac_reduction``.

    Unit-count sparsity is not comparable across criteria: Taylor-type scores
    concentrate pruning in high-resolution layers (many MACs per channel) while
    magnitude prunes almost uniformly, so equal unit sparsity gives unequal
    compute. Every method therefore receives the same MAC budget. The search is
    a bisection over the prefix length of the greedy ranking (which is prefix
    consistent), evaluating the exported slim network each time.
    """
    total_capacity = sum(unit.active_count() for unit in iter_prunable_units(model))
    target = float(target_mac_reduction)

    def reduction_for(count: int) -> tuple[float, List[Dict[str, Any]]]:
        plan = select_pruning_plan(model, result, count, config)
        plan = align_plan_to_multiple(model, result, plan, alignment, config)
        macs = macs_for_plan(model, plan, input_shape)
        return 1.0 - macs / max(1, dense_macs), plan

    lo, hi = 0, total_capacity
    best_plan: List[Dict[str, Any]] = []
    best_red = 0.0
    evaluations: list[tuple[int, float]] = []
    red_hi, plan_hi = reduction_for(hi)
    evaluations.append((hi, red_hi))
    if red_hi < target:
        return plan_hi, {"achieved_mac_reduction": red_hi, "target_mac_reduction": target, "capped": True,
                         "evaluations": evaluations, "units": len(plan_hi)}
    best_plan, best_red = plan_hi, red_hi
    for _ in range(max_iterations):
        if hi - lo <= 1:
            break
        mid = (lo + hi) // 2
        red, plan = reduction_for(mid)
        evaluations.append((mid, red))
        if red >= target:
            hi = mid
            if red < best_red or not best_plan:
                best_plan, best_red = plan, red
            elif abs(red - target) < abs(best_red - target):
                best_plan, best_red = plan, red
            if red - target <= tolerance:
                break
        else:
            lo = mid
    return best_plan, {"achieved_mac_reduction": best_red, "target_mac_reduction": target, "capped": False,
                       "evaluations": evaluations, "units": len(best_plan)}
