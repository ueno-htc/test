from __future__ import annotations

import math
import traceback
from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader

from frequency_pruning.distributed import (
    DistributedContext,
    assert_consensus,
    coalesced_all_reduce_,
    synchronize_failures,
    unwrap_model,
)
from frequency_pruning.fourier import split_frequency
from frequency_pruning.models import iter_prunable_units
from frequency_pruning.models.common import StructuredPruningUnit, unique_parameters
from frequency_pruning.utils import autocast_context, move_batch_to_device


class DistributedSaliencyError(RuntimeError):
    """Backward-compatible alias for distributed phase failures."""


class _RequiresGradGuard:
    """Enable only target derivatives and restore every original flag.

    Treating non-target model weights as constants is mathematically exact for
    derivatives with respect to the requested parameters/gates.  It is
    especially important for gate-level HAP: otherwise autograd records a
    full-model parameter graph even though only a few thousand structural gate
    variables are differentiated.
    """

    def __init__(
        self,
        tensors: Sequence[Tensor],
        *,
        freeze: Sequence[Tensor] = (),
    ) -> None:
        self.targets = list(dict.fromkeys(tensors))
        self.all_tensors = list(dict.fromkeys([*freeze, *self.targets]))
        self.states = [tensor.requires_grad for tensor in self.all_tensors]

    def __enter__(self):
        for tensor in self.all_tensors:
            tensor.requires_grad_(False)
            tensor.grad = None
        for tensor in self.targets:
            tensor.requires_grad_(True)
        return self

    def __exit__(self, exc_type, exc, traceback_obj):
        for tensor, state in zip(self.all_tensors, self.states):
            tensor.requires_grad_(state)
            tensor.grad = None
        return False


@dataclass
class SaliencyResult:
    method: str
    scores: Dict[str, Tensor]
    raw_scores: Dict[str, Tensor]
    diagnostics: Dict[str, Any] = field(default_factory=dict)

    def cpu(self) -> "SaliencyResult":
        return SaliencyResult(
            method=self.method,
            scores={name: value.detach().float().cpu() for name, value in self.scores.items()},
            raw_scores={name: value.detach().float().cpu() for name, value in self.raw_scores.items()},
            diagnostics=dict(self.diagnostics),
        )


def compute_method_scores(
    model: nn.Module,
    loader: DataLoader | None,
    config: Mapping[str, Any],
    device: torch.device,
    *,
    distributed_reduce: bool = False,
) -> SaliencyResult:
    """Compute structured keep-importance scores.

    The function intentionally accepts only an ordinary module.  DDP wrappers
    register reducer hooks and buffer broadcasts that are inappropriate for the
    local saliency forward/autograd phase.  Distributed callers unwrap the model,
    process one deterministic calibration shard per rank, and explicitly reduce
    FP32 accumulators only at the phase boundary.
    """

    if isinstance(model, DDP):
        raise TypeError(
            "compute_method_scores received DistributedDataParallel. Pass the "
            "unwrapped module and set distributed_reduce explicitly."
        )

    method = str(config["pruning"]["method"]).lower()
    named_units: list[tuple[str, StructuredPruningUnit]] = iter_prunable_units(model, named=True)
    if not named_units:
        raise ValueError("The selected model exposes no structured pruning units")
    reduction = str(config["pruning"].get("score_reduction", "mean"))

    if method == "dense":
        raw = {name: torch.full((unit.num_units,), float("inf")) for name, unit in named_units}
        return SaliencyResult(method, raw, raw, {"note": "Dense baseline does not prune"})
    if method == "random":
        generator = torch.Generator(device="cpu").manual_seed(
            int(config["pruning"].get("random_seed", 123))
        )
        raw = {name: torch.rand(unit.num_units, generator=generator) for name, unit in named_units}
        return _finalize_scores(method, named_units, raw, config, {})
    if method == "magnitude":
        raw = {
            name: unit.magnitude_scores(reduction=reduction).detach().cpu()
            for name, unit in named_units
        }
        return _finalize_scores(method, named_units, raw, config, {})
    if loader is None:
        raise ValueError(f"Pruning method {method} requires a calibration loader")

    model.eval()
    max_batches = int(config["pruning"].get("score_batches", 8))
    channels_last = bool(config["model"].get("channels_last", False)) and device.type == "cuda"
    amp_dtype = _saliency_amp_dtype(str(config["train"].get("amp", "none")), device)
    bucket_mb = float(config["pruning"].get("saliency_reduce_bucket_mb", 64.0))

    if method == "robust_allocation":
        return _robust_allocation_scores(
            model,
            loader,
            config,
            device,
            named_units,
            max_batches=max_batches,
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )

    if method == "spectral_reliance":
        return _spectral_reliance_scores(
            model,
            loader,
            config,
            device,
            named_units,
            max_batches=max_batches,
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )

    if method in {"spectral_steering", "taylor", "lfs", "reliance_filtered"}:
        return _spectral_family_scores(
            method,
            model,
            loader,
            config,
            device,
            named_units,
            max_batches=max_batches,
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )

    if method in {"frequency_steering", "steering_only"}:
        parameters = unique_parameters(unit for _, unit in named_units)
        lam = 0.0 if method == "steering_only" else float(config["pruning"].get("lambda", 1.0))
        direction = str(config["pruning"].get("steering", "high")).lower()
        low_formula = str(config["pruning"].get("low_steering_formula", "swap")).lower()
        coefficients = _steering_coefficients(direction, low_formula, lam)
        abs_after_combine = bool(config["pruning"].get("saliency_abs_after_combine", True))

        with _RequiresGradGuard(parameters, freeze=list(model.parameters())):
            if abs_after_combine:
                combined_gradients, diagnostics = _frequency_combined_gradients(
                    model,
                    loader,
                    parameters,
                    device,
                    max_batches,
                    float(config["pruning"].get("cutoff", 0.25)),
                    str(config["pruning"].get("cutoff_mode", "relative")),
                    float(config["pruning"].get("transition_width", 0.0)),
                    str(config["pruning"].get("hp_dc_mode", "image_mean")),
                    channels_last,
                    amp_dtype,
                    coefficients=coefficients,
                    distributed_reduce=distributed_reduce,
                    bucket_mb=bucket_mb,
                )
                parameter_values = {
                    parameter: (combined_gradients[parameter] * parameter.detach().float()).abs()
                    for parameter in parameters
                }
            else:
                grad_lp, grad_hp, diagnostics = _frequency_gradients_separate(
                    model,
                    loader,
                    parameters,
                    device,
                    max_batches,
                    float(config["pruning"].get("cutoff", 0.25)),
                    str(config["pruning"].get("cutoff_mode", "relative")),
                    float(config["pruning"].get("transition_width", 0.0)),
                    str(config["pruning"].get("hp_dc_mode", "image_mean")),
                    channels_last,
                    amp_dtype,
                    distributed_reduce=distributed_reduce,
                    bucket_mb=bucket_mb,
                )
                parameter_values: Dict[nn.Parameter, Tensor] = {}
                for parameter in parameters:
                    lp = grad_lp[parameter]
                    hp = grad_hp[parameter]
                    target_grad, opposite_grad = (
                        (hp, lp) if direction == "high" else (lp, hp)
                    )
                    parameter_values[parameter] = (
                        (target_grad * parameter.detach().float()).abs()
                        - lam * (opposite_grad * parameter.detach().float()).abs()
                    )

        raw = {
            name: unit.aggregate_parameter_scores(parameter_values, reduction=reduction).detach().cpu()
            for name, unit in named_units
        }
        diagnostics.update(
            {
                "lambda": lam,
                "cutoff": float(config["pruning"].get("cutoff", 0.25)),
                "steering": direction,
                "low_steering_formula": low_formula,
                "formula": (
                    "abs((g_target - lambda*g_opposite) * w)"
                    if abs_after_combine
                    else "abs(g_target*w) - lambda*abs(g_opposite*w)"
                ),
                "gradient_accumulation_dtype": "float32",
                "combined_gradient_accumulator": abs_after_combine,
                "frequency_coefficients": coefficients,
            }
        )
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    if method == "snip":
        parameters = unique_parameters(unit for _, unit in named_units)
        with _RequiresGradGuard(parameters, freeze=list(model.parameters())):
            gradients, diagnostics = _clean_gradients(
                model,
                loader,
                parameters,
                device,
                max_batches,
                channels_last,
                amp_dtype,
                distributed_reduce=distributed_reduce,
                bucket_mb=bucket_mb,
            )
        parameter_values = {
            parameter: (gradients[parameter] * parameter.detach().float()).abs()
            for parameter in parameters
        }
        raw = {
            name: unit.aggregate_parameter_scores(parameter_values, reduction=reduction).detach().cpu()
            for name, unit in named_units
        }
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    if method == "hap":
        raw, diagnostics = _hap_gate_scores(
            model,
            loader,
            named_units,
            device,
            max_batches=max_batches,
            hutchinson_samples=int(config["pruning"].get("hap_samples", 1)),
            mode=str(config["pruning"].get("hap_mode", "gate_empirical_fisher")),
            microbatch_size=int(config["pruning"].get("hap_microbatch_size", 8)),
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    raise ValueError(f"Unsupported pruning method: {method}")


def compute_method_scores_for_context(
    model: nn.Module,
    loader: DataLoader | None,
    config: Mapping[str, Any],
    context: DistributedContext,
) -> SaliencyResult:
    """Execute saliency under a collective-safe distributed policy."""

    execution = str(config["pruning"].get("saliency_execution", "all_ranks")).lower()
    if not context.distributed:
        result = compute_method_scores(
            unwrap_model(model),
            loader,
            config,
            context.device,
            distributed_reduce=False,
        )
        result.diagnostics.update(
            {"saliency_execution": "single_process", "saliency_world_size": 1}
        )
        return result

    if execution not in {"all", "all_ranks", "sharded", "all_rank_sharded"}:
        raise DistributedSaliencyError(
            "Distributed rank-0-only saliency is disabled because it caused the "
            "observed NCCL collective mismatch. Use pruning.saliency_execution=all_ranks."
        )

    result: SaliencyResult | None = None
    local_error: BaseException | None = None
    local_trace = ""
    try:
        result = compute_method_scores(
            unwrap_model(model),
            loader,
            config,
            context.device,
            distributed_reduce=True,
        )
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, context.device)

    # This outer phase boundary also covers errors that occur before a method's
    # accumulator helper is entered (model/unit discovery, configuration, or
    # method dispatch).  Healthy ranks never proceed to pruning while a peer has
    # already left the saliency state machine.
    synchronize_failures(
        local_error,
        phase=f"saliency_dispatch/{config['pruning'].get('method', 'unknown')}",
        local_traceback=local_trace,
    )
    if result is None:  # synchronize_failures raises when local_error is set.
        raise DistributedSaliencyError("Saliency completed without a result")
    result.diagnostics.update(
        {
            "saliency_execution": "all_ranks_sharded",
            "saliency_world_size": context.world_size,
            "control_backend": context.control_backend,
        }
    )
    # A compact deterministic fingerprint catches sampler, model-mask, or score
    # divergence before ranks independently select different pruning units.
    consensus = {
        name: {
            "numel": int(value.numel()),
            "finite": int(torch.isfinite(value).sum().item()),
            "sum": float(torch.nan_to_num(value.double(), posinf=0.0, neginf=0.0).sum().item()),
            "sum_sq": float(
                torch.nan_to_num(value.double(), posinf=0.0, neginf=0.0).square().sum().item()
            ),
        }
        for name, value in sorted(result.scores.items())
    }
    assert_consensus(consensus, phase=f"saliency_consensus/{result.method}")
    result.diagnostics["score_consensus_verified"] = True
    return result


def _robust_allocation_scores(
    model: nn.Module,
    loader: DataLoader,
    config: Mapping[str, Any],
    device: torch.device,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    *,
    max_batches: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    distributed_reduce: bool,
    bucket_mb: float,
) -> SaliencyResult:
    """Layer-wise sparsity from frequency robustness, unit selection from Taylor.

    Two scores are computed for every unit:

    * ``I_g = E|dL/dgate_g|``  (clean Taylor) decides WHICH units of a layer go;
    * ``A_g = sum_{b in bands} E|dG_b/dgate_g|`` decides HOW MANY units each layer
      loses, where G_b is the loss increase caused by perturbing band b (additive
      band noise, or removal of the band).  A_g is the first-order estimate of how
      much the robustness to those bands degrades when unit g is removed.

    The two are combined so that any prefix of the final ranking removes, from
    every layer, as many units as the global ranking of A would remove, and takes
    them in the order of I ("transport" of the sorted A percentiles onto the I
    order).  ``rank_mix_alpha`` interpolates the layer counts between a uniform
    allocation (0) and the robustness-driven one (1).
    """
    from .spectral import accumulate_spectral_statistics, band_names, spectral_config, _normalize_profile

    pruning_cfg = config["pruning"]
    spectral = spectral_config(pruning_cfg)
    edges = spectral["band_edges"]
    num_bands = len(edges) - 1
    alloc = dict(pruning_cfg.get("allocation", {}) or {})
    perturbation = str(alloc.get("perturbation", "noise")).lower()
    if perturbation not in {"noise", "stop"}:
        raise ValueError("pruning.allocation.perturbation must be noise or stop")
    bands = [int(b) for b in (alloc.get("bands", []) or range(num_bands))]
    if any(b < 0 or b >= num_bands for b in bands):
        raise ValueError(f"pruning.allocation.bands must index the {num_bands} bands")
    amplitude = float(alloc.get("noise_amplitude", 0.1))
    clean_weight = float(alloc.get("clean_weight", 0.0))
    alpha = float(pruning_cfg.get("rank_mix_alpha", 0.5))
    gates = [unit.gate for _, unit in named_units]
    with _RequiresGradGuard(gates, freeze=list(model.parameters())):
        acc = accumulate_spectral_statistics(
            model,
            loader,
            named_units,
            device,
            estimator="robust_noise" if perturbation == "noise" else "stop",
            edges=edges,
            max_batches=max_batches,
            microbatch_size=spectral["microbatch_size"],
            taylor_reduction=spectral["taylor_reduction"],
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            noise_samples_per_band=1,
            noise_amplitude=amplitude,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )
    microbatches = max(1.0, float(acc.scalar[2].item()))
    samples = max(1.0, float(acc.scalar[0].item()))
    selection: Dict[str, Tensor] = {}
    allocation: Dict[str, Tensor] = {}
    active_masks: Dict[str, Tensor] = {}
    pooled: list[Tensor] = []
    for name, unit in named_units:
        clean = acc.taylor[name].detach().float().cpu() / microbatches
        robust = acc.contribution[name].detach().float().cpu()[:, bands].sum(dim=1) / microbatches
        selection[name] = clean
        allocation[name] = robust + clean_weight * clean
        active = unit.active_mask().cpu() & torch.isfinite(allocation[name]) & torch.isfinite(clean)
        active_masks[name] = active
        pooled.append(allocation[name][active])
    sorted_all, _ = torch.sort(torch.cat(pooled) if pooled else torch.zeros(0))
    total = max(1, int(sorted_all.numel()) - 1)
    output: Dict[str, Tensor] = {}
    layer_sensitivity: Dict[str, float] = {}
    for name, unit in named_units:
        active = active_masks[name]
        out = torch.full_like(selection[name], float("inf"))
        if active.any():
            sel = selection[name][active]
            order = torch.argsort(sel)
            local = torch.empty_like(sel)
            local[order] = torch.linspace(0.0, 1.0, sel.numel()) if sel.numel() > 1 else torch.zeros(1)
            global_pct = (torch.searchsorted(sorted_all, allocation[name][active], right=False).float() / float(total)).clamp(0.0, 1.0)
            transported = torch.empty_like(sel)
            transported[order] = torch.sort(global_pct).values
            out[active] = (1.0 - alpha) * local + alpha * transported
            layer_sensitivity[name] = float(allocation[name][active].mean().item())
        out[~unit.active_mask().cpu()] = float("inf")
        output[name] = out
    mean_sensitivity = max(1e-30, float(sum(layer_sensitivity.values()) / max(1, len(layer_sensitivity))))
    diagnostics: Dict[str, Any] = {
        "estimator": "robustness_gap_" + perturbation,
        "layer_normalization": "robust_allocation",
        "rank_mix_alpha": alpha,
        "allocation_perturbation": perturbation,
        "allocation_bands": bands,
        "allocation_noise_amplitude": amplitude if perturbation == "noise" else None,
        "allocation_clean_weight": clean_weight,
        "band_edges": edges,
        "band_names": band_names(edges),
        # robustness gap of each band on the calibration images (loss increase)
        "band_gap": [float(v) / samples for v in acc.band_power.tolist()],
        "band_gap_profile": _normalize_profile([max(0.0, float(v)) for v in acc.band_power.tolist()]),
        # per-unit robustness sensitivity of each group relative to the network mean (>1: protect, <1: prune more)
        "layer_robust_sensitivity": {k: v / mean_sensitivity for k, v in layer_sensitivity.items()},
        "calibration_samples": int(samples),
        "calibration_microbatches": int(microbatches),
        "clean_loss": float(acc.scalar[1].item() / samples),
        "formula": "counts per layer: global rank of sum_b E|dG_b/dgate|; order inside a layer: E|dL/dgate|",
        "score_reduction": str(pruning_cfg.get("score_reduction", "mean")),
        "num_structured_groups": len(named_units),
        "num_units": sum(unit.num_units for _, unit in named_units),
    }
    return SaliencyResult("robust_allocation", output, {k: v.clone() for k, v in selection.items()}, diagnostics)


def _spectral_reliance_scores(
    model: nn.Module,
    loader: DataLoader,
    config: Mapping[str, Any],
    device: torch.device,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    *,
    max_batches: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    distributed_reduce: bool,
    bucket_mb: float,
) -> SaliencyResult:
    """Spectral Reliance Pruning (v5): protect the units that carry the bands the task relies on.

    Everything is expressed through ONE quantity, band reliance:

    * task level  : R_b = L(x_{-b}) - L(x), loss increase when band b is removed
    * unit level  : |dR_b/dgate_g|, first-order distortion of R_b when g is removed
    * selection   : score_g = E|dL/dgate_g| + lambda * sum_b rho_b E|dR_b/dgate_g|
                    (preserve the loss and the reliance profile to first order)
    * recovery    : optional reliance-preserving distillation (engine.py)

    ``reliance_estimator=pass`` switches the unit-level term to band-pass Taylor
    shares (a multi-band generalisation of VTC-LFC's LFS) for comparison.

    v4's mismatch target (reliance vs. input-gradient sensitivity) mixed two
    incommensurable profiles and always steered toward low frequency; it lost
    accuracy on every task (see docs/V4_1_EVALUATION.md).
    """

    from .spectral import (
        accumulate_spectral_statistics,
        band_names,
        combine_reliance_scores,
        measure_reliance,
        reliance_weights,
        spectral_config,
        _normalize_profile,
    )

    pruning_cfg = config["pruning"]
    spectral = spectral_config(pruning_cfg)
    edges = spectral["band_edges"]
    num_bands = len(edges) - 1
    gates = [unit.gate for _, unit in named_units]
    with _RequiresGradGuard(gates, freeze=list(model.parameters())):
        acc = accumulate_spectral_statistics(
            model,
            loader,
            named_units,
            device,
            estimator={"stop": "stop", "pass": "filtered", "outdiff": "outdiff"}[spectral["reliance_estimator"]],
            edges=edges,
            max_batches=max_batches,
            microbatch_size=spectral["microbatch_size"],
            taylor_reduction=spectral["taylor_reduction"],
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            noise_samples_per_band=1,
            noise_amplitude=0.0,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )
    mode = spectral["reliance_weights"]
    reliance: Dict[str, Any] | None = None
    source = "not_needed"
    if mode in {"task", "shift"}:
        cached = getattr(model, "_fsp_reliance_profile", None)
        if cached is not None and spectral["reliance_source"] == "dense":
            reliance, source = cached, "cached_dense"
        else:
            reliance = measure_reliance(
                model,
                loader,
                device,
                edges,
                max_batches=spectral["reliance_batches"],
                channels_last=channels_last,
                keep_dc=spectral["keep_dc"],
                distributed_reduce=distributed_reduce,
            )
            reliance["reliance_profile"] = _normalize_profile(reliance["reliance_loss"])
            source = "measured_" + spectral["reliance_source"]
            if spectral["reliance_source"] == "dense" and cached is None:
                try:
                    model._fsp_reliance_profile = reliance  # type: ignore[attr-defined]
                except Exception:  # pragma: no cover - defensive
                    pass
    weights = reliance_weights(
        mode,
        num_bands,
        task_reliance=None if reliance is None else reliance["reliance_profile"],
        source_reliance=spectral["source_reliance"],
        manual=spectral["manual_weights"],
    )
    raw, diagnostics = combine_reliance_scores(
        acc, named_units, weights=weights, lam=spectral["lambda"], scale=spectral["reliance_scale"],
        clean_weight=spectral["clean_weight"],
    )
    diagnostics["estimator"] = {
        "stop": "band_stop_derivative", "pass": "band_pass_share", "outdiff": "output_difference",
    }[spectral["reliance_estimator"]]
    if spectral["reliance_estimator"] == "outdiff":
        diagnostics["band_output_effect"] = _normalize_profile([float(v) for v in acc.band_power.tolist()])
    diagnostics.update(
        {
            "band_edges": edges,
            "band_names": band_names(edges),
            "taylor_level": "gate",
            "taylor_reduction": spectral["taylor_reduction"],
            "target_profile": "reliance_" + mode,
            "reliance_weights_mode": mode,
            "steering_weights": weights,
            "signed": mode == "shift",
            "reliance_profile": None if reliance is None else reliance["reliance_profile"],
            "reliance_loss": None if reliance is None else reliance["reliance_loss"],
            "reliance_accuracy_drop": None if reliance is None else reliance["reliance_accuracy_drop"],
            "reliance_profile_source": source,
            "source_reliance": spectral["source_reliance"],
            "calibration_reliance_profile": (
                _normalize_profile([float(v) for v in acc.band_power.tolist()])
                if spectral["reliance_estimator"] == "stop" else None
            ),
            "microbatch_size": spectral["microbatch_size"],
        }
    )
    # Loss-unit scores / global shares are comparable across layers; per-layer z-scoring would discard
    # exactly the cross-layer allocation signal this criterion provides.
    local_config = {**config, "pruning": {**pruning_cfg, "layer_normalization": spectral["layer_normalization"]}}
    return _finalize_scores("spectral_reliance", named_units, raw, local_config, diagnostics)


def _spectral_family_scores(
    method: str,
    model: nn.Module,
    loader: DataLoader,
    config: Mapping[str, Any],
    device: torch.device,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    *,
    max_batches: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    distributed_reduce: bool,
    bucket_mb: float,
) -> SaliencyResult:
    """Gate-level Taylor-FO (``taylor``), low-frequency Taylor (``lfs``) and
    Spectral-Steering (``spectral_steering``).

    All three share the same gate-level first-order machinery, so the only
    difference between ``taylor`` and ``spectral_steering`` is the spectral term:
    ``spectral_steering`` with ``lambda=0`` or ``target_profile=flat`` is exactly
    ``taylor``.
    """

    from .spectral import (
        accumulate_spectral_statistics,
        band_masks,
        band_names,
        combine_spectral_scores,
        density_profile,
        measure_reliance,
        profile_mismatch,
        spectral_config,
        steering_weights,
        unit_contribution_table,
        _normalize_profile,
    )

    pruning_cfg = config["pruning"]
    spectral = spectral_config(pruning_cfg)
    edges = spectral["band_edges"]
    num_bands = len(edges) - 1
    gates = [unit.gate for _, unit in named_units]
    reduction = str(pruning_cfg.get("score_reduction", "mean"))
    diagnostics: Dict[str, Any] = {
        "band_edges": edges,
        "band_names": band_names(edges),
        "taylor_level": "gate",
        "taylor_reduction": spectral["taylor_reduction"],
        "gradient_accumulation_dtype": "float32",
    }

    input_transform = None
    if method == "lfs":
        # VTC-LFC style: importance estimated only from low-pass filtered inputs.
        cutoff = float(pruning_cfg.get("cutoff", 0.25))

        def input_transform(images: Tensor, _cutoff: float = cutoff) -> Tensor:  # type: ignore[misc]
            lp, _ = split_frequency(
                images,
                _cutoff,
                cutoff_mode=str(pruning_cfg.get("cutoff_mode", "relative")),
                transition_width=float(pruning_cfg.get("transition_width", 0.0)),
                hp_dc_mode=str(pruning_cfg.get("hp_dc_mode", "image_mean")),
            )
            return lp

        diagnostics["lfs_cutoff"] = cutoff

    if method == "reliance_filtered":
        # Reliance-Filtered Calibration (RFC): estimate gate-level Taylor importance on
        # inputs that contain only the bands the task relies on.  A unit that is driven
        # by a band the task does not use produces no activation on these inputs, so its
        # gate gradient vanishes and it is pruned first; when every band matters the
        # filter is the identity and the criterion is global Taylor-FO.  This is the
        # task-adaptive counterpart of VTC-LFC's fixed low-pass calibration.
        from .spectral import band_filter as _band_filter
        from .spectral import band_masks as _band_masks

        cached = getattr(model, "_fsp_reliance_profile", None)
        if cached is not None and spectral["reliance_source"] == "dense":
            reliance_info = cached
            diagnostics["reliance_profile_source"] = "cached_dense"
        else:
            reliance_info = measure_reliance(
                model, loader, device, edges,
                max_batches=spectral["reliance_batches"], channels_last=channels_last,
                keep_dc=spectral["keep_dc"], distributed_reduce=distributed_reduce,
            )
            reliance_info["reliance_profile"] = _normalize_profile(reliance_info["reliance_loss"])
            diagnostics["reliance_profile_source"] = "measured_" + spectral["reliance_source"]
            if spectral["reliance_source"] == "dense" and cached is None:
                try:
                    model._fsp_reliance_profile = reliance_info  # type: ignore[attr-defined]
                except Exception:  # pragma: no cover - defensive
                    pass
        profile = list(reliance_info["reliance_profile"])
        threshold = float((pruning_cfg.get("spectral", {}) or {}).get("reliance_threshold", 0.05))
        keep_bands = [b for b, value in enumerate(profile) if value >= threshold]
        if not keep_bands:
            keep_bands = [max(range(len(profile)), key=lambda b: profile[b])]
        diagnostics.update(
            {"reliance_profile": profile, "reliance_threshold": threshold, "kept_bands": keep_bands,
             "reliance_loss": reliance_info.get("reliance_loss")}
        )
        if len(keep_bands) < num_bands:

            def input_transform(images: Tensor, _keep: tuple[int, ...] = tuple(keep_bands)) -> Tensor:  # type: ignore[misc]
                masks = _band_masks(images.shape[-2], images.shape[-1], edges, images.device)
                keep = masks[list(_keep)].sum(dim=0)
                return _band_filter(images, keep, keep_dc=True)

    estimator = spectral["estimator"] if method == "spectral_steering" else "taylor_only"
    with _RequiresGradGuard(gates, freeze=list(model.parameters())):
        acc = accumulate_spectral_statistics(
            model,
            loader,
            named_units,
            device,
            estimator=estimator,
            edges=edges,
            max_batches=max_batches,
            microbatch_size=spectral["microbatch_size"],
            taylor_reduction=spectral["taylor_reduction"],
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            noise_samples_per_band=spectral["noise_samples_per_band"],
            noise_amplitude=spectral["noise_amplitude"],
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
            input_transform=input_transform,
        )

    if method in {"taylor", "lfs", "reliance_filtered"}:
        raw, combo = combine_spectral_scores(
            acc,
            named_units,
            weights=[0.0] * num_bands,
            lam=0.0,
            signed=True,
            estimator="exact",
        )
        diagnostics.update(combo)
        diagnostics["estimator"] = method
        diagnostics["target_profile"] = "flat"
        diagnostics["formula"] = "mean_batches |dL/dgate_g|" + (
            " on low-pass inputs" if method == "lfs"
            else " on inputs restricted to the task's reliant bands" if method == "reliance_filtered" else ""
        )
        if method == "reliance_filtered":
            # loss-unit gate gradients are comparable across layers: rank globally by default
            local_config = {**config, "pruning": {**pruning_cfg, "layer_normalization": spectral["layer_normalization"]}}
            return _finalize_scores(method, named_units, raw, local_config, diagnostics)
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    # ------------------------------------------------------------------
    # Spectral steering: derive the target weights from task reliance and the
    # current sensitivity profile, then combine.
    # ------------------------------------------------------------------
    sensitivity_profile = _normalize_profile([float(v) for v in acc.band_power.tolist()])
    if spectral["profile_normalization"] == "density" and acc.band_area:
        sensitivity_profile = density_profile([float(v) for v in acc.band_power.tolist()], acc.band_area)
    target_mode = spectral["target_profile"]
    reliance: Dict[str, Any] | None = None
    if target_mode in {"auto", "mismatch", "reliance"}:
        cached = getattr(model, "_fsp_reliance_profile", None)
        if cached is not None and spectral["reliance_source"] == "dense":
            reliance = cached
            diagnostics["reliance_profile_source"] = "cached_dense"
        else:
            reliance = measure_reliance(
                model,
                loader,
                device,
                edges,
                max_batches=spectral["reliance_batches"],
                channels_last=channels_last,
                keep_dc=spectral["keep_dc"],
                distributed_reduce=distributed_reduce,
            )
            reliance["reliance_profile"] = (
                density_profile(reliance["reliance_loss"], acc.band_area)
                if spectral["profile_normalization"] == "density" and acc.band_area
                else _normalize_profile(reliance["reliance_loss"])
            )
            if spectral["reliance_source"] == "dense" and cached is None:
                try:
                    model._fsp_reliance_profile = reliance  # type: ignore[attr-defined]
                except Exception:  # pragma: no cover - defensive
                    pass
            diagnostics["reliance_profile_source"] = "measured_" + spectral["reliance_source"]
    weights = steering_weights(
        target_mode,
        num_bands,
        reliance_profile=None if reliance is None else reliance["reliance_profile"],
        sensitivity_profile=sensitivity_profile,
        manual=spectral["manual_weights"],
    )
    raw, combo = combine_spectral_scores(
        acc,
        named_units,
        weights=weights,
        lam=spectral["lambda"],
        signed=spectral["signed"],
        estimator=spectral["estimator"],
    )
    diagnostics.update(combo)
    diagnostics.update(
        {
            "target_profile": target_mode,
            "sensitivity_profile": sensitivity_profile,
            "reliance_profile": None if reliance is None else reliance["reliance_profile"],
            "reliance_loss": None if reliance is None else reliance["reliance_loss"],
            "reliance_accuracy_drop": None if reliance is None else reliance["reliance_accuracy_drop"],
            "profile_mismatch_l1": (
                None if reliance is None else profile_mismatch(reliance["reliance_profile"], sensitivity_profile)
            ),
            "formula": "I0/mean(I0) + lambda * (sum_b w_b c_gb)/mean|.|, c_gb=(dS_b/dgate_g)/S_b",
            "microbatch_size": spectral["microbatch_size"],
            "profile_normalization": spectral["profile_normalization"],
            "band_area": list(acc.band_area),
        }
    )
    result = _finalize_scores(method, named_units, raw, config, diagnostics)
    # Per-unit band contributions are kept for analysis plots (saliency_round_XX.pt).
    result.diagnostics["unit_band_contribution"] = {
        name: value.tolist() for name, value in unit_contribution_table(acc).items()
    }
    return result


def _steering_coefficients(direction: str, low_formula: str, lam: float) -> Dict[str, float]:
    if direction == "high":
        return {"hp": 1.0, "lp": -float(lam)}
    if direction != "low":
        raise ValueError(f"Unsupported steering direction: {direction}")
    if low_formula == "swap":
        return {"lp": 1.0, "hp": -float(lam)}
    if low_formula in {"inverse_ratio", "reverse_ratio"}:
        return {"lp": float(lam), "hp": -1.0}
    raise ValueError(f"Unsupported low_steering_formula: {low_formula}")


def _finalize_scores(
    method: str,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    raw_scores: Mapping[str, Tensor],
    config: Mapping[str, Any],
    diagnostics: Dict[str, Any],
) -> SaliencyResult:
    normalization = str(config["pruning"].get("layer_normalization", "none")).lower()
    output: Dict[str, Tensor] = {}
    if normalization == "rankmix":
        # Cross-layer calibration family (v6).  Every active unit gets
        #     q = (1 - alpha) * (rank percentile inside its own group)
        #         + alpha * (rank percentile among all units of the network)
        # alpha = 0 prunes every group by the same percentile (uniform allocation,
        # the regime per-layer normalisation approximates); alpha = 1 is the global
        # ranking of the raw scores (loss-calibrated allocation).  The v5 runs showed
        # that the better end of this family flips between the source task and
        # small-data transfer tasks.
        alpha = float(config["pruning"].get("rank_mix_alpha", 0.5))
        if not 0.0 <= alpha <= 1.0:
            raise ValueError("pruning.rank_mix_alpha must be in [0, 1]")
        values: Dict[str, Tensor] = {}
        masks: Dict[str, Tensor] = {}
        pooled: list[Tensor] = []
        for name, unit in named_units:
            value = raw_scores[name].detach().float().clone().cpu()
            active = unit.active_mask().cpu() & torch.isfinite(value)
            values[name], masks[name] = value, active
            pooled.append(value[active])
        all_values = torch.cat(pooled) if pooled else torch.zeros(0)
        sorted_all, _ = torch.sort(all_values)
        total = max(1, int(sorted_all.numel()) - 1)
        for name, unit in named_units:
            value, active = values[name], masks[name]
            out = torch.full_like(value, float("inf"))
            if active.any():
                subset = value[active]
                local = torch.empty_like(subset)
                order = torch.argsort(subset)
                local[order] = torch.linspace(0.0, 1.0, subset.numel()) if subset.numel() > 1 else torch.zeros(1)
                global_pct = torch.searchsorted(sorted_all, subset, right=False).float() / float(total)
                out[active] = (1.0 - alpha) * local + alpha * global_pct.clamp(0.0, 1.0)
            out[~unit.active_mask().cpu()] = float("inf")
            output[name] = out
        diagnostics = dict(diagnostics)
        diagnostics["layer_normalization"] = normalization
        diagnostics["rank_mix_alpha"] = alpha
        diagnostics["score_reduction"] = str(config["pruning"].get("score_reduction", "mean"))
        diagnostics["num_structured_groups"] = len(named_units)
        diagnostics["num_units"] = sum(unit.num_units for _, unit in named_units)
        return SaliencyResult(
            method,
            output,
            {name: value.detach().float().cpu() for name, value in raw_scores.items()},
            diagnostics,
        )
    for name, unit in named_units:
        value = raw_scores[name].detach().float().clone().cpu()
        active = unit.active_mask().cpu()
        finite_active = active & torch.isfinite(value)
        if normalization not in {"none", "", "false"} and finite_active.any():
            subset = value[finite_active]
            if normalization == "mean":
                value = value / subset.abs().mean().clamp_min(1e-12)
            elif normalization == "l2":
                value = value / subset.square().mean().sqrt().clamp_min(1e-12)
            elif normalization in {"zscore", "gaussian"}:
                value = (value - subset.mean()) / subset.std(unbiased=False).clamp_min(1e-12)
            elif normalization == "sum":
                value = value / subset.sum().abs().clamp_min(1e-12)
            elif normalization == "max":
                value = value / subset.max().abs().clamp_min(1e-12)
            elif normalization == "standardization":
                # (x - mean) / (max - min), the "standardization" option of common pruning toolkits
                value = (value - subset.mean()) / (subset.max() - subset.min()).clamp_min(1e-8)
            elif normalization == "lamp":
                # LAMP-style layer-adaptive rescaling (Lee et al., ICLR 2021) applied to unit
                # scores: s_i / sum of the scores that are at least as large as s_i.
                order = torch.argsort(subset, descending=True)
                sorted_scores = subset[order].clamp_min(0.0)
                denominators = torch.cumsum(sorted_scores, dim=0).clamp_min(1e-12)
                lamp = torch.empty_like(subset)
                lamp[order] = sorted_scores / denominators
                value[finite_active] = lamp
            elif normalization == "rank":
                ranks = torch.empty_like(subset)
                order = torch.argsort(subset)
                ranks[order] = torch.linspace(0.0, 1.0, subset.numel())
                value[finite_active] = ranks
            else:
                raise ValueError(f"Unsupported layer_normalization: {normalization}")
        value[~active] = float("inf")
        output[name] = value
    diagnostics = dict(diagnostics)
    diagnostics["layer_normalization"] = normalization
    diagnostics["score_reduction"] = str(config["pruning"].get("score_reduction", "mean"))
    diagnostics["num_structured_groups"] = len(named_units)
    diagnostics["num_units"] = sum(unit.num_units for _, unit in named_units)
    return SaliencyResult(
        method,
        output,
        {name: value.detach().float().cpu() for name, value in raw_scores.items()},
        diagnostics,
    )


def _capture_local_error(error: BaseException, device: torch.device) -> tuple[BaseException, str]:
    trace = traceback.format_exc()
    if isinstance(error, torch.OutOfMemoryError) and device.type == "cuda":
        torch.cuda.empty_cache()
    return error, trace


def _frequency_combined_gradients(
    model: nn.Module,
    loader: DataLoader,
    params: Sequence[nn.Parameter],
    device: torch.device,
    max_batches: int,
    cutoff: float,
    cutoff_mode: str,
    transition_width: float,
    hp_dc_mode: str,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    *,
    coefficients: Mapping[str, float],
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[nn.Parameter, Tensor], Dict[str, Any]]:
    sums = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    scalar = torch.zeros(3, dtype=torch.float64, device=device)  # count, lp loss, hp loss
    local_batches = 0
    local_error: BaseException | None = None
    local_trace = ""
    computed = {"lp": False, "hp": False}

    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            lp, hp = split_frequency(
                images,
                cutoff,
                cutoff_mode=cutoff_mode,
                transition_width=transition_width,
                hp_dc_mode=hp_dc_mode,
            )
            views = {"lp": lp, "hp": hp}
            for name in ("hp", "lp"):
                coefficient = float(coefficients.get(name, 0.0))
                if coefficient == 0.0:
                    continue
                computed[name] = True
                with autocast_context(device, amp_dtype):
                    loss = F.cross_entropy(model(views[name]), target, reduction="sum")
                gradients = torch.autograd.grad(loss, params, allow_unused=True)
                for parameter, gradient in zip(params, gradients):
                    if gradient is not None:
                        sums[parameter].add_(gradient.detach().float(), alpha=coefficient)
                scalar[1 if name == "lp" else 2] += loss.detach().double()
                del gradients, loss
            scalar[0] += target.numel()
            local_batches += 1
            del views, lp, hp, images, target
        if scalar[0].item() <= 0:
            raise RuntimeError("Frequency saliency consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)

    synchronize_failures(
        local_error,
        phase="frequency_saliency_local",
        local_traceback=local_trace,
    )
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(
            sums.values(), enabled=True, bucket_mb=bucket_mb
        )
    denominator = float(scalar[0].clamp_min(1).item())
    for value in sums.values():
        value.div_(denominator)
    return sums, {
        "calibration_samples": int(scalar[0].item()),
        "calibration_batches_local": local_batches,
        "lp_loss": float(scalar[1].item() / denominator) if computed["lp"] else None,
        "hp_loss": float(scalar[2].item() / denominator) if computed["hp"] else None,
        "computed_lp_gradient": computed["lp"],
        "computed_hp_gradient": computed["hp"],
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
        "gradient_accumulators": 1,
    }


def _frequency_gradients_separate(
    model: nn.Module,
    loader: DataLoader,
    params: Sequence[nn.Parameter],
    device: torch.device,
    max_batches: int,
    cutoff: float,
    cutoff_mode: str,
    transition_width: float,
    hp_dc_mode: str,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    *,
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[nn.Parameter, Tensor], Dict[nn.Parameter, Tensor], Dict[str, Any]]:
    sum_lp = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    sum_hp = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    scalar = torch.zeros(3, dtype=torch.float64, device=device)
    local_batches = 0
    local_error: BaseException | None = None
    local_trace = ""
    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            lp, hp = split_frequency(
                images,
                cutoff,
                cutoff_mode=cutoff_mode,
                transition_width=transition_width,
                hp_dc_mode=hp_dc_mode,
            )
            with autocast_context(device, amp_dtype):
                loss_hp = F.cross_entropy(model(hp), target, reduction="sum")
            gradients_hp = torch.autograd.grad(loss_hp, params, allow_unused=True)
            with autocast_context(device, amp_dtype):
                loss_lp = F.cross_entropy(model(lp), target, reduction="sum")
            gradients_lp = torch.autograd.grad(loss_lp, params, allow_unused=True)
            for parameter, gradient in zip(params, gradients_hp):
                if gradient is not None:
                    sum_hp[parameter].add_(gradient.detach().float())
            for parameter, gradient in zip(params, gradients_lp):
                if gradient is not None:
                    sum_lp[parameter].add_(gradient.detach().float())
            scalar[0] += target.numel()
            scalar[1] += loss_lp.detach().double()
            scalar[2] += loss_hp.detach().double()
            local_batches += 1
        if scalar[0].item() <= 0:
            raise RuntimeError("Frequency saliency consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)
    synchronize_failures(local_error, phase="frequency_saliency_local", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(sum_lp.values(), enabled=True, bucket_mb=bucket_mb)
        coalesced_all_reduce_(sum_hp.values(), enabled=True, bucket_mb=bucket_mb)
    denominator = float(scalar[0].clamp_min(1).item())
    for parameter in params:
        sum_lp[parameter].div_(denominator)
        sum_hp[parameter].div_(denominator)
    return sum_lp, sum_hp, {
        "calibration_samples": int(scalar[0].item()),
        "calibration_batches_local": local_batches,
        "lp_loss": float(scalar[1].item() / denominator),
        "hp_loss": float(scalar[2].item() / denominator),
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
        "gradient_accumulators": 2,
    }


def _clean_gradients(
    model: nn.Module,
    loader: DataLoader,
    params: Sequence[nn.Parameter],
    device: torch.device,
    max_batches: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    *,
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[nn.Parameter, Tensor], Dict[str, Any]]:
    sums = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    scalar = torch.zeros(2, dtype=torch.float64, device=device)
    local_batches = 0
    local_error: BaseException | None = None
    local_trace = ""
    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            with autocast_context(device, amp_dtype):
                loss = F.cross_entropy(model(images), target, reduction="sum")
            gradients = torch.autograd.grad(loss, params, allow_unused=True)
            for parameter, gradient in zip(params, gradients):
                if gradient is not None:
                    sums[parameter].add_(gradient.detach().float())
            scalar[0] += target.numel()
            scalar[1] += loss.detach().double()
            local_batches += 1
            del gradients, loss, images, target
        if scalar[0].item() <= 0:
            raise RuntimeError("Clean saliency consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)
    synchronize_failures(local_error, phase="clean_saliency_local", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(sums.values(), enabled=True, bucket_mb=bucket_mb)
    denominator = float(scalar[0].clamp_min(1).item())
    for value in sums.values():
        value.div_(denominator)
    return sums, {
        "calibration_samples": int(scalar[0].item()),
        "calibration_batches_local": local_batches,
        "clean_loss": float(scalar[1].item() / denominator),
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
    }


def _hap_gate_scores(
    model: nn.Module,
    loader: DataLoader,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    device: torch.device,
    *,
    max_batches: int,
    hutchinson_samples: int,
    mode: str,
    microbatch_size: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[str, Tensor], Dict[str, Any]]:
    """Low-memory HAP on structural gate variables, never full model weights."""

    normalized_mode = mode.lower().replace("-", "_")
    if normalized_mode in {"exact", "hessian", "hessian_diag", "exact_hessian"}:
        raise ValueError(
            "Exact gate-Hessian diagonal scoring is not implemented. Use "
            "gate_hutchinson for the explicit stochastic gate-Hessian estimator "
            "or gate_empirical_fisher for the production baseline."
        )
    aliases = {
        "fisher": "gate_empirical_fisher",
        "empirical_fisher": "gate_empirical_fisher",
        "gate_fisher": "gate_empirical_fisher",
        "minibatch_empirical_fisher": "gate_empirical_fisher",
        "hutchinson": "gate_hutchinson",
    }
    normalized_mode = aliases.get(normalized_mode, normalized_mode)
    if normalized_mode not in {"gate_empirical_fisher", "gate_hutchinson"}:
        raise ValueError(
            "pruning.hap_mode must be gate_empirical_fisher or gate_hutchinson; "
            f"got {mode!r}"
        )

    gates = [unit.gate for _, unit in named_units]
    structural_variables = sum(gate.numel() for gate in gates)
    max_variables = int(1_000_000)
    if structural_variables > max_variables:
        raise RuntimeError(
            f"Gate-level HAP refuses {structural_variables} variables; limit={max_variables}"
        )
    microbatch_size = max(1, int(microbatch_size))
    hutchinson_samples = max(1, int(hutchinson_samples))
    accumulators = {
        name: torch.zeros(unit.num_units, dtype=torch.float32, device=device)
        for name, unit in named_units
    }
    scalar = torch.zeros(2, dtype=torch.float64, device=device)
    local_microbatches = 0
    local_error: BaseException | None = None
    local_trace = ""

    try:
        with _RequiresGradGuard(gates, freeze=list(model.parameters())):
            for batch_index, batch in enumerate(loader):
                if max_batches > 0 and batch_index >= max_batches:
                    break
                images, target = batch[:2]
                for start in range(0, int(target.shape[0]), microbatch_size):
                    stop = min(int(target.shape[0]), start + microbatch_size)
                    image_chunk = move_batch_to_device(images[start:stop], device, channels_last)
                    target_chunk = target[start:stop].to(device, non_blocking=True)
                    chunk_size = int(target_chunk.numel())
                    if normalized_mode == "gate_empirical_fisher":
                        with autocast_context(device, amp_dtype):
                            loss = F.cross_entropy(
                                model(image_chunk), target_chunk, reduction="mean"
                            )
                        gradients = torch.autograd.grad(loss, gates, allow_unused=True)
                        for (name, _), gradient in zip(named_units, gradients):
                            if gradient is not None:
                                accumulators[name].add_(
                                    gradient.detach().float().square(), alpha=chunk_size
                                )
                        del gradients
                    else:
                        with torch.autocast(device_type=device.type, enabled=False):
                            loss = F.cross_entropy(
                                model(image_chunk.float()), target_chunk, reduction="mean"
                            )
                            first = torch.autograd.grad(
                                loss, gates, create_graph=True, allow_unused=True
                            )
                            for sample_index in range(hutchinson_samples):
                                # Deterministic across retries/ranks for a fixed
                                # shard and microbatch index.
                                generator = torch.Generator(device=device).manual_seed(
                                    104729 * (batch_index + 1)
                                    + 1009 * (start + 1)
                                    + sample_index
                                )
                                vectors = [
                                    torch.empty_like(gate, dtype=torch.float32)
                                    .bernoulli_(0.5, generator=generator)
                                    .mul_(2)
                                    .sub_(1)
                                    if gradient is not None
                                    else None
                                    for gate, gradient in zip(gates, first)
                                ]
                                terms = [
                                    (gradient.float() * vector).sum()
                                    for gradient, vector in zip(first, vectors)
                                    if gradient is not None and vector is not None
                                ]
                                if not terms:
                                    raise RuntimeError(
                                        "No structural gate participates in the HAP graph"
                                    )
                                dot = torch.stack(terms).sum()
                                hvp = torch.autograd.grad(
                                    dot,
                                    gates,
                                    retain_graph=sample_index + 1 < hutchinson_samples,
                                    allow_unused=True,
                                )
                                for (name, _), vector, value in zip(
                                    named_units, vectors, hvp
                                ):
                                    if vector is not None and value is not None:
                                        accumulators[name].add_(
                                            (vector * value.detach().float()).abs(),
                                            alpha=chunk_size,
                                        )
                                del hvp, dot, terms, vectors
                            del first
                    scalar[0] += chunk_size
                    scalar[1] += loss.detach().double() * chunk_size
                    local_microbatches += 1
                    del loss, image_chunk, target_chunk
        if scalar[0].item() <= 0:
            raise RuntimeError("HAP consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)

    synchronize_failures(local_error, phase="hap_saliency_local", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(
            accumulators.values(), enabled=True, bucket_mb=bucket_mb
        )
    denominator = float(scalar[0].clamp_min(1).item())
    if normalized_mode == "gate_hutchinson":
        denominator *= hutchinson_samples
    scores: Dict[str, Tensor] = {}
    for name, unit in named_units:
        diagonal = accumulators[name] / max(denominator, 1.0)
        scores[name] = (
            0.5 * unit.gate.detach().float().square() * diagonal
        ).cpu()
    diagnostics: Dict[str, Any] = {
        "hap_mode_requested": mode,
        "hap_estimator": (
            "mini_batch_empirical_fisher_gate_diagonal"
            if normalized_mode == "gate_empirical_fisher"
            else "hutchinson_absolute_gate_hessian_diagonal"
        ),
        "hap_structural_variables": structural_variables,
        "hap_microbatch_size": microbatch_size,
        "hutchinson_samples": (
            hutchinson_samples if normalized_mode == "gate_hutchinson" else 0
        ),
        "calibration_samples": int(scalar[0].item()),
        "calibration_microbatches_local": local_microbatches,
        "clean_loss": float(scalar[1].item() / max(float(scalar[0].item()), 1.0)),
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
        "full_model_second_order_graph": False,
    }
    return scores, diagnostics


def _saliency_amp_dtype(name: str, device: torch.device) -> torch.dtype | None:
    # Accumulators and FFTs remain FP32. BF16 is limited to model forward paths.
    normalized = str(name).lower()
    if normalized == "bf16" and device.type in {"cuda", "cpu"}:
        return torch.bfloat16
    return None
