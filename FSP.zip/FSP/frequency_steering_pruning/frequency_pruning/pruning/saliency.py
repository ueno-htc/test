from __future__ import annotations

import math
import traceback
from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader

from frequency_pruning.distributed import (
    DistributedContext,
    assert_consensus,
    coalesced_all_reduce_,
    synchronize_failures,
    unwrap_model,
)
from frequency_pruning.fourier import split_frequency
from frequency_pruning.models import iter_prunable_units
from frequency_pruning.models.common import StructuredPruningUnit, unique_parameters
from frequency_pruning.utils import autocast_context, move_batch_to_device


class DistributedSaliencyError(RuntimeError):
    """Backward-compatible alias for distributed phase failures."""


class _RequiresGradGuard:
    """Enable only target derivatives and restore every original flag.

    Treating non-target model weights as constants is mathematically exact for
    derivatives with respect to the requested parameters/gates.  It is
    especially important for gate-level HAP: otherwise autograd records a
    full-model parameter graph even though only a few thousand structural gate
    variables are differentiated.
    """

    def __init__(
        self,
        tensors: Sequence[Tensor],
        *,
        freeze: Sequence[Tensor] = (),
    ) -> None:
        self.targets = list(dict.fromkeys(tensors))
        self.all_tensors = list(dict.fromkeys([*freeze, *self.targets]))
        self.states = [tensor.requires_grad for tensor in self.all_tensors]

    def __enter__(self):
        for tensor in self.all_tensors:
            tensor.requires_grad_(False)
            tensor.grad = None
        for tensor in self.targets:
            tensor.requires_grad_(True)
        return self

    def __exit__(self, exc_type, exc, traceback_obj):
        for tensor, state in zip(self.all_tensors, self.states):
            tensor.requires_grad_(state)
            tensor.grad = None
        return False


@dataclass
class SaliencyResult:
    method: str
    scores: Dict[str, Tensor]
    raw_scores: Dict[str, Tensor]
    diagnostics: Dict[str, Any] = field(default_factory=dict)

    def cpu(self) -> "SaliencyResult":
        return SaliencyResult(
            method=self.method,
            scores={name: value.detach().float().cpu() for name, value in self.scores.items()},
            raw_scores={name: value.detach().float().cpu() for name, value in self.raw_scores.items()},
            diagnostics=dict(self.diagnostics),
        )


def compute_method_scores(
    model: nn.Module,
    loader: DataLoader | None,
    config: Mapping[str, Any],
    device: torch.device,
    *,
    distributed_reduce: bool = False,
) -> SaliencyResult:
    """Compute structured keep-importance scores.

    The function intentionally accepts only an ordinary module.  DDP wrappers
    register reducer hooks and buffer broadcasts that are inappropriate for the
    local saliency forward/autograd phase.  Distributed callers unwrap the model,
    process one deterministic calibration shard per rank, and explicitly reduce
    FP32 accumulators only at the phase boundary.
    """

    if isinstance(model, DDP):
        raise TypeError(
            "compute_method_scores received DistributedDataParallel. Pass the "
            "unwrapped module and set distributed_reduce explicitly."
        )

    method = str(config["pruning"]["method"]).lower()
    named_units: list[tuple[str, StructuredPruningUnit]] = iter_prunable_units(model, named=True)
    if not named_units:
        raise ValueError("The selected model exposes no structured pruning units")
    reduction = str(config["pruning"].get("score_reduction", "mean"))

    if method == "dense":
        raw = {name: torch.full((unit.num_units,), float("inf")) for name, unit in named_units}
        return SaliencyResult(method, raw, raw, {"note": "Dense baseline does not prune"})
    if method == "random":
        generator = torch.Generator(device="cpu").manual_seed(
            int(config["pruning"].get("random_seed", 123))
        )
        raw = {name: torch.rand(unit.num_units, generator=generator) for name, unit in named_units}
        return _finalize_scores(method, named_units, raw, config, {})
    if method == "magnitude":
        raw = {
            name: unit.magnitude_scores(reduction=reduction).detach().cpu()
            for name, unit in named_units
        }
        return _finalize_scores(method, named_units, raw, config, {})
    if loader is None:
        raise ValueError(f"Pruning method {method} requires a calibration loader")

    model.eval()
    max_batches = int(config["pruning"].get("score_batches", 8))
    channels_last = bool(config["model"].get("channels_last", False)) and device.type == "cuda"
    amp_dtype = _saliency_amp_dtype(str(config["train"].get("amp", "none")), device)
    bucket_mb = float(config["pruning"].get("saliency_reduce_bucket_mb", 64.0))

    if method in {"spectral_steering", "taylor", "lfs"}:
        return _spectral_family_scores(
            method,
            model,
            loader,
            config,
            device,
            named_units,
            max_batches=max_batches,
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )

    if method in {"frequency_steering", "steering_only"}:
        parameters = unique_parameters(unit for _, unit in named_units)
        lam = 0.0 if method == "steering_only" else float(config["pruning"].get("lambda", 1.0))
        direction = str(config["pruning"].get("steering", "high")).lower()
        low_formula = str(config["pruning"].get("low_steering_formula", "swap")).lower()
        coefficients = _steering_coefficients(direction, low_formula, lam)
        abs_after_combine = bool(config["pruning"].get("saliency_abs_after_combine", True))

        with _RequiresGradGuard(parameters, freeze=list(model.parameters())):
            if abs_after_combine:
                combined_gradients, diagnostics = _frequency_combined_gradients(
                    model,
                    loader,
                    parameters,
                    device,
                    max_batches,
                    float(config["pruning"].get("cutoff", 0.25)),
                    str(config["pruning"].get("cutoff_mode", "relative")),
                    float(config["pruning"].get("transition_width", 0.0)),
                    str(config["pruning"].get("hp_dc_mode", "image_mean")),
                    channels_last,
                    amp_dtype,
                    coefficients=coefficients,
                    distributed_reduce=distributed_reduce,
                    bucket_mb=bucket_mb,
                )
                parameter_values = {
                    parameter: (combined_gradients[parameter] * parameter.detach().float()).abs()
                    for parameter in parameters
                }
            else:
                grad_lp, grad_hp, diagnostics = _frequency_gradients_separate(
                    model,
                    loader,
                    parameters,
                    device,
                    max_batches,
                    float(config["pruning"].get("cutoff", 0.25)),
                    str(config["pruning"].get("cutoff_mode", "relative")),
                    float(config["pruning"].get("transition_width", 0.0)),
                    str(config["pruning"].get("hp_dc_mode", "image_mean")),
                    channels_last,
                    amp_dtype,
                    distributed_reduce=distributed_reduce,
                    bucket_mb=bucket_mb,
                )
                parameter_values: Dict[nn.Parameter, Tensor] = {}
                for parameter in parameters:
                    lp = grad_lp[parameter]
                    hp = grad_hp[parameter]
                    target_grad, opposite_grad = (
                        (hp, lp) if direction == "high" else (lp, hp)
                    )
                    parameter_values[parameter] = (
                        (target_grad * parameter.detach().float()).abs()
                        - lam * (opposite_grad * parameter.detach().float()).abs()
                    )

        raw = {
            name: unit.aggregate_parameter_scores(parameter_values, reduction=reduction).detach().cpu()
            for name, unit in named_units
        }
        diagnostics.update(
            {
                "lambda": lam,
                "cutoff": float(config["pruning"].get("cutoff", 0.25)),
                "steering": direction,
                "low_steering_formula": low_formula,
                "formula": (
                    "abs((g_target - lambda*g_opposite) * w)"
                    if abs_after_combine
                    else "abs(g_target*w) - lambda*abs(g_opposite*w)"
                ),
                "gradient_accumulation_dtype": "float32",
                "combined_gradient_accumulator": abs_after_combine,
                "frequency_coefficients": coefficients,
            }
        )
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    if method == "snip":
        parameters = unique_parameters(unit for _, unit in named_units)
        with _RequiresGradGuard(parameters, freeze=list(model.parameters())):
            gradients, diagnostics = _clean_gradients(
                model,
                loader,
                parameters,
                device,
                max_batches,
                channels_last,
                amp_dtype,
                distributed_reduce=distributed_reduce,
                bucket_mb=bucket_mb,
            )
        parameter_values = {
            parameter: (gradients[parameter] * parameter.detach().float()).abs()
            for parameter in parameters
        }
        raw = {
            name: unit.aggregate_parameter_scores(parameter_values, reduction=reduction).detach().cpu()
            for name, unit in named_units
        }
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    if method == "hap":
        raw, diagnostics = _hap_gate_scores(
            model,
            loader,
            named_units,
            device,
            max_batches=max_batches,
            hutchinson_samples=int(config["pruning"].get("hap_samples", 1)),
            mode=str(config["pruning"].get("hap_mode", "gate_empirical_fisher")),
            microbatch_size=int(config["pruning"].get("hap_microbatch_size", 8)),
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
        )
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    raise ValueError(f"Unsupported pruning method: {method}")


def compute_method_scores_for_context(
    model: nn.Module,
    loader: DataLoader | None,
    config: Mapping[str, Any],
    context: DistributedContext,
) -> SaliencyResult:
    """Execute saliency under a collective-safe distributed policy."""

    execution = str(config["pruning"].get("saliency_execution", "all_ranks")).lower()
    if not context.distributed:
        result = compute_method_scores(
            unwrap_model(model),
            loader,
            config,
            context.device,
            distributed_reduce=False,
        )
        result.diagnostics.update(
            {"saliency_execution": "single_process", "saliency_world_size": 1}
        )
        return result

    if execution not in {"all", "all_ranks", "sharded", "all_rank_sharded"}:
        raise DistributedSaliencyError(
            "Distributed rank-0-only saliency is disabled because it caused the "
            "observed NCCL collective mismatch. Use pruning.saliency_execution=all_ranks."
        )

    result: SaliencyResult | None = None
    local_error: BaseException | None = None
    local_trace = ""
    try:
        result = compute_method_scores(
            unwrap_model(model),
            loader,
            config,
            context.device,
            distributed_reduce=True,
        )
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, context.device)

    # This outer phase boundary also covers errors that occur before a method's
    # accumulator helper is entered (model/unit discovery, configuration, or
    # method dispatch).  Healthy ranks never proceed to pruning while a peer has
    # already left the saliency state machine.
    synchronize_failures(
        local_error,
        phase=f"saliency_dispatch/{config['pruning'].get('method', 'unknown')}",
        local_traceback=local_trace,
    )
    if result is None:  # synchronize_failures raises when local_error is set.
        raise DistributedSaliencyError("Saliency completed without a result")
    result.diagnostics.update(
        {
            "saliency_execution": "all_ranks_sharded",
            "saliency_world_size": context.world_size,
            "control_backend": context.control_backend,
        }
    )
    # A compact deterministic fingerprint catches sampler, model-mask, or score
    # divergence before ranks independently select different pruning units.
    consensus = {
        name: {
            "numel": int(value.numel()),
            "finite": int(torch.isfinite(value).sum().item()),
            "sum": float(torch.nan_to_num(value.double(), posinf=0.0, neginf=0.0).sum().item()),
            "sum_sq": float(
                torch.nan_to_num(value.double(), posinf=0.0, neginf=0.0).square().sum().item()
            ),
        }
        for name, value in sorted(result.scores.items())
    }
    assert_consensus(consensus, phase=f"saliency_consensus/{result.method}")
    result.diagnostics["score_consensus_verified"] = True
    return result


def _spectral_family_scores(
    method: str,
    model: nn.Module,
    loader: DataLoader,
    config: Mapping[str, Any],
    device: torch.device,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    *,
    max_batches: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    distributed_reduce: bool,
    bucket_mb: float,
) -> SaliencyResult:
    """Gate-level Taylor-FO (``taylor``), low-frequency Taylor (``lfs``) and
    Spectral-Steering (``spectral_steering``).

    All three share the same gate-level first-order machinery, so the only
    difference between ``taylor`` and ``spectral_steering`` is the spectral term:
    ``spectral_steering`` with ``lambda=0`` or ``target_profile=flat`` is exactly
    ``taylor``.
    """

    from .spectral import (
        accumulate_spectral_statistics,
        band_masks,
        band_names,
        combine_spectral_scores,
        density_profile,
        measure_reliance,
        profile_mismatch,
        spectral_config,
        steering_weights,
        unit_contribution_table,
        _normalize_profile,
    )

    pruning_cfg = config["pruning"]
    spectral = spectral_config(pruning_cfg)
    edges = spectral["band_edges"]
    num_bands = len(edges) - 1
    gates = [unit.gate for _, unit in named_units]
    reduction = str(pruning_cfg.get("score_reduction", "mean"))
    diagnostics: Dict[str, Any] = {
        "band_edges": edges,
        "band_names": band_names(edges),
        "taylor_level": "gate",
        "taylor_reduction": spectral["taylor_reduction"],
        "gradient_accumulation_dtype": "float32",
    }

    input_transform = None
    if method == "lfs":
        # VTC-LFC style: importance estimated only from low-pass filtered inputs.
        cutoff = float(pruning_cfg.get("cutoff", 0.25))

        def input_transform(images: Tensor, _cutoff: float = cutoff) -> Tensor:  # type: ignore[misc]
            lp, _ = split_frequency(
                images,
                _cutoff,
                cutoff_mode=str(pruning_cfg.get("cutoff_mode", "relative")),
                transition_width=float(pruning_cfg.get("transition_width", 0.0)),
                hp_dc_mode=str(pruning_cfg.get("hp_dc_mode", "image_mean")),
            )
            return lp

        diagnostics["lfs_cutoff"] = cutoff

    estimator = spectral["estimator"] if method == "spectral_steering" else "taylor_only"
    with _RequiresGradGuard(gates, freeze=list(model.parameters())):
        acc = accumulate_spectral_statistics(
            model,
            loader,
            named_units,
            device,
            estimator=estimator,
            edges=edges,
            max_batches=max_batches,
            microbatch_size=spectral["microbatch_size"],
            taylor_reduction=spectral["taylor_reduction"],
            channels_last=channels_last,
            amp_dtype=amp_dtype,
            noise_samples_per_band=spectral["noise_samples_per_band"],
            noise_amplitude=spectral["noise_amplitude"],
            distributed_reduce=distributed_reduce,
            bucket_mb=bucket_mb,
            input_transform=input_transform,
        )

    if method in {"taylor", "lfs"}:
        raw, combo = combine_spectral_scores(
            acc,
            named_units,
            weights=[0.0] * num_bands,
            lam=0.0,
            signed=True,
            estimator="exact",
        )
        diagnostics.update(combo)
        diagnostics["estimator"] = method
        diagnostics["target_profile"] = "flat"
        diagnostics["formula"] = "mean_batches |dL/dgate_g|" + (" on low-pass inputs" if method == "lfs" else "")
        return _finalize_scores(method, named_units, raw, config, diagnostics)

    # ------------------------------------------------------------------
    # Spectral steering: derive the target weights from task reliance and the
    # current sensitivity profile, then combine.
    # ------------------------------------------------------------------
    sensitivity_profile = _normalize_profile([float(v) for v in acc.band_power.tolist()])
    if spectral["profile_normalization"] == "density" and acc.band_area:
        sensitivity_profile = density_profile([float(v) for v in acc.band_power.tolist()], acc.band_area)
    target_mode = spectral["target_profile"]
    reliance: Dict[str, Any] | None = None
    if target_mode in {"auto", "mismatch", "reliance"}:
        cached = getattr(model, "_fsp_reliance_profile", None)
        if cached is not None and spectral["reliance_source"] == "dense":
            reliance = cached
            diagnostics["reliance_profile_source"] = "cached_dense"
        else:
            reliance = measure_reliance(
                model,
                loader,
                device,
                edges,
                max_batches=spectral["reliance_batches"],
                channels_last=channels_last,
                keep_dc=spectral["keep_dc"],
                distributed_reduce=distributed_reduce,
            )
            reliance["reliance_profile"] = (
                density_profile(reliance["reliance_loss"], acc.band_area)
                if spectral["profile_normalization"] == "density" and acc.band_area
                else _normalize_profile(reliance["reliance_loss"])
            )
            if spectral["reliance_source"] == "dense" and cached is None:
                try:
                    model._fsp_reliance_profile = reliance  # type: ignore[attr-defined]
                except Exception:  # pragma: no cover - defensive
                    pass
            diagnostics["reliance_profile_source"] = "measured_" + spectral["reliance_source"]
    weights = steering_weights(
        target_mode,
        num_bands,
        reliance_profile=None if reliance is None else reliance["reliance_profile"],
        sensitivity_profile=sensitivity_profile,
        manual=spectral["manual_weights"],
    )
    raw, combo = combine_spectral_scores(
        acc,
        named_units,
        weights=weights,
        lam=spectral["lambda"],
        signed=spectral["signed"],
        estimator=spectral["estimator"],
    )
    diagnostics.update(combo)
    diagnostics.update(
        {
            "target_profile": target_mode,
            "sensitivity_profile": sensitivity_profile,
            "reliance_profile": None if reliance is None else reliance["reliance_profile"],
            "reliance_loss": None if reliance is None else reliance["reliance_loss"],
            "reliance_accuracy_drop": None if reliance is None else reliance["reliance_accuracy_drop"],
            "profile_mismatch_l1": (
                None if reliance is None else profile_mismatch(reliance["reliance_profile"], sensitivity_profile)
            ),
            "formula": "I0/mean(I0) + lambda * (sum_b w_b c_gb)/mean|.|, c_gb=(dS_b/dgate_g)/S_b",
            "microbatch_size": spectral["microbatch_size"],
            "profile_normalization": spectral["profile_normalization"],
            "band_area": list(acc.band_area),
        }
    )
    result = _finalize_scores(method, named_units, raw, config, diagnostics)
    # Per-unit band contributions are kept for analysis plots (saliency_round_XX.pt).
    result.diagnostics["unit_band_contribution"] = {
        name: value.tolist() for name, value in unit_contribution_table(acc).items()
    }
    return result


def _steering_coefficients(direction: str, low_formula: str, lam: float) -> Dict[str, float]:
    if direction == "high":
        return {"hp": 1.0, "lp": -float(lam)}
    if direction != "low":
        raise ValueError(f"Unsupported steering direction: {direction}")
    if low_formula == "swap":
        return {"lp": 1.0, "hp": -float(lam)}
    if low_formula in {"inverse_ratio", "reverse_ratio"}:
        return {"lp": float(lam), "hp": -1.0}
    raise ValueError(f"Unsupported low_steering_formula: {low_formula}")


def _finalize_scores(
    method: str,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    raw_scores: Mapping[str, Tensor],
    config: Mapping[str, Any],
    diagnostics: Dict[str, Any],
) -> SaliencyResult:
    normalization = str(config["pruning"].get("layer_normalization", "none")).lower()
    output: Dict[str, Tensor] = {}
    for name, unit in named_units:
        value = raw_scores[name].detach().float().clone().cpu()
        active = unit.active_mask().cpu()
        finite_active = active & torch.isfinite(value)
        if normalization not in {"none", "", "false"} and finite_active.any():
            subset = value[finite_active]
            if normalization == "mean":
                value = value / subset.abs().mean().clamp_min(1e-12)
            elif normalization == "l2":
                value = value / subset.square().mean().sqrt().clamp_min(1e-12)
            elif normalization == "zscore":
                value = (value - subset.mean()) / subset.std(unbiased=False).clamp_min(1e-12)
            elif normalization == "rank":
                ranks = torch.empty_like(subset)
                order = torch.argsort(subset)
                ranks[order] = torch.linspace(0.0, 1.0, subset.numel())
                value[finite_active] = ranks
            else:
                raise ValueError(f"Unsupported layer_normalization: {normalization}")
        value[~active] = float("inf")
        output[name] = value
    diagnostics = dict(diagnostics)
    diagnostics["layer_normalization"] = normalization
    diagnostics["score_reduction"] = str(config["pruning"].get("score_reduction", "mean"))
    diagnostics["num_structured_groups"] = len(named_units)
    diagnostics["num_units"] = sum(unit.num_units for _, unit in named_units)
    return SaliencyResult(
        method,
        output,
        {name: value.detach().float().cpu() for name, value in raw_scores.items()},
        diagnostics,
    )


def _capture_local_error(error: BaseException, device: torch.device) -> tuple[BaseException, str]:
    trace = traceback.format_exc()
    if isinstance(error, torch.OutOfMemoryError) and device.type == "cuda":
        torch.cuda.empty_cache()
    return error, trace


def _frequency_combined_gradients(
    model: nn.Module,
    loader: DataLoader,
    params: Sequence[nn.Parameter],
    device: torch.device,
    max_batches: int,
    cutoff: float,
    cutoff_mode: str,
    transition_width: float,
    hp_dc_mode: str,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    *,
    coefficients: Mapping[str, float],
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[nn.Parameter, Tensor], Dict[str, Any]]:
    sums = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    scalar = torch.zeros(3, dtype=torch.float64, device=device)  # count, lp loss, hp loss
    local_batches = 0
    local_error: BaseException | None = None
    local_trace = ""
    computed = {"lp": False, "hp": False}

    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            lp, hp = split_frequency(
                images,
                cutoff,
                cutoff_mode=cutoff_mode,
                transition_width=transition_width,
                hp_dc_mode=hp_dc_mode,
            )
            views = {"lp": lp, "hp": hp}
            for name in ("hp", "lp"):
                coefficient = float(coefficients.get(name, 0.0))
                if coefficient == 0.0:
                    continue
                computed[name] = True
                with autocast_context(device, amp_dtype):
                    loss = F.cross_entropy(model(views[name]), target, reduction="sum")
                gradients = torch.autograd.grad(loss, params, allow_unused=True)
                for parameter, gradient in zip(params, gradients):
                    if gradient is not None:
                        sums[parameter].add_(gradient.detach().float(), alpha=coefficient)
                scalar[1 if name == "lp" else 2] += loss.detach().double()
                del gradients, loss
            scalar[0] += target.numel()
            local_batches += 1
            del views, lp, hp, images, target
        if scalar[0].item() <= 0:
            raise RuntimeError("Frequency saliency consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)

    synchronize_failures(
        local_error,
        phase="frequency_saliency_local",
        local_traceback=local_trace,
    )
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(
            sums.values(), enabled=True, bucket_mb=bucket_mb
        )
    denominator = float(scalar[0].clamp_min(1).item())
    for value in sums.values():
        value.div_(denominator)
    return sums, {
        "calibration_samples": int(scalar[0].item()),
        "calibration_batches_local": local_batches,
        "lp_loss": float(scalar[1].item() / denominator) if computed["lp"] else None,
        "hp_loss": float(scalar[2].item() / denominator) if computed["hp"] else None,
        "computed_lp_gradient": computed["lp"],
        "computed_hp_gradient": computed["hp"],
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
        "gradient_accumulators": 1,
    }


def _frequency_gradients_separate(
    model: nn.Module,
    loader: DataLoader,
    params: Sequence[nn.Parameter],
    device: torch.device,
    max_batches: int,
    cutoff: float,
    cutoff_mode: str,
    transition_width: float,
    hp_dc_mode: str,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    *,
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[nn.Parameter, Tensor], Dict[nn.Parameter, Tensor], Dict[str, Any]]:
    sum_lp = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    sum_hp = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    scalar = torch.zeros(3, dtype=torch.float64, device=device)
    local_batches = 0
    local_error: BaseException | None = None
    local_trace = ""
    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            lp, hp = split_frequency(
                images,
                cutoff,
                cutoff_mode=cutoff_mode,
                transition_width=transition_width,
                hp_dc_mode=hp_dc_mode,
            )
            with autocast_context(device, amp_dtype):
                loss_hp = F.cross_entropy(model(hp), target, reduction="sum")
            gradients_hp = torch.autograd.grad(loss_hp, params, allow_unused=True)
            with autocast_context(device, amp_dtype):
                loss_lp = F.cross_entropy(model(lp), target, reduction="sum")
            gradients_lp = torch.autograd.grad(loss_lp, params, allow_unused=True)
            for parameter, gradient in zip(params, gradients_hp):
                if gradient is not None:
                    sum_hp[parameter].add_(gradient.detach().float())
            for parameter, gradient in zip(params, gradients_lp):
                if gradient is not None:
                    sum_lp[parameter].add_(gradient.detach().float())
            scalar[0] += target.numel()
            scalar[1] += loss_lp.detach().double()
            scalar[2] += loss_hp.detach().double()
            local_batches += 1
        if scalar[0].item() <= 0:
            raise RuntimeError("Frequency saliency consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)
    synchronize_failures(local_error, phase="frequency_saliency_local", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(sum_lp.values(), enabled=True, bucket_mb=bucket_mb)
        coalesced_all_reduce_(sum_hp.values(), enabled=True, bucket_mb=bucket_mb)
    denominator = float(scalar[0].clamp_min(1).item())
    for parameter in params:
        sum_lp[parameter].div_(denominator)
        sum_hp[parameter].div_(denominator)
    return sum_lp, sum_hp, {
        "calibration_samples": int(scalar[0].item()),
        "calibration_batches_local": local_batches,
        "lp_loss": float(scalar[1].item() / denominator),
        "hp_loss": float(scalar[2].item() / denominator),
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
        "gradient_accumulators": 2,
    }


def _clean_gradients(
    model: nn.Module,
    loader: DataLoader,
    params: Sequence[nn.Parameter],
    device: torch.device,
    max_batches: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    *,
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[nn.Parameter, Tensor], Dict[str, Any]]:
    sums = {parameter: torch.zeros_like(parameter, dtype=torch.float32) for parameter in params}
    scalar = torch.zeros(2, dtype=torch.float64, device=device)
    local_batches = 0
    local_error: BaseException | None = None
    local_trace = ""
    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images, target = batch[:2]
            images = move_batch_to_device(images, device, channels_last)
            target = target.to(device, non_blocking=True)
            with autocast_context(device, amp_dtype):
                loss = F.cross_entropy(model(images), target, reduction="sum")
            gradients = torch.autograd.grad(loss, params, allow_unused=True)
            for parameter, gradient in zip(params, gradients):
                if gradient is not None:
                    sums[parameter].add_(gradient.detach().float())
            scalar[0] += target.numel()
            scalar[1] += loss.detach().double()
            local_batches += 1
            del gradients, loss, images, target
        if scalar[0].item() <= 0:
            raise RuntimeError("Clean saliency consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)
    synchronize_failures(local_error, phase="clean_saliency_local", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(sums.values(), enabled=True, bucket_mb=bucket_mb)
    denominator = float(scalar[0].clamp_min(1).item())
    for value in sums.values():
        value.div_(denominator)
    return sums, {
        "calibration_samples": int(scalar[0].item()),
        "calibration_batches_local": local_batches,
        "clean_loss": float(scalar[1].item() / denominator),
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
    }


def _hap_gate_scores(
    model: nn.Module,
    loader: DataLoader,
    named_units: Sequence[tuple[str, StructuredPruningUnit]],
    device: torch.device,
    *,
    max_batches: int,
    hutchinson_samples: int,
    mode: str,
    microbatch_size: int,
    channels_last: bool,
    amp_dtype: torch.dtype | None,
    distributed_reduce: bool,
    bucket_mb: float,
) -> tuple[Dict[str, Tensor], Dict[str, Any]]:
    """Low-memory HAP on structural gate variables, never full model weights."""

    normalized_mode = mode.lower().replace("-", "_")
    if normalized_mode in {"exact", "hessian", "hessian_diag", "exact_hessian"}:
        raise ValueError(
            "Exact gate-Hessian diagonal scoring is not implemented. Use "
            "gate_hutchinson for the explicit stochastic gate-Hessian estimator "
            "or gate_empirical_fisher for the production baseline."
        )
    aliases = {
        "fisher": "gate_empirical_fisher",
        "empirical_fisher": "gate_empirical_fisher",
        "gate_fisher": "gate_empirical_fisher",
        "minibatch_empirical_fisher": "gate_empirical_fisher",
        "hutchinson": "gate_hutchinson",
    }
    normalized_mode = aliases.get(normalized_mode, normalized_mode)
    if normalized_mode not in {"gate_empirical_fisher", "gate_hutchinson"}:
        raise ValueError(
            "pruning.hap_mode must be gate_empirical_fisher or gate_hutchinson; "
            f"got {mode!r}"
        )

    gates = [unit.gate for _, unit in named_units]
    structural_variables = sum(gate.numel() for gate in gates)
    max_variables = int(1_000_000)
    if structural_variables > max_variables:
        raise RuntimeError(
            f"Gate-level HAP refuses {structural_variables} variables; limit={max_variables}"
        )
    microbatch_size = max(1, int(microbatch_size))
    hutchinson_samples = max(1, int(hutchinson_samples))
    accumulators = {
        name: torch.zeros(unit.num_units, dtype=torch.float32, device=device)
        for name, unit in named_units
    }
    scalar = torch.zeros(2, dtype=torch.float64, device=device)
    local_microbatches = 0
    local_error: BaseException | None = None
    local_trace = ""

    try:
        with _RequiresGradGuard(gates, freeze=list(model.parameters())):
            for batch_index, batch in enumerate(loader):
                if max_batches > 0 and batch_index >= max_batches:
                    break
                images, target = batch[:2]
                for start in range(0, int(target.shape[0]), microbatch_size):
                    stop = min(int(target.shape[0]), start + microbatch_size)
                    image_chunk = move_batch_to_device(images[start:stop], device, channels_last)
                    target_chunk = target[start:stop].to(device, non_blocking=True)
                    chunk_size = int(target_chunk.numel())
                    if normalized_mode == "gate_empirical_fisher":
                        with autocast_context(device, amp_dtype):
                            loss = F.cross_entropy(
                                model(image_chunk), target_chunk, reduction="mean"
                            )
                        gradients = torch.autograd.grad(loss, gates, allow_unused=True)
                        for (name, _), gradient in zip(named_units, gradients):
                            if gradient is not None:
                                accumulators[name].add_(
                                    gradient.detach().float().square(), alpha=chunk_size
                                )
                        del gradients
                    else:
                        with torch.autocast(device_type=device.type, enabled=False):
                            loss = F.cross_entropy(
                                model(image_chunk.float()), target_chunk, reduction="mean"
                            )
                            first = torch.autograd.grad(
                                loss, gates, create_graph=True, allow_unused=True
                            )
                            for sample_index in range(hutchinson_samples):
                                # Deterministic across retries/ranks for a fixed
                                # shard and microbatch index.
                                generator = torch.Generator(device=device).manual_seed(
                                    104729 * (batch_index + 1)
                                    + 1009 * (start + 1)
                                    + sample_index
                                )
                                vectors = [
                                    torch.empty_like(gate, dtype=torch.float32)
                                    .bernoulli_(0.5, generator=generator)
                                    .mul_(2)
                                    .sub_(1)
                                    if gradient is not None
                                    else None
                                    for gate, gradient in zip(gates, first)
                                ]
                                terms = [
                                    (gradient.float() * vector).sum()
                                    for gradient, vector in zip(first, vectors)
                                    if gradient is not None and vector is not None
                                ]
                                if not terms:
                                    raise RuntimeError(
                                        "No structural gate participates in the HAP graph"
                                    )
                                dot = torch.stack(terms).sum()
                                hvp = torch.autograd.grad(
                                    dot,
                                    gates,
                                    retain_graph=sample_index + 1 < hutchinson_samples,
                                    allow_unused=True,
                                )
                                for (name, _), vector, value in zip(
                                    named_units, vectors, hvp
                                ):
                                    if vector is not None and value is not None:
                                        accumulators[name].add_(
                                            (vector * value.detach().float()).abs(),
                                            alpha=chunk_size,
                                        )
                                del hvp, dot, terms, vectors
                            del first
                    scalar[0] += chunk_size
                    scalar[1] += loss.detach().double() * chunk_size
                    local_microbatches += 1
                    del loss, image_chunk, target_chunk
        if scalar[0].item() <= 0:
            raise RuntimeError("HAP consumed zero calibration samples")
    except BaseException as error:
        local_error, local_trace = _capture_local_error(error, device)

    synchronize_failures(local_error, phase="hap_saliency_local", local_traceback=local_trace)
    if distributed_reduce:
        torch.distributed.all_reduce(scalar, op=torch.distributed.ReduceOp.SUM)
        coalesced_all_reduce_(
            accumulators.values(), enabled=True, bucket_mb=bucket_mb
        )
    denominator = float(scalar[0].clamp_min(1).item())
    if normalized_mode == "gate_hutchinson":
        denominator *= hutchinson_samples
    scores: Dict[str, Tensor] = {}
    for name, unit in named_units:
        diagonal = accumulators[name] / max(denominator, 1.0)
        scores[name] = (
            0.5 * unit.gate.detach().float().square() * diagonal
        ).cpu()
    diagnostics: Dict[str, Any] = {
        "hap_mode_requested": mode,
        "hap_estimator": (
            "mini_batch_empirical_fisher_gate_diagonal"
            if normalized_mode == "gate_empirical_fisher"
            else "hutchinson_absolute_gate_hessian_diagonal"
        ),
        "hap_structural_variables": structural_variables,
        "hap_microbatch_size": microbatch_size,
        "hutchinson_samples": (
            hutchinson_samples if normalized_mode == "gate_hutchinson" else 0
        ),
        "calibration_samples": int(scalar[0].item()),
        "calibration_microbatches_local": local_microbatches,
        "clean_loss": float(scalar[1].item() / max(float(scalar[0].item()), 1.0)),
        "distributed_reduction": distributed_reduce,
        "reduce_bucket_mb": float(bucket_mb),
        "full_model_second_order_graph": False,
    }
    return scores, diagnostics


def _saliency_amp_dtype(name: str, device: torch.device) -> torch.dtype | None:
    # Accumulators and FFTs remain FP32. BF16 is limited to model forward paths.
    normalized = str(name).lower()
    if normalized == "bf16" and device.type in {"cuda", "cpu"}:
        return torch.bfloat16
    return None
