"""BatchNorm statistics recalibration after structured pruning.

Removing channels changes the input distribution of every downstream
BatchNorm layer.  Re-estimating the running statistics on a few calibration
batches (cumulative average, no gradient) before recovery training is cheap,
method-agnostic, and removes an otherwise large source of variance between
pruning criteria.  Models without BatchNorm (ViT/DeiT) are returned unchanged.
"""
from __future__ import annotations

from typing import Any, Dict

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from frequency_pruning.distributed import unwrap_model
from frequency_pruning.utils import autocast_context, move_batch_to_device


def _batchnorm_modules(model: nn.Module) -> list[nn.modules.batchnorm._BatchNorm]:
    return [m for m in unwrap_model(model).modules() if isinstance(m, nn.modules.batchnorm._BatchNorm)]


@torch.no_grad()
def recalibrate_batchnorm(
    model: nn.Module,
    loader: DataLoader | None,
    device: torch.device,
    *,
    max_batches: int,
    channels_last: bool = False,
    amp_dtype: torch.dtype | None = None,
) -> Dict[str, Any]:
    """Reset and re-estimate BatchNorm running statistics in place."""
    modules = _batchnorm_modules(model)
    if max_batches <= 0 or loader is None or not modules:
        return {"recalibrated": False, "batchnorm_layers": len(modules), "batches": 0}
    raw = unwrap_model(model)
    was_training = raw.training
    momenta = []
    for module in modules:
        momenta.append(module.momentum)
        module.reset_running_stats()
        module.momentum = None  # cumulative moving average
    raw.train()
    # Only BatchNorm should be in training mode: keep dropout/stochastic depth off.
    for module in raw.modules():
        if not isinstance(module, nn.modules.batchnorm._BatchNorm):
            module.training = False
    for module in modules:
        module.training = True
    batches = 0
    for batch_index, batch in enumerate(loader):
        if batch_index >= max_batches:
            break
        images = move_batch_to_device(batch[0], device, channels_last and device.type == "cuda")
        with autocast_context(device, amp_dtype):
            raw(images)
        batches += 1
    for module, momentum in zip(modules, momenta):
        module.momentum = momentum
    raw.train(was_training)
    return {"recalibrated": True, "batchnorm_layers": len(modules), "batches": batches}
