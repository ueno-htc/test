from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader

from .distributed import all_reduce_, is_main_process
from .fourier import denormalize, normalize, radial_profile
from .models import feature_modules
from .utils import autocast_context, move_batch_to_device, save_json


def _amp_dtype(name: str, device: torch.device) -> torch.dtype | None:
    if device.type == "cuda" and str(name).lower() == "bf16":
        return torch.bfloat16
    if device.type == "cuda" and str(name).lower() == "fp16":
        return torch.float16
    if device.type == "cpu" and str(name).lower() == "bf16":
        return torch.bfloat16
    return None


def _sinusoidal_perturbation(images: Tensor, fx: float, fy: float, amplitude: float, phase: float) -> Tensor:
    batch, channels, height, width = images.shape
    yy = torch.linspace(-0.5, 0.5, height, device=images.device, dtype=torch.float32)
    xx = torch.linspace(-0.5, 0.5, width, device=images.device, dtype=torch.float32)
    grid_y, grid_x = torch.meshgrid(yy, xx, indexing="ij")
    wave = torch.sin(2.0 * math.pi * (fx * grid_x + fy * grid_y) + phase)
    raw = denormalize(images.float())
    perturbed = (raw + float(amplitude) * wave.view(1, 1, height, width)).clamp(0.0, 1.0)
    return normalize(perturbed).to(images.dtype)


@torch.inference_mode()
def compute_fourier_sensitivity_heatmap(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    *,
    resolution: int = 17,
    amplitude: float = 0.15,
    max_batches: int = 4,
    amp: str = "none",
    channels_last: bool = False,
    reduce_distributed: bool = True,
) -> np.ndarray:
    """Measure true-class loss increase for sinusoidal perturbations over a 2-D grid."""
    model.eval()
    resolution = int(resolution)
    coordinates = torch.linspace(-1.0, 1.0, resolution)
    heat = torch.zeros((resolution, resolution), dtype=torch.float64, device=device)
    counts = torch.zeros_like(heat)
    dtype = _amp_dtype(amp, device)

    cached: list[tuple[Tensor, Tensor, Tensor]] = []
    for batch_index, batch in enumerate(loader):
        if max_batches > 0 and batch_index >= max_batches:
            break
        images, target = batch[:2]
        images = move_batch_to_device(images, device, channels_last and device.type == "cuda")
        target = target.to(device, non_blocking=True)
        with autocast_context(device, dtype):
            clean_loss = F.cross_entropy(model(images), target, reduction="none")
        cached.append((images, target, clean_loss.float()))

    frequency_scale = min(cached[0][0].shape[-2:]) / 2.0 if cached else 1.0
    for row, fy_norm in enumerate(coordinates.tolist()):
        for col, fx_norm in enumerate(coordinates.tolist()):
            fx = fx_norm * frequency_scale
            fy = fy_norm * frequency_scale
            total_delta = torch.zeros(1, device=device, dtype=torch.float64)
            total_count = 0
            for images, target, clean_loss in cached:
                phase_deltas = []
                for phase in (0.0, math.pi / 2.0):
                    perturbed = _sinusoidal_perturbation(images, fx, fy, amplitude, phase)
                    with autocast_context(device, dtype):
                        loss = F.cross_entropy(model(perturbed), target, reduction="none")
                    phase_deltas.append((loss.float() - clean_loss).abs())
                delta = torch.stack(phase_deltas).mean(dim=0)
                total_delta += delta.double().sum()
                total_count += delta.numel()
            heat[row, col] = total_delta
            counts[row, col] = total_count
    if reduce_distributed:
        all_reduce_(heat)
        all_reduce_(counts)
    return (heat / counts.clamp_min(1)).cpu().numpy()


def _activation_to_spatial(output: Any) -> Tensor | None:
    if isinstance(output, (tuple, list)):
        output = next((value for value in output if isinstance(value, Tensor)), None)
    if not isinstance(output, Tensor):
        return None
    if output.ndim == 4:
        return output
    if output.ndim == 3:
        # Transformer tokens: remove CLS token when present and recover patch grid.
        tokens = output
        count = tokens.shape[1]
        grid = int(round(math.sqrt(count - 1)))
        if grid * grid == count - 1:
            tokens = tokens[:, 1:]
        else:
            grid = int(round(math.sqrt(count)))
        if grid * grid != tokens.shape[1]:
            return None
        return tokens.transpose(1, 2).reshape(tokens.shape[0], tokens.shape[2], grid, grid)
    return None


@torch.inference_mode()
def compute_layer_frequency_maps(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    *,
    max_batches: int = 4,
    target_size: int = 64,
    amp: str = "none",
    channels_last: bool = False,
    max_layers: int = 0,
    reduce_distributed: bool = True,
) -> Dict[str, np.ndarray]:
    model.eval()
    modules = list(feature_modules(model).items())
    if max_layers > 0 and len(modules) > max_layers:
        indices = np.linspace(0, len(modules) - 1, max_layers).round().astype(int)
        modules = [modules[index] for index in indices]
    accumulators = {name: torch.zeros((target_size, target_size), dtype=torch.float64, device=device) for name, _ in modules}
    counts = {name: torch.zeros(1, dtype=torch.float64, device=device) for name, _ in modules}
    hooks = []

    def make_hook(name: str):
        def hook(_module, _input, output):
            spatial = _activation_to_spatial(output)
            if spatial is None:
                return
            spatial = spatial.detach().float()
            spatial = spatial - spatial.mean(dim=(-2, -1), keepdim=True)
            spectrum = torch.fft.fftshift(torch.fft.fft2(spatial, dim=(-2, -1), norm="ortho"), dim=(-2, -1))
            power = spectrum.abs().square().mean(dim=(0, 1), keepdim=True)
            power = F.interpolate(power, size=(target_size, target_size), mode="bilinear", align_corners=False)[0, 0]
            accumulators[name].add_(power.double())
            counts[name].add_(1)
        return hook

    for name, module in modules:
        hooks.append(module.register_forward_hook(make_hook(name)))
    dtype = _amp_dtype(amp, device)
    try:
        for batch_index, batch in enumerate(loader):
            if max_batches > 0 and batch_index >= max_batches:
                break
            images = move_batch_to_device(batch[0], device, channels_last and device.type == "cuda")
            with autocast_context(device, dtype):
                model(images)
    finally:
        for hook in hooks:
            hook.remove()

    result: Dict[str, np.ndarray] = {}
    for name in accumulators:
        if reduce_distributed:
            all_reduce_(accumulators[name])
            all_reduce_(counts[name])
        power = accumulators[name] / counts[name].clamp_min(1)
        power = torch.log1p(power)
        power = power / power.sum().clamp_min(1e-12)
        result[name] = power.cpu().numpy()
    return result


def save_heatmap(array: np.ndarray, path: str | Path, title: str, *, symmetric: bool = False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(6.2, 5.3))
    if symmetric:
        limit = float(np.max(np.abs(array))) if array.size else 1.0
        image = ax.imshow(array, origin="lower", cmap="coolwarm", vmin=-limit, vmax=limit)
    else:
        image = ax.imshow(array, origin="lower", cmap="magma")
    ax.set_title(title)
    ax.set_xlabel("Horizontal spatial frequency")
    ax.set_ylabel("Vertical spatial frequency")
    fig.colorbar(image, ax=ax, shrink=0.85)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def save_layer_maps(
    maps: Mapping[str, np.ndarray],
    output_dir: str | Path,
    prefix: str,
) -> Dict[str, str]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: Dict[str, str] = {}
    for name, array in maps.items():
        safe = name.replace(".", "_").replace("/", "_")
        npy = output_dir / f"{prefix}_{safe}.npy"
        png = output_dir / f"{prefix}_{safe}.png"
        np.save(npy, array)
        save_heatmap(array, png, f"{prefix}: {name}")
        paths[name] = str(png)
    return paths


def compare_frequency_maps(
    dense: Mapping[str, np.ndarray],
    pruned: Mapping[str, np.ndarray],
    output_dir: str | Path,
) -> Dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for name in sorted(set(dense) & set(pruned)):
        before = dense[name]
        after = pruned[name]
        if before.shape != after.shape:
            tensor = torch.from_numpy(after)[None, None]
            after = F.interpolate(tensor, size=before.shape, mode="bilinear", align_corners=False)[0, 0].numpy()
        delta = after - before
        safe = name.replace(".", "_").replace("/", "_")
        np.save(output_dir / f"delta_{safe}.npy", delta)
        save_heatmap(delta, output_dir / f"delta_{safe}.png", f"Pruned - dense: {name}", symmetric=True)
        before_profile = radial_profile(torch.from_numpy(before)).numpy()
        after_profile = radial_profile(torch.from_numpy(after)).numpy()
        n = min(len(before_profile), len(after_profile))
        low = slice(0, max(1, n // 4))
        high = slice(max(0, 3 * n // 4), n)
        rows.append(
            {
                "layer": name,
                "low_power_dense": float(before_profile[low].mean()),
                "low_power_pruned": float(after_profile[low].mean()),
                "high_power_dense": float(before_profile[high].mean()),
                "high_power_pruned": float(after_profile[high].mean()),
                "high_to_low_shift": float(
                    (after_profile[high].mean() / max(after_profile[low].mean(), 1e-12))
                    - (before_profile[high].mean() / max(before_profile[low].mean(), 1e-12))
                ),
            }
        )
    if rows:
        with (output_dir / "layer_frequency_shift.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    save_json(output_dir / "layer_frequency_shift.json", rows)
    return {"rows": rows}


def plot_frequency_error_curve(rows: Sequence[Mapping[str, Any]], path: str | Path, title: str = "Frequency-region error vs sparsity") -> None:
    if not rows:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    ordered = sorted(rows, key=lambda row: float(row.get("sparsity", 0.0)))
    x = [float(row["sparsity"]) for row in ordered]
    fields = [
        ("low_frequency_region_error", "Low-frequency L2 region"),
        ("high_frequency_region_error", "High-frequency L2 region"),
        ("lowpass_error", "Low-pass inputs"),
        ("highpass_error", "High-pass inputs"),
    ]
    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    plotted = False
    for key, label in fields:
        y = [row.get(key) for row in ordered]
        if all(value is not None for value in y):
            ax.plot(x, [float(value) for value in y], marker="o", label=label)
            plotted = True
    if not plotted:
        plt.close(fig)
        return
    ax.set_xlabel("Structured sparsity")
    ax.set_ylabel("Mean error rate (%)")
    ax.set_title(title)
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def plot_imagenet_c_summary(result: Mapping[str, Any], output_dir: str | Path) -> None:
    """Plot corruption-wise means and severity curves from evaluate_imagenet_c."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    by_corruption = result.get("by_corruption", {})
    if by_corruption:
        names = list(by_corruption)
        values = [float(by_corruption[name]) for name in names]
        fig, ax = plt.subplots(figsize=(10.5, 5.0))
        ax.bar(range(len(names)), values)
        ax.set_xticks(range(len(names)), names, rotation=45, ha="right")
        ax.set_ylabel("Top-1 accuracy (%)")
        ax.set_title("ImageNet-C corruption-wise mean")
        ax.grid(True, axis="y", alpha=0.25)
        fig.tight_layout()
        fig.savefig(output_dir / "imagenet_c_by_corruption.png", dpi=180)
        plt.close(fig)
    details = result.get("details", {})
    curves: Dict[str, list[tuple[int, float]]] = {}
    for key, metrics in details.items():
        if "/" not in key or not isinstance(metrics, Mapping):
            continue
        corruption, severity = key.rsplit("/", 1)
        curves.setdefault(corruption, []).append((int(severity), float(metrics["top1"])))
    if curves:
        fig, ax = plt.subplots(figsize=(8.0, 5.5))
        for name, points in sorted(curves.items()):
            points = sorted(points)
            ax.plot([x for x, _ in points], [y for _, y in points], marker="o", label=name)
        ax.set_xticks([1, 2, 3, 4, 5])
        ax.set_xlabel("Severity")
        ax.set_ylabel("Top-1 accuracy (%)")
        ax.set_title("ImageNet-C severity curves")
        ax.grid(True, alpha=0.25)
        ax.legend(fontsize=7, ncol=3)
        fig.tight_layout()
        fig.savefig(output_dir / "imagenet_c_severity_curves.png", dpi=180)
        plt.close(fig)
