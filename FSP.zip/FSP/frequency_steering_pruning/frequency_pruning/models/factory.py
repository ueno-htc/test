from __future__ import annotations

from collections import OrderedDict
from typing import Dict, Iterable, List, Tuple

import torch
import torch.nn as nn

from frequency_pruning.distributed import unwrap_model
from .common import StructuredPruningUnit, UnitDescriptor
from .efficientnet import PrunableEfficientNet, build_prunable_efficientnet_b4, export_slim_efficientnet
from .resnet import PrunableResNet, build_prunable_resnet, export_slim_resnet
from .vit import PrunableVisionTransformer, build_prunable_vit, export_slim_vit


_ARCH_ALIASES = {
    "resnet-50": "resnet50",
    "resnet_50": "resnet50",
    "resnet-18": "resnet18",
    "resnet_18": "resnet18",
    "efficientnet-b4": "efficientnet_b4",
    "efficientnetb4": "efficientnet_b4",
    "vit-b": "vit_b_16",
    "vit_b": "vit_b_16",
    "vit-b/16": "vit_b_16",
    "vit-l": "vit_l_16",
    "vit_l": "vit_l_16",
    "vit-l/16": "vit_l_16",
    "deit-b": "deit_base_patch16_224",
    "deit_b": "deit_base_patch16_224",
    "deit-base": "deit_base_patch16_224",
    "tiny-vit-debug": "tiny_vit_debug",
}


def normalize_arch_name(arch: str) -> str:
    key = str(arch).strip().lower()
    return _ARCH_ALIASES.get(key, key)


def build_model(
    arch: str,
    num_classes: int = 1000,
    weights: str | None = "DEFAULT",
    image_size: int = 224,
) -> nn.Module:
    arch = normalize_arch_name(arch)
    if arch in {"resnet18", "resnet50"}:
        return build_prunable_resnet(arch, num_classes=num_classes, weights=weights)
    if arch == "efficientnet_b4":
        return build_prunable_efficientnet_b4(num_classes=num_classes, weights=weights)
    if arch in {"vit_b_16", "vit_l_16", "deit_base_patch16_224", "tiny_vit_debug"}:
        return build_prunable_vit(arch, num_classes=num_classes, weights=weights, image_size=image_size)
    raise ValueError(
        f"Unsupported architecture: {arch}. Supported: resnet50, efficientnet_b4, "
        "vit_b_16, vit_l_16, deit_base_patch16_224 (plus debug resnet18/tiny_vit_debug)."
    )


def iter_prunable_units(model: nn.Module, named: bool = False):
    raw = unwrap_model(model)
    pairs: list[tuple[str, StructuredPruningUnit]] = []
    for name, module in raw.named_modules():
        if isinstance(module, StructuredPruningUnit):
            pairs.append((name, module))
    return pairs if named else [module for _, module in pairs]


def unit_descriptors(model: nn.Module) -> List[UnitDescriptor]:
    return [
        UnitDescriptor(name=name, kind=unit.unit_kind, size=unit.num_units, active=unit.active_count())
        for name, unit in iter_prunable_units(model, named=True)
    ]


def total_units(model: nn.Module) -> int:
    return sum(unit.num_units for unit in iter_prunable_units(model))


def active_units(model: nn.Module) -> int:
    return sum(unit.active_count() for unit in iter_prunable_units(model))


def export_slim_model(model: nn.Module) -> nn.Module:
    raw = unwrap_model(model)
    if isinstance(raw, PrunableResNet):
        return export_slim_resnet(raw)
    if isinstance(raw, PrunableEfficientNet):
        return export_slim_efficientnet(raw)
    if isinstance(raw, PrunableVisionTransformer):
        return export_slim_vit(raw)
    raise TypeError(f"No physical exporter is registered for {type(raw).__name__}")


def feature_modules(model: nn.Module) -> Dict[str, nn.Module]:
    raw = unwrap_model(model)
    if hasattr(raw, "feature_modules"):
        result = raw.feature_modules()  # type: ignore[attr-defined]
        if isinstance(result, dict):
            return result
    # Conservative fallback for custom checkpoints.
    result: Dict[str, nn.Module] = OrderedDict()
    for name, module in raw.named_children():
        if not isinstance(module, (nn.Linear, nn.AdaptiveAvgPool2d, nn.Dropout)):
            result[name] = module
    return result


def classifier_module(model: nn.Module) -> nn.Linear:
    raw = unwrap_model(model)
    if isinstance(raw, PrunableResNet):
        return raw.fc
    if isinstance(raw, PrunableEfficientNet):
        module = raw.classifier[-1]
        if not isinstance(module, nn.Linear):
            raise TypeError("EfficientNet classifier tail is not Linear")
        return module
    if isinstance(raw, PrunableVisionTransformer):
        return raw.head
    raise TypeError(f"Unsupported model type: {type(raw).__name__}")


def replace_classifier(model: nn.Module, num_classes: int) -> nn.Module:
    raw = unwrap_model(model)
    num_classes = int(num_classes)
    if isinstance(raw, PrunableResNet):
        raw.fc = nn.Linear(raw.fc.in_features, num_classes)
    elif isinstance(raw, PrunableEfficientNet):
        old = raw.classifier[-1]
        if not isinstance(old, nn.Linear):
            raise TypeError("EfficientNet classifier tail is not Linear")
        raw.classifier[-1] = nn.Linear(old.in_features, num_classes)
    elif isinstance(raw, PrunableVisionTransformer):
        raw.head = nn.Linear(raw.head.in_features, num_classes)
    else:
        raise TypeError(f"Unsupported model type: {type(raw).__name__}")
    return model


def freeze_backbone(model: nn.Module, frozen: bool = True) -> None:
    raw = unwrap_model(model)
    for parameter in raw.parameters():
        parameter.requires_grad_(not frozen)
    for parameter in classifier_module(raw).parameters():
        parameter.requires_grad_(True)
