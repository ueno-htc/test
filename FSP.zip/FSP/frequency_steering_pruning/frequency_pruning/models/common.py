from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, MutableSequence, Sequence

import torch
import torch.nn as nn

ParameterScoreMap = Mapping[nn.Parameter, torch.Tensor]


@dataclass(frozen=True)
class UnitDescriptor:
    name: str
    kind: str
    size: int
    active: int


class ScoreAccumulator:
    """Accumulate per-parameter values into equally sized structured units."""

    def __init__(self, num_units: int, device: torch.device | str = "cpu") -> None:
        self.num_units = int(num_units)
        self.sums = torch.zeros(self.num_units, dtype=torch.float64, device=device)
        self.counts = torch.zeros(self.num_units, dtype=torch.float64, device=device)

    def add_axis(self, value: torch.Tensor | None, axis: int, scale: float = 1.0) -> None:
        if value is None:
            return
        value = value.detach().to(device=self.sums.device, dtype=torch.float64)
        axis = axis % value.ndim
        if value.shape[axis] != self.num_units:
            raise ValueError(
                f"Expected axis {axis} to have {self.num_units} entries, got {tuple(value.shape)}"
            )
        flattened = value.movedim(axis, 0).reshape(self.num_units, -1)
        self.sums.add_(flattened.sum(dim=1), alpha=float(scale))
        self.counts.add_(
            torch.full_like(self.counts, flattened.shape[1] * abs(float(scale)))
        )

    def add_preaggregated(
        self,
        sums: torch.Tensor,
        counts: torch.Tensor | float | int,
        scale: float = 1.0,
    ) -> None:
        sums = sums.detach().to(device=self.sums.device, dtype=torch.float64)
        if sums.numel() != self.num_units:
            raise ValueError(f"Expected {self.num_units} unit sums, got {sums.numel()}")
        self.sums.add_(sums.reshape(-1), alpha=float(scale))
        if isinstance(counts, torch.Tensor):
            c = counts.detach().to(device=self.sums.device, dtype=torch.float64).reshape(-1)
            if c.numel() == 1:
                c = c.expand(self.num_units)
            if c.numel() != self.num_units:
                raise ValueError(f"Expected {self.num_units} counts, got {c.numel()}")
            self.counts.add_(c * abs(float(scale)))
        else:
            self.counts.add_(float(counts) * abs(float(scale)))

    def finish(self, reduction: str = "sum") -> torch.Tensor:
        reduction = str(reduction).lower()
        if reduction == "sum":
            return self.sums.to(torch.float32)
        if reduction == "mean":
            return (self.sums / self.counts.clamp_min(1.0)).to(torch.float32)
        if reduction == "l2":
            return torch.sqrt(self.sums.clamp_min(0.0)).to(torch.float32)
        raise ValueError(f"Unsupported structured score reduction: {reduction}")


class StructuredPruningUnit(ABC):
    """Mixin implemented by modules that expose structured pruning units.

    A unit owns a one-dimensional binary gate. The gate is used while scoring and
    recovering the masked model. Export functions physically slice all weights that
    depend on inactive units.
    """

    unit_kind: str = "channel"
    gate: torch.Tensor
    min_units_default: int = 1

    @property
    def num_units(self) -> int:
        return int(self.gate.numel())

    def active_mask(self) -> torch.Tensor:
        return self.gate.detach() > 0.5

    def active_indices(self) -> torch.Tensor:
        return torch.nonzero(self.active_mask(), as_tuple=False).flatten()

    def active_count(self) -> int:
        return int(self.active_mask().sum().item())

    def prune(self, indices: Sequence[int] | torch.Tensor) -> None:
        if isinstance(indices, torch.Tensor):
            idx = indices.to(device=self.gate.device, dtype=torch.long)
        else:
            idx = torch.tensor(list(indices), device=self.gate.device, dtype=torch.long)
        if idx.numel() == 0:
            return
        self.gate.index_fill_(0, idx, 0.0)

    def restore_all(self) -> None:
        self.gate.fill_(1.0)

    @abstractmethod
    def required_parameters(self) -> List[nn.Parameter]:
        """Return actual model parameters used by this structured group."""

    @abstractmethod
    def aggregate_parameter_scores(
        self, score_map: ParameterScoreMap, reduction: str = "sum"
    ) -> torch.Tensor:
        """Aggregate per-parameter values into one score per structured unit."""

    def magnitude_scores(self, reduction: str = "sum", power: float = 1.0) -> torch.Tensor:
        values: Dict[nn.Parameter, torch.Tensor] = {}
        for p in self.required_parameters():
            values[p] = p.detach().abs().pow(float(power))
        score = self.aggregate_parameter_scores(values, reduction=reduction)
        if power != 1.0 and reduction in {"sum", "mean"}:
            score = score.clamp_min(0).pow(1.0 / float(power))
        return score


def unique_parameters(units: Iterable[StructuredPruningUnit]) -> List[nn.Parameter]:
    out: List[nn.Parameter] = []
    seen: set[int] = set()
    for unit in units:
        for p in unit.required_parameters():
            if id(p) in seen:
                continue
            seen.add(id(p))
            out.append(p)
    return out


def copy_batchnorm_subset(dst: nn.modules.batchnorm._BatchNorm, src: nn.modules.batchnorm._BatchNorm, idx: torch.Tensor) -> None:
    idx = idx.to(dtype=torch.long, device=src.weight.device if src.affine else src.running_mean.device)
    if src.affine:
        assert dst.weight is not None and dst.bias is not None
        assert src.weight is not None and src.bias is not None
        dst.weight.data.copy_(src.weight.data.index_select(0, idx).to(dst.weight.device))
        dst.bias.data.copy_(src.bias.data.index_select(0, idx).to(dst.bias.device))
    if src.track_running_stats:
        assert src.running_mean is not None and src.running_var is not None
        assert dst.running_mean is not None and dst.running_var is not None
        dst.running_mean.data.copy_(src.running_mean.data.index_select(0, idx).to(dst.running_mean.device))
        dst.running_var.data.copy_(src.running_var.data.index_select(0, idx).to(dst.running_var.device))
        if src.num_batches_tracked is not None and dst.num_batches_tracked is not None:
            dst.num_batches_tracked.data.copy_(src.num_batches_tracked.data.to(dst.num_batches_tracked.device))


def clone_batchnorm(src: nn.modules.batchnorm._BatchNorm, num_features: int) -> nn.modules.batchnorm._BatchNorm:
    cls = type(src)
    dst = cls(
        num_features,
        eps=src.eps,
        momentum=src.momentum,
        affine=src.affine,
        track_running_stats=src.track_running_stats,
    )
    return dst
