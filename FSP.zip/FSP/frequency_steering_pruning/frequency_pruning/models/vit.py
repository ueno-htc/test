from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from frequency_pruning.torchvision_compat import ensure_torchvision_nms_stub
from .common import ParameterScoreMap, ScoreAccumulator, StructuredPruningUnit

ensure_torchvision_nms_stub()
from torchvision.models import (
    ViT_B_16_Weights,
    ViT_L_16_Weights,
    vit_b_16,
    vit_l_16,
)

DEIT_BASE_URL = "https://dl.fbaipublicfiles.com/deit/deit_base_patch16_224-b5f2ef4d.pth"


@dataclass(frozen=True)
class ViTConfig:
    image_size: int
    patch_size: int
    depth: int
    embed_dim: int
    num_heads: int
    mlp_dim: int
    dropout: float = 0.0
    attention_dropout: float = 0.0
    norm_eps: float = 1e-6


class PrunableAttention(nn.Module, StructuredPruningUnit):
    unit_kind = "attention_head"
    min_units_default = 1

    def __init__(
        self,
        embed_dim: int,
        num_heads: int,
        qkv_bias: bool = True,
        attn_drop: float = 0.0,
        proj_drop: float = 0.0,
    ) -> None:
        super().__init__()
        if embed_dim % num_heads != 0:
            raise ValueError(f"embed_dim={embed_dim} must be divisible by num_heads={num_heads}")
        self.embed_dim = int(embed_dim)
        self.original_num_heads = int(num_heads)
        self.head_dim = embed_dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nn.Linear(embed_dim, 3 * embed_dim, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(embed_dim, embed_dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.register_buffer("gate", torch.ones(num_heads))

    def forward(self, x: Tensor) -> Tensor:
        batch, tokens, _ = x.shape
        qkv = self.qkv(x).reshape(batch, tokens, 3, self.original_num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        attn = (q * self.scale) @ k.transpose(-2, -1)
        attn = self.attn_drop(attn.softmax(dim=-1))
        out = attn @ v
        out = out * self.gate.view(1, -1, 1, 1)
        out = out.transpose(1, 2).reshape(batch, tokens, self.embed_dim)
        return self.proj_drop(self.proj(out))

    def required_parameters(self) -> List[nn.Parameter]:
        params = [self.qkv.weight, self.proj.weight]
        if self.qkv.bias is not None:
            params.append(self.qkv.bias)
        # Output projection bias is shared after head concatenation and is not
        # attributable to one removable head.
        return params

    def aggregate_parameter_scores(self, score_map: ParameterScoreMap, reduction: str = "sum") -> Tensor:
        heads = self.original_num_heads
        dim = self.head_dim
        acc = ScoreAccumulator(heads)
        qkv_w = score_map.get(self.qkv.weight)
        if qkv_w is not None:
            qkv_w = qkv_w.reshape(3, heads, dim, self.embed_dim)
            sums = qkv_w.sum(dim=(0, 2, 3))
            acc.add_preaggregated(sums, 3 * dim * self.embed_dim)
        qkv_b = score_map.get(self.qkv.bias) if self.qkv.bias is not None else None
        if qkv_b is not None:
            qkv_b = qkv_b.reshape(3, heads, dim)
            acc.add_preaggregated(qkv_b.sum(dim=(0, 2)), 3 * dim)
        proj_w = score_map.get(self.proj.weight)
        if proj_w is not None:
            proj_w = proj_w.reshape(self.embed_dim, heads, dim)
            acc.add_preaggregated(proj_w.sum(dim=(0, 2)), self.embed_dim * dim)
        return acc.finish(reduction)


class SlimAttention(nn.Module):
    def __init__(self, source: PrunableAttention) -> None:
        super().__init__()
        idx = source.active_indices().cpu()
        if idx.numel() == 0:
            idx = torch.tensor([0], dtype=torch.long)
        self.embed_dim = source.embed_dim
        self.head_dim = source.head_dim
        self.num_heads = int(idx.numel())
        self.inner_dim = self.num_heads * self.head_dim
        self.scale = source.scale
        self.qkv = nn.Linear(self.embed_dim, 3 * self.inner_dim, bias=source.qkv.bias is not None)
        self.attn_drop = copy.deepcopy(source.attn_drop)
        self.proj = nn.Linear(self.inner_dim, self.embed_dim, bias=source.proj.bias is not None)
        self.proj_drop = copy.deepcopy(source.proj_drop)

        rows = []
        for qkv_index in range(3):
            base = qkv_index * source.embed_dim
            for head in idx.tolist():
                rows.extend(range(base + head * self.head_dim, base + (head + 1) * self.head_dim))
        row_idx = torch.tensor(rows, dtype=torch.long)
        self.qkv.weight.data.copy_(source.qkv.weight.data.index_select(0, row_idx))
        if source.qkv.bias is not None and self.qkv.bias is not None:
            self.qkv.bias.data.copy_(source.qkv.bias.data.index_select(0, row_idx))
        cols = []
        for head in idx.tolist():
            cols.extend(range(head * self.head_dim, (head + 1) * self.head_dim))
        col_idx = torch.tensor(cols, dtype=torch.long)
        self.proj.weight.data.copy_(source.proj.weight.data.index_select(1, col_idx))
        if source.proj.bias is not None and self.proj.bias is not None:
            self.proj.bias.data.copy_(source.proj.bias.data)

    def forward(self, x: Tensor) -> Tensor:
        batch, tokens, _ = x.shape
        qkv = self.qkv(x).reshape(batch, tokens, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        attn = (q * self.scale) @ k.transpose(-2, -1)
        attn = self.attn_drop(attn.softmax(dim=-1))
        out = (attn @ v).transpose(1, 2).reshape(batch, tokens, self.inner_dim)
        return self.proj_drop(self.proj(out))


class PrunableMLP(nn.Module, StructuredPruningUnit):
    unit_kind = "transformer_mlp_channel"
    min_units_default = 16

    def __init__(self, embed_dim: int, mlp_dim: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.fc1 = nn.Linear(embed_dim, mlp_dim)
        self.act = nn.GELU()
        self.drop1 = nn.Dropout(dropout)
        self.fc2 = nn.Linear(mlp_dim, embed_dim)
        self.drop2 = nn.Dropout(dropout)
        self.register_buffer("gate", torch.ones(mlp_dim))

    def forward(self, x: Tensor) -> Tensor:
        x = self.drop1(self.act(self.fc1(x)))
        x = x * self.gate.view(1, 1, -1)
        return self.drop2(self.fc2(x))

    def required_parameters(self) -> List[nn.Parameter]:
        params = [self.fc1.weight, self.fc2.weight]
        if self.fc1.bias is not None:
            params.append(self.fc1.bias)
        return params

    def aggregate_parameter_scores(self, score_map: ParameterScoreMap, reduction: str = "sum") -> Tensor:
        acc = ScoreAccumulator(self.num_units)
        acc.add_axis(score_map.get(self.fc1.weight), axis=0)
        if self.fc1.bias is not None:
            acc.add_axis(score_map.get(self.fc1.bias), axis=0)
        acc.add_axis(score_map.get(self.fc2.weight), axis=1)
        return acc.finish(reduction)


class SlimMLP(nn.Module):
    def __init__(self, source: PrunableMLP) -> None:
        super().__init__()
        idx = source.active_indices().cpu()
        if idx.numel() == 0:
            idx = torch.tensor([0], dtype=torch.long)
        hidden = int(idx.numel())
        self.fc1 = nn.Linear(source.fc1.in_features, hidden, bias=source.fc1.bias is not None)
        self.act = copy.deepcopy(source.act)
        self.drop1 = copy.deepcopy(source.drop1)
        self.fc2 = nn.Linear(hidden, source.fc2.out_features, bias=source.fc2.bias is not None)
        self.drop2 = copy.deepcopy(source.drop2)
        self.fc1.weight.data.copy_(source.fc1.weight.data.index_select(0, idx))
        if source.fc1.bias is not None and self.fc1.bias is not None:
            self.fc1.bias.data.copy_(source.fc1.bias.data.index_select(0, idx))
        self.fc2.weight.data.copy_(source.fc2.weight.data.index_select(1, idx))
        if source.fc2.bias is not None and self.fc2.bias is not None:
            self.fc2.bias.data.copy_(source.fc2.bias.data)

    def forward(self, x: Tensor) -> Tensor:
        return self.drop2(self.fc2(self.drop1(self.act(self.fc1(x)))))


class TransformerBlock(nn.Module):
    def __init__(self, config: ViTConfig) -> None:
        super().__init__()
        self.norm1 = nn.LayerNorm(config.embed_dim, eps=config.norm_eps)
        self.attn: nn.Module = PrunableAttention(
            config.embed_dim,
            config.num_heads,
            qkv_bias=True,
            attn_drop=config.attention_dropout,
            proj_drop=config.dropout,
        )
        self.norm2 = nn.LayerNorm(config.embed_dim, eps=config.norm_eps)
        self.mlp: nn.Module = PrunableMLP(config.embed_dim, config.mlp_dim, config.dropout)

    def forward(self, x: Tensor) -> Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class PrunableVisionTransformer(nn.Module):
    def __init__(self, config: ViTConfig, num_classes: int = 1000, arch: str = "vit") -> None:
        super().__init__()
        self.config = config
        self.arch = arch
        self.image_size = int(config.image_size)
        self.patch_size = int(config.patch_size)
        self.embed_dim = int(config.embed_dim)
        self.grid_size = self.image_size // self.patch_size
        self.conv_proj = nn.Conv2d(3, config.embed_dim, kernel_size=config.patch_size, stride=config.patch_size)
        self.class_token = nn.Parameter(torch.zeros(1, 1, config.embed_dim))
        self.pos_embedding = nn.Parameter(torch.zeros(1, self.grid_size * self.grid_size + 1, config.embed_dim))
        self.pos_drop = nn.Dropout(config.dropout)
        self.blocks = nn.ModuleList([TransformerBlock(config) for _ in range(config.depth)])
        self.norm = nn.LayerNorm(config.embed_dim, eps=config.norm_eps)
        self.head = nn.Linear(config.embed_dim, num_classes)
        self._init_weights()

    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.pos_embedding, std=0.02)
        nn.init.trunc_normal_(self.class_token, std=0.02)
        nn.init.trunc_normal_(self.conv_proj.weight, std=math.sqrt(1.0 / (3 * self.patch_size * self.patch_size)))
        if self.conv_proj.bias is not None:
            nn.init.zeros_(self.conv_proj.bias)
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.trunc_normal_(module.weight, std=0.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def _position_embedding(self, height: int, width: int) -> Tensor:
        grid_h = height // self.patch_size
        grid_w = width // self.patch_size
        expected = self.pos_embedding.shape[1] - 1
        if grid_h * grid_w == expected and grid_h == self.grid_size and grid_w == self.grid_size:
            return self.pos_embedding
        cls_pos = self.pos_embedding[:, :1]
        patch_pos = self.pos_embedding[:, 1:]
        old_grid = int(round(math.sqrt(patch_pos.shape[1])))
        if old_grid * old_grid != patch_pos.shape[1]:
            raise ValueError("Only square pretrained positional grids are supported")
        patch_pos = patch_pos.reshape(1, old_grid, old_grid, self.embed_dim).permute(0, 3, 1, 2)
        patch_pos = F.interpolate(patch_pos, size=(grid_h, grid_w), mode="bicubic", align_corners=False)
        patch_pos = patch_pos.permute(0, 2, 3, 1).reshape(1, grid_h * grid_w, self.embed_dim)
        return torch.cat([cls_pos, patch_pos], dim=1)

    def forward_features(self, x: Tensor) -> Tensor:
        batch, _, height, width = x.shape
        if height % self.patch_size or width % self.patch_size:
            raise ValueError(f"Input size {(height, width)} must be divisible by patch size {self.patch_size}")
        x = self.conv_proj(x).flatten(2).transpose(1, 2)
        cls = self.class_token.expand(batch, -1, -1)
        x = torch.cat([cls, x], dim=1)
        x = self.pos_drop(x + self._position_embedding(height, width))
        for block in self.blocks:
            x = block(x)
        return self.norm(x)

    def forward(self, x: Tensor) -> Tensor:
        return self.head(self.forward_features(x)[:, 0])

    def feature_modules(self) -> Dict[str, nn.Module]:
        return {f"block_{index:02d}": block for index, block in enumerate(self.blocks)}




def _resize_position_embedding(source: Tensor, target_tokens: int) -> Tensor:
    if source.shape[1] == target_tokens:
        return source
    cls = source[:, :1]
    patch = source[:, 1:]
    old_grid = int(round(math.sqrt(patch.shape[1])))
    new_grid = int(round(math.sqrt(target_tokens - 1)))
    if old_grid * old_grid != patch.shape[1] or new_grid * new_grid != target_tokens - 1:
        raise ValueError("Positional embeddings require square patch grids")
    patch = patch.reshape(1, old_grid, old_grid, source.shape[-1]).permute(0, 3, 1, 2)
    patch = F.interpolate(patch, size=(new_grid, new_grid), mode="bicubic", align_corners=False)
    patch = patch.permute(0, 2, 3, 1).reshape(1, new_grid * new_grid, source.shape[-1])
    return torch.cat([cls, patch], dim=1)

def _copy_torchvision_weights(model: PrunableVisionTransformer, source: nn.Module, num_classes: int) -> None:
    model.conv_proj.load_state_dict(source.conv_proj.state_dict())
    model.class_token.data.copy_(source.class_token.data)
    model.pos_embedding.data.copy_(_resize_position_embedding(source.encoder.pos_embedding.data, model.pos_embedding.shape[1]))
    model.norm.load_state_dict(source.encoder.ln.state_dict())
    for index, block in enumerate(model.blocks):
        src = source.encoder.layers[index]
        block.norm1.load_state_dict(src.ln_1.state_dict())
        block.norm2.load_state_dict(src.ln_2.state_dict())
        assert isinstance(block.attn, PrunableAttention)
        block.attn.qkv.weight.data.copy_(src.self_attention.in_proj_weight.data)
        if block.attn.qkv.bias is not None and src.self_attention.in_proj_bias is not None:
            block.attn.qkv.bias.data.copy_(src.self_attention.in_proj_bias.data)
        block.attn.proj.load_state_dict(src.self_attention.out_proj.state_dict())
        assert isinstance(block.mlp, PrunableMLP)
        block.mlp.fc1.load_state_dict(src.mlp[0].state_dict())
        block.mlp.fc2.load_state_dict(src.mlp[3].state_dict())
    source_head = source.heads.head if hasattr(source.heads, "head") else source.heads[-1]
    if num_classes == source_head.out_features:
        model.head.load_state_dict(source_head.state_dict())


def _copy_deit_state(model: PrunableVisionTransformer, state: Mapping[str, Tensor], num_classes: int) -> None:
    model.conv_proj.weight.data.copy_(state["patch_embed.proj.weight"])
    model.conv_proj.bias.data.copy_(state["patch_embed.proj.bias"])
    model.class_token.data.copy_(state["cls_token"])
    model.pos_embedding.data.copy_(_resize_position_embedding(state["pos_embed"], model.pos_embedding.shape[1]))
    model.norm.weight.data.copy_(state["norm.weight"])
    model.norm.bias.data.copy_(state["norm.bias"])
    for index, block in enumerate(model.blocks):
        prefix = f"blocks.{index}."
        block.norm1.weight.data.copy_(state[prefix + "norm1.weight"])
        block.norm1.bias.data.copy_(state[prefix + "norm1.bias"])
        block.norm2.weight.data.copy_(state[prefix + "norm2.weight"])
        block.norm2.bias.data.copy_(state[prefix + "norm2.bias"])
        assert isinstance(block.attn, PrunableAttention)
        block.attn.qkv.weight.data.copy_(state[prefix + "attn.qkv.weight"])
        block.attn.qkv.bias.data.copy_(state[prefix + "attn.qkv.bias"])
        block.attn.proj.weight.data.copy_(state[prefix + "attn.proj.weight"])
        block.attn.proj.bias.data.copy_(state[prefix + "attn.proj.bias"])
        assert isinstance(block.mlp, PrunableMLP)
        block.mlp.fc1.weight.data.copy_(state[prefix + "mlp.fc1.weight"])
        block.mlp.fc1.bias.data.copy_(state[prefix + "mlp.fc1.bias"])
        block.mlp.fc2.weight.data.copy_(state[prefix + "mlp.fc2.weight"])
        block.mlp.fc2.bias.data.copy_(state[prefix + "mlp.fc2.bias"])
    if num_classes == state["head.weight"].shape[0]:
        model.head.weight.data.copy_(state["head.weight"])
        model.head.bias.data.copy_(state["head.bias"])


def build_prunable_vit(
    arch: str,
    num_classes: int = 1000,
    weights: str | None = "DEFAULT",
    image_size: int = 224,
) -> PrunableVisionTransformer:
    if arch == "vit_b_16":
        config = ViTConfig(image_size, 16, 12, 768, 12, 3072, norm_eps=1e-6)
        model = PrunableVisionTransformer(config, num_classes, arch)
        if weights is not None and str(weights).lower() not in {"", "none", "false"}:
            enum = ViT_B_16_Weights.DEFAULT if str(weights).lower() == "default" else getattr(ViT_B_16_Weights, str(weights))
            source = vit_b_16(weights=enum)
            _copy_torchvision_weights(model, source, num_classes)
        return model
    if arch == "vit_l_16":
        config = ViTConfig(image_size, 16, 24, 1024, 16, 4096, norm_eps=1e-6)
        model = PrunableVisionTransformer(config, num_classes, arch)
        if weights is not None and str(weights).lower() not in {"", "none", "false"}:
            enum = ViT_L_16_Weights.DEFAULT if str(weights).lower() == "default" else getattr(ViT_L_16_Weights, str(weights))
            source = vit_l_16(weights=enum)
            _copy_torchvision_weights(model, source, num_classes)
        return model
    if arch == "deit_base_patch16_224":
        config = ViTConfig(image_size, 16, 12, 768, 12, 3072, norm_eps=1e-6)
        model = PrunableVisionTransformer(config, num_classes, arch)
        if weights is not None and str(weights).lower() not in {"", "none", "false"}:
            if str(weights).lower() not in {"default", "imagenet1k_v1"}:
                raise ValueError("DeiT-B supports weights=DEFAULT/NONE; use --checkpoint for custom weights")
            checkpoint = torch.hub.load_state_dict_from_url(DEIT_BASE_URL, map_location="cpu", check_hash=True)
            _copy_deit_state(model, checkpoint.get("model", checkpoint), num_classes)
        return model
    if arch == "tiny_vit_debug":
        config = ViTConfig(image_size, 8, 2, 128, 4, 256, norm_eps=1e-6)
        return PrunableVisionTransformer(config, num_classes, arch)
    raise ValueError(f"Unsupported transformer architecture: {arch}")


def export_slim_vit(model: PrunableVisionTransformer) -> PrunableVisionTransformer:
    device = next(model.parameters()).device
    was_training = model.training
    model.cpu().eval()
    slim = copy.deepcopy(model).eval()
    for block in slim.blocks:
        if isinstance(block.attn, PrunableAttention):
            block.attn = SlimAttention(block.attn)
        if isinstance(block.mlp, PrunableMLP):
            block.mlp = SlimMLP(block.mlp)
    model.to(device).train(was_training)
    return slim
