from __future__ import annotations

import copy
from typing import Dict, List, Sequence

import torch
import torch.nn as nn
from torch import Tensor

from frequency_pruning.torchvision_compat import ensure_torchvision_nms_stub
from .common import (
    ParameterScoreMap,
    ScoreAccumulator,
    StructuredPruningUnit,
    clone_batchnorm,
    copy_batchnorm_subset,
)

ensure_torchvision_nms_stub()
from torchvision.models import EfficientNet_B4_Weights, efficientnet_b4
from torchvision.models.efficientnet import MBConv


def _conv_like(src: nn.Conv2d, in_channels: int, out_channels: int, groups: int) -> nn.Conv2d:
    return nn.Conv2d(
        in_channels=in_channels,
        out_channels=out_channels,
        kernel_size=src.kernel_size,
        stride=src.stride,
        padding=src.padding,
        dilation=src.dilation,
        groups=groups,
        bias=src.bias is not None,
        padding_mode=src.padding_mode,
    )


def _copy_conv(dst: nn.Conv2d, src_weight: Tensor, src_bias: Tensor | None = None) -> None:
    dst.weight.data.copy_(src_weight.to(dst.weight.device))
    if dst.bias is not None and src_bias is not None:
        dst.bias.data.copy_(src_bias.to(dst.bias.device))


class PrunableMBConv(nn.Module, StructuredPruningUnit):
    """Torchvision MBConv with a gate on expanded hidden channels.

    Expansion-ratio-one blocks are intentionally left dense because their hidden
    channels are also the residual input channels. Pruning only expanded channels
    keeps every block's public input/output width unchanged and permits exact,
    dependency-free physical export.
    """

    unit_kind = "mbconv_expanded_channel"
    min_units_default = 8

    def __init__(self, source: MBConv) -> None:
        super().__init__()
        if len(source.block) != 4:
            raise ValueError("PrunableMBConv requires an MBConv with an explicit expansion layer")
        self.expand = source.block[0]
        self.depthwise = source.block[1]
        self.se = source.block[2]
        self.project = source.block[3]
        self.stochastic_depth = source.stochastic_depth
        self.use_res_connect = bool(source.use_res_connect)
        self.out_channels = int(source.out_channels)
        hidden = int(self.expand[0].out_channels)
        self.register_buffer("gate", torch.ones(hidden))

    def forward(self, x: Tensor) -> Tensor:
        identity = x
        gate = self.gate.view(1, -1, 1, 1)
        out = self.expand(x) * gate
        out = self.depthwise(out) * gate
        out = self.se(out)
        out = self.project(out)
        if self.use_res_connect:
            out = self.stochastic_depth(out) + identity
        return out

    def required_parameters(self) -> List[nn.Parameter]:
        params: List[nn.Parameter] = [
            self.expand[0].weight,
            self.depthwise[0].weight,
            self.se.fc1.weight,
            self.se.fc2.weight,
            self.project[0].weight,
        ]
        if self.expand[0].bias is not None:
            params.append(self.expand[0].bias)
        if self.depthwise[0].bias is not None:
            params.append(self.depthwise[0].bias)
        # fc1/project biases are not indexed by the expanded channel and remain
        # unchanged in the physical exporter. fc2 bias is channel-indexed.
        if self.se.fc2.bias is not None:
            params.append(self.se.fc2.bias)
        for norm in (self.expand[1], self.depthwise[1]):
            if isinstance(norm, nn.modules.batchnorm._BatchNorm) and norm.affine:
                assert norm.weight is not None and norm.bias is not None
                params.extend([norm.weight, norm.bias])
        return params

    def aggregate_parameter_scores(self, score_map: ParameterScoreMap, reduction: str = "sum") -> Tensor:
        acc = ScoreAccumulator(self.num_units)
        acc.add_axis(score_map.get(self.expand[0].weight), axis=0)
        if self.expand[0].bias is not None:
            acc.add_axis(score_map.get(self.expand[0].bias), axis=0)
        expand_bn = self.expand[1]
        if isinstance(expand_bn, nn.modules.batchnorm._BatchNorm) and expand_bn.affine:
            acc.add_axis(score_map.get(expand_bn.weight), axis=0)
            acc.add_axis(score_map.get(expand_bn.bias), axis=0)

        acc.add_axis(score_map.get(self.depthwise[0].weight), axis=0)
        if self.depthwise[0].bias is not None:
            acc.add_axis(score_map.get(self.depthwise[0].bias), axis=0)
        dw_bn = self.depthwise[1]
        if isinstance(dw_bn, nn.modules.batchnorm._BatchNorm) and dw_bn.affine:
            acc.add_axis(score_map.get(dw_bn.weight), axis=0)
            acc.add_axis(score_map.get(dw_bn.bias), axis=0)

        acc.add_axis(score_map.get(self.se.fc1.weight), axis=1)
        acc.add_axis(score_map.get(self.se.fc2.weight), axis=0)
        if self.se.fc2.bias is not None:
            acc.add_axis(score_map.get(self.se.fc2.bias), axis=0)
        acc.add_axis(score_map.get(self.project[0].weight), axis=1)
        return acc.finish(reduction)


class SlimSqueezeExcitation(nn.Module):
    def __init__(self, in_channels: int, squeeze_channels: int, activation: nn.Module, scale_activation: nn.Module):
        super().__init__()
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(in_channels, squeeze_channels, 1)
        self.fc2 = nn.Conv2d(squeeze_channels, in_channels, 1)
        self.activation = activation
        self.scale_activation = scale_activation

    def forward(self, x: Tensor) -> Tensor:
        scale = self.avgpool(x)
        scale = self.activation(self.fc1(scale))
        scale = self.scale_activation(self.fc2(scale))
        return x * scale


class SlimMBConv(nn.Module):
    def __init__(self, source: PrunableMBConv) -> None:
        super().__init__()
        idx = source.active_indices().cpu()
        if idx.numel() == 0:
            idx = torch.tensor([0], dtype=torch.long)
        hidden = int(idx.numel())

        old_expand_conv: nn.Conv2d = source.expand[0]
        old_expand_bn: nn.modules.batchnorm._BatchNorm = source.expand[1]
        expand_conv = _conv_like(old_expand_conv, old_expand_conv.in_channels, hidden, groups=1)
        expand_bn = clone_batchnorm(old_expand_bn, hidden)
        self.expand = nn.Sequential(expand_conv, expand_bn, copy.deepcopy(source.expand[2]))
        _copy_conv(expand_conv, old_expand_conv.weight.data.index_select(0, idx), None if old_expand_conv.bias is None else old_expand_conv.bias.data.index_select(0, idx))
        copy_batchnorm_subset(expand_bn, old_expand_bn, idx)

        old_dw_conv: nn.Conv2d = source.depthwise[0]
        old_dw_bn: nn.modules.batchnorm._BatchNorm = source.depthwise[1]
        dw_conv = _conv_like(old_dw_conv, hidden, hidden, groups=hidden)
        dw_bn = clone_batchnorm(old_dw_bn, hidden)
        self.depthwise = nn.Sequential(dw_conv, dw_bn, copy.deepcopy(source.depthwise[2]))
        _copy_conv(dw_conv, old_dw_conv.weight.data.index_select(0, idx), None if old_dw_conv.bias is None else old_dw_conv.bias.data.index_select(0, idx))
        copy_batchnorm_subset(dw_bn, old_dw_bn, idx)

        squeeze_channels = int(source.se.fc1.out_channels)
        self.se = SlimSqueezeExcitation(
            hidden,
            squeeze_channels,
            copy.deepcopy(source.se.activation),
            copy.deepcopy(source.se.scale_activation),
        )
        self.se.fc1.weight.data.copy_(source.se.fc1.weight.data.index_select(1, idx))
        if source.se.fc1.bias is not None:
            self.se.fc1.bias.data.copy_(source.se.fc1.bias.data)
        self.se.fc2.weight.data.copy_(source.se.fc2.weight.data.index_select(0, idx))
        if source.se.fc2.bias is not None:
            self.se.fc2.bias.data.copy_(source.se.fc2.bias.data.index_select(0, idx))

        old_proj_conv: nn.Conv2d = source.project[0]
        old_proj_bn: nn.modules.batchnorm._BatchNorm = source.project[1]
        proj_conv = _conv_like(old_proj_conv, hidden, old_proj_conv.out_channels, groups=1)
        proj_bn = clone_batchnorm(old_proj_bn, old_proj_bn.num_features)
        self.project = nn.Sequential(proj_conv, proj_bn)
        _copy_conv(proj_conv, old_proj_conv.weight.data.index_select(1, idx), old_proj_conv.bias.data if old_proj_conv.bias is not None else None)
        proj_bn.load_state_dict(old_proj_bn.state_dict())

        self.stochastic_depth = copy.deepcopy(source.stochastic_depth)
        self.use_res_connect = source.use_res_connect
        self.out_channels = source.out_channels

    def forward(self, x: Tensor) -> Tensor:
        identity = x
        out = self.expand(x)
        out = self.depthwise(out)
        out = self.se(out)
        out = self.project(out)
        if self.use_res_connect:
            out = self.stochastic_depth(out) + identity
        return out


class PrunableEfficientNet(nn.Module):
    def __init__(self, features: nn.Sequential, avgpool: nn.Module, classifier: nn.Sequential, arch: str = "efficientnet_b4") -> None:
        super().__init__()
        self.features = features
        self.avgpool = avgpool
        self.classifier = classifier
        self.arch = arch

    def forward(self, x: Tensor) -> Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)

    def feature_modules(self) -> Dict[str, nn.Module]:
        return {f"stage_{index}": stage for index, stage in enumerate(self.features)}


def _replace_mbconv_expansions(module: nn.Module) -> None:
    for name, child in list(module.named_children()):
        if isinstance(child, MBConv) and len(child.block) == 4:
            setattr(module, name, PrunableMBConv(child))
        else:
            _replace_mbconv_expansions(child)


def build_prunable_efficientnet_b4(num_classes: int = 1000, weights: str | None = "DEFAULT") -> PrunableEfficientNet:
    weight_obj = None
    if weights is not None and str(weights).lower() not in {"", "none", "false"}:
        weight_obj = EfficientNet_B4_Weights.DEFAULT if str(weights).lower() == "default" else getattr(EfficientNet_B4_Weights, str(weights))
    source = efficientnet_b4(weights=weight_obj)
    if num_classes != source.classifier[-1].out_features:
        source.classifier[-1] = nn.Linear(source.classifier[-1].in_features, num_classes)
    _replace_mbconv_expansions(source.features)
    return PrunableEfficientNet(source.features, source.avgpool, source.classifier)


def _replace_with_slim(module: nn.Module) -> None:
    for name, child in list(module.named_children()):
        if isinstance(child, PrunableMBConv):
            setattr(module, name, SlimMBConv(child))
        else:
            _replace_with_slim(child)


def export_slim_efficientnet(model: PrunableEfficientNet) -> PrunableEfficientNet:
    device = next(model.parameters()).device
    was_training = model.training
    model.cpu().eval()
    slim = copy.deepcopy(model).eval()
    _replace_with_slim(slim)
    model.to(device).train(was_training)
    return slim
