from __future__ import annotations

from collections import OrderedDict
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Type, Union

import torch
import torch.nn as nn
from torch import Tensor

from frequency_pruning.torchvision_compat import ensure_torchvision_nms_stub
from .common import ParameterScoreMap, ScoreAccumulator, StructuredPruningUnit, copy_batchnorm_subset

ensure_torchvision_nms_stub()
from torchvision.models import resnet as tv_resnet


class PrunableBasicBlock(nn.Module, StructuredPruningUnit):
    expansion: int = 1
    unit_kind = "residual_hidden_channel"
    min_units_default = 4

    def __init__(
        self,
        inplanes: int,
        planes: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
    ) -> None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if groups != 1 or base_width != 64:
            raise ValueError("PrunableBasicBlock supports groups=1 and base_width=64 only")
        if dilation > 1:
            raise NotImplementedError("Dilation > 1 is not supported by PrunableBasicBlock")
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = norm_layer(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, padding=1, bias=False)
        self.bn2 = norm_layer(planes)
        self.downsample = downsample
        self.stride = stride
        self.register_buffer("gate", torch.ones(planes))

    def forward(self, x: Tensor) -> Tensor:
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = out * self.gate.view(1, -1, 1, 1)
        out = self.bn2(self.conv2(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        return self.relu(out + identity)

    def required_parameters(self) -> List[nn.Parameter]:
        params = [self.conv1.weight, self.conv2.weight]
        if self.bn1.affine:
            assert self.bn1.weight is not None and self.bn1.bias is not None
            params += [self.bn1.weight, self.bn1.bias]
        return params

    def aggregate_parameter_scores(self, score_map: ParameterScoreMap, reduction: str = "sum") -> Tensor:
        acc = ScoreAccumulator(self.num_units)
        acc.add_axis(score_map.get(self.conv1.weight), axis=0)
        if self.bn1.affine:
            acc.add_axis(score_map.get(self.bn1.weight), axis=0)
            acc.add_axis(score_map.get(self.bn1.bias), axis=0)
        acc.add_axis(score_map.get(self.conv2.weight), axis=1)
        return acc.finish(reduction)


class PrunableBottleneck(nn.Module, StructuredPruningUnit):
    expansion: int = 4
    unit_kind = "bottleneck_hidden_channel"
    min_units_default = 8

    def __init__(
        self,
        inplanes: int,
        planes: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
    ) -> None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        width = int(planes * (base_width / 64.0)) * groups
        if groups != 1:
            raise ValueError("The physical exporter currently supports groups=1 ResNet bottlenecks")
        self.hidden_width = width
        self.conv1 = nn.Conv2d(inplanes, width, kernel_size=1, bias=False)
        self.bn1 = norm_layer(width)
        self.conv2 = nn.Conv2d(
            width,
            width,
            kernel_size=3,
            stride=stride,
            padding=dilation,
            groups=groups,
            dilation=dilation,
            bias=False,
        )
        self.bn2 = norm_layer(width)
        self.conv3 = nn.Conv2d(width, planes * self.expansion, kernel_size=1, bias=False)
        self.bn3 = norm_layer(planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride
        self.register_buffer("gate", torch.ones(width))

    def forward(self, x: Tensor) -> Tensor:
        identity = x
        gate = self.gate.view(1, -1, 1, 1)
        out = self.relu(self.bn1(self.conv1(x))) * gate
        out = self.relu(self.bn2(self.conv2(out))) * gate
        out = self.bn3(self.conv3(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        return self.relu(out + identity)

    def required_parameters(self) -> List[nn.Parameter]:
        params = [self.conv1.weight, self.conv2.weight, self.conv3.weight]
        for bn in (self.bn1, self.bn2):
            if bn.affine:
                assert bn.weight is not None and bn.bias is not None
                params += [bn.weight, bn.bias]
        return params

    def aggregate_parameter_scores(self, score_map: ParameterScoreMap, reduction: str = "sum") -> Tensor:
        acc = ScoreAccumulator(self.num_units)
        acc.add_axis(score_map.get(self.conv1.weight), axis=0)
        if self.bn1.affine:
            acc.add_axis(score_map.get(self.bn1.weight), axis=0)
            acc.add_axis(score_map.get(self.bn1.bias), axis=0)
        # A bottleneck channel is both an input and an output of the 3x3 layer.
        # Dependency-aware group Taylor pruning therefore attributes both slices.
        acc.add_axis(score_map.get(self.conv2.weight), axis=0)
        acc.add_axis(score_map.get(self.conv2.weight), axis=1)
        if self.bn2.affine:
            acc.add_axis(score_map.get(self.bn2.weight), axis=0)
            acc.add_axis(score_map.get(self.bn2.bias), axis=0)
        acc.add_axis(score_map.get(self.conv3.weight), axis=1)
        return acc.finish(reduction)


class PrunableResNet(nn.Module):
    def __init__(
        self,
        block: Type[Union[PrunableBasicBlock, PrunableBottleneck]],
        layers: Sequence[int],
        num_classes: int = 1000,
        zero_init_residual: bool = False,
        groups: int = 1,
        width_per_group: int = 64,
        replace_stride_with_dilation: Optional[List[bool]] = None,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
    ) -> None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        self._norm_layer = norm_layer
        self.block = block
        self.layers_cfg = list(layers)
        self.inplanes = 64
        self.dilation = 1
        if replace_stride_with_dilation is None:
            replace_stride_with_dilation = [False, False, False]
        if len(replace_stride_with_dilation) != 3:
            raise ValueError("replace_stride_with_dilation must have three entries")
        self.groups = groups
        self.base_width = width_per_group

        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = norm_layer(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2, dilate=replace_stride_with_dilation[0])
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2, dilate=replace_stride_with_dilation[1])
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2, dilate=replace_stride_with_dilation[2])
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512 * block.expansion, num_classes)

        for module in self.modules():
            if isinstance(module, nn.Conv2d):
                nn.init.kaiming_normal_(module.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(module, (nn.BatchNorm2d, nn.GroupNorm)):
                if module.weight is not None:
                    nn.init.ones_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
        if zero_init_residual:
            for module in self.modules():
                if isinstance(module, PrunableBottleneck) and module.bn3.weight is not None:
                    nn.init.zeros_(module.bn3.weight)
                elif isinstance(module, PrunableBasicBlock) and module.bn2.weight is not None:
                    nn.init.zeros_(module.bn2.weight)

    def _make_layer(
        self,
        block: Type[Union[PrunableBasicBlock, PrunableBottleneck]],
        planes: int,
        blocks: int,
        stride: int = 1,
        dilate: bool = False,
    ) -> nn.Sequential:
        norm_layer = self._norm_layer
        downsample = None
        previous_dilation = self.dilation
        if dilate:
            self.dilation *= stride
            stride = 1
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion, kernel_size=1, stride=stride, bias=False),
                norm_layer(planes * block.expansion),
            )
        layers: List[nn.Module] = [
            block(
                self.inplanes,
                planes,
                stride,
                downsample,
                self.groups,
                self.base_width,
                previous_dilation,
                norm_layer,
            )
        ]
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(
                block(
                    self.inplanes,
                    planes,
                    groups=self.groups,
                    base_width=self.base_width,
                    dilation=self.dilation,
                    norm_layer=norm_layer,
                )
            )
        return nn.Sequential(*layers)

    def forward(self, x: Tensor) -> Tensor:
        x = self.maxpool(self.relu(self.bn1(self.conv1(x))))
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.avgpool(x)
        return self.fc(torch.flatten(x, 1))

    def feature_modules(self) -> Dict[str, nn.Module]:
        return {
            "stem": self.relu,
            "layer1": self.layer1,
            "layer2": self.layer2,
            "layer3": self.layer3,
            "layer4": self.layer4,
        }


class SlimBasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes: int, planes: int, hidden: int, stride: int, downsample: Optional[nn.Module]):
        super().__init__()
        self.conv1 = nn.Conv2d(inplanes, hidden, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(hidden)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(hidden, planes, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.downsample = downsample

    def forward(self, x: Tensor) -> Tensor:
        identity = x if self.downsample is None else self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.relu(out + identity)


class SlimBottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes: int, planes: int, hidden: int, stride: int, downsample: Optional[nn.Module]):
        super().__init__()
        self.conv1 = nn.Conv2d(inplanes, hidden, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(hidden)
        self.conv2 = nn.Conv2d(hidden, hidden, 3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(hidden)
        self.conv3 = nn.Conv2d(hidden, planes * 4, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample

    def forward(self, x: Tensor) -> Tensor:
        identity = x if self.downsample is None else self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        return self.relu(out + identity)


class SlimResNet(nn.Module):
    def __init__(self, block_type: str, hidden_cfg: Sequence[int], layers: Sequence[int], num_classes: int):
        super().__init__()
        if block_type not in {"basic", "bottleneck"}:
            raise ValueError(block_type)
        self.block_type = block_type
        self.hidden_cfg = list(map(int, hidden_cfg))
        self.layers_cfg = list(map(int, layers))
        self.inplanes = 64
        self.conv1 = nn.Conv2d(3, 64, 7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(3, stride=2, padding=1)
        offset = 0
        self.layer1, offset = self._make_layer(64, layers[0], 1, offset)
        self.layer2, offset = self._make_layer(128, layers[1], 2, offset)
        self.layer3, offset = self._make_layer(256, layers[2], 2, offset)
        self.layer4, offset = self._make_layer(512, layers[3], 2, offset)
        expansion = 1 if block_type == "basic" else 4
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512 * expansion, num_classes)

    def _make_layer(self, planes: int, blocks: int, first_stride: int, offset: int) -> Tuple[nn.Sequential, int]:
        out: List[nn.Module] = []
        expansion = 1 if self.block_type == "basic" else 4
        for block_index in range(blocks):
            stride = first_stride if block_index == 0 else 1
            downsample = None
            if stride != 1 or self.inplanes != planes * expansion:
                downsample = nn.Sequential(
                    nn.Conv2d(self.inplanes, planes * expansion, 1, stride=stride, bias=False),
                    nn.BatchNorm2d(planes * expansion),
                )
            hidden = self.hidden_cfg[offset]
            if self.block_type == "basic":
                block = SlimBasicBlock(self.inplanes, planes, hidden, stride, downsample)
            else:
                block = SlimBottleneck(self.inplanes, planes, hidden, stride, downsample)
            out.append(block)
            self.inplanes = planes * expansion
            offset += 1
        return nn.Sequential(*out), offset

    def forward(self, x: Tensor) -> Tensor:
        x = self.maxpool(self.relu(self.bn1(self.conv1(x))))
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        return self.fc(torch.flatten(self.avgpool(x), 1))


def _builders(arch: str):
    table = {
        "resnet18": (PrunableBasicBlock, [2, 2, 2, 2], tv_resnet.resnet18, tv_resnet.ResNet18_Weights),
        "resnet50": (PrunableBottleneck, [3, 4, 6, 3], tv_resnet.resnet50, tv_resnet.ResNet50_Weights),
    }
    if arch not in table:
        raise ValueError(f"Unsupported ResNet architecture: {arch}")
    return table[arch]


def build_prunable_resnet(
    arch: str,
    num_classes: int = 1000,
    weights: str | None = "DEFAULT",
) -> PrunableResNet:
    block, layers, tv_builder, weights_enum = _builders(arch)
    model = PrunableResNet(block, layers, num_classes=num_classes)
    model.arch = arch
    if weights is not None and str(weights).lower() not in {"", "none", "false"}:
        weight_obj = weights_enum.DEFAULT if str(weights).lower() == "default" else getattr(weights_enum, str(weights))
        source = tv_builder(weights=weight_obj)
        state = source.state_dict()
        if num_classes != source.fc.out_features:
            state.pop("fc.weight", None)
            state.pop("fc.bias", None)
        missing, unexpected = model.load_state_dict(state, strict=False)
        unexpected = [key for key in unexpected if not key.endswith("gate")]
        missing = [key for key in missing if not key.endswith("gate") and not key.startswith("fc.")]
        if missing or unexpected:
            raise RuntimeError(f"ResNet pretrained conversion failed. missing={missing}, unexpected={unexpected}")
    return model


def export_slim_resnet(model: PrunableResNet) -> SlimResNet:
    device = next(model.parameters()).device
    was_training = model.training
    source = model.cpu().eval()
    units = [m for m in source.modules() if isinstance(m, (PrunableBasicBlock, PrunableBottleneck))]
    keep = [m.active_indices().cpu() for m in units]
    keep = [idx if idx.numel() > 0 else torch.tensor([0], dtype=torch.long) for idx in keep]
    block_type = "basic" if isinstance(units[0], PrunableBasicBlock) else "bottleneck"
    slim = SlimResNet(block_type, [int(x.numel()) for x in keep], source.layers_cfg, source.fc.out_features)
    slim.conv1.weight.data.copy_(source.conv1.weight.data)
    slim.bn1.load_state_dict(source.bn1.state_dict())
    slim.fc.load_state_dict(source.fc.state_dict())

    slim_units: List[nn.Module] = []
    for name in ("layer1", "layer2", "layer3", "layer4"):
        slim_units.extend(list(getattr(slim, name)))
    for old, new, idx in zip(units, slim_units, keep):
        if isinstance(old, PrunableBasicBlock) and isinstance(new, SlimBasicBlock):
            new.conv1.weight.data.copy_(old.conv1.weight.data.index_select(0, idx))
            copy_batchnorm_subset(new.bn1, old.bn1, idx)
            new.conv2.weight.data.copy_(old.conv2.weight.data.index_select(1, idx))
            new.bn2.load_state_dict(old.bn2.state_dict())
        elif isinstance(old, PrunableBottleneck) and isinstance(new, SlimBottleneck):
            new.conv1.weight.data.copy_(old.conv1.weight.data.index_select(0, idx))
            copy_batchnorm_subset(new.bn1, old.bn1, idx)
            new.conv2.weight.data.copy_(old.conv2.weight.data.index_select(0, idx).index_select(1, idx))
            copy_batchnorm_subset(new.bn2, old.bn2, idx)
            new.conv3.weight.data.copy_(old.conv3.weight.data.index_select(1, idx))
            new.bn3.load_state_dict(old.bn3.state_dict())
        else:
            raise TypeError(f"Unexpected block pair: {type(old)} / {type(new)}")
        if old.downsample is not None and new.downsample is not None:
            new.downsample.load_state_dict(old.downsample.state_dict())
    model.to(device).train(was_training)
    return slim
