from __future__ import annotations

import gc
from collections import defaultdict
from typing import Any, Dict, Mapping

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .datasets import (
    build_eval_transform,
    build_loader,
    iter_imagenet_c_datasets,
    resolve_batch_size,
)
from .engine import evaluate_classification, evaluate_frequency_regions
from .h200_runtime import cleanup_loader


def evaluate_standard_suite(
    model: nn.Module,
    loaders: Mapping[str, DataLoader | None],
    config: Mapping[str, Any],
    device: torch.device,
    *,
    suite_mode: str = "full",
) -> Dict[str, Any]:
    """Evaluate a clean round checkpoint or the complete final suite."""

    suite_mode = str(suite_mode).lower()
    if suite_mode == "none":
        return {}
    if suite_mode not in {"clean", "full"}:
        raise ValueError("suite_mode must be clean/full/none")
    eval_cfg = config["evaluation"]
    model_cfg = config["model"]
    train_cfg = config["train"]
    pruning_cfg = config["pruning"]
    channels_last = bool(model_cfg.get("channels_last", False)) and device.type == "cuda"
    output: Dict[str, Any] = {}
    ood_names = tuple(
        name for name in ("imagenet_r", "imagenet_sketch", "stylized_imagenet") if loaders.get(name) is not None
    )
    names = ("val",) if suite_mode == "clean" else ("val", "test", *ood_names)
    evaluated: Dict[int, str] = {}
    for name in names:
        if name == "imagenet_r" and not bool(eval_cfg.get("eval_imagenet_r", True)):
            continue
        loader = loaders.get(name)
        if loader is None:
            continue
        prior = evaluated.get(id(loader))
        if prior is not None:
            output[name] = dict(output[prior])
            output[name]["alias_of"] = prior
            continue
        output[name] = evaluate_classification(
            model,
            loader,
            device,
            amp=str(train_cfg["amp"]),
            channels_last=channels_last,
        )
        evaluated[id(loader)] = name
    if suite_mode == "full" and bool(eval_cfg.get("eval_filtered", True)) and loaders.get("val") is not None:
        frequency: Dict[str, Any] = {}
        for cutoff in eval_cfg.get("frequency_cutoffs", [pruning_cfg["cutoff"]]):
            frequency[f"rc_{float(cutoff):.4f}"] = evaluate_frequency_regions(
                model,
                loaders["val"],  # type: ignore[arg-type]
                device,
                float(cutoff),
                amp=str(train_cfg["amp"]),
                channels_last=channels_last,
                low_quantile=float(eval_cfg.get("l2_low_quantile", 0.25)),
                high_quantile=float(eval_cfg.get("l2_high_quantile", 0.75)),
                cutoff_mode=str(pruning_cfg.get("cutoff_mode", "relative")),
                transition_width=float(pruning_cfg.get("transition_width", 0.0)),
                hp_dc_mode=str(pruning_cfg.get("hp_dc_mode", "image_mean")),
            )
        output["frequency"] = frequency
    return output


def evaluate_imagenet_c(
    model: nn.Module,
    config: Mapping[str, Any],
    global_class_to_idx: Mapping[str, int],
    device: torch.device,
    distributed: bool,
) -> Dict[str, Any]:
    """Evaluate ImageNet-C with at most one split/worker pool resident."""

    data_cfg = config["data"]
    eval_cfg = config["evaluation"]
    root = str(data_cfg.get("imagenet_c_root", ""))
    if not root:
        return {"skipped": "data.imagenet_c_root is empty"}
    transform = build_eval_transform(
        int(config["model"]["image_size"]),
        int(data_cfg["resize_size"]),
        str(data_cfg.get("interpolation", "bicubic")),
        str(data_cfg.get("normalization", "imagenet")),
    )
    details: Dict[str, Any] = {}
    corruption_scores: Dict[str, list[float]] = defaultdict(list)
    split_iterator = iter_imagenet_c_datasets(
        root,
        global_class_to_idx,
        transform,
        eval_cfg.get("imagenet_c_corruptions", "all"),
        eval_cfg.get("imagenet_c_severities", [1, 2, 3, 4, 5]),
    )
    for index, (name, dataset) in enumerate(split_iterator):
        loader = build_loader(
            dataset,
            resolve_batch_size(data_cfg, "eval_batch_size", distributed),
            int(data_cfg["workers"]),
            False,
            distributed,
            False,
            int(config["experiment"]["seed"]) + 100 + index,
            role="eval",
            persistent_workers=False,
        )
        assert loader is not None
        try:
            metrics = evaluate_classification(
                model,
                loader,
                device,
                amp=str(config["train"]["amp"]),
                channels_last=bool(config["model"].get("channels_last", False))
                and device.type == "cuda",
            )
        finally:
            cleanup_loader(loader)
            del loader
        details[name] = metrics
        corruption_scores[name.split("/")[0]].append(float(metrics["top1"]))
        del dataset
        if index % 10 == 9:
            gc.collect()
    by_corruption = {
        name: float(np.mean(scores)) for name, scores in corruption_scores.items()
    }
    return {
        "mean_top1": (
            float(np.mean(list(by_corruption.values()))) if by_corruption else float("nan")
        ),
        "by_corruption": by_corruption,
        "details": details,
    }
