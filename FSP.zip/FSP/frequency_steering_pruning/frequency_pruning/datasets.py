from __future__ import annotations

import os
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

import numpy as np

from PIL import Image, ImageFile
import torch
from torch import Tensor
from torch.utils.data import DataLoader, Dataset, DistributedSampler, Subset

from frequency_pruning.h200_runtime import cleanup_loader, env_int, resolve_loader_runtime
from frequency_pruning.torchvision_compat import ensure_torchvision_nms_stub

ensure_torchvision_nms_stub()
from torchvision import datasets, transforms
from torchvision.datasets.folder import default_loader
from torchvision.transforms import InterpolationMode

ImageFile.LOAD_TRUNCATED_IMAGES = True


@dataclass
class DatasetBundle:
    train: Dataset | None
    val: Dataset | None
    calibration: Dataset | None
    test: Dataset | None
    num_classes: int
    class_to_idx: Dict[str, int]
    ood: Dict[str, Dataset] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


class MappedImageFolder(Dataset):
    """ImageFolder whose local folder labels are mapped to a global label space."""

    def __init__(
        self,
        root: str | Path,
        global_class_to_idx: Mapping[str, int],
        transform=None,
        strict: bool = True,
    ) -> None:
        self.base = datasets.ImageFolder(str(root), transform=transform)
        unknown = sorted(set(self.base.classes) - set(global_class_to_idx))
        if unknown and strict:
            raise ValueError(
                f"{root} contains classes absent from the global ImageNet mapping: {unknown[:10]}"
            )
        self.local_to_global = {
            local_idx: int(global_class_to_idx[name])
            for name, local_idx in self.base.class_to_idx.items()
            if name in global_class_to_idx
        }
        allowed = set(self.local_to_global)
        self.indices = [index for index, (_, target) in enumerate(self.base.samples) if target in allowed]
        self.classes = list(self.base.classes)
        self.class_to_idx = dict(global_class_to_idx)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, index: int):
        image, local = self.base[self.indices[index]]
        return image, self.local_to_global[int(local)]


class ImageFolderTransformView(Dataset):
    """Share an ImageFolder sample index while applying another transform."""

    def __init__(self, source: datasets.ImageFolder, transform=None) -> None:
        self.root = source.root
        self.loader = source.loader
        self.transform = transform
        self.target_transform = source.target_transform
        self.extensions = source.extensions
        self.classes = source.classes
        self.class_to_idx = source.class_to_idx
        self.samples = source.samples
        self.imgs = self.samples
        self.targets = source.targets

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int):
        path, target = self.samples[index]
        image = self.loader(path)
        if self.transform is not None:
            image = self.transform(image)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return image, target


class DistributedShardSampler(torch.utils.data.Sampler[int]):
    """Deterministic no-padding sampler for unwrapped saliency forwards.

    DDP evaluation needs equal forward counts because DDP may synchronize
    buffers. Saliency explicitly uses the unwrapped module, so calibration can
    avoid DistributedSampler's duplicated padding examples and recover the exact
    global subset even when its size is not divisible by world size.
    """

    def __init__(self, dataset: Dataset) -> None:
        if not torch.distributed.is_available() or not torch.distributed.is_initialized():
            raise RuntimeError("DistributedShardSampler requires an initialized process group")
        self.dataset = dataset
        self.rank = torch.distributed.get_rank()
        self.world_size = torch.distributed.get_world_size()

    def __iter__(self):
        return iter(range(self.rank, len(self.dataset), self.world_size))

    def __len__(self) -> int:
        if self.rank >= len(self.dataset):
            return 0
        return (len(self.dataset) - 1 - self.rank) // self.world_size + 1


class CUB2002011(Dataset):
    """CUB-200-2011 loader using the official metadata text files."""

    def __init__(self, root: str | Path, train: bool, transform=None) -> None:
        root = Path(root)
        candidate = root / "CUB_200_2011"
        self.root = candidate if candidate.exists() else root
        self.transform = transform
        images_file = self.root / "images.txt"
        labels_file = self.root / "image_class_labels.txt"
        split_file = self.root / "train_test_split.txt"
        if not all(path.exists() for path in (images_file, labels_file, split_file)):
            raise FileNotFoundError(
                "CUB metadata missing. Expected images.txt, image_class_labels.txt, "
                f"and train_test_split.txt under {self.root}"
            )
        paths = _read_id_value_file(images_file, str)
        labels = _read_id_value_file(labels_file, int)
        splits = _read_id_value_file(split_file, int)
        wanted = 1 if train else 0
        ids = sorted(index for index in paths if int(splits[index]) == wanted)
        self.samples = [(self.root / "images" / paths[index], int(labels[index]) - 1) for index in ids]
        self.classes = self._load_classes()
        self.class_to_idx = {name: index for index, name in enumerate(self.classes)}

    def _load_classes(self) -> List[str]:
        classes_file = self.root / "classes.txt"
        if classes_file.exists():
            values = _read_id_value_file(classes_file, str)
            return [values[index] for index in sorted(values)]
        return [f"class_{index:03d}" for index in range(200)]

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int):
        path, target = self.samples[index]
        image = default_loader(str(path))
        if self.transform is not None:
            image = self.transform(image)
        return image, target


def _read_id_value_file(path: Path, value_type):
    output: Dict[int, Any] = {}
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            index, value = line.split(maxsplit=1)
            output[int(index)] = value_type(value)
    return output


class SyntheticFrequencyDataset(Dataset):
    """Deterministic smoke-test data with labels tied to low/high-frequency cues."""

    def __init__(
        self,
        size: int = 128,
        image_size: int = 64,
        num_classes: int = 4,
        seed: int = 0,
        transform=None,
    ) -> None:
        self.size = int(size)
        self.image_size = int(image_size)
        self.num_classes = int(num_classes)
        self.seed = int(seed)
        self.transform = transform
        self.classes = [f"synthetic_{i}" for i in range(num_classes)]
        self.class_to_idx = {name: i for i, name in enumerate(self.classes)}

    def __len__(self) -> int:
        return self.size

    def __getitem__(self, index: int):
        generator = torch.Generator().manual_seed(self.seed + index)
        target = index % self.num_classes
        h = w = self.image_size
        yy, xx = torch.meshgrid(torch.linspace(-1, 1, h), torch.linspace(-1, 1, w), indexing="ij")
        import math
        angle = target * math.pi / max(1, self.num_classes)
        low = math.cos(angle) * xx + math.sin(angle) * yy
        low = torch.exp(-((low - 0.15) ** 2) / 0.16)
        frequency = 4 + target * 2
        high = 0.5 + 0.5 * torch.sin(frequency * 3.141592653589793 * (xx - yy))
        noise = torch.randn((h, w), generator=generator) * 0.03
        image = torch.stack(
            [0.65 * low + 0.25 * high, 0.55 * low + 0.35 * (1 - high), 0.45 * low + 0.25 * high]
        )
        image = (image + noise).clamp(0, 1)
        pil = transforms.ToPILImage()(image)
        if self.transform is not None:
            pil = self.transform(pil)
        return pil, target


class BandTaskDataset(Dataset):
    """Controlled task whose label lives in a known frequency band.

    Every image is the sum of a low-frequency oriented wave (1-1.5 cycles per
    image, normalised radius < 0.125), a high-frequency oriented grating (period
    of 3-5 pixels at 32 px, radius ~0.45-0.6) and white noise.  The two
    orientations are drawn independently from ``classes`` values.

    * ``task="joint"``: label = (low orientation, high orientation)  -> generic
      "pre-training" that needs both pathways;
    * ``task="low"`` / ``task="high"``: label = one orientation only -> downstream
      tasks whose band reliance is known by construction.

    Used by tools/controlled_experiment.py to test, in minutes and with ground
    truth, whether a pruning criterion keeps the pathway the task relies on.
    """

    def __init__(
        self,
        size: int,
        image_size: int,
        task: str,
        seed: int,
        classes: int = 8,
        low_amp: float = 0.18,
        high_amp: float = 0.18,
        noise: float = 0.12,
        transform=None,
    ) -> None:
        import math

        task = str(task).lower()
        if task not in {"joint", "low", "high"}:
            raise ValueError("bandtask task must be joint, low or high")
        self.transform = transform
        self.task = task
        generator = torch.Generator().manual_seed(int(seed))
        n, k = int(size), int(classes)
        c_low = torch.randint(0, k, (n,), generator=generator)
        c_high = torch.randint(0, k, (n,), generator=generator)
        f_low = 1.0 + 0.5 * torch.rand(n, generator=generator)
        scale = image_size / 32.0
        f_high = (7.0 + 3.0 * torch.rand(n, generator=generator)) * scale
        phase_low = 2 * math.pi * torch.rand(n, generator=generator)
        phase_high = 2 * math.pi * torch.rand(n, generator=generator)
        axis = torch.linspace(0.0, 1.0, image_size + 1)[:-1]
        yy, xx = torch.meshgrid(axis, axis, indexing="ij")

        def wave(cls: Tensor, freq: Tensor, phase: Tensor) -> Tensor:
            theta = cls.float() * math.pi / k
            proj = torch.cos(theta).view(-1, 1, 1) * xx + torch.sin(theta).view(-1, 1, 1) * yy
            return torch.sin(2 * math.pi * freq.view(-1, 1, 1) * proj + phase.view(-1, 1, 1))

        base = 0.5 + low_amp * wave(c_low, f_low, phase_low) + high_amp * wave(c_high, f_high, phase_high)
        images = base.unsqueeze(1).repeat(1, 3, 1, 1)
        images = images + noise * torch.randn(images.shape, generator=generator)
        self.images = images.clamp(0.0, 1.0)
        if task == "joint":
            self.targets = (c_low * k + c_high).tolist()
            self.num_classes = k * k
        elif task == "low":
            self.targets = c_low.tolist()
            self.num_classes = k
        else:
            self.targets = c_high.tolist()
            self.num_classes = k
        self.classes = [f"band_{i}" for i in range(self.num_classes)]
        self.class_to_idx = {name: i for i, name in enumerate(self.classes)}

    def __len__(self) -> int:
        return len(self.targets)

    def __getitem__(self, index: int):
        image = self.images[index]
        if self.transform is not None:
            image = self.transform(image)
        return image, int(self.targets[index])


def interpolation_mode(name: str) -> InterpolationMode:
    name = str(name).lower()
    table = {
        "nearest": InterpolationMode.NEAREST,
        "bilinear": InterpolationMode.BILINEAR,
        "bicubic": InterpolationMode.BICUBIC,
    }
    if name not in table:
        raise ValueError(f"Unsupported interpolation: {name}")
    return table[name]


def build_train_transform(
    image_size: int,
    interpolation: str = "bicubic",
    normalization: str = "imagenet",
    augment: bool = True,
):
    ops: List[Any] = []
    if augment:
        ops.extend(
            [
                transforms.RandomResizedCrop(
                    image_size,
                    scale=(0.08, 1.0),
                    interpolation=interpolation_mode(interpolation),
                ),
                transforms.RandomHorizontalFlip(),
            ]
        )
    else:
        ops.extend(
            [
                transforms.Resize(image_size, interpolation=interpolation_mode(interpolation)),
                transforms.CenterCrop(image_size),
            ]
        )
    ops.append(transforms.ToTensor())
    if normalization == "imagenet":
        ops.append(transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)))
    elif normalization not in {"none", ""}:
        raise ValueError(f"Unsupported normalization: {normalization}")
    return transforms.Compose(ops)


def build_eval_transform(
    image_size: int,
    resize_size: int | None = None,
    interpolation: str = "bicubic",
    normalization: str = "imagenet",
):
    resize_size = int(resize_size or round(image_size / 0.875))
    ops: List[Any] = [
        transforms.Resize(resize_size, interpolation=interpolation_mode(interpolation)),
        transforms.CenterCrop(image_size),
        transforms.ToTensor(),
    ]
    if normalization == "imagenet":
        ops.append(transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)))
    elif normalization not in {"none", ""}:
        raise ValueError(f"Unsupported normalization: {normalization}")
    return transforms.Compose(ops)


def deterministic_subset(dataset: Dataset | None, size: int, seed: int) -> Dataset | None:
    if dataset is None or size <= 0 or size >= len(dataset):
        return dataset
    generator = torch.Generator().manual_seed(int(seed))
    indices = torch.randperm(len(dataset), generator=generator)[: int(size)].tolist()
    return Subset(dataset, indices)


def fraction_subset(dataset: Dataset | None, fraction: float, seed: int) -> Dataset | None:
    if dataset is None or fraction >= 1.0:
        return dataset
    if fraction <= 0:
        raise ValueError("Dataset fraction must be positive")
    return deterministic_subset(dataset, max(1, int(round(len(dataset) * fraction))), seed)


def stratified_split(dataset: datasets.ImageFolder, val_fraction: float, seed: int) -> tuple[Subset, Subset]:
    by_class: Dict[int, List[int]] = {}
    for index, (_, target) in enumerate(dataset.samples):
        by_class.setdefault(int(target), []).append(index)
    generator = random.Random(int(seed))
    train_indices: List[int] = []
    val_indices: List[int] = []
    for indices in by_class.values():
        generator.shuffle(indices)
        n_val = max(1, int(round(len(indices) * val_fraction))) if len(indices) > 1 else 0
        val_indices.extend(indices[:n_val])
        train_indices.extend(indices[n_val:])
    return Subset(dataset, sorted(train_indices)), Subset(dataset, sorted(val_indices))


def _resolve_imagenet_roots(data_cfg: Mapping[str, Any]) -> tuple[Path, Path, Path]:
    root = Path(str(data_cfg.get("root", ""))) if data_cfg.get("root") else Path()
    train_root = Path(str(data_cfg.get("train_root", ""))) if data_cfg.get("train_root") else root / "train"
    val_root = Path(str(data_cfg.get("val_root", ""))) if data_cfg.get("val_root") else root / "val"
    calibration_root = (
        Path(str(data_cfg.get("calibration_root", "")))
        if data_cfg.get("calibration_root")
        else train_root
    )
    return train_root, val_root, calibration_root


# torchvision classification datasets usable as transfer tasks without custom code.
# name -> (class name, kwargs for train split, kwargs for val split, kwargs for test split or None)
# Datasets without an official validation split use the test split for validation
# (as CUB does); datasets without any split are split deterministically and
# stratified (``tv_val_fraction``).
_TV_SPECS: Dict[str, Dict[str, Any]] = {
    "flowers102": {"cls": "Flowers102", "train": {"split": "train"}, "val": {"split": "val"}, "test": {"split": "test"}},
    "oxfordiiitpet": {"cls": "OxfordIIITPet", "train": {"split": "trainval"}, "val": {"split": "test"}, "test": None},
    "fgvcaircraft": {"cls": "FGVCAircraft", "train": {"split": "train"}, "val": {"split": "val"}, "test": {"split": "test"}},
    "food101": {"cls": "Food101", "train": {"split": "train"}, "val": {"split": "test"}, "test": None},
    "gtsrb": {"cls": "GTSRB", "train": {"split": "train"}, "val": {"split": "test"}, "test": None},
    "stanfordcars": {"cls": "StanfordCars", "train": {"split": "train"}, "val": {"split": "test"}, "test": None},
    "country211": {"cls": "Country211", "train": {"split": "train"}, "val": {"split": "valid"}, "test": {"split": "test"}},
    "pcam": {"cls": "PCAM", "train": {"split": "train"}, "val": {"split": "val"}, "test": {"split": "test"}},
    "eurosat": {"cls": "EuroSAT", "train": None, "val": None, "test": None},
    "sun397": {"cls": "SUN397", "train": None, "val": None, "test": None},
    "caltech101": {"cls": "Caltech101", "train": None, "val": None, "test": None},
}


class _TransformedSubset(Dataset):
    """Index subset of a base dataset with its own transform (base returns PIL)."""

    def __init__(self, base: Dataset, indices: Sequence[int], transform: Callable | None) -> None:
        self.base = base
        self.indices = list(indices)
        self.transform = transform

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, index: int):
        image, target = self.base[self.indices[index]]
        if hasattr(image, "convert"):
            image = image.convert("RGB")
        if self.transform is not None:
            image = self.transform(image)
        return image, int(target)


def _tv_targets(dataset: Dataset) -> list[int]:
    for attribute in ("targets", "_labels", "labels", "_targets", "y"):
        value = getattr(dataset, attribute, None)
        if value is not None:
            return [int(v) for v in value]
    samples = getattr(dataset, "_samples", None) or getattr(dataset, "samples", None)
    if samples is not None:
        return [int(sample[1]) for sample in samples]
    return [int(dataset[index][1]) for index in range(len(dataset))]


def _build_torchvision_bundle(
    data_cfg: Mapping[str, Any],
    train_transform: Callable,
    eval_transform: Callable,
    cal_transform: Callable,
    split_seed: int,
) -> DatasetBundle:
    name = str(data_cfg.get("tv_name", "")).lower().replace("-", "").replace("_", "")
    if name not in _TV_SPECS:
        raise ValueError(f"Unsupported torchvision transfer dataset {name!r}; choose from {sorted(_TV_SPECS)}")
    spec = _TV_SPECS[name]
    cls = getattr(datasets, spec["cls"])
    root = str(data_cfg.get("folder_root") or data_cfg.get("root") or "")
    download = bool(data_cfg.get("download", False))

    def make(kwargs: Mapping[str, Any] | None) -> Dataset:
        return cls(root, download=download, **(kwargs or {}))

    if spec["train"] is None:
        base = make(None)
        targets = _tv_targets(base)
        rng = np.random.default_rng(split_seed)
        by_class: Dict[int, list[int]] = {}
        for index, target in enumerate(targets):
            by_class.setdefault(target, []).append(index)
        train_idx: list[int] = []
        val_idx: list[int] = []
        fraction = float(data_cfg.get("tv_val_fraction", 0.2))
        for target in sorted(by_class):
            indices = np.array(by_class[target])
            rng.shuffle(indices)
            cut = max(1, int(round(len(indices) * fraction)))
            val_idx.extend(int(i) for i in indices[:cut])
            train_idx.extend(int(i) for i in indices[cut:])
        train = _TransformedSubset(base, sorted(train_idx), train_transform)
        val = _TransformedSubset(base, sorted(val_idx), eval_transform)
        test: Dataset = val
        calibration_source: Dataset = _TransformedSubset(base, sorted(train_idx), cal_transform)
        num_classes = len(by_class)
    else:
        train_base = make(spec["train"])
        val_base = make(spec["val"])
        train = _TransformedSubset(train_base, range(len(train_base)), train_transform)
        val = _TransformedSubset(val_base, range(len(val_base)), eval_transform)
        if spec["test"] is not None:
            test_base = make(spec["test"])
            test = _TransformedSubset(test_base, range(len(test_base)), eval_transform)
        else:
            test = val
        calibration_source = _TransformedSubset(train_base, range(len(train_base)), cal_transform)
        num_classes = len(set(_tv_targets(train_base)))
    calibration = deterministic_subset(calibration_source, int(data_cfg["calibration_size"]), split_seed)
    class_to_idx = {str(index): index for index in range(num_classes)}
    return DatasetBundle(train, val, calibration, test, num_classes, class_to_idx)


def build_dataset_bundle(config: Mapping[str, Any]) -> DatasetBundle:
    data_cfg = config["data"]
    model_cfg = config["model"]
    dataset_name = str(data_cfg["dataset"]).lower().replace("-", "_")
    image_size = int(model_cfg["image_size"])
    resize_size = int(data_cfg["resize_size"])
    interpolation = str(data_cfg.get("interpolation", "bicubic"))
    normalization = str(data_cfg.get("normalization", "imagenet"))
    train_transform = build_train_transform(image_size, interpolation, normalization, augment=True)
    eval_transform = build_eval_transform(image_size, resize_size, interpolation, normalization)
    # Calibration views. A fine-tuned model can memorise its (evaluation-transformed)
    # training images, which makes loss gradients on them vanish; augmented views of
    # the same images are not memorised and keep gradient criteria informative.
    cal_transform = train_transform if bool(data_cfg.get("calibration_augment", False)) else eval_transform
    split_seed = int(data_cfg.get("split_seed", config["experiment"]["seed"]))

    if dataset_name in {"imagenet", "imagenet1k", "ilsvrc2012"}:
        train_root, val_root, calibration_root = _resolve_imagenet_roots(data_cfg)
        if not train_root.exists() or not val_root.exists():
            raise FileNotFoundError(
                f"ImageNet folders not found: train={train_root}, val={val_root}. "
                "Set data.root or data.train_root/data.val_root."
            )
        train = datasets.ImageFolder(str(train_root), transform=train_transform)
        val = datasets.ImageFolder(str(val_root), transform=eval_transform)
        if calibration_root.resolve() == train_root.resolve():
            calibration = ImageFolderTransformView(train, transform=cal_transform)
        elif calibration_root.resolve() == val_root.resolve():
            calibration = val
        else:
            calibration = datasets.ImageFolder(str(calibration_root), transform=eval_transform)
        if train.class_to_idx != val.class_to_idx:
            raise ValueError("ImageNet train/val class mappings differ")
        class_to_idx = dict(train.class_to_idx)
        ood: Dict[str, Dataset] = {}
        r_root = str(data_cfg.get("imagenet_r_root", ""))
        if r_root:
            ood["imagenet_r"] = MappedImageFolder(r_root, class_to_idx, eval_transform)
        # Optional low-frequency / shape-biased OOD sets (same WNID folder layout).
        for key, name in (
            ("imagenet_sketch_root", "imagenet_sketch"),
            ("stylized_imagenet_root", "stylized_imagenet"),
        ):
            extra_root = str(data_cfg.get(key, "") or "")
            if extra_root and Path(extra_root).exists():
                ood[name] = MappedImageFolder(extra_root, class_to_idx, eval_transform, strict=False)
        bundle = DatasetBundle(train, val, calibration, val, len(class_to_idx), class_to_idx, ood)

    elif dataset_name in {"neu", "neu_cls", "neucls"}:
        root = Path(str(data_cfg.get("neu_root") or data_cfg.get("root") or ""))
        if not root.exists():
            raise FileNotFoundError(f"NEU-CLS root not found: {root}")
        # If official train/val folders are supplied, preserve them. Otherwise use a
        # deterministic stratified split over the six defect folders.
        if (root / "train").is_dir() and (root / "val").is_dir():
            train = datasets.ImageFolder(str(root / "train"), transform=train_transform)
            val = datasets.ImageFolder(str(root / "val"), transform=eval_transform)
            class_to_idx = dict(train.class_to_idx)
            calibration_source: Dataset = ImageFolderTransformView(train, transform=cal_transform)
        else:
            raw_train = datasets.ImageFolder(str(root), transform=train_transform)
            raw_eval = ImageFolderTransformView(raw_train, transform=eval_transform)
            train_idx, val_idx = stratified_split(raw_train, float(data_cfg.get("neu_val_fraction", 0.2)), split_seed)
            train = train_idx
            # Rebuild subset over evaluation-transform instance.
            val = Subset(raw_eval, list(val_idx.indices))
            class_to_idx = dict(raw_train.class_to_idx)
            calibration_source = Subset(
                ImageFolderTransformView(raw_train, transform=cal_transform), list(train_idx.indices)
            )
        # Saliency calibration must never see evaluation images (val == test here).
        calibration = deterministic_subset(calibration_source, int(data_cfg["calibration_size"]), split_seed)
        bundle = DatasetBundle(train, val, calibration, val, len(class_to_idx), class_to_idx)

    elif dataset_name == "dtd":
        root = Path(str(data_cfg.get("dtd_root") or data_cfg.get("root") or ""))
        download = bool(data_cfg.get("download", False))
        partition = int(data_cfg.get("dtd_partition", 1))
        train = datasets.DTD(str(root), split="train", partition=partition, transform=train_transform, download=download)
        val = datasets.DTD(str(root), split="val", partition=partition, transform=eval_transform, download=download)
        test = datasets.DTD(str(root), split="test", partition=partition, transform=eval_transform, download=download)
        class_to_idx = dict(train.class_to_idx)
        calibration_source = datasets.DTD(
            str(root), split="train", partition=partition, transform=cal_transform, download=False
        )
        calibration = deterministic_subset(calibration_source, int(data_cfg["calibration_size"]), split_seed)
        bundle = DatasetBundle(train, val, calibration, test, len(class_to_idx), class_to_idx)

    elif dataset_name in {"cub", "cub200", "cub_200_2011"}:
        root = Path(str(data_cfg.get("cub_root") or data_cfg.get("root") or ""))
        train = CUB2002011(root, train=True, transform=train_transform)
        val = CUB2002011(root, train=False, transform=eval_transform)
        class_to_idx = dict(train.class_to_idx)
        calibration_source = CUB2002011(root, train=True, transform=cal_transform)
        calibration = deterministic_subset(calibration_source, int(data_cfg["calibration_size"]), split_seed)
        bundle = DatasetBundle(train, val, calibration, val, len(class_to_idx), class_to_idx)

    elif dataset_name in {"imagefolder", "folder", "custom"}:
        # Generic transfer dataset: <root>/train/<class>/*.jpg, <root>/val/<class>/*.jpg
        # and optionally <root>/test/<class>/*.jpg. Used to add texture / defect /
        # scene datasets (e.g. KTH-TIPS2b, MVTec-cls, SUN397 subset) without code.
        root = Path(str(data_cfg.get("folder_root") or data_cfg.get("root") or ""))
        if not (root / "train").is_dir() or not (root / "val").is_dir():
            raise FileNotFoundError(f"imagefolder dataset needs {root}/train and {root}/val")
        train = datasets.ImageFolder(str(root / "train"), transform=train_transform)
        val = datasets.ImageFolder(str(root / "val"), transform=eval_transform)
        test = datasets.ImageFolder(str(root / "test"), transform=eval_transform) if (root / "test").is_dir() else val
        if train.class_to_idx != val.class_to_idx:
            raise ValueError(f"imagefolder train/val class mappings differ under {root}")
        class_to_idx = dict(train.class_to_idx)
        calibration_source = ImageFolderTransformView(train, transform=cal_transform)
        calibration = deterministic_subset(calibration_source, int(data_cfg["calibration_size"]), split_seed)
        bundle = DatasetBundle(train, val, calibration, test, len(class_to_idx), class_to_idx)

    elif dataset_name in {"torchvision", "tv"}:
        bundle = _build_torchvision_bundle(data_cfg, train_transform, eval_transform, cal_transform, split_seed)

    elif dataset_name == "bandtask":
        # Controlled frequency task: no geometric augmentation (it would change
        # the orientation/frequency that defines the label), only normalisation.
        mean, std = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)
        norm = transforms.Normalize(mean, std)
        task = str(data_cfg.get("bandtask_task", "joint"))
        classes = int(data_cfg.get("bandtask_classes", 8))
        kwargs = dict(
            image_size=image_size,
            task=task,
            classes=classes,
            low_amp=float(data_cfg.get("bandtask_low_amp", 0.18)),
            high_amp=float(data_cfg.get("bandtask_high_amp", 0.18)),
            noise=float(data_cfg.get("bandtask_noise", 0.12)),
            transform=norm,
        )
        train = BandTaskDataset(int(data_cfg.get("bandtask_train_size", 2048)), seed=split_seed * 7919 + 1, **kwargs)
        val = BandTaskDataset(int(data_cfg.get("bandtask_val_size", 2048)), seed=split_seed * 7919 + 2, **kwargs)
        calibration = deterministic_subset(train, int(data_cfg["calibration_size"]), split_seed)
        bundle = DatasetBundle(train, val, calibration, val, train.num_classes, train.class_to_idx)

    elif dataset_name in {"synthetic", "smoke"}:
        num_classes = int(model_cfg.get("num_classes", 4))
        # Explicitly override ImageNet's default in smoke configs.
        if num_classes == 1000:
            num_classes = 4
        train = SyntheticFrequencyDataset(96, image_size, num_classes, split_seed, train_transform)
        val = SyntheticFrequencyDataset(48, image_size, num_classes, split_seed + 10000, eval_transform)
        calibration = SyntheticFrequencyDataset(32, image_size, num_classes, split_seed + 20000, eval_transform)
        bundle = DatasetBundle(train, val, calibration, val, num_classes, train.class_to_idx)

    else:
        raise ValueError(f"Unsupported dataset: {dataset_name}")

    shared_val_test = bundle.test is bundle.val
    bundle.train = fraction_subset(bundle.train, float(data_cfg.get("train_fraction", 1.0)), split_seed)
    bundle.val = fraction_subset(bundle.val, float(data_cfg.get("val_fraction", 1.0)), split_seed + 1)
    if shared_val_test:
        bundle.test = bundle.val
    else:
        bundle.test = fraction_subset(bundle.test, float(data_cfg.get("val_fraction", 1.0)), split_seed + 2)
    bundle.calibration = deterministic_subset(
        bundle.calibration,
        int(data_cfg.get("calibration_size", 0)),
        split_seed + 3,
    )
    holdout_fraction = float(data_cfg.get("holdout_fraction", 0.0))
    if holdout_fraction > 0 and bundle.train is not None:
        # Hold-out for model-selection decisions (e.g. the look-ahead choice of the
        # cross-layer calibration).  It is carved from the TRAINING split, so the
        # validation/test images are never used for selection, and it is removed
        # from the data used for recovery.
        total = len(bundle.train)  # type: ignore[arg-type]
        count = int(min(max(1, round(total * holdout_fraction)), int(data_cfg.get("holdout_max", 10000))))
        generator = torch.Generator().manual_seed(split_seed + 977)
        order = torch.randperm(total, generator=generator).tolist()
        bundle.ood["holdout"] = Subset(bundle.train, sorted(order[:count]))
        bundle.train = Subset(bundle.train, sorted(order[count:]))
    train_size = int(data_cfg.get("train_subset_size", 0))
    if train_size > 0 and train_size < len(bundle.train):  # type: ignore[arg-type]
        # A fixed subset (independent of the experiment seed) so that every method
        # and seed recovers on the same reduced training set.
        bundle.train = deterministic_subset(bundle.train, train_size, 20261119)
    eval_size = int(data_cfg.get("eval_subset_size", 0))
    if eval_size > 0:
        bundle.val = deterministic_subset(bundle.val, eval_size, split_seed + 4)
        if shared_val_test:
            bundle.test = bundle.val
        else:
            bundle.test = deterministic_subset(bundle.test, eval_size, split_seed + 5)
        bundle.ood = {
            name: deterministic_subset(dataset, eval_size, split_seed + 6 + i)  # type: ignore[arg-type]
            for i, (name, dataset) in enumerate(bundle.ood.items())
        }
    bundle.metadata.update({"dataset": dataset_name, "image_size": image_size})
    return bundle


def _seed_worker(worker_id: int) -> None:
    # torch.initial_seed already incorporates the DataLoader generator seed.
    worker_seed = torch.initial_seed() % 2**32
    random.seed(worker_seed)
    try:
        import numpy as np

        np.random.seed(worker_seed)
    except ImportError:
        pass


def build_loader(
    dataset: Dataset | None,
    batch_size: int,
    workers: int,
    shuffle: bool,
    distributed: bool,
    drop_last: bool = False,
    seed: int = 0,
    *,
    role: str = "eval",
    persistent_workers: bool | None = None,
) -> DataLoader | None:
    if dataset is None:
        return None
    world = max(1, int(os.environ.get("WORLD_SIZE", "1"))) if distributed else 1
    persistent = role == "train" if persistent_workers is None else bool(persistent_workers)
    runtime = resolve_loader_runtime(
        int(workers),
        world_size=world,
        persistent=persistent,
        pin_memory=torch.cuda.is_available(),
    )
    if distributed and role == "calibration":
        sampler = DistributedShardSampler(dataset)
    elif distributed:
        sampler = DistributedSampler(
            dataset,
            shuffle=shuffle,
            seed=int(seed),
            drop_last=drop_last,
        )
    else:
        sampler = None
    generator = torch.Generator().manual_seed(int(seed))
    kwargs: Dict[str, Any] = {
        "dataset": dataset,
        "batch_size": int(batch_size),
        "shuffle": bool(shuffle and sampler is None),
        "sampler": sampler,
        "num_workers": runtime.workers,
        "pin_memory": runtime.pin_memory,
        "drop_last": bool(drop_last),
        "persistent_workers": runtime.persistent_workers,
        "generator": generator,
        "worker_init_fn": _seed_worker,
    }
    if runtime.workers > 0 and runtime.prefetch_factor is not None:
        kwargs["prefetch_factor"] = runtime.prefetch_factor
    if runtime.workers > 0 and distributed:
        start_method = os.environ.get("FSP_DATALOADER_START_METHOD", "spawn").strip()
        if start_method:
            if start_method not in {"spawn", "forkserver"}:
                raise ValueError(
                    "FSP_DATALOADER_START_METHOD must be spawn or forkserver for "
                    "distributed jobs"
                )
            kwargs["multiprocessing_context"] = start_method
    return DataLoader(**kwargs)



def close_loaders(loaders: Mapping[str, DataLoader | None]) -> None:
    seen: set[int] = set()
    for loader in loaders.values():
        if loader is None or id(loader) in seen:
            continue
        seen.add(id(loader))
        cleanup_loader(loader)


def resolve_batch_size(data_cfg: Mapping[str, Any], key: str, distributed: bool) -> int:
    value = int(data_cfg[key])
    if value <= 0:
        raise ValueError(f"data.{key} must be positive")
    scope = str(data_cfg.get("batch_size_scope", "per_process")).lower()
    if not distributed or scope == "per_process":
        return value
    if scope != "global":
        raise ValueError("data.batch_size_scope must be per_process or global")
    world = torch.distributed.get_world_size()
    if value < world or value % world != 0:
        raise ValueError(
            f"Global data.{key}={value} must be divisible by world_size={world}"
        )
    return value // world


def build_loaders(
    bundle: DatasetBundle,
    config: Mapping[str, Any],
    distributed: bool,
) -> Dict[str, DataLoader | None]:
    data_cfg = config["data"]
    seed = int(config["experiment"]["seed"])
    workers = int(data_cfg["workers"])
    eval_workers = min(workers, env_int("FSP_EVAL_WORKERS_PER_JOB", 2, 0))
    calibration_workers = min(
        workers, env_int("FSP_CALIBRATION_WORKERS_PER_JOB", 2, 0)
    )
    train_batch = resolve_batch_size(data_cfg, "batch_size", distributed)
    eval_batch = resolve_batch_size(data_cfg, "eval_batch_size", distributed)
    calibration_value = int(data_cfg.get("calibration_batch_size", 0) or data_cfg["eval_batch_size"])
    calibration_cfg = dict(data_cfg)
    calibration_cfg["_calibration_batch"] = calibration_value
    calibration_batch = calibration_value
    if distributed and str(data_cfg.get("batch_size_scope", "per_process")).lower() == "global":
        world = torch.distributed.get_world_size()
        if calibration_value < world or calibration_value % world != 0:
            raise ValueError(
                f"Global calibration batch {calibration_value} must be divisible by world_size={world}"
            )
        calibration_batch = calibration_value // world

    train_loader = build_loader(
        bundle.train, train_batch, workers, True, distributed, False, seed, role="train"
    )
    val_loader = build_loader(
        bundle.val, eval_batch, eval_workers, False, distributed, False, seed + 1, role="eval"
    )
    if bundle.test is bundle.val:
        test_loader = val_loader
    else:
        test_loader = build_loader(
            bundle.test, eval_batch, eval_workers, False, distributed, False, seed + 2, role="eval"
        )
    calibration_loader = build_loader(
        bundle.calibration,
        calibration_batch,
        calibration_workers,
        False,
        distributed,
        False,
        seed + 3,
        role="calibration",
        persistent_workers=False,
    )
    output: Dict[str, DataLoader | None] = {
        "train": train_loader,
        "val": val_loader,
        "test": test_loader,
        "calibration": calibration_loader,
    }
    for index, (name, dataset) in enumerate(bundle.ood.items()):
        output[name] = build_loader(
            dataset,
            eval_batch,
            eval_workers,
            False,
            distributed,
            False,
            seed + 10 + index,
            role="eval",
            persistent_workers=False,
        )
    return output


IMAGENET_C_CORRUPTIONS = [
    "gaussian_noise",
    "shot_noise",
    "impulse_noise",
    "defocus_blur",
    "glass_blur",
    "motion_blur",
    "zoom_blur",
    "snow",
    "frost",
    "fog",
    "brightness",
    "contrast",
    "elastic_transform",
    "pixelate",
    "jpeg_compression",
]


def iter_imagenet_c_datasets(
    root: str | Path,
    global_class_to_idx: Mapping[str, int],
    transform,
    corruptions: str | Sequence[str] = "all",
    severities: Sequence[int] = (1, 2, 3, 4, 5),
):
    """Yield one ImageNet-C dataset at a time to bound metadata and FDs."""

    root = Path(root)
    if not root.exists():
        raise FileNotFoundError(f"ImageNet-C root not found: {root}")
    if isinstance(corruptions, str):
        names = (
            IMAGENET_C_CORRUPTIONS
            if corruptions.lower() == "all"
            else [item.strip() for item in corruptions.split(",") if item.strip()]
        )
    else:
        names = list(corruptions)
    for corruption in names:
        for severity in severities:
            path = root / corruption / str(int(severity))
            if not path.exists():
                raise FileNotFoundError(f"ImageNet-C split missing: {path}")
            yield (
                f"{corruption}/{int(severity)}",
                MappedImageFolder(path, global_class_to_idx, transform),
            )


def build_imagenet_c_datasets(
    root: str | Path,
    global_class_to_idx: Mapping[str, int],
    transform,
    corruptions: str | Sequence[str] = "all",
    severities: Sequence[int] = (1, 2, 3, 4, 5),
) -> Dict[str, Dataset]:
    """Compatibility wrapper; production evaluation uses the lazy iterator."""

    return dict(
        iter_imagenet_c_datasets(
            root, global_class_to_idx, transform, corruptions, severities
        )
    )
