from __future__ import annotations

PIPELINE_VERSION = "fsp-v4.1-mac-budget"
RELEASE_VERSION = "4.1.0"
