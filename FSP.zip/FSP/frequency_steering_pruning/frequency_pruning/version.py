from __future__ import annotations

# The pipeline version is unchanged from v5 on purpose: the protocol of every existing method is
# identical, so completed runs are reused and only the new variants and stages are executed.
PIPELINE_VERSION = "fsp-v5-spectral-reliance"
RELEASE_VERSION = "6.3.0"
