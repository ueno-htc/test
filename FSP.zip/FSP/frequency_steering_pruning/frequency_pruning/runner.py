from __future__ import annotations

import copy
import gc
import json
import math
import os
import time
from pathlib import Path
from typing import Any, Dict, Mapping, MutableMapping, Sequence

import numpy as np
import torch
import torch.nn as nn
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader

from .checkpoint import load_checkpoint, save_checkpoint
from .config import resolve_config
from .datasets import (
    build_dataset_bundle,
    build_loaders,
    close_loaders,
)
from .distributed import (
    DistributedContext,
    assert_consensus,
    barrier,
    broadcast_object,
    cleanup_distributed,
    setup_distributed,
    unwrap_model,
)
from .engine import ModelEma, TrainState, evaluate_classification, train_one_epoch
from .evaluation import evaluate_imagenet_c, evaluate_standard_suite
from .models import build_model, export_slim_model, freeze_backbone, iter_prunable_units
from .pruning.iterative import (
    apply_pruning_plan,
    current_sparsity,
    mask_state_dict,
    prune_count_for_target,
    select_pruning_plan,
    target_schedule,
)
from .pruning.saliency import compute_method_scores_for_context
from .pruning.recalibrate import recalibrate_batchnorm
from .pruning.spectral import compute_spectral_profiles, measure_sensitivity, normalize_band_edges
from .pruning.iterative import align_plan_to_multiple, macs_for_plan, select_pruning_plan_for_mac_target
from .h200_runtime import initialize_runtime, runtime_snapshot
from .utils import (
    append_jsonl,
    benchmark_throughput,
    count_parameters,
    create_run_dir,
    enable_channels_last,
    move_batch_to_device,
    profile_macs,
    save_json,
    save_yaml,
    set_seed,
    setup_logger,
    write_csv,
)
from .version import PIPELINE_VERSION
from .visualization import (
    compare_frequency_maps,
    compute_fourier_sensitivity_heatmap,
    compute_layer_frequency_maps,
    plot_frequency_error_curve,
    plot_imagenet_c_summary,
    save_heatmap,
    save_layer_maps,
)


class WarmupCosineScheduler:
    step_per_batch = False

    def __init__(self, optimizer: torch.optim.Optimizer, total_epochs: int, warmup_epochs: int, min_lr: float) -> None:
        self.optimizer = optimizer
        self.total_epochs = max(1, int(total_epochs))
        self.warmup_epochs = max(0, int(warmup_epochs))
        self.min_lr = float(min_lr)
        self.base_lrs = [float(group["lr"]) for group in optimizer.param_groups]
        self.epoch = 0

    def step(self) -> None:
        self.epoch += 1
        for group, base_lr in zip(self.optimizer.param_groups, self.base_lrs):
            if self.epoch <= self.warmup_epochs and self.warmup_epochs > 0:
                lr = base_lr * self.epoch / self.warmup_epochs
            else:
                progress = (self.epoch - self.warmup_epochs) / max(1, self.total_epochs - self.warmup_epochs)
                progress = min(max(progress, 0.0), 1.0)
                lr = self.min_lr + 0.5 * (base_lr - self.min_lr) * (1.0 + math.cos(math.pi * progress))
            group["lr"] = lr

    def state_dict(self) -> Dict[str, Any]:
        return {"epoch": self.epoch, "base_lrs": self.base_lrs}

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        self.epoch = int(state.get("epoch", 0))
        self.base_lrs = list(map(float, state.get("base_lrs", self.base_lrs)))


def build_optimizer(model: nn.Module, config: Mapping[str, Any]) -> torch.optim.Optimizer:
    train_cfg = config["train"]
    parameters = list(unwrap_model(model).parameters())
    name = str(train_cfg.get("optimizer", "sgd")).lower()
    if name == "sgd":
        return torch.optim.SGD(
            parameters,
            lr=float(train_cfg["lr"]),
            momentum=float(train_cfg.get("momentum", 0.9)),
            weight_decay=float(train_cfg.get("weight_decay", 1e-4)),
            nesterov=bool(train_cfg.get("nesterov", True)),
        )
    if name == "adamw":
        return torch.optim.AdamW(
            parameters,
            lr=float(train_cfg["lr"]),
            weight_decay=float(train_cfg.get("weight_decay", 0.05)),
        )
    if name == "rmsprop":
        return torch.optim.RMSprop(
            parameters,
            lr=float(train_cfg["lr"]),
            momentum=float(train_cfg.get("momentum", 0.9)),
            weight_decay=float(train_cfg.get("weight_decay", 1e-5)),
            alpha=float(train_cfg.get("rmsprop_alpha", 0.9)),
            eps=float(train_cfg.get("rmsprop_eps", 0.001)),
        )
    raise ValueError(f"Unsupported optimizer: {name}")


def is_dense_method(method: str) -> bool:
    return str(method).lower() in {"dense", "dense_finetuned"}


def total_training_epochs(config: Mapping[str, Any]) -> int:
    """Total optimizer epochs for the cosine schedule.

    * ``dense``: the untouched pretrained (or task-adapted) reference; it only
      receives ``epochs_before_pruning`` (needed for transfer tasks whose
      classifier is new) and no recovery budget.
    * ``dense_finetuned``: receives exactly the same total budget as a pruned run
      (pre + rounds x recovery + final), so the pruned/dense comparison is
      matched in optimisation steps.
    * pruned methods: pre + rounds x recovery + final.
    """
    train_cfg = config["train"]
    method = str(config["pruning"]["method"]).lower()
    pre = int(train_cfg.get("epochs_before_pruning", 0))
    rounds = len(target_schedule(config))
    budget = rounds * int(train_cfg.get("recovery_epochs", 0)) + int(train_cfg.get("final_epochs", 0))
    if method == "dense":
        return pre
    return pre + budget


def dense_finetune_epochs(config: Mapping[str, Any]) -> int:
    train_cfg = config["train"]
    rounds = len(target_schedule(config))
    return rounds * int(train_cfg.get("recovery_epochs", 0)) + int(train_cfg.get("final_epochs", 0))


def _load_flexible_model(path: str | Path, model: nn.Module, logger) -> Dict[str, Any]:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    state = checkpoint.get("model", checkpoint.get("state_dict", checkpoint)) if isinstance(checkpoint, dict) else checkpoint
    if not isinstance(state, Mapping):
        raise TypeError(f"Checkpoint {path} does not contain a state dict")
    state = {key.removeprefix("module."): value for key, value in state.items()}
    current = unwrap_model(model).state_dict()
    compatible = {key: value for key, value in state.items() if key in current and current[key].shape == value.shape}
    skipped = sorted(set(state) - set(compatible))
    missing, unexpected = unwrap_model(model).load_state_dict(compatible, strict=False)
    if isinstance(checkpoint, dict):
        masks = checkpoint.get("mask_state", checkpoint.get("gate_state"))
        if masks is not None:
            from .pruning.iterative import load_mask_state_dict

            load_mask_state_dict(model, masks, strict=False)
    logger.info(
        "Loaded %d compatible tensors from %s; skipped=%d missing=%d unexpected=%d",
        len(compatible),
        path,
        len(skipped),
        len(missing),
        len(unexpected),
    )
    return checkpoint if isinstance(checkpoint, dict) else {"model": checkpoint}


def _wrap_ddp(
    model: nn.Module,
    context: DistributedContext,
    config: Mapping[str, Any],
) -> nn.Module:
    if not context.distributed:
        return model
    freeze_epochs = int(config["train"].get("freeze_backbone_epochs", 0))
    find_unused = bool(config.get("runtime", {}).get("ddp_find_unused_parameters", freeze_epochs > 0))
    static_graph = bool(
        config.get("runtime", {}).get("ddp_static_graph", False)
        and freeze_epochs <= 0
        and not find_unused
    )
    kwargs: Dict[str, Any] = {
        "device_ids": [context.local_rank] if context.device.type == "cuda" else None,
        "output_device": context.local_rank if context.device.type == "cuda" else None,
        "broadcast_buffers": True,
        "find_unused_parameters": find_unused,
        "gradient_as_bucket_view": True,
        "bucket_cap_mb": int(config.get("runtime", {}).get("ddp_bucket_mb", 100)),
    }
    # static_graph is unavailable in older torch releases.
    if static_graph:
        kwargs["static_graph"] = True
    try:
        return DDP(model, **kwargs)
    except TypeError:
        kwargs.pop("static_graph", None)
        kwargs.pop("gradient_as_bucket_view", None)
        return DDP(model, **kwargs)


def _flatten_round_metrics(
    phase: str,
    round_index: int,
    sparsity: float,
    suite: Mapping[str, Any],
    proposal_cutoff: float,
) -> Dict[str, Any]:
    row: Dict[str, Any] = {"phase": phase, "round": round_index, "sparsity": float(sparsity)}
    for split in ("val", "test", "imagenet_r", "imagenet_sketch", "stylized_imagenet"):
        metrics = suite.get(split)
        if isinstance(metrics, Mapping):
            for key in ("loss", "top1", "top5", "error"):
                if key in metrics:
                    row[f"{split}_{key}"] = metrics[key]
    frequency = suite.get("frequency", {})
    if isinstance(frequency, Mapping) and frequency:
        keys = list(frequency)
        selected = min(keys, key=lambda key: abs(float(key.removeprefix("rc_")) - proposal_cutoff))
        metrics = frequency[selected]
        if isinstance(metrics, Mapping):
            for key, value in metrics.items():
                if isinstance(value, (int, float)):
                    row[key] = value
            row["frequency_key"] = selected
    return row


def _evaluate_round(
    model: nn.Module,
    loaders: Mapping[str, DataLoader | None],
    config: Mapping[str, Any],
    context: DistributedContext,
    phase: str,
    round_index: int,
    rows: list[Dict[str, Any]],
    run_dir: Path,
    logger,
) -> Dict[str, Any]:
    suite_mode = (
        "full"
        if phase == "final"
        else str(config["evaluation"].get("round_eval_mode", "clean"))
    )
    suite = evaluate_standard_suite(
        model,
        loaders,
        config,
        context.device,
        suite_mode=suite_mode,
    )
    if phase in {"dense", "final"} and bool(config["evaluation"].get("spectral_profiles", True)):
        calibration = loaders.get("calibration") or loaders.get("val")
        if calibration is not None:
            try:
                spectral_cfg = config["pruning"].get("spectral", {}) or {}
                profiles = compute_spectral_profiles(
                    unwrap_model(model),
                    calibration,
                    context.device,
                    edges=normalize_band_edges(spectral_cfg.get("band_edges")),
                    max_batches=int(config["evaluation"].get("spectral_profile_batches", 8)),
                    channels_last=bool(config["model"].get("channels_last", False))
                    and context.device.type == "cuda",
                    microbatch_size=int(config["evaluation"].get("spectral_profile_microbatch", 32)),
                    distributed_reduce=context.distributed,
                )
                suite["spectral"] = profiles.as_dict()
            except Exception as error:  # pragma: no cover - diagnostics must not kill a run
                logger.exception("Spectral profile evaluation failed: %s", error)
                suite["spectral"] = {"error": str(error)}
    sparsity = current_sparsity(model)
    row = _flatten_round_metrics(
        phase,
        round_index,
        sparsity,
        suite,
        float(config["pruning"]["cutoff"]),
    )
    rows.append(row)
    if context.is_main:
        append_jsonl(run_dir / "metrics.jsonl", {"phase": phase, "round": round_index, "suite": suite, **row})
        write_csv(run_dir / "curve.csv", rows)
        frequency_rows = [r for r in rows if "low_frequency_region_error" in r]
        plot_frequency_error_curve(frequency_rows, run_dir / "frequency_error_curve.png")
        logger.info(
            "eval phase=%s round=%d sparsity=%.4f val_top1=%s",
            phase,
            round_index,
            sparsity,
            row.get("val_top1", "n/a"),
        )
    return suite


def _run_epochs(
    count: int,
    phase: str,
    model: nn.Module,
    loader: DataLoader | None,
    optimizer: torch.optim.Optimizer,
    scheduler: WarmupCosineScheduler,
    config: Mapping[str, Any],
    context: DistributedContext,
    state: TrainState,
    run_dir: Path,
    logger,
    teacher: nn.Module | None,
    ema: ModelEma | None,
) -> list[Dict[str, Any]]:
    if count <= 0:
        return []
    if loader is None:
        raise ValueError(f"Training phase {phase} requested, but no train loader exists")
    output: list[Dict[str, Any]] = []
    for _ in range(count):
        freeze_epochs = int(config["train"].get("freeze_backbone_epochs", 0))
        if freeze_epochs > 0:
            freeze_backbone(model, frozen=state.epoch < freeze_epochs)
        metrics = train_one_epoch(
            model,
            loader,
            optimizer,
            context.device,
            config,
            state,
            scheduler=scheduler,
            teacher=teacher,
            ema=ema,
            logger=logger if context.is_main else None,
        )
        row = {"phase": phase, "epoch": state.epoch, **metrics}
        output.append(row)
        if context.is_main:
            append_jsonl(run_dir / "train_metrics.jsonl", row)
    return output


def _export_and_benchmark(
    model: nn.Module,
    loader: DataLoader | None,
    config: Mapping[str, Any],
    context: DistributedContext,
    run_dir: Path,
    logger,
) -> Dict[str, Any]:
    if not context.is_main or not bool(config["evaluation"].get("export_slim", True)):
        return {}
    raw = unwrap_model(model)
    raw.eval()
    image_size = int(config["model"]["image_size"])
    batch_size = int(config["evaluation"].get("throughput_batch_size", 64))
    if loader is not None:
        sample = next(iter(loader))[0][:1].cpu()
    else:
        sample = torch.randn(1, 3, image_size, image_size)
    sample_device = move_batch_to_device(sample, context.device, False)

    # Export equivalence must be measured on the same device and precision.
    # Comparing a TF32 CUDA masked model against an FP32 CPU slim model can
    # report differences around 1e-2 even when structural slicing is exact.
    slim = export_slim_model(raw).eval().to(context.device)
    old_matmul_tf32 = None
    old_cudnn_tf32 = None
    if context.device.type == "cuda":
        old_matmul_tf32 = torch.backends.cuda.matmul.allow_tf32
        old_cudnn_tf32 = torch.backends.cudnn.allow_tf32
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    try:
        with torch.inference_mode():
            masked_output = raw(sample_device.float()).detach().float()
            slim_output = slim(sample_device.float()).detach().float()
    finally:
        if context.device.type == "cuda":
            assert old_matmul_tf32 is not None and old_cudnn_tf32 is not None
            torch.backends.cuda.matmul.allow_tf32 = old_matmul_tf32
            torch.backends.cudnn.allow_tf32 = old_cudnn_tf32
    difference = (masked_output - slim_output).abs()
    max_difference = float(difference.max().cpu())
    mean_difference = float(difference.mean().cpu())
    atol = float(config["evaluation"].get("export_equivalence_atol", 1e-4))
    rtol = float(config["evaluation"].get("export_equivalence_rtol", 1e-4))
    if not torch.allclose(masked_output, slim_output, atol=atol, rtol=rtol):
        raise RuntimeError(
            "Physical slim export is not numerically equivalent to the masked model: "
            f"max_abs_diff={max_difference:.6e}, mean_abs_diff={mean_difference:.6e}, "
            f"atol={atol:.3e}, rtol={rtol:.3e}"
        )
    slim.cpu()
    torch.save(slim, run_dir / "slim_model.pt")
    torch.save(
        {
            "state_dict": slim.state_dict(),
            "arch": config["model"]["arch"],
            "num_classes": config["model"]["num_classes"],
            "image_size": image_size,
            "note": "Use slim_model.pt for exact class reconstruction; this file is weights-only.",
        },
        run_dir / "slim_state_dict.pt",
    )
    if bool(config["evaluation"].get("torchscript", True)):
        try:
            traced = torch.jit.trace(slim, sample.cpu(), strict=False)
            traced = torch.jit.freeze(traced.eval())
            traced.save(str(run_dir / "slim_model.ts"))
        except Exception as error:
            logger.warning("TorchScript export failed: %s", error)

    dense_params = count_parameters(raw)
    slim_params = count_parameters(slim)
    try:
        dense_macs = profile_macs(raw.to(context.device), (1, 3, image_size, image_size), context.device)
        slim_macs = profile_macs(slim, (1, 3, image_size, image_size), torch.device("cpu"))
    except Exception as error:
        logger.warning("MAC profiling failed: %s", error)
        dense_macs = slim_macs = -1

    metrics: Dict[str, Any] = {
        "masked_slim_max_abs_diff": max_difference,
        "masked_slim_mean_abs_diff": mean_difference,
        "export_equivalence_atol": atol,
        "export_equivalence_rtol": rtol,
        "export_equivalence_device": str(context.device),
        "export_equivalence_tf32": False,
        "dense_parameter_count": dense_params,
        "slim_parameter_count": slim_params,
        "parameter_reduction": 1.0 - slim_params / max(1, dense_params),
        "dense_macs": dense_macs,
        "slim_macs": slim_macs,
        "mac_reduction": (1.0 - slim_macs / max(1, dense_macs)) if dense_macs > 0 and slim_macs >= 0 else None,
    }
    if bool(config["evaluation"].get("throughput", True)):
        warmup = int(config["evaluation"].get("throughput_warmup", 10))
        steps = int(config["evaluation"].get("throughput_steps", 30))
        shape = (batch_size, 3, image_size, image_size)
        amp_name = str(config["train"].get("amp", "none")).lower()
        amp_dtype = None
        if context.device.type == "cuda":
            amp_dtype = torch.bfloat16 if amp_name == "bf16" else torch.float16 if amp_name == "fp16" else None
        masked_benchmark_model: nn.Module = raw
        slim_benchmark_model: nn.Module = slim
        if bool(config["model"].get("compile", False)) and context.device.type == "cuda" and hasattr(torch, "compile"):
            masked_benchmark_model = torch.compile(raw, mode="reduce-overhead")
            slim_benchmark_model = torch.compile(slim.to(context.device), mode="reduce-overhead")
        masked_perf = benchmark_throughput(
            masked_benchmark_model,
            shape,
            context.device,
            warmup,
            steps,
            amp_dtype,
            bool(config["model"].get("channels_last", False)),
        )
        slim_perf = benchmark_throughput(
            slim_benchmark_model,
            shape,
            context.device,
            warmup,
            steps,
            amp_dtype,
            bool(config["model"].get("channels_last", False)),
        )
        metrics["masked_throughput"] = masked_perf
        metrics["slim_throughput"] = slim_perf
        # NOTE: the masked (gated) network carries gate-multiplication overhead,
        # so this ratio over-states the gain. The collector reports
        # ``speedup_vs_dense`` using the dense run's slim throughput instead.
        metrics["measured_speedup_vs_masked"] = slim_perf["throughput_images_per_s"] / max(
            masked_perf["throughput_images_per_s"], 1e-12
        )
        metrics["measured_speedup"] = metrics["measured_speedup_vs_masked"]
        extra_batches = [
            int(b) for b in (config["evaluation"].get("throughput_batch_sizes", []) or []) if int(b) != batch_size
        ]
        by_batch: Dict[str, Any] = {str(batch_size): slim_perf}
        for extra in extra_batches:
            try:
                by_batch[str(extra)] = benchmark_throughput(
                    slim_benchmark_model,
                    (extra, 3, image_size, image_size),
                    context.device,
                    warmup,
                    steps,
                    amp_dtype,
                    bool(config["model"].get("channels_last", False)),
                )
            except Exception as error:  # pragma: no cover - benchmarking is best effort
                logger.warning("Throughput benchmark at batch %d failed: %s", extra, error)
        metrics["slim_throughput_by_batch"] = by_batch
    slim.cpu()
    save_json(run_dir / "export_metrics.json", metrics)
    logger.info("Physical export max_abs_diff=%.3e params=%d -> %d", max_difference, dense_params, slim_params)
    return metrics


def _run_visualizations(
    model: nn.Module,
    loader: DataLoader | None,
    config: Mapping[str, Any],
    context: DistributedContext,
    run_dir: Path,
    dense_checkpoint: Path,
    logger,
) -> Dict[str, Any]:
    if not context.is_main or loader is None:
        return {}
    vis_cfg = config["visualization"]
    if not bool(vis_cfg.get("fourier_heatmap", True)) and not bool(vis_cfg.get("layer_heatmap", True)):
        return {}
    output_dir = run_dir / "fourier"
    output_dir.mkdir(parents=True, exist_ok=True)
    raw = unwrap_model(model).eval()
    channels_last = bool(config["model"].get("channels_last", False)) and context.device.type == "cuda"
    result: Dict[str, Any] = {}
    visualization_error: Exception | None = None

    dense_model = build_model(
        str(config["model"]["arch"]),
        int(config["model"]["num_classes"]),
        weights="NONE",
        image_size=int(config["model"]["image_size"]),
    )
    load_checkpoint(dense_checkpoint, dense_model, strict_model=True, strict_masks=False)
    dense_model.to(context.device).eval()

    try:
        if bool(vis_cfg.get("fourier_heatmap", True)):
            kwargs = dict(
                resolution=int(vis_cfg.get("heatmap_resolution", 17)),
                amplitude=float(vis_cfg.get("heatmap_amplitude", 0.15)),
                max_batches=int(vis_cfg.get("heatmap_batches", 4)),
                amp=str(config["train"].get("amp", "none")),
                channels_last=channels_last,
                reduce_distributed=False,
            )
            dense_heat = compute_fourier_sensitivity_heatmap(dense_model, loader, context.device, **kwargs)
            pruned_heat = compute_fourier_sensitivity_heatmap(raw, loader, context.device, **kwargs)
            np.save(output_dir / "model_dense.npy", dense_heat)
            np.save(output_dir / "model_pruned.npy", pruned_heat)
            np.save(output_dir / "model_shift.npy", pruned_heat - dense_heat)
            save_heatmap(dense_heat, output_dir / "model_dense.png", "Dense Fourier sensitivity")
            save_heatmap(pruned_heat, output_dir / "model_pruned.png", "Pruned Fourier sensitivity")
            save_heatmap(
                pruned_heat - dense_heat,
                output_dir / "model_shift.png",
                "Fourier sensitivity shift (pruned - dense)",
                symmetric=True,
            )
            result["model_heatmaps"] = ["model_dense.png", "model_pruned.png", "model_shift.png"]
        if bool(vis_cfg.get("layer_heatmap", True)):
            kwargs = dict(
                max_batches=int(vis_cfg.get("layer_batches", 4)),
                target_size=64,
                amp=str(config["train"].get("amp", "none")),
                channels_last=channels_last,
                max_layers=int(vis_cfg.get("max_layers", 0)),
                reduce_distributed=False,
            )
            dense_maps = compute_layer_frequency_maps(dense_model, loader, context.device, **kwargs)
            pruned_maps = compute_layer_frequency_maps(raw, loader, context.device, **kwargs)
            save_layer_maps(dense_maps, output_dir / "layers_dense", "dense")
            save_layer_maps(pruned_maps, output_dir / "layers_pruned", "pruned")
            result["layer_comparison"] = compare_frequency_maps(dense_maps, pruned_maps, output_dir / "layer_shift")
    except Exception as error:
        logger.exception("Fourier visualization failed: %s", error)
        result["error_type"] = type(error).__name__
        result["error"] = str(error)
        visualization_error = error
    finally:
        dense_model.cpu()
        del dense_model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    save_json(output_dir / "visualization_summary.json", result)
    if visualization_error is not None:
        raise RuntimeError(
            "Required Fourier visualization stage failed; see "
            f"{output_dir / 'visualization_summary.json'}"
        ) from visualization_error
    return result


def _first_round_saliency_summary(run_dir: Path) -> Dict[str, Any]:
    path = run_dir / "saliency_round_01.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    keys = (
        "estimator", "target_profile", "lambda", "signed", "steering_weights",
        "sensitivity_profile", "reliance_profile", "reliance_loss", "reliance_accuracy_drop",
        "profile_mismatch_l1", "band_edges", "band_names", "formula", "lfs_cutoff",
    )
    return {key: data[key] for key in keys if key in data}


def run_experiment(
    config: MutableMapping[str, Any],
    *,
    run_dir: str | Path | None = None,
    evaluate_only: bool = False,
    manage_distributed: bool = True,
) -> Dict[str, Any]:
    runtime_report = initialize_runtime(config)
    context = setup_distributed(str(config["experiment"].get("device", "auto")))
    set_seed(
        int(config["experiment"]["seed"]),
        bool(config["experiment"].get("deterministic", False)),
        context.rank,
    )
    output_dir = create_run_dir(config, run_dir)
    logger = setup_logger(output_dir)
    if context.is_main:
        save_json(output_dir / "runtime.json", {
            "pipeline_version": PIPELINE_VERSION,
            "initialization": runtime_report,
            "snapshot": runtime_snapshot(),
            "distributed": {
                "rank": context.rank,
                "world_size": context.world_size,
                "backend": context.backend,
                "control_backend": context.control_backend,
                "device": str(context.device),
            },
        })

    bundle = build_dataset_bundle(config)
    config["model"]["num_classes"] = int(bundle.num_classes)
    loaders = build_loaders(bundle, config, context.distributed)
    if context.is_main:
        save_yaml(output_dir / "config.yaml", config)
        save_json(
            output_dir / "dataset.json",
            {
                "num_classes": bundle.num_classes,
                "class_to_idx": bundle.class_to_idx,
                "sizes": {
                    "train": len(bundle.train) if bundle.train is not None else 0,
                    "val": len(bundle.val) if bundle.val is not None else 0,
                    "calibration": len(bundle.calibration) if bundle.calibration is not None else 0,
                    "test": len(bundle.test) if bundle.test is not None else 0,
                    **{name: len(dataset) for name, dataset in bundle.ood.items()},
                },
            },
        )
    logger.info(
        "Building arch=%s classes=%d dataset=%s device=%s world_size=%d",
        config["model"]["arch"],
        bundle.num_classes,
        config["data"]["dataset"],
        context.device,
        context.world_size,
    )
    model = build_model(
        str(config["model"]["arch"]),
        bundle.num_classes,
        str(config["model"].get("weights", "DEFAULT")),
        int(config["model"]["image_size"]),
    )
    checkpoint_path = str(config["experiment"].get("checkpoint", ""))
    resume_path = str(config["experiment"].get("resume", ""))
    if checkpoint_path:
        _load_flexible_model(checkpoint_path, model, logger)
    elif resume_path:
        _load_flexible_model(resume_path, model, logger)
    model.to(context.device)
    if bool(config["model"].get("channels_last", False)) and context.device.type == "cuda":
        enable_channels_last(model)
    model = _wrap_ddp(model, context, config)
    optimizer = build_optimizer(model, config)
    scheduler = WarmupCosineScheduler(
        optimizer,
        total_training_epochs(config),
        int(config["train"].get("warmup_epochs", 0)),
        float(config["train"].get("min_lr", 1e-6)),
    )
    state = TrainState()
    start_round = 0
    if resume_path:
        resumed = load_checkpoint(
            resume_path,
            model,
            optimizer=optimizer,
            scheduler=scheduler,
            strict_model=False,
            strict_masks=False,
        )
        state.epoch = int(resumed.get("epoch", 0))
        state.global_step = int(resumed.get("global_step", 0))
        start_round = int(resumed.get("round_index", 0))

    ema = ModelEma(model, float(config["train"].get("ema_decay", 0.0))) if float(config["train"].get("ema_decay", 0.0)) > 0 else None
    rows: list[Dict[str, Any]] = []
    all_pruned_records: list[Dict[str, Any]] = []
    dense_checkpoint = output_dir / "checkpoint_dense_calibrated.pt"

    if context.is_main and not resume_path:
        save_checkpoint(output_dir / "checkpoint_pretrained.pt", model, config=config)

    teacher = None
    method = str(config["pruning"]["method"]).lower()
    pre_epochs = int(config["train"].get("epochs_before_pruning", 0))
    if not evaluate_only and pre_epochs > 0:
        _run_epochs(
            pre_epochs,
            "pre_pruning_finetune",
            model,
            loaders.get("train"),
            optimizer,
            scheduler,
            config,
            context,
            state,
            output_dir,
            logger,
            None,
            ema,
        )
    if context.is_main:
        save_checkpoint(
            dense_checkpoint,
            model,
            optimizer=optimizer,
            scheduler=scheduler,
            epoch=state.epoch,
            global_step=state.global_step,
            config=config,
        )
    barrier(phase="dense_checkpoint_ready")

    dense_suite = _evaluate_round(model, loaders, config, context, "dense", 0, rows, output_dir, logger)

    wants_frequency_distill = (
        bool(config["train"].get("distill_frequency", False))
        and float(config["train"].get("distill_alpha", 0.0)) > 0
    )
    wants_dense_distill = (
        bool(config["train"].get("distill_dense", False))
        and float(config["train"].get("dense_distill_alpha", 0.5)) > 0
    )
    if (wants_frequency_distill or wants_dense_distill) and not is_dense_method(method):
        teacher = copy.deepcopy(unwrap_model(model)).to(context.device).eval()
        for parameter in teacher.parameters():
            parameter.requires_grad_(False)

    bn_recal_batches = int(config["pruning"].get("bn_recalibration_batches", 0))
    budget_mode = str(config["pruning"].get("budget", "units")).lower()
    channel_alignment = int(config["pruning"].get("channel_alignment", 1))
    image_size = int(config["model"]["image_size"])
    trajectory: list[Dict[str, Any]] = []
    spectral_edges = normalize_band_edges((config["pruning"].get("spectral", {}) or {}).get("band_edges"))
    track_trajectory = bool(config["evaluation"].get("spectral_trajectory", True)) and loaders.get("calibration") is not None
    budget_dense_macs = None
    if not evaluate_only and not is_dense_method(method) and budget_mode == "macs":
        if not context.distributed or context.is_main:
            budget_dense_macs = macs_for_plan(unwrap_model(model), [], (1, 3, image_size, image_size))
        if context.distributed:
            budget_dense_macs = broadcast_object(budget_dense_macs, src=0)

    def _sensitivity_profile_now() -> Dict[str, Any] | None:
        if not track_trajectory:
            return None
        try:
            measured = measure_sensitivity(
                unwrap_model(model), loaders["calibration"], context.device, spectral_edges,
                max_batches=int(config["evaluation"].get("spectral_trajectory_batches", 4)),
                channels_last=bool(config["model"].get("channels_last", False)) and context.device.type == "cuda",
                microbatch_size=int(config["evaluation"].get("spectral_profile_microbatch", 32)),
                distributed_reduce=context.distributed,
            )
            return {"sensitivity": measured["sensitivity"], "sensitivity_profile": measured["sensitivity_profile"]}
        except Exception as error:  # pragma: no cover - diagnostics must not kill a run
            logger.warning("Sensitivity trajectory measurement failed: %s", error)
            return None

    if not evaluate_only and not is_dense_method(method):
        for round_index, target in enumerate(target_schedule(config), start=1):
            if round_index <= start_round:
                continue
            score_result = compute_method_scores_for_context(
                model, loaders.get("calibration"), config, context
            )
            plan = None
            budget_info: Dict[str, Any] = {"budget": budget_mode}
            if not context.distributed or context.is_main:
                if budget_mode == "macs":
                    plan, budget_info_extra = select_pruning_plan_for_mac_target(
                        unwrap_model(model),
                        score_result,
                        target,
                        config,
                        dense_macs=int(budget_dense_macs),
                        input_shape=(1, 3, image_size, image_size),
                        alignment=channel_alignment,
                    )
                    budget_info.update(budget_info_extra)
                else:
                    prune_count = prune_count_for_target(model, target)
                    plan = select_pruning_plan(model, score_result, prune_count, config)
                    plan = align_plan_to_multiple(unwrap_model(model), score_result, plan, channel_alignment, config)
            if context.distributed:
                plan = broadcast_object(plan, src=0)
                budget_info = broadcast_object(budget_info, src=0)
            if not isinstance(plan, list):
                raise TypeError(f"Invalid pruning plan type: {type(plan).__name__}")
            records = apply_pruning_plan(
                model,
                plan,
                round_index=round_index,
            )
            # First-order prediction of the relative band-sensitivity change
            # implied by the plan (exact estimator only) for later validation.
            predicted_rel_change = None
            diag = score_result.diagnostics
            table = diag.get("unit_band_contribution")
            band_power = diag.get("band_power")
            if diag.get("estimator") == "exact" and isinstance(table, dict) and band_power:
                sums = [0.0] * len(band_power)
                for row in plan:
                    values = table.get(str(row["group"]))
                    if values is None:
                        continue
                    contrib = values[int(row["index"])]
                    for b, c in enumerate(contrib):
                        sums[b] += float(c)
                predicted_rel_change = [-(sums[b] / max(float(band_power[b]), 1e-12)) for b in range(len(band_power))]
            if context.distributed:
                mask_state = mask_state_dict(model)
                assert_consensus(
                    {
                        name: torch.nonzero(value > 0, as_tuple=False).flatten().tolist()
                        for name, value in sorted(mask_state.items())
                    },
                    phase=f"mask_after_prune_round_{round_index}",
                )
            all_pruned_records.extend(records)
            after_pruning = _sensitivity_profile_now()  # before BN recalibration: tests the first-order prediction
            if bn_recal_batches > 0:
                recal = recalibrate_batchnorm(
                    model,
                    loaders.get("calibration") or loaders.get("train"),
                    context.device,
                    max_batches=bn_recal_batches,
                    channels_last=bool(config["model"].get("channels_last", False)),
                    amp_dtype=None,
                )
                if context.is_main:
                    logger.info("BatchNorm recalibration after round %d: %s", round_index, recal)
            pre_recovery = _sensitivity_profile_now() if bn_recal_batches > 0 else after_pruning
            if context.is_main and budget_mode == "macs":
                logger.info(
                    "MAC budget round=%d target=%.4f achieved=%.4f units=%d capped=%s",
                    round_index, target, float(budget_info.get("achieved_mac_reduction", float("nan"))),
                    int(budget_info.get("units", len(plan))), budget_info.get("capped"),
                )
            if context.is_main:
                torch.save(
                    {
                        "method": score_result.method,
                        "scores": score_result.scores,
                        "raw_scores": score_result.raw_scores,
                        "diagnostics": score_result.diagnostics,
                    },
                    output_dir / f"saliency_round_{round_index:02d}.pt",
                )
                save_json(output_dir / f"saliency_round_{round_index:02d}.json", score_result.diagnostics)
                write_csv(output_dir / "pruning_steps.csv", all_pruned_records)
                logger.info(
                    "pruning round=%d target=%.4f removed=%d actual_sparsity=%.4f",
                    round_index,
                    target,
                    len(records),
                    current_sparsity(model),
                )
            recovery_epochs = int(config["train"].get("recovery_epochs", 0))
            _run_epochs(
                recovery_epochs,
                f"recovery_round_{round_index}",
                model,
                loaders.get("train"),
                optimizer,
                scheduler,
                config,
                context,
                state,
                output_dir,
                logger,
                teacher,
                ema,
            )
            post_recovery = _sensitivity_profile_now()
            dense_band_power = diag.get("band_power")
            actual_rel_change = None
            if after_pruning is not None and dense_band_power:
                actual_rel_change = [
                    (float(after) - float(before)) / max(float(before), 1e-12)
                    for before, after in zip(dense_band_power, after_pruning["sensitivity"])
                ]
            trajectory.append(
                {
                    "round": round_index,
                    "target": float(target),
                    "budget": dict(budget_info),
                    "units_pruned": len(plan),
                    "unit_sparsity_after": current_sparsity(model),
                    "sensitivity_profile_before_pruning": diag.get("sensitivity_profile"),
                    "sensitivity_profile_after_pruning": None if after_pruning is None else after_pruning["sensitivity_profile"],
                    "sensitivity_profile_after_recalibration": None if pre_recovery is None else pre_recovery["sensitivity_profile"],
                    "sensitivity_profile_after_recovery": None if post_recovery is None else post_recovery["sensitivity_profile"],
                    "predicted_relative_change": predicted_rel_change,
                    "actual_relative_change": actual_rel_change,
                    "steering_weights": diag.get("steering_weights"),
                }
            )
            if context.is_main:
                save_json(output_dir / "spectral_trajectory.json", trajectory)
            if bool(config["evaluation"].get("eval_each_round", True)):
                suite = _evaluate_round(
                    model,
                    loaders,
                    config,
                    context,
                    f"prune_round_{round_index}",
                    round_index,
                    rows,
                    output_dir,
                    logger,
                )
            else:
                suite = {}
            if context.is_main:
                save_checkpoint(
                    output_dir / f"checkpoint_round_{round_index:02d}.pt",
                    model,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    epoch=state.epoch,
                    global_step=state.global_step,
                    round_index=round_index,
                    config=config,
                    metrics=suite,
                )
            barrier(phase=f"prune_round_{round_index}_checkpoint_ready")

    if not evaluate_only:
        if method == "dense":
            final_count = 0  # untouched reference model
        elif method == "dense_finetuned":
            final_count = dense_finetune_epochs(config)  # matched optimisation budget
        else:
            final_count = int(config["train"].get("final_epochs", 0))
        _run_epochs(
            final_count,
            "final_finetune",
            model,
            loaders.get("train"),
            optimizer,
            scheduler,
            config,
            context,
            state,
            output_dir,
            logger,
            teacher,
            ema,
        )

    final_model = ema.module.to(context.device) if ema is not None else model
    final_suite = _evaluate_round(
        final_model,
        loaders,
        config,
        context,
        "final",
        len(target_schedule(config)) if not is_dense_method(method) else 0,
        rows,
        output_dir,
        logger,
    )
    if bool(config["evaluation"].get("eval_imagenet_c", True)) and str(config["data"].get("imagenet_c_root", "")):
        imagenet_c = evaluate_imagenet_c(
            final_model,
            config,
            bundle.class_to_idx,
            context.device,
            context.distributed,
        )
        final_suite["imagenet_c"] = imagenet_c
        if context.is_main:
            save_json(output_dir / "imagenet_c_detail.json", imagenet_c)
            plot_imagenet_c_summary(imagenet_c, output_dir)

    if context.is_main:
        save_checkpoint(
            output_dir / "checkpoint_final_masked.pt",
            final_model,
            epoch=state.epoch,
            global_step=state.global_step,
            round_index=len(target_schedule(config)) if not is_dense_method(method) else 0,
            config=config,
            metrics=final_suite,
        )
    barrier(phase="final_checkpoint_ready")

    visualization = _run_visualizations(
        final_model,
        loaders.get("val"),
        config,
        context,
        output_dir,
        dense_checkpoint,
        logger,
    )
    barrier(phase="visualization_complete")
    export_metrics = _export_and_benchmark(
        final_model,
        loaders.get("val"),
        config,
        context,
        output_dir,
        logger,
    )
    barrier(phase="export_complete")

    summary = {
        "pipeline_version": PIPELINE_VERSION,
        "run_dir": str(output_dir),
        "method": method,
        "arch": config["model"]["arch"],
        "dataset": config["data"]["dataset"],
        "target_sparsity": config["pruning"]["target_sparsity"],
        "actual_sparsity": current_sparsity(final_model),
        "seed": int(config["experiment"]["seed"]),
        "dense": {
            "val": dense_suite.get("val"),
            "spectral": dense_suite.get("spectral"),
        },
        "spectral_config": dict(config["pruning"].get("spectral", {}) or {}),
        "recovery_protocol": {
            "distill_dense": bool(config["train"].get("distill_dense", False)),
            "dense_distill_alpha": float(config["train"].get("dense_distill_alpha", 0.5)),
            "frequency_augment": bool(config["train"].get("frequency_augment", False)),
            "bn_recalibration_batches": bn_recal_batches,
            "epochs_before_pruning": pre_epochs,
            "recovery_epochs": int(config["train"].get("recovery_epochs", 0)),
            "final_epochs": int(config["train"].get("final_epochs", 0)),
        },
        "saliency_round1": _first_round_saliency_summary(output_dir),
        "spectral_trajectory": trajectory,
        "budget": {
            "mode": budget_mode,
            "channel_alignment": channel_alignment,
            "dense_macs_for_budget": budget_dense_macs,
        },
        "kept_fraction_by_group": {
            name: unit.active_count() / max(1, unit.num_units)
            for name, unit in iter_prunable_units(final_model, named=True)
        },
        "final": final_suite,
        "export": export_metrics,
        "visualization": visualization,
        "epochs": state.epoch,
        "global_step": state.global_step,
        "runtime": {
            "world_size": context.world_size,
            "data_backend": context.backend,
            "control_backend": context.control_backend,
            "saliency_execution": str(
                config["pruning"].get("saliency_execution", "all_ranks")
            ),
            "precision": str(config["train"].get("amp", "none")),
            "hap_mode": str(
                config["pruning"].get("hap_mode", "gate_empirical_fisher")
            ),
        },
    }
    if context.is_main:
        save_json(output_dir / "summary.json", summary)
        write_csv(output_dir / "curve.csv", rows)
        (output_dir / "COMPLETED").write_text(
            f"{PIPELINE_VERSION}\n", encoding="utf-8"
        )
        logger.info("Run complete: %s", output_dir)
        print(f"RUN_DIR={output_dir}", flush=True)
    if teacher is not None:
        teacher.cpu()
    if ema is not None:
        ema.module.cpu()
    close_loaders(loaders)
    if manage_distributed:
        cleanup_distributed(synchronize=True)
    return summary
