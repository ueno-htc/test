#!/usr/bin/env python3
"""Collect every ``summary.json`` below an output directory into one CSV.

Besides accuracy/efficiency columns, the table carries the controllability
metrics that the CVPR story rests on:

* ``profile_mismatch_dense`` / ``profile_mismatch_pruned``: L1 distance between
  the task reliance profile r_hat and the model sensitivity profile s_hat
  before and after pruning (smaller = the model's frequency sensitivity is
  better aligned with what the task needs).
* ``steering_gain`` = mismatch_dense - mismatch_pruned (positive = steering worked).
* ``sens_shift_<band>``: change of the sensitivity profile per band.
* ImageNet-C accuracy grouped by corruption frequency content
  (high: noise; mid: blur/digital; low: weather/contrast), following the
  Fourier analysis of Yin et al. (2019).
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, Mapping

IMAGENET_C_FREQUENCY_GROUPS: Dict[str, tuple[str, ...]] = {
    "high": ("gaussian_noise", "shot_noise", "impulse_noise"),
    "mid": (
        "defocus_blur",
        "glass_blur",
        "motion_blur",
        "zoom_blur",
        "elastic_transform",
        "pixelate",
        "jpeg_compression",
    ),
    "low": ("snow", "frost", "fog", "brightness", "contrast"),
}


def get(mapping: Mapping[str, Any], path: str, default=""):
    current: Any = mapping
    for key in path.split("."):
        if not isinstance(current, Mapping) or key not in current:
            return default
        current = current[key]
    return current


def _mean(values: list[float]) -> float | str:
    return sum(values) / len(values) if values else ""


def _l1(a, b) -> float | str:
    try:
        return float(sum(abs(float(x) - float(y)) for x, y in zip(a, b)))
    except Exception:
        return ""


def _fmt_list(values) -> str:
    try:
        return ";".join(f"{float(v):.5f}" for v in values)
    except Exception:
        return ""


def summarise(path: Path) -> Dict[str, Any]:
    summary = json.loads(path.read_text(encoding="utf-8"))
    run_dir = path.parent
    row: Dict[str, Any] = {
        "run_dir": str(run_dir),
        "arch": summary.get("arch", ""),
        "method": summary.get("method", ""),
        "dataset": summary.get("dataset", ""),
        "seed": summary.get("seed", ""),
        "target_sparsity": summary.get("target_sparsity", ""),
        "actual_sparsity": summary.get("actual_sparsity", ""),
        "epochs": summary.get("epochs", ""),
        "dense_val_top1": get(summary, "dense.val.top1"),
        "val_top1": get(summary, "final.val.top1"),
        "val_top5": get(summary, "final.val.top5"),
        "test_top1": get(summary, "final.test.top1"),
        "imagenet_r_top1": get(summary, "final.imagenet_r.top1"),
        "imagenet_sketch_top1": get(summary, "final.imagenet_sketch.top1"),
        "stylized_imagenet_top1": get(summary, "final.stylized_imagenet.top1"),
        "imagenet_c_top1": get(summary, "final.imagenet_c.mean_top1"),
        "slim_parameters": get(summary, "export.slim_parameter_count"),
        "parameter_reduction": get(summary, "export.parameter_reduction"),
        "slim_macs": get(summary, "export.slim_macs"),
        "mac_reduction": get(summary, "export.mac_reduction"),
        "measured_speedup": get(summary, "export.measured_speedup"),
        "export_max_abs_diff": get(summary, "export.masked_slim_max_abs_diff"),
        # recovery protocol
        "distill_dense": get(summary, "recovery_protocol.distill_dense"),
        "frequency_augment": get(summary, "recovery_protocol.frequency_augment"),
        "bn_recalibration_batches": get(summary, "recovery_protocol.bn_recalibration_batches"),
        # criterion hyper-parameters (from round-1 saliency diagnostics)
        "estimator": get(summary, "saliency_round1.estimator"),
        "target_profile": get(summary, "saliency_round1.target_profile"),
        "lambda": get(summary, "saliency_round1.lambda"),
        "signed": get(summary, "saliency_round1.signed"),
        "steering_weights": _fmt_list(get(summary, "saliency_round1.steering_weights", [])),
    }

    # ImageNet-C grouped by corruption frequency content.
    by_corruption = get(summary, "final.imagenet_c.by_corruption", {})
    if isinstance(by_corruption, Mapping) and by_corruption:
        for group, names in IMAGENET_C_FREQUENCY_GROUPS.items():
            values = [float(by_corruption[name]) for name in names if name in by_corruption]
            row[f"imagenet_c_{group}_freq_top1"] = _mean(values)

    # Controllability metrics from spectral profiles.
    dense_spec = get(summary, "dense.spectral", {})
    final_spec = get(summary, "final.spectral", {})
    if isinstance(dense_spec, Mapping) and isinstance(final_spec, Mapping) and "sensitivity_profile" in final_spec:
        reliance = dense_spec.get("reliance_profile") or final_spec.get("reliance_profile")
        dense_sens = dense_spec.get("sensitivity_profile")
        final_sens = final_spec.get("sensitivity_profile")
        names = final_spec.get("band_names", [])
        row["band_names"] = ";".join(map(str, names))
        row["reliance_profile"] = _fmt_list(reliance or [])
        row["dense_sensitivity_profile"] = _fmt_list(dense_sens or [])
        row["pruned_sensitivity_profile"] = _fmt_list(final_sens or [])
        if reliance and dense_sens and final_sens:
            mismatch_dense = _l1(reliance, dense_sens)
            mismatch_pruned = _l1(reliance, final_sens)
            row["profile_mismatch_dense"] = mismatch_dense
            row["profile_mismatch_pruned"] = mismatch_pruned
            if mismatch_dense != "" and mismatch_pruned != "":
                row["steering_gain"] = float(mismatch_dense) - float(mismatch_pruned)
            for name, d, f in zip(names, dense_sens, final_sens):
                row[f"sens_shift_{name}"] = float(f) - float(d)
        for name, value in zip(names, final_spec.get("band_stop_top1", []) or []):
            row[f"bandstop_top1_{name}"] = value
        row["pruned_clean_top1_profile_subset"] = final_spec.get("clean_top1", "")

    # Budget / hardware columns.
    row["budget_mode"] = get(summary, "budget.mode")
    row["channel_alignment"] = get(summary, "budget.channel_alignment")
    slim_by_batch = get(summary, "export.slim_throughput_by_batch", {})
    if isinstance(slim_by_batch, Mapping):
        for batch, perf in slim_by_batch.items():
            if isinstance(perf, Mapping) and "throughput_images_per_s" in perf:
                row[f"slim_throughput_bs{batch}"] = perf["throughput_images_per_s"]
    slim_perf = get(summary, "export.slim_throughput", {})
    if isinstance(slim_perf, Mapping) and "throughput_images_per_s" in slim_perf:
        row["slim_throughput"] = slim_perf["throughput_images_per_s"]

    # Sensitivity trajectory: first-order prediction quality and re-sensitisation.
    trajectory = summary.get("spectral_trajectory") or []
    preds, actuals, resens = [], [], []
    for step in trajectory:
        p_, a_ = step.get("predicted_relative_change"), step.get("actual_relative_change")
        if p_ and a_:
            preds.extend(float(v) for v in p_)
            actuals.extend(float(v) for v in a_)
        after_prune = step.get("sensitivity_profile_after_pruning")
        after_rec = step.get("sensitivity_profile_after_recovery")
        if after_prune and after_rec:
            # positive = recovery pushed sensitivity back toward the high band
            resens.append(float(after_rec[-1]) - float(after_prune[-1]))
    if preds and actuals and len(preds) > 2:
        import statistics

        try:
            mp, ma = statistics.fmean(preds), statistics.fmean(actuals)
            cov = sum((x - mp) * (y - ma) for x, y in zip(preds, actuals))
            var_p = sum((x - mp) ** 2 for x in preds)
            var_a = sum((y - ma) ** 2 for y in actuals)
            row["trajectory_pred_actual_corr"] = cov / ((var_p * var_a) ** 0.5) if var_p > 0 and var_a > 0 else ""
        except Exception:
            row["trajectory_pred_actual_corr"] = ""
        row["trajectory_pred_actual_mae"] = statistics.fmean(abs(x - y) for x, y in zip(preds, actuals))
    if resens:
        row["recovery_resensitization_high"] = sum(resens) / len(resens)
    row["trajectory_rounds"] = len(trajectory)

    kept = summary.get("kept_fraction_by_group") or {}
    if isinstance(kept, Mapping) and kept:
        # aggregate by top-level stage (layer1.0 -> layer1, blocks.3 -> blocks.3)
        by_stage: Dict[str, list[float]] = {}
        for name, value in kept.items():
            stage = str(name).split(".")[0]
            by_stage.setdefault(stage, []).append(float(value))
        row["kept_fraction_by_stage"] = ";".join(f"{k}={sum(v)/len(v):.3f}" for k, v in sorted(by_stage.items()))
        row["kept_fraction_json"] = json.dumps({k: round(float(v), 4) for k, v in kept.items()}, separators=(",", ":"))

    frequency = summary.get("final", {}).get("frequency", {})
    if frequency:
        key = sorted(frequency)[0]
        metrics = frequency[key]
        row.update(
            {
                "frequency_key": key,
                "lowpass_error": metrics.get("lowpass_error", ""),
                "highpass_error": metrics.get("highpass_error", ""),
                "low_frequency_region_error": metrics.get("low_frequency_region_error", ""),
                "high_frequency_region_error": metrics.get("high_frequency_region_error", ""),
            }
        )
    return row


def main() -> None:
    parser = argparse.ArgumentParser(description="Collect every summary.json below an output directory")
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    rows: list[Dict[str, Any]] = []
    for path in sorted(Path(args.root).rglob("summary.json")):
        try:
            rows.append(summarise(path))
        except Exception as error:  # noqa: BLE001 - keep collecting
            print(f"Skipping {path}: {error}")
    # Speed-up relative to the *dense slim* network of the same architecture
    # (the gated reference inflates speed-ups by the gate overhead).
    dense_reference: Dict[tuple[str, str], Dict[str, float]] = {}
    for row in rows:
        if row.get("method") == "dense":
            key = (str(row.get("arch")), str(row.get("dataset")))
            ref = {k: float(v) for k, v in row.items() if k.startswith("slim_throughput") and v not in ("", None)}
            if ref:
                dense_reference.setdefault(key, ref)
    for row in rows:
        ref = dense_reference.get((str(row.get("arch")), str(row.get("dataset"))))
        if not ref:
            continue
        for key, value in list(row.items()):
            if key.startswith("slim_throughput") and value not in ("", None) and key in ref and ref[key] > 0:
                suffix = key[len("slim_throughput"):]
                row[f"speedup_vs_dense{suffix}"] = float(value) / ref[key]

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row}) if rows else []
    priority = [
        "dataset", "arch", "method", "seed", "target_sparsity", "actual_sparsity",
        "dense_val_top1", "val_top1", "test_top1", "mac_reduction", "parameter_reduction",
        "measured_speedup", "speedup_vs_dense", "speedup_vs_dense_bs1", "speedup_vs_dense_bs32",
        "imagenet_c_top1", "imagenet_c_high_freq_top1", "imagenet_c_mid_freq_top1",
        "imagenet_c_low_freq_top1", "imagenet_r_top1", "imagenet_sketch_top1", "stylized_imagenet_top1",
        "profile_mismatch_dense", "profile_mismatch_pruned", "steering_gain",
        "trajectory_pred_actual_corr", "recovery_resensitization_high", "budget_mode",
    ]
    fields = [f for f in priority if f in fields] + [f for f in fields if f not in priority]
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        if fields:
            writer.writeheader()
            writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {output}")


if __name__ == "__main__":
    main()
