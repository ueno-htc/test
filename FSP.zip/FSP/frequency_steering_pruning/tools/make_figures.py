#!/usr/bin/env python3
"""Paper-style figures and tables from ``outputs/all_results.csv``.

Produced files (under ``--output-dir``):

* ``pareto_<dataset>_<arch>.png``      accuracy vs. MAC reduction per method
* ``profiles_<dataset>_<arch>.png``    task reliance vs. dense/pruned sensitivity profiles
* ``steering_gain_<dataset>_<arch>.png`` mismatch reduction per method
* ``imagenet_c_frequency_<arch>.png``  ImageNet-C accuracy by corruption frequency group
* ``results_table.md``                 markdown table (mean +- std over seeds)

Everything degrades gracefully when a column is missing or empty.
"""
from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

METHOD_ORDER = [
    "dense",
    "dense_finetuned",
    "random",
    "magnitude",
    "snip",
    "taylor",
    "hap",
    "lfs",
    "steering_only",
    "frequency_steering",
    "spectral_steering",
]


def _float(value: Any) -> float:
    try:
        if value in ("", None):
            return float("nan")
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _parse_list(value: str) -> list[float]:
    if not value:
        return []
    try:
        return [float(v) for v in str(value).split(";") if v != ""]
    except ValueError:
        return []


def read_rows(path: Path) -> list[Dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _method_key(method: str) -> int:
    base = method.split("@")[0]
    return METHOD_ORDER.index(base) if base in METHOD_ORDER else len(METHOD_ORDER)


def _label(row: Dict[str, str]) -> str:
    method = row.get("method", "")
    if method == "spectral_steering":
        tag = []
        if row.get("estimator") and row["estimator"] != "exact":
            tag.append(row["estimator"])
        if row.get("target_profile") and row["target_profile"] not in {"auto", ""}:
            tag.append(row["target_profile"])
        if row.get("signed") in {"False", "false", "0"}:
            tag.append("unsigned")
        if row.get("frequency_augment") in {"True", "true", "1"}:
            tag.append("freq-aug")
        if tag:
            return "spectral_steering[" + ",".join(tag) + "]"
    if method == "taylor" and row.get("frequency_augment") in {"True", "true", "1"}:
        return "taylor+freq_aug"
    return method


def _accuracy(row: Dict[str, str]) -> float:
    value = _float(row.get("test_top1"))
    return value if not math.isnan(value) else _float(row.get("val_top1"))


def _mean_std(values: Iterable[float]) -> tuple[float, float, int]:
    arr = np.asarray([v for v in values if not math.isnan(v)], dtype=np.float64)
    if arr.size == 0:
        return float("nan"), float("nan"), 0
    return float(arr.mean()), float(arr.std(ddof=0)), int(arr.size)


def plot_pareto(rows: list[Dict[str, str]], output_dir: Path) -> list[Path]:
    produced: list[Path] = []
    groups: Dict[tuple[str, str], list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        groups[(row.get("dataset", ""), row.get("arch", ""))].append(row)
    for (dataset, arch), items in sorted(groups.items()):
        pruned = [r for r in items if r.get("method") not in {"dense", "dense_finetuned"}]
        if not pruned:
            continue
        fig, ax = plt.subplots(figsize=(6.4, 4.4))
        by_label: Dict[str, list[tuple[float, float]]] = defaultdict(list)
        for row in pruned:
            x = 100.0 * _float(row.get("mac_reduction"))
            y = _accuracy(row)
            if math.isnan(x) or math.isnan(y):
                continue
            by_label[_label(row)].append((x, y))
        for label in sorted(by_label, key=_method_key):
            points = sorted(by_label[label])
            xs = [p[0] for p in points]
            ys = [p[1] for p in points]
            style = "-o" if label.startswith("spectral_steering") else "--s"
            ax.plot(xs, ys, style, label=label, linewidth=2.0 if label.startswith("spectral") else 1.2, markersize=5)
        dense = [_accuracy(r) for r in items if r.get("method") == "dense"]
        dense = [v for v in dense if not math.isnan(v)]
        if dense:
            ax.axhline(np.mean(dense), color="black", linestyle=":", label="dense (pretrained)")
        ax.set_xlabel("MAC reduction (%)")
        ax.set_ylabel("Top-1 accuracy (%)")
        ax.set_title(f"{dataset} / {arch}")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=7, loc="lower left")
        fig.tight_layout()
        path = output_dir / f"pareto_{dataset}_{arch}.png"
        fig.savefig(path, dpi=180)
        plt.close(fig)
        produced.append(path)
    return produced


def plot_profiles(rows: list[Dict[str, str]], output_dir: Path) -> list[Path]:
    produced: list[Path] = []
    groups: Dict[tuple[str, str], list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row.get("reliance_profile"):
            groups[(row.get("dataset", ""), row.get("arch", ""))].append(row)
    for (dataset, arch), items in sorted(groups.items()):
        reliance = _parse_list(items[0].get("reliance_profile", ""))
        dense = _parse_list(items[0].get("dense_sensitivity_profile", ""))
        names = (items[0].get("band_names") or "").split(";")
        if not reliance or not dense:
            continue
        pruned_series: Dict[str, list[float]] = {}
        for row in items:
            label = _label(row)
            if label.startswith("spectral_steering") or label in {"taylor", "lfs", "frequency_steering"}:
                values = _parse_list(row.get("pruned_sensitivity_profile", ""))
                if values and label not in pruned_series:
                    pruned_series[label] = values
        series = {"task reliance r": reliance, "dense sensitivity s": dense, **pruned_series}
        fig, ax = plt.subplots(figsize=(6.8, 4.0))
        width = 0.8 / max(1, len(series))
        x = np.arange(len(reliance))
        for index, (label, values) in enumerate(series.items()):
            ax.bar(x + (index - len(series) / 2 + 0.5) * width, values, width, label=label)
        ax.set_xticks(x, names if len(names) == len(reliance) else [str(i) for i in x])
        ax.set_ylabel("normalised profile")
        ax.set_title(f"Reliance vs. sensitivity: {dataset} / {arch}")
        ax.legend(fontsize=7)
        ax.grid(axis="y", alpha=0.3)
        fig.tight_layout()
        path = output_dir / f"profiles_{dataset}_{arch}.png"
        fig.savefig(path, dpi=180)
        plt.close(fig)
        produced.append(path)
    return produced


def plot_steering_gain(rows: list[Dict[str, str]], output_dir: Path) -> list[Path]:
    produced: list[Path] = []
    groups: Dict[tuple[str, str], Dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        gain = _float(row.get("steering_gain"))
        if math.isnan(gain) or row.get("method") in {"dense", "dense_finetuned"}:
            continue
        groups[(row.get("dataset", ""), row.get("arch", ""))][_label(row)].append(gain)
    for (dataset, arch), per_label in sorted(groups.items()):
        labels = sorted(per_label, key=_method_key)
        means = [np.mean(per_label[l]) for l in labels]
        stds = [np.std(per_label[l]) for l in labels]
        fig, ax = plt.subplots(figsize=(6.8, 3.8))
        colors = ["tab:red" if l.startswith("spectral_steering") else "tab:gray" for l in labels]
        ax.bar(range(len(labels)), means, yerr=stds, color=colors, capsize=3)
        ax.axhline(0.0, color="black", linewidth=0.8)
        ax.set_xticks(range(len(labels)), labels, rotation=30, ha="right", fontsize=7)
        ax.set_ylabel("steering gain (L1 mismatch reduction)")
        ax.set_title(f"Controllability: {dataset} / {arch}")
        ax.grid(axis="y", alpha=0.3)
        fig.tight_layout()
        path = output_dir / f"steering_gain_{dataset}_{arch}.png"
        fig.savefig(path, dpi=180)
        plt.close(fig)
        produced.append(path)
    return produced


def plot_imagenet_c(rows: list[Dict[str, str]], output_dir: Path) -> list[Path]:
    produced: list[Path] = []
    groups: Dict[str, list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row.get("dataset") == "imagenet" and row.get("imagenet_c_high_freq_top1"):
            groups[row.get("arch", "")].append(row)
    for arch, items in sorted(groups.items()):
        per_label: Dict[str, Dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
        for row in items:
            label = _label(row)
            for group in ("low", "mid", "high"):
                value = _float(row.get(f"imagenet_c_{group}_freq_top1"))
                if not math.isnan(value):
                    per_label[label][group].append(value)
        labels = sorted(per_label, key=_method_key)
        if not labels:
            continue
        fig, ax = plt.subplots(figsize=(7.2, 4.0))
        width = 0.8 / 3
        x = np.arange(len(labels))
        for index, group in enumerate(("low", "mid", "high")):
            ax.bar(
                x + (index - 1) * width,
                [np.mean(per_label[l][group]) if per_label[l][group] else np.nan for l in labels],
                width,
                label=f"{group}-frequency corruptions",
            )
        ax.set_xticks(x, labels, rotation=30, ha="right", fontsize=7)
        ax.set_ylabel("ImageNet-C top-1 (%)")
        ax.set_title(f"ImageNet-C by corruption frequency: {arch}")
        ax.legend(fontsize=7)
        ax.grid(axis="y", alpha=0.3)
        fig.tight_layout()
        path = output_dir / f"imagenet_c_frequency_{arch}.png"
        fig.savefig(path, dpi=180)
        plt.close(fig)
        produced.append(path)
    return produced


def plot_kept_fraction(rows: list[Dict[str, str]], output_dir: Path) -> list[Path]:
    """Where does each criterion remove capacity? Kept fraction per stage/block."""
    import json as _json

    produced: list[Path] = []
    groups: Dict[tuple[str, str, str], list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row.get("kept_fraction_json") and row.get("method") not in {"dense", "dense_finetuned"}:
            groups[(row.get("dataset", ""), row.get("arch", ""), f"{_float(row.get('target_sparsity')):.2f}")].append(row)
    for (dataset, arch, sp), items in sorted(groups.items()):
        series: Dict[str, Dict[str, float]] = {}
        for row in items:
            try:
                kept = _json.loads(row["kept_fraction_json"])
            except Exception:
                continue
            series.setdefault(_label(row), kept)
        if not series:
            continue
        names = list(next(iter(series.values())).keys())
        fig, ax = plt.subplots(figsize=(max(7.0, 0.22 * len(names)), 3.8))
        for label in sorted(series, key=_method_key):
            values = [series[label].get(n, np.nan) for n in names]
            style = "-o" if label.startswith("spectral_steering") else "--"
            ax.plot(range(len(names)), values, style, label=label, markersize=3, linewidth=1.8 if style == "-o" else 1.0)
        ax.set_xticks(range(len(names)), names, rotation=90, fontsize=6)
        ax.set_ylabel("kept fraction")
        ax.set_ylim(0, 1.02)
        ax.set_title(f"Capacity kept per structural group: {dataset} / {arch} / sp{sp}")
        ax.legend(fontsize=6, ncol=2)
        ax.grid(alpha=0.3)
        fig.tight_layout()
        path = output_dir / f"kept_fraction_{dataset}_{arch}_sp{sp}.png"
        fig.savefig(path, dpi=180)
        plt.close(fig)
        produced.append(path)
    return produced


def plot_speed(rows: list[Dict[str, str]], output_dir: Path) -> list[Path]:
    """Measured speed-up vs. dense (not vs. the gated model) against MAC reduction."""
    produced: list[Path] = []
    groups: Dict[tuple[str, str], list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row.get("speedup_vs_dense") and row.get("method") not in {"dense", "dense_finetuned"}:
            groups[(row.get("dataset", ""), row.get("arch", ""))].append(row)
    for (dataset, arch), items in sorted(groups.items()):
        fig, ax = plt.subplots(figsize=(6.0, 4.0))
        keys = [k for k in ("speedup_vs_dense_bs1", "speedup_vs_dense_bs32", "speedup_vs_dense") if any(r.get(k) for r in items)]
        for key in keys:
            xs = [100 * _float(r.get("mac_reduction")) for r in items if r.get(key)]
            ys = [_float(r.get(key)) for r in items if r.get(key)]
            ax.scatter(xs, ys, label=key.replace("speedup_vs_dense", "speed-up") or "speed-up", s=22)
        ax.axhline(1.0, color="black", linestyle=":", linewidth=0.8)
        ax.set_xlabel("MAC reduction (%)")
        ax.set_ylabel("throughput / dense throughput")
        ax.set_title(f"MACs vs. measured speed-up: {dataset} / {arch}")
        ax.grid(alpha=0.3)
        ax.legend(fontsize=7)
        fig.tight_layout()
        path = output_dir / f"speedup_{dataset}_{arch}.png"
        fig.savefig(path, dpi=180)
        plt.close(fig)
        produced.append(path)
    return produced


def write_table(rows: list[Dict[str, str]], output_dir: Path) -> Path:
    groups: Dict[tuple[str, str, str, str], list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        key = (row.get("dataset", ""), row.get("arch", ""), f"{_float(row.get('target_sparsity')):.2f}", _label(row))
        groups[key].append(row)
    lines = [
        "| dataset | arch | target | method | top-1 (mean±std, n) | MAC red. (%) | speed-up vs dense | ImNet-C | steering gain |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for key in sorted(groups, key=lambda k: (k[0], k[1], k[2], _method_key(k[3]), k[3])):
        items = groups[key]
        acc_mean, acc_std, n = _mean_std(_accuracy(r) for r in items)
        mac_mean, _, _ = _mean_std(100.0 * _float(r.get("mac_reduction")) for r in items)
        speed_mean, _, _ = _mean_std(_float(r.get("speedup_vs_dense", r.get("measured_speedup"))) for r in items)
        c_mean, _, _ = _mean_std(_float(r.get("imagenet_c_top1")) for r in items)
        gain_mean, _, _ = _mean_std(_float(r.get("steering_gain")) for r in items)

        def fmt(value: float, digits: int = 2) -> str:
            return "-" if math.isnan(value) else f"{value:.{digits}f}"

        lines.append(
            f"| {key[0]} | {key[1]} | {key[2]} | {key[3]} | {fmt(acc_mean)}±{fmt(acc_std)} ({n}) | "
            f"{fmt(mac_mean, 1)} | {fmt(speed_mean)} | {fmt(c_mean)} | {fmt(gain_mean, 3)} |"
        )
    path = output_dir / "results_table.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate figures from all_results.csv")
    parser.add_argument("--results", default="outputs/all_results.csv")
    parser.add_argument("--output-dir", default="outputs/figures")
    args = parser.parse_args()
    results = Path(args.results)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if not results.exists():
        print(f"No results file at {results}; nothing to plot")
        return
    rows = read_rows(results)
    if not rows:
        print("Results file is empty; nothing to plot")
        return
    produced = []
    produced += plot_pareto(rows, output_dir)
    produced += plot_profiles(rows, output_dir)
    produced += plot_steering_gain(rows, output_dir)
    produced += plot_imagenet_c(rows, output_dir)
    produced += plot_kept_fraction(rows, output_dir)
    produced += plot_speed(rows, output_dir)
    produced.append(write_table(rows, output_dir))
    for path in produced:
        print(f"wrote {path}")


if __name__ == "__main__":
    main()
