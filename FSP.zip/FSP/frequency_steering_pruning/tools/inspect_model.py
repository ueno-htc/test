#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from frequency_pruning.models import build_model, unit_descriptors
from frequency_pruning.utils import count_parameters


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect structured pruning groups for an architecture")
    parser.add_argument("--arch", default="resnet50")
    parser.add_argument("--num-classes", type=int, default=1000)
    parser.add_argument("--image-size", type=int, default=224)
    args = parser.parse_args()
    model = build_model(args.arch, args.num_classes, weights="NONE", image_size=args.image_size)
    descriptors = unit_descriptors(model)
    print(
        json.dumps(
            {
                "arch": args.arch,
                "parameters": count_parameters(model),
                "num_groups": len(descriptors),
                "num_units": sum(item.size for item in descriptors),
                "groups": [item.__dict__ for item in descriptors],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
