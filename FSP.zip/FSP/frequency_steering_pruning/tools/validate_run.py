#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import sys
from pathlib import Path


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("Usage: validate_run.py RUN_DIR")
    run_dir = Path(sys.argv[1])
    required = [
        "config.yaml",
        "summary.json",
        "curve.csv",
        "checkpoint_final_masked.pt",
        "slim_model.pt",
        "export_metrics.json",
    ]
    missing = [name for name in required if not (run_dir / name).exists()]
    if missing:
        raise RuntimeError(f"Missing run artifacts: {missing}")
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    sparsity = float(summary["actual_sparsity"])
    if not 0.0 <= sparsity < 1.0:
        raise RuntimeError(f"Invalid sparsity: {sparsity}")
    difference = float(summary["export"]["masked_slim_max_abs_diff"])
    if not math.isfinite(difference) or difference > 1e-4:
        raise RuntimeError(f"Physical export does not match masked model: {difference}")
    if int(summary["export"]["slim_parameter_count"]) >= int(summary["export"]["dense_parameter_count"]) and sparsity > 0:
        raise RuntimeError("Pruned run did not reduce physical parameter count")
    print(
        json.dumps(
            {
                "run_dir": str(run_dir.resolve()),
                "actual_sparsity": sparsity,
                "export_max_abs_diff": difference,
                "status": "ok",
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
