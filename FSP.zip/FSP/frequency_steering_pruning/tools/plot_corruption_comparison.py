#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def load(path: str):
    path_obj = Path(path)
    if path_obj.is_dir():
        path_obj = path_obj / "imagenet_c_detail.json"
    return json.loads(path_obj.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot corruption-wise ImageNet-C delta between two runs")
    parser.add_argument("--proposed", required=True)
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--title", default="ImageNet-C: proposed - baseline")
    args = parser.parse_args()
    proposed = load(args.proposed)["by_corruption"]
    baseline = load(args.baseline)["by_corruption"]
    names = sorted(set(proposed) & set(baseline))
    deltas = [float(proposed[name]) - float(baseline[name]) for name in names]
    fig, ax = plt.subplots(figsize=(10.5, 5.0))
    bars = ax.bar(range(len(names)), deltas)
    for bar, value in zip(bars, deltas):
        bar.set_alpha(0.85 if value >= 0 else 0.55)
    ax.axhline(0.0, linewidth=1.0)
    ax.set_xticks(range(len(names)), names, rotation=45, ha="right")
    ax.set_ylabel("Top-1 difference (points)")
    ax.set_title(args.title)
    ax.grid(True, axis="y", alpha=0.25)
    fig.tight_layout()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180)
    plt.close(fig)
    print(output.resolve())


if __name__ == "__main__":
    main()
