#!/usr/bin/env python3
"""Audit a results tree and decide what the evidence supports.

Input : outputs/all_results.csv (tools/collect_results.py)
Output: <output-dir>/analysis_report.md and analysis_verdicts.json

Sections
  1. Dense gate          dense accuracies vs. configs/dense_reference.json
  2. Rankings            per (dataset, arch, target) table, with seed std or a
                         single-seed noise band
  3. Hypotheses H1-H8    pre-registered in docs/HYPOTHESES_V5.md; each gets
                         SUPPORTED / REJECTED / INCONCLUSIVE / NO DATA
  4. Paper gate          READY only if every mandatory condition holds

The tool never edits results; it is safe to run after every run_all.sh.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, Sequence

import numpy as np

SINGLE_SEED_NOISE = 0.4  # points; v4.0 repeated-run range was ~0.2-0.35 on ImageNet
DENSE = {"dense", "dense_finetuned"}
PROPOSED = "srp"
BASELINES = ("magnitude", "taylor", "taylor_global", "lfs", "random", "hap", "frequency_steering")


def f(value: Any) -> float:
    try:
        if value in ("", None):
            return float("nan")
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def plist(value: Any) -> list[float]:
    if not value:
        return []
    try:
        return [float(v) for v in str(value).split(";") if v != ""]
    except ValueError:
        return []


def acc(row: Dict[str, str]) -> float:
    value = f(row.get("test_top1"))
    return value if not math.isnan(value) else f(row.get("val_top1"))


def label(row: Dict[str, str]) -> str:
    variant = row.get("variant") or ""
    if variant and not variant.startswith("seed"):
        return variant
    return row.get("method", "")


def stage_of(row: Dict[str, str]) -> str:
    # The synthetic controlled tasks are a mechanism check; they never count as
    # transfer evidence for the hypotheses or the paper gate.
    if str(row.get("dataset", "")).lower().startswith("bandtask"):
        return "controlled"
    parts = Path(row.get("run_dir", "")).parts
    for name in ("specialize", "lowdata", "latency", "transfer", "main", "vit", "ablations", "tuning"):
        if name in parts:
            return name
    # Results collected from a non-standard root: infer the stage from the task.
    dataset = str(row.get("dataset", "")).lower()
    if dataset in {"", "synthetic"}:
        return "other"
    return "main" if dataset.startswith("imagenet") else "transfer"


def mean_std(values: Iterable[float]) -> tuple[float, float, int]:
    arr = np.asarray([v for v in values if not math.isnan(v)], dtype=np.float64)
    if arr.size == 0:
        return float("nan"), float("nan"), 0
    return float(arr.mean()), float(arr.std(ddof=1)) if arr.size > 1 else float("nan"), int(arr.size)


def spearman(x: Sequence[float], y: Sequence[float]) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    return float(np.corrcoef(rx, ry)[0, 1])


def paired(rows_a: Dict[Any, float], rows_b: Dict[Any, float]) -> Dict[str, Any]:
    keys = sorted(set(rows_a) & set(rows_b))
    diffs = np.asarray([rows_a[k] - rows_b[k] for k in keys], dtype=np.float64)
    if diffs.size == 0:
        return {"n": 0}
    out: Dict[str, Any] = {"n": int(diffs.size), "mean_diff": float(diffs.mean()), "wins": int((diffs > 0).sum())}
    if diffs.size > 1 and diffs.std(ddof=1) > 0:
        t = diffs.mean() / (diffs.std(ddof=1) / math.sqrt(diffs.size))
        out["t"] = float(t)
        # two-sided p-value from the t distribution without scipy (normal approx for n>=30, else table-free bound)
        try:
            from scipy import stats  # type: ignore

            out["p"] = float(2 * stats.t.sf(abs(t), df=diffs.size - 1))
        except Exception:  # pragma: no cover - scipy optional
            out["p"] = float(math.erfc(abs(t) / math.sqrt(2)))
    return out


def verdict(supported: bool | None, detail: str) -> Dict[str, Any]:
    status = "NO DATA" if supported is None else ("SUPPORTED" if supported else "REJECTED")
    return {"status": status, "detail": detail}


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit results and evaluate the pre-registered hypotheses")
    parser.add_argument("--results", default="outputs/all_results.csv")
    parser.add_argument("--output-dir", default="outputs/analysis")
    parser.add_argument("--dense-reference", default="configs/dense_reference.json")
    parser.add_argument("--source-reliance", default="configs/source_reliance.json")
    parser.add_argument("--proposed", default=PROPOSED)
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    results = Path(args.results)
    if not results.exists():
        (out_dir / "analysis_report.md").write_text("No results file found.\n", encoding="utf-8")
        print(f"No results at {results}")
        return
    with results.open("r", newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["_stage"] = stage_of(row)
        row["_acc"] = acc(row)
        row["_label"] = label(row)
    reference = json.loads(Path(args.dense_reference).read_text()) if Path(args.dense_reference).exists() else {}
    source = json.loads(Path(args.source_reliance).read_text()) if Path(args.source_reliance).exists() else {}
    proposed = args.proposed
    lines: list[str] = ["# Automated results audit", ""]
    verdicts: Dict[str, Any] = {}

    # ------------------------------------------------------------------ 1. dense gate
    lines += ["## 1. Dense gate", "", "| stage | dataset | arch | dense top-1 | reference / minimum | status |", "|---|---|---|---|---|---|"]
    dense_ok = True
    seen: set[tuple[str, str, str]] = set()
    dense_fail: list[str] = []
    for row in rows:
        if row.get("method") != "dense":
            continue
        key = (row["_stage"], row.get("dataset", ""), row.get("arch", ""))
        values = [r["_acc"] for r in rows if r.get("method") == "dense" and (r["_stage"], r.get("dataset", ""), r.get("arch", "")) == key]
        if key in seen:
            continue
        seen.add(key)
        mean, _, _ = mean_std(values)
        dataset, arch = key[1], key[2]
        if dataset == "imagenet":
            ref = f(reference.get("imagenet", {}).get(arch))
            tol = f(reference.get("imagenet_tolerance", 0.3))
            ok = math.isnan(ref) or abs(mean - ref) <= tol or mean >= ref
            ref_text = f"{ref:.2f} ± {tol}" if not math.isnan(ref) else "n/a"
        else:
            table = reference.get("transfer_min", {})
            entry = table.get(dataset, {})
            minimum = f(entry.get(arch, entry.get("default", table.get("default", 0.0)))) if isinstance(entry, dict) else f(table.get("default", 0.0))
            ok = mean >= minimum
            ref_text = f">= {minimum:.1f}"
        dense_ok &= ok
        if not ok:
            dense_fail.append(f"{dataset}/{arch}")
        lines.append(f"| {key[0]} | {dataset} | {arch} | {mean:.2f} | {ref_text} | {'OK' if ok else '**FAIL**'} |")
    verdicts["dense_gate"] = {"passed": bool(dense_ok), "failed": dense_fail}
    lines.append("")

    # ------------------------------------------------------------------ 2. rankings
    lines += ["## 2. Rankings at equal budget", ""]
    groups: Dict[tuple[str, str, str, str], list[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row["_stage"] in {"tuning", "other"}:
            continue
        groups[(row["_stage"], row.get("dataset", ""), row.get("arch", ""), f"{f(row.get('target_sparsity')):.2f}")].append(row)
    # Latency-budget groups are compared at equal measured speed-up, not equal MACs.
    latency_groups = {key for key in groups if key[0] == "latency"}
    ranking_summary: Dict[str, Any] = {}
    budget_violations: list[str] = []
    max_seeds = 1
    for key in sorted(groups):
        items = groups[key]
        per: Dict[str, list[Dict[str, str]]] = defaultdict(list)
        for row in items:
            per[row["_label"]].append(row)
        table = []
        for name, group_rows in per.items():
            mean, std, n = mean_std(r["_acc"] for r in group_rows)
            mac, _, _ = mean_std(100 * f(r.get("mac_reduction")) for r in group_rows)
            drift, _, _ = mean_std(f(r.get("reliance_drift")) for r in group_rows)
            speed, _, _ = mean_std(f(r.get("speedup_vs_dense")) for r in group_rows)
            table.append((name, mean, std, n, mac, drift, speed))
            max_seeds = max(max_seeds, n)
        table.sort(key=lambda t: (-(t[1] if not math.isnan(t[1]) else -1e9)))
        pruned = [t for t in table if t[0] not in DENSE]
        if not pruned:
            continue
        best_base = max((t for t in pruned if not t[0].startswith(("srp", "spectral"))), key=lambda t: t[1], default=None)
        lines += [f"### {key[0]} / {key[1]} / {key[2]} / target {key[3]}", "",
                  "| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |", "|---|---|---|---|---|---|---|"]
        for name, mean, std, n, mac, drift, speed in table:
            mark = " ← proposed" if name == proposed else ""
            lines.append(
                f"| {name}{mark} | {mean:.2f} | {'' if math.isnan(std) else f'{std:.2f}'} | {n} | "
                f"{'' if math.isnan(mac) else f'{mac:.1f}'} | {'' if math.isnan(drift) else f'{drift:.3f}'} | "
                f"{'' if math.isnan(speed) else f'{speed:.2f}'} |"
            )
        macs = [t[4] for t in pruned if not math.isnan(t[4])]
        target_pct = 100.0 * f(items[0].get("target_sparsity"))
        if key in latency_groups:
            speeds = [t[6] for t in pruned if not math.isnan(t[6])]
            if speeds and (max(speeds) / max(min(speeds), 1e-9) > 1.08):
                lines.append("")
                lines.append(f"⚠ budget check: measured speed-up ranges {min(speeds):.2f}–{max(speeds):.2f}x (latency budgets differ by more than 8%).")
                budget_violations.append("/".join(key))
        elif macs and (max(macs) - min(macs) > 1.0 or (not math.isnan(target_pct) and abs(np.mean(macs) - target_pct) > 1.5)):
            lines.append("")
            lines.append(
                f"⚠ budget check: MAC reduction ranges {min(macs):.1f}–{max(macs):.1f}% for target {target_pct:.0f}% "
                "(unequal or capped budgets; this group is not a valid comparison)."
            )
            budget_violations.append("/".join(key))
        prop = next((t for t in pruned if t[0] == proposed), None)
        if prop and best_base:
            noise = max(SINGLE_SEED_NOISE, 2 * (prop[2] if not math.isnan(prop[2]) else 0.0))
            delta = prop[1] - best_base[1]
            state = "better" if delta > noise else ("worse" if delta < -noise else "tie")
            lines.append("")
            lines.append(f"{proposed} vs best baseline ({best_base[0]}): {delta:+.2f} pt → **{state}** (noise band ±{noise:.2f}).")
            ranking_summary["/".join(key)] = {"delta_vs_best_baseline": delta, "best_baseline": best_base[0], "state": state}
        lines.append("")
    verdicts["rankings"] = ranking_summary
    verdicts["budget_violations"] = budget_violations
    verdicts["max_seeds"] = max_seeds

    # ------------------------------------------------------------------ 3. hypotheses
    lines += ["## 3. Pre-registered hypotheses (docs/HYPOTHESES_V5.md)", ""]
    pruned_rows = [r for r in rows if r.get("method") not in DENSE and r["_stage"] in {"transfer", "main", "vit", "ablations"}]

    def by_group_seed(name: str, stages: Sequence[str] = ("transfer",)) -> Dict[tuple, float]:
        out: Dict[tuple, float] = {}
        for r in pruned_rows:
            if r["_label"] == name and r["_stage"] in stages and not math.isnan(r["_acc"]):
                out[(r.get("dataset"), r.get("arch"), r.get("target_sparsity"), r.get("seed"))] = r["_acc"]
        return out

    hyp: Dict[str, Any] = {}

    # H1: task reliance differs from the source task
    dists = []
    for r in rows:
        if r.get("method") != "dense" or r["_stage"] != "transfer":
            continue
        rel = plist(r.get("reliance_profile"))
        src = source.get(r.get("arch", ""))
        if rel and src and len(rel) == len(src):
            dists.append((r.get("dataset"), r.get("arch"), float(np.abs(np.asarray(rel) - np.asarray(src)).sum())))
    if dists:
        per_ds: Dict[str, list[float]] = defaultdict(list)
        for ds, _arch, d in dists:
            per_ds[ds].append(d)
        text = ", ".join(f"{ds}: {np.mean(v):.2f}" for ds, v in sorted(per_ds.items()))
        hyp["H1"] = verdict(max(np.mean(v) for v in per_ds.values()) >= 0.2, f"L1(task reliance, source reliance) per dataset: {text} (threshold 0.2 on at least one task)")
    else:
        hyp["H1"] = verdict(None, "no transfer dense profiles")

    # H2: reliance drift predicts accuracy within groups
    zx, zy = [], []
    per_group_rho = []
    for key, items in groups.items():
        sel = [(f(r.get("reliance_drift")), r["_acc"]) for r in items if r.get("method") not in DENSE]
        sel = [(a, b) for a, b in sel if not math.isnan(a) and not math.isnan(b)]
        if len(sel) < 5:
            continue
        x, y = np.asarray([s[0] for s in sel]), np.asarray([s[1] for s in sel])
        if x.std() == 0 or y.std() == 0:
            continue
        per_group_rho.append(spearman(x, y))
        zx.extend(((x - x.mean()) / x.std()).tolist())
        zy.extend(((y - y.mean()) / y.std()).tolist())
    if len(zx) >= 20:
        pooled = float(np.corrcoef(zx, zy)[0, 1])
        frac_neg = float(np.mean(np.asarray(per_group_rho) < 0))
        hyp["H2"] = verdict(pooled <= -0.3 and frac_neg >= 0.7,
                            f"pooled within-group r(drift, acc) = {pooled:+.2f} (n={len(zx)}); negative in {frac_neg:.0%} of {len(per_group_rho)} groups (need r <= -0.3 and >= 70%)")
    else:
        hyp["H2"] = verdict(None, "fewer than 20 pruned runs with reliance drift")

    def compare(name_a: str, name_b: str, stages: Sequence[str] = ("transfer",)) -> Dict[str, Any]:
        return paired(by_group_seed(name_a, stages), by_group_seed(name_b, stages))

    def hyp_pair(tag: str, a: str, b: str, need: float, text: str, stages: Sequence[str] = ("transfer",), reverse: bool = False) -> None:
        """Claim "a beats b by >= need points" (or, with reverse, "a is not worse than b by more than need").

        SUPPORTED    needs >= 3 paired runs, the required mean difference and p < 0.05 (paired t-test);
        REJECTED     needs >= 3 paired runs and a mean difference clearly short of the requirement;
        INCONCLUSIVE otherwise (too few pairs, or the right direction without significance).
        """
        res = compare(a, b, stages)
        n = res.get("n", 0)
        if n == 0:
            hyp[tag] = verdict(None, f"{a} vs {b}: no paired runs")
            return
        mean = res["mean_diff"]
        p = res.get("p", float("nan"))
        p_text = f", p = {p:.3g}" if not math.isnan(p) else ""
        detail = f"{text}: {a} − {b} = {mean:+.2f} pt over {n} paired runs, wins {res['wins']}/{n}{p_text}"
        if n < 3:
            status = "INCONCLUSIVE"
            detail += " (fewer than 3 pairs)"
        elif reverse:
            status = "SUPPORTED" if mean >= -need else "REJECTED"
        elif mean >= need and not math.isnan(p) and p < 0.05:
            status = "SUPPORTED"
        elif mean < need / 2:
            status = "REJECTED"
        else:
            status = "INCONCLUSIVE"
        hyp[tag] = {"status": status, "detail": detail}

    hyp_pair("H3a", proposed, "taylor", 0.5, "SRP beats clean gate-Taylor on transfer tasks (>= +0.5 pt)")
    hyp_pair("H3b", proposed, "magnitude", 0.5, "SRP beats magnitude on transfer tasks (>= +0.5 pt)")
    hyp_pair("H4a", proposed, "srp_lambda0", 0.3, "the reliance term adds to global Taylor (lambda = 0)")
    hyp_pair("H4b", proposed, "srp_low", 0.3, "all bands matter (vs preserving only the low band, VTC-LFC prior)")
    hyp_pair("H4c", proposed, "srp_pass", 0.0, "band-stop derivative is at least as good as band-pass shares", reverse=True)
    hyp_pair("H4d", "rfc", "taylor_global", 0.3, "restricting calibration inputs to the task's reliant bands adds to global Taylor")
    hyp_pair("H4e", "srp_od", "taylor_global", 0.3, "the output-difference band term adds to global Taylor")
    hyp_pair("H5", "taylor_augcal", "taylor", 0.5, "augmented calibration views repair saturated Taylor gradients")
    hyp_pair("H6", "taylor_global", "taylor", 0.5, "global (un-normalised) ranking beats per-layer z-scoring")
    hyp_pair("H7a", "srp_rpr", proposed, 0.3, "reliance-preserving recovery adds accuracy on top of SRP selection")
    hyp_pair("H7b", "taylor_rpr", "taylor", 0.3, "reliance-preserving recovery helps a baseline criterion")
    hyp_pair("H8", proposed, "taylor", 0.3, "no harm on the source task (ImageNet): SRP >= Taylor − 0.3", stages=("main", "vit"), reverse=True)
    # ------------------------------------------------------------------ v6 hypotheses (docs/HYPOTHESES_V6.md)
    def pairs_for(name: str, stage_names: Sequence[str], arch: str | None = None) -> Dict[tuple, float]:
        out: Dict[tuple, float] = {}
        for r in pruned_rows + [x for x in rows if x["_stage"] in stage_names and x.get("method") not in DENSE and x not in pruned_rows]:
            if r["_label"] != name or r["_stage"] not in stage_names or math.isnan(r["_acc"]):
                continue
            if arch is not None and r.get("arch") != arch:
                continue
            out[(r["_stage"], r.get("dataset"), r.get("arch"), r.get("target_sparsity"), r.get("seed"))] = r["_acc"]
        return out

    def g_pair(tag: str, a: str, b: str, need: float, text: str, stage_names: Sequence[str], arch: str | None = None,
               min_pairs: int = 3, at_least: bool = False) -> Dict[str, Any]:
        res = paired(pairs_for(a, stage_names, arch), pairs_for(b, stage_names, arch))
        n = res.get("n", 0)
        if n == 0:
            hyp[tag] = verdict(None, f"{text}: no paired runs ({a} vs {b})")
            return res
        mean, p = res["mean_diff"], res.get("p", float("nan"))
        detail = f"{text}: {a} − {b} = {mean:+.2f} pt over {n} paired runs, wins {res['wins']}/{n}" + ("" if math.isnan(p) else f", p = {p:.3g}")
        if n < min_pairs:
            status = "INCONCLUSIVE"
            detail += f" (fewer than {min_pairs} pairs)"
        elif at_least:
            status = "SUPPORTED" if mean >= need else "REJECTED"
        elif mean >= need and not math.isnan(p) and p < 0.05:
            status = "SUPPORTED"
        elif mean < need / 2:
            status = "REJECTED"
        else:
            status = "INCONCLUSIVE"
        hyp[tag] = {"status": status, "detail": detail}
        return res

    g_pair("G1", "taylor_global", "taylor", 1.0, "transfer: loss-calibrated global ranking beats per-layer normalisation", ("transfer",), min_pairs=12)
    g_pair("G2", "taylor", "taylor_global", 0.5, "source task (ImageNet ResNet-50, full data): per-layer normalisation beats global ranking", ("main", "ablations"), arch="resnet50", min_pairs=3)
    low = g_pair("G3a", "taylor_global", "taylor", 0.0, "ImageNet ResNet-50 with scarce recovery data: global ranking is not worse", ("lowdata",), arch="resnet50", min_pairs=3, at_least=True)
    full = paired(pairs_for("taylor_global", ("main", "ablations"), "resnet50"), pairs_for("taylor", ("main", "ablations"), "resnet50"))
    if low.get("n", 0) >= 3 and full.get("n", 0) >= 1:
        did = low["mean_diff"] - full["mean_diff"]
        hyp["G3b"] = {
            "status": "SUPPORTED" if did >= 1.0 else "REJECTED",
            "detail": f"data regime drives the flip: (global − per-layer) is {low['mean_diff']:+.2f} pt with scarce data vs {full['mean_diff']:+.2f} pt with full data; difference-in-differences {did:+.2f} pt (need >= +1.0)",
        }
    else:
        hyp["G3b"] = verdict(None, "needs the lowdata stage (>= 3 pairs) and the full-data ImageNet ResNet-50 runs")
    # G4: the look-ahead choice matches the better end of the family everywhere
    auto_rows = [r for r in rows if r["_label"] == "taylor_auto" and not math.isnan(r["_acc"])]
    if auto_rows:
        shortfalls, gains = [], []
        for r in auto_rows:
            key = (r["_stage"], r.get("dataset"), r.get("arch"), r.get("target_sparsity"), r.get("seed"))
            ends = [x["_acc"] for x in rows if x["_label"] in {"taylor", "taylor_global"} and
                    (x["_stage"], x.get("dataset"), x.get("arch"), x.get("target_sparsity"), x.get("seed")) == key and not math.isnan(x["_acc"])]
            if len(ends) == 2:
                shortfalls.append(r["_acc"] - max(ends))
                gains.append(r["_acc"] - min(ends))
        if len(shortfalls) >= 6:
            mean_short, worst = float(np.mean(shortfalls)), float(np.min(shortfalls))
            hyp["G4"] = {
                "status": "SUPPORTED" if mean_short >= -0.3 and float(np.mean(gains)) >= 1.0 else "REJECTED",
                "detail": f"look-ahead calibration vs the better of (per-layer, global): mean {mean_short:+.2f} pt, worst {worst:+.2f} pt over {len(shortfalls)} runs; vs the worse end {float(np.mean(gains)):+.2f} pt (need mean >= −0.3 and >= +1.0)",
            }
        else:
            hyp["G4"] = {"status": "INCONCLUSIVE", "detail": f"only {len(shortfalls)} taylor_auto runs with both fixed ends"}
    else:
        hyp["G4"] = verdict(None, "no taylor_auto runs")
    # G8: the look-ahead choice is as good as the best FIXED normaliser, which is only known in hindsight
    fixed = {"taylor", "taylor_global", "taylor_sum", "taylor_mean", "taylor_max", "taylor_std", "taylor_lamp"}
    if auto_rows:
        short8, winners = [], defaultdict(int)
        for r in auto_rows:
            key = (r["_stage"], r.get("dataset"), r.get("arch"), r.get("target_sparsity"), r.get("seed"))
            cands = {x["_label"]: x["_acc"] for x in rows if x["_label"] in fixed and not math.isnan(x["_acc"]) and
                     (x["_stage"], x.get("dataset"), x.get("arch"), x.get("target_sparsity"), x.get("seed")) == key}
            if len(cands) >= 4:
                best_name = max(cands, key=cands.get)
                winners[best_name] += 1
                short8.append(r["_acc"] - cands[best_name])
        if len(short8) >= 6:
            hyp["G8"] = {
                "status": "SUPPORTED" if float(np.mean(short8)) >= -0.5 else "REJECTED",
                "detail": f"look-ahead calibration vs the best fixed normaliser in hindsight: mean {float(np.mean(short8)):+.2f} pt over {len(short8)} runs (need >= −0.5); "
                          "best fixed normaliser per run: " + ", ".join(f"{k} x{v}" for k, v in sorted(winners.items(), key=lambda kv: -kv[1])),
            }
        else:
            hyp["G8"] = {"status": "INCONCLUSIVE", "detail": f"only {len(short8)} taylor_auto runs with >= 4 fixed normalisers"}
    else:
        hyp["G8"] = verdict(None, "no taylor_auto runs")
    g_pair("G5", "taylor_global", "taylor", -0.3, "ViT at equal measured latency: global ranking is not worse than per-layer", ("latency",), min_pairs=3, at_least=True)
    g_pair("G6", proposed, "taylor_global", 0.3, "the band-reliance term adds to global Taylor on transfer", ("transfer",), min_pairs=18)
    # best alpha per group in the rank-mix family
    alpha_names = {"taylor_mix0": 0.0, "taylor_mix0.25": 0.25, "taylor_mix0.5": 0.5, "taylor_mix0.75": 0.75, "taylor_mix1": 1.0}
    best_alpha: Dict[str, float] = {}
    for key, items in groups.items():
        per_alpha: Dict[float, list[float]] = defaultdict(list)
        for r in items:
            if r["_label"] in alpha_names and not math.isnan(r["_acc"]):
                per_alpha[alpha_names[r["_label"]]].append(r["_acc"])
        if len(per_alpha) >= 3:
            best_alpha["/".join(key)] = max(per_alpha, key=lambda a: float(np.mean(per_alpha[a])))
    if best_alpha:
        transfer_best = [v for k, v in best_alpha.items() if k.startswith("transfer/")]
        source_best = [v for k, v in best_alpha.items() if k.startswith(("main/", "ablations/")) and "resnet50" in k]
        text = "; ".join(f"{k}: {v:g}" for k, v in sorted(best_alpha.items()))
        ok = bool(transfer_best) and bool(source_best) and float(np.mean([v >= 0.75 for v in transfer_best])) >= 0.75 and max(source_best) <= 0.5
        hyp["G7"] = {"status": "SUPPORTED" if ok else ("INCONCLUSIVE" if not (transfer_best and source_best) else "REJECTED"),
                     "detail": "best alpha of the rank-mix family (need >= 0.75 on >= 75% of transfer groups and <= 0.5 on ImageNet ResNet-50). " + text}
    else:
        hyp["G7"] = verdict(None, "no rank-mix alpha sweep")

    # H9: under a globally comparable criterion, capacity moves toward the early
    # (high-resolution) groups as the task's reliance on bands >= 0.25 grows.
    allocation_rows: list[tuple[str, str, str, float, float, int]] = []
    for stage_name in ("transfer", "controlled", "main", "vit"):
        per_task: Dict[tuple[str, str], list[tuple[float, float]]] = defaultdict(list)
        for r in rows:
            if r["_stage"] != stage_name or r["_label"] != "taylor_global" or not r.get("kept_fraction_json"):
                continue
            rel = plist(r.get("reliance_profile"))
            try:
                kept = list(json.loads(r["kept_fraction_json"]).values())
            except Exception:
                continue
            if len(rel) < 3 or len(kept) < 4:
                continue
            # depth centre of mass of the kept capacity: 0 = all in the first group, 1 = all in the last
            positions = np.linspace(0.0, 1.0, len(kept))
            weights = np.asarray(kept, dtype=np.float64)
            early_minus_late = -float((positions * weights).sum() / max(weights.sum(), 1e-12))  # higher = earlier
            high_reliance = float(sum(rel[len(rel) // 2:]))
            per_task[(r.get("dataset", ""), r.get("arch", ""))].append((high_reliance, early_minus_late))
        for (dataset, arch), values in sorted(per_task.items()):
            arr = np.asarray(values)
            allocation_rows.append((stage_name, dataset, arch, float(arr[:, 0].mean()), float(arr[:, 1].mean()), len(values)))
    if allocation_rows:
        by_arch: Dict[str, list[tuple[float, float]]] = defaultdict(list)
        for _stage, _dataset, arch, high, eml, _n in allocation_rows:
            by_arch[arch].append((high, eml))
        rhos = {arch: spearman([v[0] for v in vals], [v[1] for v in vals]) for arch, vals in by_arch.items() if len(vals) >= 4}
        text = "; ".join(
            f"{stage}/{dataset}/{arch}: reliance on upper bands {high:.2f}, kept-capacity depth {-eml:.3f} (n={n})"
            for stage, dataset, arch, high, eml, n in allocation_rows
        )
        if rhos:
            ok = all(v >= 0.5 for v in rhos.values() if not math.isnan(v))
            hyp["H9"] = {
                "status": "SUPPORTED" if ok else "REJECTED",
                "detail": "allocation follows reliance under global Taylor (more upper-band reliance -> shallower kept capacity): "
                "Spearman(reliance, -depth) per arch "
                + ", ".join(f"{a} {v:+.2f}" for a, v in rhos.items()) + f" (need >= +0.5 with >= 4 tasks). {text}",
            }
        else:
            hyp["H9"] = {"status": "INCONCLUSIVE", "detail": "fewer than 4 tasks per architecture with taylor_global. " + text}
    else:
        hyp["H9"] = verdict(None, "no taylor_global runs with kept fractions")

    for tag in sorted(hyp):
        lines.append(f"- **{tag}** — {hyp[tag]['status']}: {hyp[tag]['detail']}")
    lines.append("")
    verdicts["hypotheses"] = hyp

    # ------------------------------------------------------------------ 3b. controlled mechanism check
    controlled = [r for r in rows if r["_stage"] == "controlled" and r.get("method") not in DENSE]
    if controlled:
        lines += ["## 3b. Controlled frequency tasks (mechanism check, not transfer evidence)", "",
                  "| task | comparison | mean diff (pt) | pairs | wins | p |", "|---|---|---|---|---|---|"]
        controlled_summary: Dict[str, Any] = {}
        tasks = sorted({r.get("dataset", "") for r in controlled})
        comparisons = [("taylor_global", "taylor"), ("taylor_global", "magnitude"), (proposed, "taylor_global"),
                       ("srp_lambda1", "taylor_global"), ("srp_od", "taylor_global"), ("srp_od_only", "taylor_global"),
                       ("srp_pass", "taylor_global"), ("srp_low", "taylor_global"), ("rfc", "taylor_global"),
                       ("lfs", "taylor_global"), ("taylor_global_rpr", "taylor_global")]
        for task in tasks:
            def pick(name: str) -> Dict[tuple, float]:
                return {
                    (r.get("arch"), r.get("target_sparsity"), r.get("seed")): r["_acc"]
                    for r in controlled if r.get("dataset") == task and r["_label"] == name and not math.isnan(r["_acc"])
                }
            for a, b in comparisons:
                res = paired(pick(a), pick(b))
                if res.get("n", 0) == 0:
                    continue
                p_value = res.get("p", float("nan"))
                lines.append(
                    f"| {task} | {a} − {b} | {res['mean_diff']:+.2f} | {res['n']} | {res['wins']}/{res['n']} | "
                    f"{'' if math.isnan(p_value) else f'{p_value:.3g}'} |"
                )
                controlled_summary[f"{task}:{a}-{b}"] = res
        lines.append("")
        verdicts["controlled"] = controlled_summary

    # ------------------------------------------------------------------ 3c. specialisation per corruption family
    fam_cols = ["imc_family_noise", "imc_family_blur", "imc_family_weather", "imc_family_digital", "imc_fog", "imc_contrast", "imc_impulse_noise"]
    spec_rows = [r for r in rows if r["_stage"] in {"specialize", "main", "ablations"} and r.get("arch") == "resnet50"
                 and abs(f(r.get("target_sparsity")) - 0.5) < 1e-6 and not math.isnan(f(r.get("imc_family_noise")))]
    if any(r["_stage"] == "specialize" for r in spec_rows):
        per_variant: Dict[str, list[Dict[str, str]]] = defaultdict(list)
        for r in spec_rows:
            per_variant[r["_label"]].append(r)
        # run-to-run spread of a repeated baseline, used as the yardstick for "outstanding"
        spread = {}
        ref_runs = per_variant.get("taylor", [])
        for c in fam_cols:
            vals = [f(r.get(c)) for r in ref_runs]
            spread[c] = float(np.std(vals, ddof=1)) if len(vals) >= 3 else float("nan")
        base_name = "taylor_mix0" if "taylor_mix0" in per_variant else "taylor"
        base = {c: float(np.mean([f(r.get(c)) for r in per_variant[base_name]])) for c in fam_cols}
        base_clean = float(np.mean([r["_acc"] for r in per_variant[base_name]]))
        lines += ["## 3c. Specialisation per ImageNet-C family (ResNet-50, 50% MAC)", "",
                  f"Differences are relative to `{base_name}` (clean {base_clean:.2f}). A family counts as *outstanding* when the gain is "
                  ">= 3 points and >= 3 times the run-to-run spread of the repeated Taylor baseline.", "",
                  "| variant | n | clean | noise | blur | weather | digital | fog | contrast | impulse | outstanding |", "|---|---|---|---|---|---|---|---|---|---|---|"]
        spec_summary: Dict[str, Any] = {}
        for name in sorted(per_variant, key=lambda n: (not n.startswith("dense"), n)):
            group_rows = per_variant[name]
            clean = float(np.mean([r["_acc"] for r in group_rows]))
            deltas = {c: float(np.mean([f(r.get(c)) for r in group_rows])) - base[c] for c in fam_cols}
            flags = [c.replace("imc_family_", "").replace("imc_", "") for c in fam_cols
                     if deltas[c] >= 3.0 and (math.isnan(spread[c]) or deltas[c] >= 3.0 * spread[c])]
            spec_summary[name] = {"clean_delta": clean - base_clean, **{c: deltas[c] for c in fam_cols}, "outstanding": flags}
            lines.append(f"| {name} | {len(group_rows)} | {clean - base_clean:+.2f} | " + " | ".join(f"{deltas[c]:+.2f}" for c in fam_cols) + f" | {', '.join(flags) or '–'} |")
        lines.append("")
        verdicts["specialisation"] = spec_summary

    # ------------------------------------------------------------------ 4. paper gate
    transfer_groups = [k for k in ranking_summary if k.startswith("transfer/")]
    all_transfer_groups = sorted({"/".join(k) for k in groups if k[0] == "transfer"})
    worse = [k for k in ranking_summary if ranking_summary[k]["state"] == "worse"]

    def supported(tag: str) -> bool:
        return hyp.get(tag, {}).get("status") == "SUPPORTED"

    # v6 gate (docs/HYPOTHESES_V6.md). The paper would claim: (i) the best cross-layer
    # calibration flips between the source task and small-data transfer, (ii) the amount
    # of recovery data is what drives the flip, (iii) a look-ahead choice recovers the
    # better regime everywhere.
    conditions = {
        "dense gate passed": bool(dense_ok),
        ">= 3 seeds per configuration": max_seeds >= 3,
        ">= 6 transfer (dataset, arch) groups evaluated": len(all_transfer_groups) >= 6,
        "equal budgets in every transfer group": not any(v.startswith("transfer/") for v in budget_violations),
        "G1 supported (global ranking wins on transfer)": supported("G1"),
        "G2 supported (per-layer wins on the source task, >= 3 seeds)": supported("G2"),
        "G3b supported (recovery-data regime drives the flip)": supported("G3b"),
        "G4 supported (look-ahead calibration matches the better regime)": supported("G4"),
    }
    ready = all(conditions.values())
    lines += ["## 4. Paper gate", ""]
    for name, ok in conditions.items():
        lines.append(f"- [{'x' if ok else ' '}] {name}")
    lines += ["", f"**Paper readiness: {'READY' if ready else 'NOT READY'}**", ""]
    verdicts["paper_gate"] = {"ready": bool(ready), "conditions": conditions}

    (out_dir / "analysis_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (out_dir / "analysis_verdicts.json").write_text(json.dumps(verdicts, indent=2, default=float), encoding="utf-8")
    print(f"wrote {out_dir / 'analysis_report.md'}")
    print(f"Paper readiness: {'READY' if ready else 'NOT READY'}")


if __name__ == "__main__":
    main()
