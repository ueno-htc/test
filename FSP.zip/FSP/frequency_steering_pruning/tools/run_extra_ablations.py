#!/usr/bin/env python3
from __future__ import annotations

import argparse
import itertools
import subprocess
import sys
from pathlib import Path


ABLATIONS = {
    "direction": [
        {"pruning.steering": "high"},
        {"pruning.steering": "low", "pruning.low_steering_formula": "swap"},
        {"pruning.steering": "low", "pruning.low_steering_formula": "inverse_ratio"},
    ],
    "transition": [
        {"pruning.transition_width": 0.0},
        {"pruning.transition_width": 0.02},
        {"pruning.transition_width": 0.05},
    ],
    "hp_dc": [
        {"pruning.hp_dc_mode": "image_mean"},
        {"pruning.hp_dc_mode": "dataset_mean"},
        {"pruning.hp_dc_mode": "zero"},
    ],
    "normalization": [
        {"pruning.layer_normalization": "none"},
        {"pruning.layer_normalization": "zscore"},
        {"pruning.layer_normalization": "rank"},
    ],
    "recovery": [
        {"pruning.sparsity_schedule": [0.7], "train.recovery_epochs": 0},
        {"pruning.sparsity_schedule": [0.3, 0.5, 0.7], "train.recovery_epochs": 1},
        {"pruning.sparsity_schedule": [0.3, 0.5, 0.7], "train.recovery_epochs": 3},
    ],
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run additional Frequency-Steering ablations")
    parser.add_argument("--config", required=True)
    parser.add_argument("--axis", choices=sorted(ABLATIONS), required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()
    root = Path(args.output_root) / args.axis
    root.mkdir(parents=True, exist_ok=True)
    for index, setting in enumerate(ABLATIONS[args.axis]):
        run_dir = root / f"setting_{index:02d}"
        command = [
            sys.executable,
            str(Path(__file__).resolve().parents[1] / "train.py"),
            "--config",
            args.config,
            "--run-dir",
            str(run_dir),
            "--set",
            "pruning.method=frequency_steering",
        ]
        for key, value in setting.items():
            command.extend(["--set", f"{key}={value}"])
        for override in args.overrides:
            command.extend(["--set", override])
        print(" ".join(command), flush=True)
        subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
