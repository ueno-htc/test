#!/usr/bin/env python3
"""Controlled test of task-specialised pruning with known band reliance.

A ResNet-18 is "pre-trained" on a joint task that needs both a low-frequency
and a high-frequency cue (data.dataset=bandtask, task=joint).  It is then
adapted to two downstream tasks whose label depends on ONE of the cues
(task=low / task=high), pruned to the same MAC budget with every criterion,
recovered and evaluated.  Because the band that carries the label is known by
construction, the experiment answers in minutes (CPU) what the ImageNet-scale
pipeline needs days for:

  * does a criterion keep the pathway the task relies on?
  * does a fixed low-frequency prior (srp_low, lfs) fail on the high task?
  * is the reliance term (srp vs srp_lambda0) doing anything?
  * does reliance-preserving recovery (*_rpr) help?

It is a mechanism check, not evidence about real datasets.

    python tools/controlled_experiment.py --output-root outputs/controlled
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from frequency_pruning.orchestration import parse_ints, resolve_method_spec, split_csv  # noqa: E402

DEFAULT_METHODS = "magnitude,taylor,taylor_global,lfs,srp,srp_lambda1,srp_od,srp_od_only,srp_pass,srp_low,rfc,taylor_global_rpr"
KEEP_CHECKPOINTS = False


def run(config: str, run_dir: Path, overrides: list[str], env: dict, log: Path) -> bool:
    if (run_dir / "summary.json").exists():
        return True
    command = [sys.executable, str(ROOT / "train.py"), "--config", config, "--run-dir", str(run_dir)]
    for item in overrides:
        command += ["--set", item]
    start = time.time()
    with log.open("a", encoding="utf-8") as handle:
        handle.write(f"\n===== {run_dir} =====\n")
        handle.flush()
        code = subprocess.call(command, cwd=str(ROOT), env=env, stdout=handle, stderr=subprocess.STDOUT)
    print(f"[controlled] {run_dir.relative_to(run_dir.parents[3]) if len(run_dir.parents) > 3 else run_dir} "
          f"{'ok' if code == 0 else 'FAILED'} ({time.time() - start:.0f}s)", flush=True)
    # Checkpoints of a ResNet-18 run add up to ~0.4 GB; keep only what later runs
    # need (the dense checkpoint every method starts from) and the JSON records.
    if not KEEP_CHECKPOINTS:
        for file in run_dir.glob("*.pt"):
            if file.name != "checkpoint_dense_calibrated.pt":
                file.unlink(missing_ok=True)
    return code == 0


def main() -> None:
    parser = argparse.ArgumentParser(description="Controlled frequency-task pruning experiment")
    parser.add_argument("--config", default="configs/controlled.yaml")
    parser.add_argument("--output-root", default="outputs/controlled")
    parser.add_argument("--tasks", default="low,high")
    parser.add_argument("--methods", default=DEFAULT_METHODS)
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--target", type=float, default=0.8, help="MAC reduction target")
    parser.add_argument("--source-epochs", type=int, default=12)
    parser.add_argument("--adapt-epochs", type=int, default=12)
    parser.add_argument("--source-train-size", type=int, default=4096)
    parser.add_argument("--task-train-size", type=int, default=512)
    # Calibrated on CPU (2026-11-15): source amplitude 0.08 gives a 96.7% joint model;
    # task amplitude 0.05 gives dense accuracies of ~75% (high) and ~95% (low), so that
    # an 80% MAC reduction separates criteria without saturating or hitting width floors.
    parser.add_argument("--source-amp", type=float, default=0.08)
    parser.add_argument("--task-amp", type=float, default=0.05)
    parser.add_argument("--noise", type=float, default=0.25)
    parser.add_argument("--recovery-epochs", type=int, default=1)
    parser.add_argument("--final-epochs", type=int, default=3)
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    parser.add_argument("--keep-checkpoints", action="store_true")
    args = parser.parse_args()
    global KEEP_CHECKPOINTS
    KEEP_CHECKPOINTS = bool(args.keep_checkpoints)

    root = Path(args.output_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    log = root / "controlled.log"
    env = dict(os.environ)
    env.setdefault("FSP_ALLOW_CPU", "1")
    env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
    config = str(ROOT / args.config)

    # 1. generic pre-training on the joint task (one source model)
    source_dir = root / "source" / "joint" / "seed0" / "dense"
    schedule = [f"train.recovery_epochs={args.recovery_epochs}", f"train.final_epochs={args.final_epochs}"]
    source_data = [f"data.bandtask_low_amp={args.source_amp}", f"data.bandtask_high_amp={args.source_amp}",
                   f"data.bandtask_noise={args.noise}"]
    task_data = [f"data.bandtask_low_amp={args.task_amp}", f"data.bandtask_high_amp={args.task_amp}",
                 f"data.bandtask_noise={args.noise}"]
    ok = run(config, source_dir, [
        "pruning.method=dense", "data.bandtask_task=joint", "data.dataset_label=bandtask_joint",
        f"data.bandtask_train_size={args.source_train_size}", f"train.epochs_before_pruning={args.source_epochs}",
        "experiment.seed=0", *source_data, *schedule, *args.overrides,
    ], env, log)
    source_ckpt = source_dir / "checkpoint_dense_calibrated.pt"
    if not ok or not source_ckpt.exists():
        raise SystemExit(f"source pre-training failed; see {log}")

    failures = 0
    for task in split_csv(args.tasks):
        for seed in parse_ints(args.seeds):
            common = [
                f"data.bandtask_task={task}", f"data.dataset_label=bandtask_{task}",
                f"data.bandtask_train_size={args.task_train_size}", f"experiment.seed={seed}",
                *task_data, *schedule, *args.overrides,
            ]
            # 2. task adaptation of the dense model (shared by every method)
            dense_dir = root / "transfer" / f"bandtask_{task}" / "resnet18" / "dense" / f"seed{seed}"
            ok = run(config, dense_dir, [
                *common, "pruning.method=dense", f"experiment.checkpoint={source_ckpt}",
                f"train.epochs_before_pruning={args.adapt_epochs}",
            ], env, log)
            dense_ckpt = dense_dir / "checkpoint_dense_calibrated.pt"
            if not ok or not dense_ckpt.exists():
                failures += 1
                continue
            # 3. every criterion from the same checkpoint at the same MAC budget
            for spec in split_csv(args.methods):
                run_name, _method, method_overrides = resolve_method_spec(spec)
                run_dir = root / "transfer" / f"bandtask_{task}" / "resnet18" / f"sp{int(round(args.target * 100)):02d}" / f"seed{seed}" / run_name
                ok = run(config, run_dir, [
                    *common, *method_overrides, f"experiment.checkpoint={dense_ckpt}",
                    "train.epochs_before_pruning=0", f"pruning.target_sparsity={args.target}",
                    "pruning.sparsity_schedule=[]",
                ], env, log)
                failures += 0 if ok else 1

    subprocess.call([sys.executable, str(ROOT / "tools" / "collect_results.py"), "--root", str(root / "transfer"),
                     "--output", str(root / "results.csv")], cwd=str(ROOT))
    subprocess.call([sys.executable, str(ROOT / "tools" / "analyze_results.py"), "--results", str(root / "results.csv"),
                     "--output-dir", str(root / "analysis")], cwd=str(ROOT))
    (root / "DONE").write_text(json.dumps({"failures": failures, "time": time.time()}), encoding="utf-8")
    print(f"[controlled] finished with {failures} failed runs; report: {root / 'analysis' / 'analysis_report.md'}")


if __name__ == "__main__":
    main()
