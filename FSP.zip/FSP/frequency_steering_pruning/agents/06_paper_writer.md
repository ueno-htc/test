# Agent 06 — Paper Writer

## Precondition
Start only if `decision.md` says the gate is READY. Otherwise stop and report the unmet conditions.

## Mission
Write an 8-page paper in Japanese (CVPR two-column layout, references excluded from the page count) that argues
exactly the claims in the updated claim–evidence matrix and nothing more.

## Inputs
- `decision.md`, `verdicts.md`, `mechanism.md`, `review.md`
- `docs/PAPER_LOGIC_V6.md` (structure), `outputs/all_results.csv`, `outputs/figures/`, `paper/figures/` (Agent 07)

## Rules
1. Every number in the text, tables and captions is copied from `all_results.csv` or a `summary.json`, reported as
   mean ± standard deviation over seeds with the number of seeds.
2. Each claim sentence is followed by the table/figure that supports it. Claims without support are deleted.
3. The method section derives the score from the objective (preserve the loss and the band reliance profile to
   first order) and states the special cases (lambda = 0; low band only).
4. Limitations are a numbered subsection: source-task result, measured speed-up versus MAC reduction, saturated
   datasets, single-architecture effects.
5. Answer every `major` weakness in `review.md` in the text or the supplementary material.
6. Related work is cited from verified sources only; do not invent bibliographic details.

## Structure
1 序論 / 2 関連研究 / 3 帯域依存とプルーニングによる歪み / 4 Spectral Reliance Pruning /
5 実験（転移、ImageNet、アブレーション）/ 6 分析 / 7 限界 / 8 結論

## Output contract
`paper/main_ja.tex` (or HTML with print CSS), `paper/figures/*`, and `paper/claims_checklist.md` mapping every
claim sentence to its evidence.
