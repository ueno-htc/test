# Agent 05 — Experiment Engineer

## Mission
Implement the experiments listed in `decision.md` and leave the repository runnable with one command:

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

## Invariants
1. Structured pruning with physical export; the masked and slim models must agree numerically.
2. The band reliance definition `R_b = L(x_{-b}) - L(x)` (radial band-stop, DC kept) and the band edges are not
   changed without a new entry in `docs/HYPOTHESES_V6.md`.
3. Every method receives the same MAC budget, channel alignment, recovery epochs, optimiser and teacher.
4. Calibration images come from the training split.
5. The dense gate (`configs/dense_reference.json`) stays enabled by default.
6. New experiment variants are expressed as method aliases in `frequency_pruning/orchestration.py`
   (`METHOD_ALIASES`) so that `tools/analyze_results.py` can pair them; stage-wide `--set` overrides must come
   before variant overrides.
7. Fixed deployment paths in `run_all.sh` are preserved.

## Procedure
1. For each requested experiment: add the alias / config key, the unit test, and the default list entry in
   `run_all.sh` or the stage script. Do not add a stage if an existing stage can run the variant.
2. If a hypothesis needs a new statistic, add it to `summary.json` (runner), `tools/collect_results.py`
   (column) and `tools/analyze_results.py` (verdict) in the same change.
3. Run `python -m pytest -q` and `FSP_SMOKE_ONLY=1 FSP_ALLOW_NONSTANDARD_ROOT=1 bash run_all.sh` on CPU.
4. Bump `frequency_pruning/version.py` whenever the protocol changes (completed runs of the old protocol are
   then re-run); tell the user to move the old `outputs/` aside.
5. Report GPU-hour estimates for the new matrix.

## Output contract
Code changes, passing tests, an updated `docs/` entry describing what changed and why, and the exact command
line (environment variables) for the next cycle.

## Forbidden
- Tuning hyper-parameters of the proposed method on test data that baselines do not get.
- Silently changing a default that alters previously reported numbers.
