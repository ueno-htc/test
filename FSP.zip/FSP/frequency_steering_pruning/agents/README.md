# 研究ループ用エージェント構成

1 回の実験サイクル（`bash run_all.sh` → 結果 → 判断 → 改訂）を、役割の異なる 8 つのエージェントに分ける。
論文ゲートが 2 サイクル続けて NOT READY のとき、または中心仮説が棄却されたときは、08 Research Strategist が継続・転換・中止を判断する。
各エージェントは下のプロンプトファイルをそのままシステムプロンプトとして与え、入力ファイルを添付して起動する。
成果物はすべてファイルで受け渡し、口頭の合意に依存しない。

```
run_all.sh ──► outputs/all_results.csv ──► tools/analyze_results.py ──► outputs/analysis/analysis_report.md
                                                                   │
        ┌──────────────────────────────────────────────────────────┘
        ▼
 01 Results Auditor ──► audit.md（Dense ゲート、プロトコル違反、無効 run）
        ▼
 02 Hypothesis Tester ─► verdicts.md（G1–G7 の判定と効果量）
        ▼
 03 Theorist ──────────► mechanism.md（なぜそうなったか、次の反証可能な予測）
        ▼
 04 Skeptical Reviewer ► review.md（CVPR 査読者としての反論、追加で必要な実験）
        ▼
 00 Orchestrator ──────► decision.md（論文ゲート判定、次サイクルの実験リスト）
        ├─ NOT READY ─► 05 Experiment Engineer（実装・テスト・run_all 更新）
        └─ READY ─────► 07 Figure Maker ─► 06 Paper Writer（日本語 8 ページ）
```

| # | ファイル | 役割 | 入力 | 出力 | 禁止事項 |
|---|---|---|---|---|---|
| 00 | `00_orchestrator.md` | 全体の進行と判断 | 01–04 の出力 | `decision.md` | 判定規則の事後変更 |
| 01 | `01_results_auditor.md` | 結果の妥当性監査 | `outputs/`、ログ | `audit.md` | 解釈・提案 |
| 02 | `02_hypothesis_tester.md` | 仮説の統計的判定 | `all_results.csv`、`docs/HYPOTHESES_V6.md` | `verdicts.md` | 閾値の変更、都合の良い部分集合の選択 |
| 03 | `03_theorist.md` | 機構の説明と理論の整合性 | 01, 02 の出力、`docs/PAPER_LOGIC_V6.md` | `mechanism.md` | データにない主張 |
| 04 | `04_skeptical_reviewer.md` | 査読者役 | 01–03 の出力 | `review.md` | 建設的でない否定 |
| 05 | `05_experiment_engineer.md` | 実装と実行 | `decision.md` | コード、テスト、`run_all.sh` | 科学的定義の無断変更 |
| 06 | `06_paper_writer.md` | 論文執筆 | ゲート通過後の全成果物 | `paper/main_ja.pdf` 相当 | ゲート未通過での執筆、未測定の数値 |
| 07 | `07_figure_maker.md` | 図表 | `all_results.csv`、summary | `paper/figures/` | 軸・集計の恣意的な変更 |
| 08 | `08_research_strategist.md` | 継続・転換・中止の判断 | 全サイクルの `decision.md`、評価レポート | `strategy.md` | 打ち切り基準のない「継続」、棄却済み仮説の言い換え |

## 共通ルール

- 実行の入口は `bash run_all.sh` のみ。分析は `python tools/analyze_results.py` のみ。
- 判定規則（`docs/HYPOTHESES_V6.md`）と Dense 基準（`configs/dense_reference.json`）は結果を見た後に変更しない。変更が必要なら次サイクルの事前登録として理由とともに記録する。
- 単一 seed の差 0.4 pt 未満は差として扱わない。
- 否定的な結果も同じ重さで報告する。v4 → v5 の改訂は否定的結果（`docs/V4_1_EVALUATION.md`）から生まれた。
