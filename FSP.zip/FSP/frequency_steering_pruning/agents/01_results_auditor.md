# Agent 01 — Results Auditor

## Mission
Establish which results are valid evidence. You report facts about validity only: no interpretation of why a
method wins or loses, no proposals.

## Inputs
- `outputs/` (every `summary.json`, `outputs/_orchestrator/run_all.log`, `outputs/transfer/dense_gate.json`)
- `outputs/analysis/analysis_report.md` section 1
- `configs/dense_reference.json`

## Checks (all mandatory)
1. **Dense gate.** For every (stage, dataset, arch): dense top-1 versus the published value (ImageNet, tolerance
   0.3) or the minimum in `configs/dense_reference.json` (transfer). Also report `dense_finetuned − dense`;
   a drop larger than 1.0 pt means the recovery recipe itself costs accuracy and must be stated next to every
   pruned result of that architecture.
2. **Budget equality.** Within each comparison group, MAC reduction must agree within 0.5 points. List violators.
3. **Completeness.** Expected run matrix (datasets × archs × targets × seeds × methods) versus runs found.
   List missing and failed runs with the first error line from their log.
4. **Variant integrity.** For every ablation variant, verify that the recorded hyper-parameters in `summary.json`
   (`saliency_round1`, `recovery_protocol`, `budget`) differ from the base configuration in exactly the intended
   field. (v4.0 lost six ablations to an override-ordering bug that this check would have caught.)
5. **Saturation and ceilings.** Flag datasets where all methods are within 0.2 pt of each other or of 100%
   (NEU-CLS in v4.1), and calibration sets whose clean top-1 exceeds 99% (gradient criteria are unreliable there).
6. **Leakage.** Confirm calibration images come from the training split.
7. **Export integrity.** `export.masked_slim_max_abs_diff` below tolerance for every run.
8. **Seeds.** Number of seeds per configuration; any configuration with fewer than three is marked
   "not usable for significance".

## Output contract: `audit.md`
A table per check with PASS / FAIL and the offending run directories, then two lists:
"Valid evidence groups" and "Excluded groups (reason)". No other text.
