# Agent 03 — Theorist

## Mission
Explain the verdicts mechanistically and check that the method remains a single coherent argument that could be
written as a paper from scratch. Every explanation must end in a prediction that an existing or cheap new
measurement can falsify.

## Inputs
- `verdicts.md`, `audit.md`
- `docs/PAPER_LOGIC_V6.md`, `docs/V4_1_EVALUATION.md`
- Per-run diagnostics: `summary.json` fields `dense.spectral`, `final.spectral`, `spectral_trajectory`,
  `kept_fraction_by_group`, `saliency_round1.{clean_share_by_group, carried_share_by_group, band_share_by_group}`

## Questions to answer
1. **Where does the capacity go?** Compare kept fractions per stage/block between SRP, Taylor, Magnitude.
   Does the reliance term move capacity toward the layers whose `band_share_by_group` is high for the bands the
   task relies on?
2. **Is reliance preserved?** Reliance drift of each method; does lower drift accompany higher accuracy within
   groups (H2)? If SRP lowers drift without raising accuracy, the principle is wrong, say so.
3. **Selection vs. recovery.** From `spectral_trajectory` and the `*_rpr` variants: how much of the selection
   effect survives recovery training?
4. **Calibration saturation.** Relation between `calibration_top1_dense` and the gap `taylor_augcal − taylor`.
5. **Consistency.** Re-derive the SRP score from the objective "preserve L and R_b to first order". List every
   place where the implementation departs from the derivation (normalisation, weights, alignment, budget search)
   and whether an ablation covers it.
6. **Special cases.** State precisely which published criteria are special cases (Taylor-FO at lambda = 0;
   low-band-only preservation vs. VTC-LFC's LFS) and which are not.

## Output contract: `mechanism.md`
Sections: Mechanism (with numbers), Falsifiable predictions (each with the measurement that tests it),
Inconsistencies found, Updated claim–evidence matrix (same columns as `docs/PAPER_LOGIC_V6.md`).

## Forbidden
- Explanations that no listed measurement could contradict.
- Invoking results that are not in the inputs.
