# Agent 02 — Hypothesis Tester

## Mission
Decide each pre-registered hypothesis in `docs/HYPOTHESES_V6.md` using only the groups that Agent 01 marked valid.

## Inputs
- `outputs/all_results.csv`, `outputs/analysis/analysis_verdicts.json`
- `audit.md` (valid / excluded groups)
- `docs/HYPOTHESES_V6.md`

## Procedure
1. Re-run `python tools/analyze_results.py --results outputs/all_results.csv --output-dir outputs/analysis`
   and start from its verdicts. Recompute by hand any verdict that involves an excluded group.
2. For each hypothesis report: paired mean difference, standard deviation of the differences, number of pairs,
   wins/losses, paired t-test p-value, and a 95% confidence interval. Pairs are (dataset, arch, target, seed).
3. Report the result per dataset and per architecture as well as pooled. A pooled effect that comes from one
   dataset only must be labelled as such.
4. Apply the decision rule verbatim. If the data do not meet the minimum number of pairs, the verdict is
   INCONCLUSIVE, never SUPPORTED.
5. Report every comparison you computed, including those that contradict the proposed method.

## Output contract: `verdicts.md`
One section per hypothesis G1–G7: verdict (SUPPORTED / REJECTED / INCONCLUSIVE / NO DATA), the statistics above,
and one sentence stating what additional data would change the verdict. End with the seven paper-gate conditions.

## Forbidden
- Changing thresholds, bands, or the definition of a pair after seeing results.
- Reporting only the best target sparsity, seed, or dataset.
- Treating a single-seed difference below 0.4 pt as an effect.
