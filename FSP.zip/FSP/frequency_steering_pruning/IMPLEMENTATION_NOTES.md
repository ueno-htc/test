# Implementation notes: FSP v4 (Spectral-Steering)

## What changed relative to v3

v3 scored a structural unit with `|(g_HP - lambda g_LP) w|`, a heuristic that
(i) is essentially VTC-LFC's low-frequency sensitivity with a sign flip, (ii)
accumulated gradients over the whole calibration set before taking the absolute
value (near-zero mean gradients at convergence), and (iii) hard-coded the
steering direction. v4 replaces it with the formulation in
`frequency_pruning/pruning/spectral.py`:

* band sensitivity `S_b` = input-gradient spectral power per radial band
  (exact first-order Fourier sensitivity, no noise sampling);
* unit contribution `c_{g,b} = (dS_b/dgate_g)/S_b` by double back-propagation;
* task reliance `r_b` = loss increase under band-stop filtering;
* target weights `w = r_hat - s_hat` (zero-sum, L1-normalised), or
  `reliance`/`high`/`low`/`flat`/`manual`;
* keep-score `I_0(g)/mean(I_0) + lambda * sum_b w_b c_{g,b} / mean|.|` with the
  gate-level Taylor-FO term `I_0` averaged per mini-batch.

Alternative estimators (`noise`: the original finite-amplitude Fourier-basis
proposal; `filtered`: Taylor on band-pass inputs) are kept for ablations.

## Evaluation protocol fixes

* `dense` is evaluated without fine-tuning; `dense_finetuned` gets the pruned
  runs' epoch budget. `total_training_epochs` / `dense_finetune_epochs` in
  `runner.py` encode the rule.
* Calibration images for NEU-CLS / DTD / CUB / generic ImageFolder datasets are
  drawn from the train split (v3 used val, which equals test for NEU and CUB).
* Transfer runs adapt the dense model once per (dataset, arch, seed) and every
  method loads that checkpoint (`transfer.py`, two phases).
* Recovery protocol shared by all methods: dense-teacher distillation
  (`train.distill_dense`), BatchNorm recalibration after each round
  (`pruning.bn_recalibration_batches`), geometric sparsity schedule, cosine LR.
* Spectral profiles (sensitivity + reliance) are measured for the dense and
  final models; `tools/collect_results.py` derives `profile_mismatch_*`,
  `steering_gain`, `sens_shift_*` and ImageNet-C accuracy per frequency group.

## Structured units and exact export

Unchanged from v3: ResNet bottleneck hidden channels, EfficientNet MBConv
expanded channels, ViT attention heads + MLP hidden channels; the slim model is
numerically checked against the masked model before a run is marked complete.

## Fair comparison protocol

Random, Magnitude, SNIP, Taylor, HAP, LFS, Steering-Only, Frequency-Steering and
Spectral-Steering share the structured groups, global selection, calibration
subset, sparsity schedule, per-layer minimum widths, recovery optimiser,
distillation, BN recalibration, augmentation and the full evaluation suite.

## Interpretation caveats

The code is an executable research pipeline, not evidence. CVPR-level claims
require the real ImageNet / ImageNet-C and transfer experiments,
multiple seeds (`FSP_SEEDS`), confidence intervals, matched budgets and
hardware-controlled latency. The CPU smoke test validates code paths, export
equivalence and artifact generation only.
