# Implementation notes: FSP v6 (cross-layer calibration); v5 notes follow

## v6 in brief

The v5 run (377 runs) showed that every band-based term was within noise of globally ranked gate-level Taylor
(+0.28 pt, p = 0.10 on transfer; -0.26 pt on ImageNet), while the ranking convention itself moved accuracy by
+3.1 pt on transfer (12/12 pairs) and by -1.0 / -2.3 pt on ImageNet ResNet-50 (`docs/V5_EVALUATION.md`).
v6 therefore studies the calibration between layers:

* `pruning.layer_normalization=rankmix` with `pruning.rank_mix_alpha` interpolates between per-group percentile
  ranking (uniform allocation) and global ranking (`_finalize_scores` in `pruning/saliency.py`);
* `rankmix_auto` chooses alpha by a look-ahead: one-shot pruning to the final budget, a short recovery and the
  loss on a hold-out carved from the training split (`_select_rank_mix_alpha` in `runner.py`,
  `data.holdout_fraction`);
* `data.train_subset_size` restricts the recovery data (ImageNet low-data stage);
* `pruning.budget=latency` bisects on the measured latency of the exported network
  (`select_pruning_plan_for_latency_target` in `pruning/iterative.py`).

Hypotheses G1-G7 and the paper gate are in `docs/HYPOTHESES_V6.md` and are evaluated by
`tools/analyze_results.py`.

## Why v5

The v4.1 run (147 runs, MAC-matched) showed that Spectral-Steering, which steered the input-gradient
sensitivity profile toward the band-stop reliance profile, was worse than the best baseline in 13 of 16
comparison groups and never better (`docs/V4_1_EVALUATION.md`). Accuracy fell monotonically with the
steering strength, the "auto" target pointed to low frequency on every task, and more than half of the
pruning-time steering was undone by recovery training.

## What v5 does

One quantity, band reliance `R_b = L(x_{-b}) - L(x)`, is used at every level:

* task level: the reliance profile (band-stop loss increases);
* unit level: `|dR_b/dgate_g| = |dL(x_{-b})/dgate_g - dL(x)/dgate_g|`, the first-order distortion of the
  reliance on band b when unit g is removed (`_accumulate_reliance_derivative` in `pruning/spectral.py`);
* selection: `score_g = E|dL/dgate_g| + lambda * sum_b rho_b E|dR_b/dgate_g|`, ranked globally in loss
  units (`combine_reliance_scores`, `_spectral_reliance_scores`); lambda = 0 is global gate-level Taylor-FO;
* recovery: optional KL between the pruned network and the dense teacher on a random band-stop view of each
  batch (`train.reliance_distill_beta`, `engine.py`).

Controls shipped with it: band-pass share estimator (`srp_pass`), low-band-only weights (`srp_low`),
per-layer z-scoring (`srp_zscore`), global Taylor (`taylor_global`, `srp_lambda0`), augmented calibration
views (`taylor_augcal`), and recovery-only variants (`taylor_rpr`, `magnitude_rpr`).

## Protocol (shared by every method)

MAC budget with bisection over the ranking prefix and physical export; kept channel counts aligned to
multiples of 8; identical recovery epochs, optimiser and teacher; calibration from the training split;
transfer runs start from one task-adapted dense checkpoint per (dataset, arch, seed) that must pass the
dense gate in `configs/dense_reference.json`.

## Automated audit

`tools/analyze_results.py` reproduces the dense gate, rankings with noise bands, the verdicts of the
pre-registered hypotheses (`docs/HYPOTHESES_V5.md`) and the paper gate after every `run_all.sh`.

## Interpretation caveats

v5 is an untested hypothesis. The CPU smoke test and unit tests validate code paths, export equivalence and
artifact generation only.
