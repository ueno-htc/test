# H200×8 production execution

## Supported command

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

これが唯一のサポート対象である。preflight、分散self-test、チューニング、main比較、ViT、transfer、評価、可視化、physical export、集計、retry、resumeは全て内部で実行される。

## 今回のNCCL障害への対策

旧経路ではdense評価後、非source rankが1要素のNCCL `BROADCAST`へ入り、source rankが同じcollective sequenceへ到達しないままwatchdog timeoutとなった。v3では次の状態遷移を全rankで共有する。

```text
initialize -> train -> evaluate -> local saliency shard
-> failure/status consensus (Gloo control plane)
-> FP32 accumulator reduction (NCCL data plane)
-> deterministic plan selection -> compact plan broadcast (Gloo)
-> apply mask -> recovery -> checkpoint -> next round
```

production defaultでは、実験行列を1 GPU/1 experimentで最大8件同時実行するため、通常runでは不要なDDP collective自体を避ける。DDPを内部検証で使用する場合もrank-0-only saliencyは禁止し、全rank sharded reductionだけを許可する。

## Fixed paths

```text
/home/ueno/FSP/frequency_steering_pruning
/home/ueno/.conda/envs/vip/bin/python
/localdata/imagenet/
/localdata/imagenet_family/imagenet-c
/localdata/imagenet_family/imagenet-r/imagenet-r
/localdata/NEU-CLS
/localdata/dtd
/localdata/CUB_200_2011
```

## Runtime defaults

- 8 H200を独立実験並列へ割り当てる
- eligible forward/trainingはBF16、saliency／FFT／rankingはFP32
- TF32、cuDNN benchmark、channels-lastを適用可能なCNN経路で使用する
- HAPは`gate_empirical_fisher`、二階診断は`gate_hutchinson`
- `file_system` sharing、adaptive worker cap、lazy ImageNet-C loaderを使用する
- `summary.json`とversioned `COMPLETED`の両方で完了判定する
- current `TORCH_NCCL_*` diagnosticsとflight recorderを有効化する

## Optional overrides on the same command

```bash
FSP_PRECISION=fp32 bash run_all.sh
FSP_MAX_PARALLEL_JOBS=4 bash run_all.sh
FSP_MAX_WORKERS_PER_JOB=2 bash run_all.sh
FSP_HAP_MODE=gate_hutchinson FSP_HAP_MICROBATCH_SIZE=1 bash run_all.sh
SKIP_TUNING=1 bash run_all.sh
SKIP_VIT=1 bash run_all.sh
SKIP_TRANSFER=1 bash run_all.sh
```

本番実行のstatusは`outputs/_orchestrator/RUN_ALL_COMPLETED.json`または`RUN_ALL_FAILED.json`で確認できる。
