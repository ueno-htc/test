# Frequency-Steering Pruning H200 NCCL Recovery and Production Refactor Prompt

## Mission

Act as a coordinated CVPR research-engineering team. Starting from the current Frequency-Steering Pruning repository, diagnose the newly supplied production log, eliminate the observed NCCL failure and all adjacent correctness/reliability defects, preserve the scientific FSP concept, and leave exactly one supported user command:

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

Do not stop at recommendations. Inspect, plan, modify, test, package, and report.

## Immutable scientific invariants

1. The method remains dependency-aware **structured pruning**, never unstructured zero masking presented as acceleration.
2. Images are decomposed by radial Fourier filtering into LP and HP views.
3. High-frequency steering retains the exact parameter-level score
   `abs((dL_HP/dw - lambda * dL_LP/dw) * w)`.
4. Low-frequency steering retains the configured target/opposite reversal.
5. Parameter scores are aggregated only through the existing structural pruning units.
6. Iterative pruning, target sparsity semantics, recovery training, class mappings, and final evaluation definitions are not silently changed.
7. Saliency accumulation, FFT-sensitive operations, ranking, and structural decisions remain FP32.
8. Any HAP approximation is named accurately in configuration and results.

## Immutable deployment paths

Preserve these paths exactly in `run_all.sh`:

- `IMAGENET_ROOT=/localdata/imagenet/`
- `IMAGENET_C_ROOT=/localdata/imagenet_family/imagenet-c`
- `IMAGENET_R_ROOT=/localdata/imagenet_family/imagenet-r/imagenet-r`
- `NEU_ROOT=/localdata/NEU-CLS`
- `DTD_ROOT=/localdata/dtd`
- `CUB_ROOT=/localdata/CUB_200_2011`
- project root `/home/ueno/FSP/frequency_steering_pruning`
- preferred interpreter `/home/ueno/.conda/envs/vip/bin/python`
- one-node production target `NPROC=8`

## Newly observed incident

The supplied run reaches 8-rank training and dense evaluation, then every non-source rank waits on the same one-element NCCL `BROADCAST` sequence for 600 seconds. The watchdog aborts the process group and torchrun reports `ChildFailedError` / SIGABRT. Treat this as a collective-order violation caused by asymmetric rank-0 saliency or failure propagation, not as a generic recommendation to increase the timeout.

The fix must ensure that no rank enters an NCCL collective while another rank performs unbounded CPU/GPU scoring work outside the same collective sequence.

## Coordinated agent roles

### Agent 1 — Incident and Timeline Analyst

- Parse the entire log, not only the final traceback.
- Build a timeline from the previous successful method through the failed method.
- Identify the exact phase boundary and collective sequence.
- Separate observed facts from inferred defects.
- Audit warnings: torchvision ABI, deprecated NCCL variables, physical-export discrepancy, file-descriptor pressure, and stale/incomplete run directories.

### Agent 2 — Distributed State-Machine Engineer

- Define explicit phases shared by every rank: initialize, train, evaluate, saliency, select plan, apply plan, recover, checkpoint, final evaluate, cleanup.
- Replace asymmetric long-running rank-0 saliency with exact **all-rank sharded saliency** by default:
  1. each rank processes a deterministic shard of the same global calibration subset;
  2. saliency forward uses the unwrapped module and `torch.autograd.grad`, not DDP backward synchronization;
  3. each rank accumulates sample-weighted FP32 gradient sums;
  4. accumulators and sample counts are coalesced-all-reduced only after local work;
  5. all ranks obtain identical scores;
  6. only the small deterministic pruning plan is broadcast if needed.
- Add assertions preventing DDP wrappers from entering local saliency internals.
- Add bounded, fail-fast distributed error propagation without leaving an outstanding collective.
- Add a two-process Gloo regression test reproducing the former mismatch and proving completion/equivalence.

### Agent 3 — Scientific Saliency and HAP Engineer

- Verify FSP and SNIP mathematical equivalence before/after refactoring.
- Use global sample counts, not batch averages, when reducing unequal last batches.
- Make all-reduce behavior explicit via function arguments; never infer it only from `dist.is_initialized()`.
- Keep empirical-Fisher gate HAP as the scalable production default and gate-Hutchinson as an explicit diagnostic mode with microbatch and parameter/memory guards.
- Record effective estimator, world size, calibration samples, score dtype, and reduction mode.

### Agent 4 — Runtime, I/O, and Environment Engineer

- Retain the prior `Too many open files` protections: adaptive nofile limit, bounded per-node workers, bounded prefetch, nonpersistent one-shot loaders, explicit shutdown, and `file_system` sharing.
- Prevent duplicate dataset indexing and duplicate val/test workers.
- Lazily construct ImageNet-C and other one-use evaluation loaders.
- Detect the torch/torchvision compiled-extension ABI mismatch before long experiments. Either fail with an exact repair command when a required API is unavailable or clearly record a safe PIL-only warning; never repeatedly download or reinstall packages inside every run.
- Use only current `TORCH_NCCL_*` variables and enable flight-recorder diagnostics.

### Agent 5 — Single-Entrypoint Orchestration Engineer

- `run_all.sh` must perform environment setup, preflight, critical tests, tuning, main experiments, ViT ablations, transfer experiments, final evaluation/visualization/export, aggregation, resume, retries, and final status.
- No separate command may be required.
- Use stage and run completion contracts (`summary.json` plus validated marker), not directory existence alone.
- Skip valid completed work and archive/retry incomplete work.
- Trap signals, terminate child process groups, release locks, and emit diagnostics.
- Use all eight H200s efficiently without changing a run's global batch/optimizer semantics.
- Do not launch a new run until the prior torchrun process group has exited cleanly.

### Agent 6 — Adversarial QA and Release Engineer

Run and record:

1. `python -m compileall`.
2. Full unit tests.
3. Shell syntax checks for every shell script.
4. CPU synthetic end-to-end execution through `run_all.sh`.
5. Two-process Gloo distributed FSP/SNIP/HAP equivalence and deadlock-regression tests.
6. Failure injection on one rank with bounded termination.
7. File-descriptor worker-budget tests.
8. Resume/idempotency tests.
9. Physical export equivalence tests on all supported architecture families.
10. Clean-archive extraction and rerun.

Hardware-dependent H200 throughput and ImageNet accuracy must not be fabricated.

## Required architecture

- A coherent saliency executor module, not global monkey patches.
- Explicit reduction modes: `local`, `all_rank_sharded`, and optional `rank0_control_plane` only when implemented without a long-lived NCCL collective.
- Stable ordered score serialization and deterministic pruning plans.
- A distributed phase/error protocol with descriptive phase names in diagnostics.
- Central runtime/preflight configuration.
- `run_all.sh` as the sole documented entrypoint.

## Acceptance criteria

- The exact observed 600-second one-element NCCL broadcast hang cannot occur in the default path.
- Every distributed saliency method completes with the same collective sequence on every rank.
- All-rank sharded FSP equals a single-process full-calibration reference within FP32 reduction tolerance.
- A rank-local injected exception reaches all ranks and exits before the configured test timeout.
- No exact full-model second-order graph is constructed by default.
- Dataset paths and FSP formula are unchanged.
- `bash run_all.sh` alone reaches final aggregation or exits early with a precise actionable error.
- The release contains the complete source, prompt, agent plan/execution record, incident report, tests, patch, and checksums.

## Execution order

1. Incident timeline and source audit.
2. Scientific invariant snapshot.
3. Distributed saliency/state-machine refactor.
4. HAP/runtime/I/O hardening.
5. `run_all.sh` orchestration consolidation.
6. Regression, failure-injection, smoke, and archive tests.
7. Release packaging and factual report.
