from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from frequency_pruning.orchestration import ExperimentTask, run_tasks
from frequency_pruning.version import PIPELINE_VERSION


_SUCCESS_PROGRAM_TEMPLATE = r'''
import json, os, pathlib, sys
run_dir = pathlib.Path(sys.argv[1])
run_dir.mkdir(parents=True, exist_ok=True)
summary = {
    "pipeline_version": "__VERSION__",
    "final": {"val": {"top1": 1.0}},
    "actual_sparsity": 0.0,
}
(run_dir / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
(run_dir / "COMPLETED").write_text("__VERSION__\n", encoding="utf-8")
'''

_RETRY_PROGRAM_TEMPLATE = r'''
import json, os, pathlib, sys
run_dir = pathlib.Path(sys.argv[1])
attempt = int(os.environ.get("FSP_RETRY_ATTEMPT", "1"))
if attempt == 1:
    print("OSError: [Errno 24] Too many open files", flush=True)
    raise SystemExit(1)
assert os.environ.get("FSP_MAX_WORKERS_PER_JOB") == "0"
assert os.environ.get("FSP_ALLOW_PERSISTENT_WORKERS") == "0"
run_dir.mkdir(parents=True, exist_ok=True)
summary = {
    "pipeline_version": "__VERSION__",
    "final": {"val": {"top1": 1.0}},
    "actual_sparsity": 0.0,
}
(run_dir / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
(run_dir / "COMPLETED").write_text("__VERSION__\n", encoding="utf-8")
'''

_SUCCESS_PROGRAM = _SUCCESS_PROGRAM_TEMPLATE.replace("__VERSION__", PIPELINE_VERSION)
_RETRY_PROGRAM = _RETRY_PROGRAM_TEMPLATE.replace("__VERSION__", PIPELINE_VERSION)


class OrchestrationTests(unittest.TestCase):
    def _environment(self):
        return mock.patch.dict(
            os.environ,
            {
                "FSP_ALLOW_CPU": "1",
                "FSP_MAX_PARALLEL_JOBS": "1",
                "FSP_TASK_RETRIES": "1",
            },
            clear=False,
        )

    def test_success_requires_versioned_summary(self) -> None:
        with tempfile.TemporaryDirectory() as directory, self._environment():
            root = Path(directory)
            run_dir = root / "run"
            task = ExperimentTask(
                "ok",
                (sys.executable, "-c", _SUCCESS_PROGRAM, str(run_dir)),
                str(run_dir),
            )
            result = run_tasks([task], stage="unit", status_root=root / "status")
            self.assertEqual(result[0].status, "ok")
            self.assertTrue((run_dir / "COMPLETED").exists())

    def test_fd_failure_retry_disables_workers_without_changing_training(self) -> None:
        with tempfile.TemporaryDirectory() as directory, self._environment():
            root = Path(directory)
            run_dir = root / "run"
            task = ExperimentTask(
                "retry",
                (sys.executable, "-c", _RETRY_PROGRAM, str(run_dir)),
                str(run_dir),
            )
            result = run_tasks([task], stage="retry", status_root=root / "status")
            self.assertEqual(result[0].status, "ok")
            self.assertEqual(result[0].attempts, 2)


if __name__ == "__main__":
    unittest.main()


class OverrideOrderingTests(unittest.TestCase):
    """Variant-specific overrides must win over stage-wide --set values."""

    def test_variant_overrides_are_applied_last(self) -> None:
        import ast
        import inspect

        import ablations
        import vit_ablation

        for module in (ablations, vit_ablation):
            source = inspect.getsource(module.main)
            self.assertLess(
                source.index("*args.overrides"),
                source.index("*method_overrides"),
                msg=f"{module.__name__}: stage-wide --set must precede the variant overrides",
            )
