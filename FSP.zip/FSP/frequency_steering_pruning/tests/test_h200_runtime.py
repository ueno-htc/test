from __future__ import annotations

import os
import resource
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from frequency_pruning.h200_runtime import (
    apply_h200_config,
    atomic_json_dump,
    raise_nofile_limit,
    recommended_workers_per_rank,
    resolve_loader_runtime,
)


class H200RuntimeTests(unittest.TestCase):
    def test_worker_cap(self):
        with mock.patch.dict(
            os.environ,
            {
                "FSP_MAX_WORKERS_PER_JOB": "3",
                "FSP_CONCURRENT_JOBS": "8",
            },
            clear=False,
        ):
            self.assertLessEqual(recommended_workers_per_rank(64, world_size=1), 3)
            runtime = resolve_loader_runtime(64, world_size=1, persistent=True)
            self.assertLessEqual(runtime.workers, 3)

    def test_explicit_precision_and_hap_overrides(self):
        config = {
            "train": {"amp": "fp16"},
            "data": {"workers": 64},
            "pruning": {
                "method": "hap",
                "hap_mode": "gate_hutchinson",
                "hap_microbatch_size": 8,
                "saliency_execution": "all_ranks",
            },
        }
        with mock.patch.dict(
            os.environ,
            {
                "FSP_PRECISION": "bf16",
                "FSP_HAP_MODE": "gate_empirical_fisher",
                "FSP_HAP_MICROBATCH_SIZE": "2",
                "FSP_SALIENCY_EXECUTION": "all_ranks",
            },
            clear=False,
        ):
            apply_h200_config(config)
        self.assertEqual(config["train"]["amp"], "bf16")
        self.assertEqual(config["pruning"]["hap_mode"], "gate_empirical_fisher")
        self.assertEqual(config["pruning"]["hap_microbatch_size"], 2)
        self.assertEqual(config["pruning"]["saliency_execution"], "all_ranks")
        # Arbitrary data keys are no longer silently rewritten.
        self.assertEqual(config["data"]["workers"], 64)

    def test_unsafe_rank0_saliency_override_is_rejected(self):
        config = {
            "train": {"amp": "bf16"},
            "data": {"workers": 0},
            "pruning": {"saliency_execution": "all_ranks"},
        }
        with mock.patch.dict(
            os.environ, {"FSP_SALIENCY_EXECUTION": "rank0"}, clear=False
        ):
            with self.assertRaisesRegex(ValueError, "all_ranks"):
                apply_h200_config(config)

    def test_nofile_never_decreases(self):
        before = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
        result = raise_nofile_limit(before)
        after = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
        self.assertGreaterEqual(after, before)
        self.assertIn("new_soft", result)

    def test_atomic_json(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "value.json"
            atomic_json_dump({"ok": True}, path)
            self.assertEqual(path.read_text().strip(), '{\n  "ok": true\n}')


if __name__ == "__main__":
    unittest.main()
