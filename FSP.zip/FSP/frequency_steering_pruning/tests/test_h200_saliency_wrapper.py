from __future__ import annotations

import inspect
import unittest

import torch

from frequency_pruning.pruning.saliency import SaliencyResult, compute_method_scores


class H200SaliencyExecutionTests(unittest.TestCase):
    def test_distributed_reduction_is_explicit(self):
        signature = inspect.signature(compute_method_scores)
        self.assertIn("distributed_reduce", signature.parameters)
        self.assertFalse(signature.parameters["distributed_reduce"].default)

    def test_result_cpu_is_fp32(self):
        value = SaliencyResult(
            "test",
            {"x": torch.ones(2, dtype=torch.float16)},
            {"x": torch.ones(2, dtype=torch.float16)},
        ).cpu()
        self.assertEqual(value.scores["x"].device.type, "cpu")
        self.assertEqual(value.scores["x"].dtype, torch.float32)

    def test_no_rank0_loader_clone_api_remains(self):
        import frequency_pruning.datasets as datasets_module

        self.assertFalse(hasattr(datasets_module, "clone_loader_for_single_process"))


if __name__ == "__main__":
    unittest.main()
