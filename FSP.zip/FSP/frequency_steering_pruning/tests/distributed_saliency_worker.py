from __future__ import annotations

import copy
import traceback

import torch
from torch.nn.parallel import DistributedDataParallel as DDP

from frequency_pruning.config import DEFAULT_CONFIG
from frequency_pruning.datasets import build_dataset_bundle, build_loaders, close_loaders
from frequency_pruning.distributed import (
    DistributedPhaseError,
    all_gather_object,
    cleanup_distributed,
    setup_distributed,
    synchronize_failures,
)
from frequency_pruning.models import build_model
from frequency_pruning.pruning.saliency import (
    DistributedSaliencyError,
    compute_method_scores_for_context,
)


def config_for(method: str, execution: str = "all_ranks"):
    config = copy.deepcopy(DEFAULT_CONFIG)
    config["experiment"].update({"device": "cpu", "seed": 123, "deterministic": True})
    config["model"].update(
        {
            "arch": "resnet18",
            "weights": "NONE",
            "num_classes": 4,
            "image_size": 32,
            "channels_last": False,
        }
    )
    config["data"].update(
        {
            "dataset": "synthetic",
            "resize_size": 32,
            "batch_size": 4,
            "eval_batch_size": 4,
            "calibration_batch_size": 4,
            "batch_size_scope": "global",
            "workers": 0,
            "calibration_size": 9,  # deliberately not divisible by world size
        }
    )
    config["pruning"].update(
        {
            "method": method,
            "score_batches": 0,
            "layer_normalization": "none",
            "hap_mode": "gate_empirical_fisher",
            "hap_microbatch_size": 2,
            "saliency_execution": execution,
            "saliency_reduce_bucket_mb": 0.01,
        }
    )
    config["train"]["amp"] = "none"
    return config


def checksum(result) -> float:
    return float(sum(value.double().sum() for value in result.scores.values()))


def assert_shared_result(result) -> None:
    values = all_gather_object(checksum(result))
    assert max(values) - min(values) < 1e-5, values
    assert result.diagnostics["saliency_execution"] == "all_ranks_sharded"
    assert result.diagnostics["score_consensus_verified"] is True


def run_method(context, method: str):
    config = config_for(method)
    bundle = build_dataset_bundle(config)
    loaders = build_loaders(bundle, config, True)
    torch.manual_seed(77)
    model = DDP(build_model("resnet18", 4, "NONE", 32))
    try:
        result = compute_method_scores_for_context(
            model, loaders["calibration"], config, context
        )
        assert_shared_result(result)
        return result
    finally:
        close_loaders(loaders)


def main() -> None:
    context = setup_distributed("cpu")
    try:
        hap = run_method(context, "hap")
        assert hap.diagnostics["full_model_second_order_graph"] is False
        assert hap.diagnostics["hap_estimator"] == "mini_batch_empirical_fisher_gate_diagonal"

        fsp = run_method(context, "frequency_steering")
        assert fsp.diagnostics["formula"] == "abs((g_target - lambda*g_opposite) * w)"
        assert fsp.diagnostics["calibration_samples"] == 9

        snip = run_method(context, "snip")
        assert snip.diagnostics["calibration_samples"] == 9

        # The unsafe policy is rejected on every rank immediately and cannot
        # enter an asymmetric NCCL collective.
        config = config_for("frequency_steering", "rank0")
        bundle = build_dataset_bundle(config)
        loaders = build_loaders(bundle, config, True)
        model = DDP(build_model("resnet18", 4, "NONE", 32))
        try:
            rejected = False
            try:
                compute_method_scores_for_context(
                    model, loaders["calibration"], config, context
                )
            except DistributedSaliencyError as error:
                rejected = "rank-0-only saliency is disabled" in str(error)
            flags = all_gather_object(rejected)
            assert all(flags), flags
        finally:
            close_loaders(loaders)

        # A rank-local failure is propagated on the Gloo control plane before
        # any later tensor collective.  Every rank receives the same phase error.
        local_error = RuntimeError("injected rank-local failure") if context.rank == 1 else None
        local_trace = "injected traceback on rank 1" if local_error is not None else ""
        caught = False
        try:
            synchronize_failures(
                local_error,
                phase="injected_failure_test",
                local_traceback=local_trace,
            )
        except DistributedPhaseError as error:
            caught = (
                "injected rank-local failure" in str(error)
                and "rank=1" in str(error)
            )
        flags = all_gather_object(caught)
        assert all(flags), flags
    finally:
        cleanup_distributed(synchronize=True)


if __name__ == "__main__":
    main()
