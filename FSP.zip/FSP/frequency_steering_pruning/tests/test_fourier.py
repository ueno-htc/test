from __future__ import annotations

import unittest

import torch

from frequency_pruning.fourier import denormalize, frequency_energy_statistics, normalize, split_frequency


class FourierTests(unittest.TestCase):
    def test_full_cutoff_preserves_image(self) -> None:
        raw = torch.rand(2, 3, 32, 32)
        normalized = normalize(raw)
        low, high = split_frequency(normalized, cutoff=2.0)
        self.assertLess(float((denormalize(low) - raw).abs().max()), 1e-5)
        # With all AC content assigned to LP, HP is the per-image channel mean.
        expected = raw.mean(dim=(-2, -1), keepdim=True).expand_as(raw)
        self.assertLess(float((denormalize(high) - expected).abs().max()), 1e-5)

    def test_low_high_energy_ratios_sum_to_one(self) -> None:
        x = normalize(torch.rand(4, 3, 24, 24))
        stats = frequency_energy_statistics(x, 0.25)
        self.assertTrue(torch.allclose(stats["low_ratio"] + stats["high_ratio"], torch.ones(4), atol=1e-5))

    def test_split_is_differentiable(self) -> None:
        x = torch.randn(2, 3, 16, 16, requires_grad=True)
        low, high = split_frequency(x, 0.3)
        (low.square().mean() + high.square().mean()).backward()
        self.assertIsNotNone(x.grad)
        self.assertTrue(torch.isfinite(x.grad).all())


if __name__ == "__main__":
    unittest.main()
