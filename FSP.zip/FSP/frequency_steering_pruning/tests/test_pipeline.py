from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

from frequency_pruning.config import resolve_config
from frequency_pruning.runner import run_experiment


class PipelineTests(unittest.TestCase):
    def test_end_to_end_smoke(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = resolve_config(
                Path(__file__).resolve().parents[1] / "configs" / "smoke_test.yaml",
                [
                    "train.recovery_epochs=0",
                    "evaluation.throughput=false",
                    "visualization.fourier_heatmap=false",
                    "visualization.layer_heatmap=false",
                ],
            )
            summary = run_experiment(config, run_dir=Path(directory) / "run")
            self.assertGreater(summary["actual_sparsity"], 0)
            self.assertLess(summary["export"]["masked_slim_max_abs_diff"], 1e-4)
            self.assertTrue((Path(directory) / "run" / "summary.json").exists())


if __name__ == "__main__":
    unittest.main()
