from __future__ import annotations

import copy
import unittest

import torch

from frequency_pruning.config import DEFAULT_CONFIG
from frequency_pruning.datasets import build_dataset_bundle, build_loaders
from frequency_pruning.models import build_model
from frequency_pruning.pruning.saliency import compute_method_scores


class SaliencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 4})
        config["pruning"].update({"score_batches": 1, "cutoff": 0.25, "lambda": 0.5, "layer_normalization": "none"})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        cls.loaders = build_loaders(bundle, config, False)

    def test_all_baselines_produce_finite_active_scores(self) -> None:
        for method in ("random", "magnitude", "snip", "steering_only", "frequency_steering", "hap"):
            config = copy.deepcopy(self.config)
            config["pruning"]["method"] = method
            if method == "hap":
                config["pruning"]["hap_mode"] = "empirical_fisher"
            model = build_model("resnet18", 4, "NONE", 32)
            result = compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))
            self.assertGreater(len(result.scores), 0)
            for scores in result.scores.values():
                self.assertTrue(torch.isfinite(scores).all())


    def test_gate_hutchinson_hap_is_finite_and_gate_only(self) -> None:
        config = copy.deepcopy(self.config)
        config["pruning"].update(
            {
                "method": "hap",
                "hap_mode": "gate_hutchinson",
                "hap_samples": 1,
                "hap_microbatch_size": 2,
                "score_batches": 1,
            }
        )
        model = build_model("resnet18", 4, "NONE", 32)
        result = compute_method_scores(
            model, self.loaders["calibration"], config, torch.device("cpu")
        )
        self.assertEqual(
            result.diagnostics["hap_estimator"],
            "hutchinson_absolute_gate_hessian_diagonal",
        )
        self.assertFalse(result.diagnostics["full_model_second_order_graph"])
        for scores in result.scores.values():
            self.assertTrue(torch.isfinite(scores).all())


    def test_exact_hap_is_not_silently_aliased(self) -> None:
        config = copy.deepcopy(self.config)
        config["pruning"].update({"method": "hap", "hap_mode": "exact"})
        model = build_model("resnet18", 4, "NONE", 32)
        with self.assertRaisesRegex(ValueError, "not implemented"):
            compute_method_scores(
                model, self.loaders["calibration"], config, torch.device("cpu")
            )

    def test_steering_only_forces_zero_lambda(self) -> None:
        config = copy.deepcopy(self.config)
        config["pruning"].update({"method": "steering_only", "lambda": 99.0})
        model = build_model("resnet18", 4, "NONE", 32)
        result = compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))
        self.assertEqual(result.diagnostics["lambda"], 0.0)


if __name__ == "__main__":
    unittest.main()
