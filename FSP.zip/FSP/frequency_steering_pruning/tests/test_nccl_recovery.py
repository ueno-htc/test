from __future__ import annotations

import copy
import json
import tempfile
from pathlib import Path
from unittest import mock

import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from frequency_pruning.config import DEFAULT_CONFIG, validate_config
from frequency_pruning.datasets import (
    build_dataset_bundle,
    build_loaders,
    close_loaders,
    resolve_batch_size,
)
from frequency_pruning.fourier import split_frequency
from frequency_pruning.orchestration import is_complete
from frequency_pruning.pruning.saliency import (
    _frequency_combined_gradients,
    _frequency_gradients_separate,
    _steering_coefficients,
)
from frequency_pruning.version import PIPELINE_VERSION


class TinyClassifier(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.fc = nn.Linear(3 * 8 * 8, 3, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc(x.flatten(1))


def test_combined_fsp_gradient_is_algebraically_equivalent() -> None:
    torch.manual_seed(42)
    model = TinyClassifier().eval()
    images = torch.rand(5, 3, 8, 8)
    labels = torch.tensor([0, 1, 2, 1, 0])
    loader = DataLoader(TensorDataset(images, labels), batch_size=3, shuffle=False)
    parameters = list(model.parameters())
    lam = 0.65

    combined, combined_diag = _frequency_combined_gradients(
        model,
        loader,
        parameters,
        torch.device("cpu"),
        max_batches=0,
        cutoff=0.25,
        cutoff_mode="relative",
        transition_width=0.0,
        hp_dc_mode="image_mean",
        channels_last=False,
        amp_dtype=None,
        coefficients=_steering_coefficients("high", "swap", lam),
        distributed_reduce=False,
        bucket_mb=1.0,
    )
    low, high, separate_diag = _frequency_gradients_separate(
        model,
        loader,
        parameters,
        torch.device("cpu"),
        max_batches=0,
        cutoff=0.25,
        cutoff_mode="relative",
        transition_width=0.0,
        hp_dc_mode="image_mean",
        channels_last=False,
        amp_dtype=None,
        distributed_reduce=False,
        bucket_mb=1.0,
    )
    assert combined_diag["calibration_samples"] == 5
    assert separate_diag["calibration_samples"] == 5
    for parameter in parameters:
        torch.testing.assert_close(
            combined[parameter],
            high[parameter] - lam * low[parameter],
            rtol=2e-5,
            atol=2e-6,
        )


def test_steering_only_skips_opposite_frequency_gradient() -> None:
    coefficients = _steering_coefficients("high", "swap", 0.0)
    assert coefficients == {"hp": 1.0, "lp": -0.0}


def test_val_and_test_reuse_one_loader() -> None:
    config = copy.deepcopy(DEFAULT_CONFIG)
    config["model"].update(
        {"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 16}
    )
    config["data"].update(
        {
            "dataset": "synthetic",
            "resize_size": 16,
            "batch_size": 4,
            "eval_batch_size": 4,
            "calibration_batch_size": 4,
            "workers": 0,
            "calibration_size": 4,
        }
    )
    bundle = build_dataset_bundle(config)
    loaders = build_loaders(bundle, config, distributed=False)
    try:
        assert bundle.test is bundle.val
        assert loaders["test"] is loaders["val"]
    finally:
        close_loaders(loaders)


def test_global_batch_scope_preserves_effective_batch() -> None:
    data = {"batch_size": 256, "batch_size_scope": "global"}
    with mock.patch("torch.distributed.get_world_size", return_value=8):
        assert resolve_batch_size(data, "batch_size", distributed=True) == 32
    assert resolve_batch_size(data, "batch_size", distributed=False) == 256


def test_rank0_saliency_configuration_is_rejected() -> None:
    config = copy.deepcopy(DEFAULT_CONFIG)
    config["pruning"]["saliency_execution"] = "rank0"
    with pytest.raises(ValueError, match="all_ranks"):
        validate_config(config)


def test_completion_contract_rejects_partial_and_stale_runs() -> None:
    with tempfile.TemporaryDirectory() as directory:
        run_dir = Path(directory)
        summary = {
            "pipeline_version": PIPELINE_VERSION,
            "final": {"val": {"top1": 1.0}},
            "actual_sparsity": 0.5,
        }
        (run_dir / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
        assert not is_complete(run_dir)
        (run_dir / "COMPLETED").write_text(f"{PIPELINE_VERSION}\n", encoding="utf-8")
        assert is_complete(run_dir)
        summary["pipeline_version"] = "stale-pipeline"
        (run_dir / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
        assert not is_complete(run_dir)
