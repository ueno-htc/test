from __future__ import annotations

from pathlib import Path


def test_run_all_is_the_single_fixed_path_entrypoint() -> None:
    root = Path(__file__).resolve().parents[1]
    text = (root / "run_all.sh").read_text(encoding="utf-8")
    required = [
        "/home/ueno/FSP/frequency_steering_pruning",
        "/home/ueno/.conda/envs/vip/bin/python",
        "export IMAGENET_ROOT=/localdata/imagenet/",
        "export IMAGENET_C_ROOT=/localdata/imagenet_family/imagenet-c",
        "export NEU_ROOT=/localdata/NEU-CLS",
        "export DTD_ROOT=/localdata",
        "export CUB_ROOT=/localdata/CUB_200_2011",
        "export NPROC=8",
        "scripts/preflight_h200.py",
        "scripts/distributed_collective_selftest.py",
        "tune.py",
        "main_experiments.py",
        "ablations.py",
        "vit_ablation.py",
        "transfer.py",
        "tools/collect_results.py",
        "tools/make_figures.py",
        "configs/imagenet_resnet50_v4.yaml",
        "configs/vit_v4.yaml",
        "configs/transfer_v4.yaml",
        "FSP_SPARSITIES",
        "FSP_SEEDS",
        "spectral_steering",
        "RUN_ALL_COMPLETED.json",
        "RUN_ALL_FAILED.json",
    ]
    for value in required:
        assert value in text
    assert 'export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"' in text
    assert "torchrun " not in text
    assert "IMAGENET_R_ROOT" not in text  # ImageNet-R evaluation was dropped in v4
    assert 'unset NCCL_ASYNC_ERROR_HANDLING' in text
    assert 'TORCH_NCCL_TRACE_BUFFER_SIZE' in text
    assert 'TORCH_FR_BUFFER_SIZE' in text
    assert 'FSP_TORCH_MAJOR' in text
    assert 'FSP_SALIENCY_EXECUTION:-all_ranks' in text
    assert 'FSP_SALIENCY_EXECUTION:-rank0' not in text


def test_no_secondary_shell_script_is_required_by_user() -> None:
    root = Path(__file__).resolve().parents[1]
    readme = (root / "README.md").read_text(encoding="utf-8")
    # The release documentation may describe internal components, but the
    # production invocation must be the top-level entrypoint.
    assert "bash run_all.sh" in readme
