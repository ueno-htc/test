from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def test_two_process_saliency_collectives_and_error_propagation(tmp_path):
    root = Path(__file__).resolve().parents[1]
    command = [
        sys.executable,
        "-m",
        "torch.distributed.run",
        "--standalone",
        "--nproc_per_node=2",
        str(root / "tests" / "distributed_saliency_worker.py"),
    ]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root) + os.pathsep + env.get("PYTHONPATH", "")
    env["FSP_DISTRIBUTED_TIMEOUT_SECONDS"] = "120"
    completed = subprocess.run(
        command,
        cwd=root,
        env=env,
        capture_output=True,
        text=True,
        timeout=180,
    )
    assert completed.returncode == 0, completed.stdout + "\n" + completed.stderr
