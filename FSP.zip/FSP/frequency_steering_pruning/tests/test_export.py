from __future__ import annotations

import unittest

import torch

from frequency_pruning.models import build_model, export_slim_model, iter_prunable_units
from frequency_pruning.utils import count_parameters


class ExportTests(unittest.TestCase):
    def _check(self, arch: str, size: int) -> None:
        torch.manual_seed(1)
        model = build_model(arch, num_classes=4, weights="NONE", image_size=size).eval()
        units = iter_prunable_units(model)
        for unit in units[: min(3, len(units))]:
            if unit.active_count() > unit.min_units_default:
                unit.prune([0])
        sample = torch.randn(2, 3, size, size)
        with torch.no_grad():
            masked = model(sample)
        slim = export_slim_model(model).eval()
        with torch.no_grad():
            physical = slim(sample)
        self.assertLess(float((masked - physical).abs().max()), 1e-5)
        self.assertLess(count_parameters(slim), count_parameters(model))

    def test_resnet_export(self) -> None:
        self._check("resnet18", 64)

    def test_vit_export(self) -> None:
        self._check("tiny_vit_debug", 64)

    def test_efficientnet_export(self) -> None:
        self._check("efficientnet_b4", 64)


if __name__ == "__main__":
    unittest.main()
