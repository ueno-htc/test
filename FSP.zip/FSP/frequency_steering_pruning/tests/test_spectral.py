from __future__ import annotations

import copy
import unittest

import torch

from frequency_pruning.config import DEFAULT_CONFIG, resolve_config
from frequency_pruning.datasets import build_dataset_bundle, build_loaders
from frequency_pruning.models import build_model, iter_prunable_units
from frequency_pruning.orchestration import resolve_method_spec, sparsity_tag
from frequency_pruning.pruning.recalibrate import recalibrate_batchnorm
from frequency_pruning.pruning.saliency import compute_method_scores
from frequency_pruning.pruning.spectral import (
    band_filter,
    band_masks,
    band_stop,
    normalize_band_edges,
    profile_mismatch,
    random_band_augment,
    steering_weights,
)
from frequency_pruning.runner import dense_finetune_epochs, total_training_epochs


class BandGeometryTests(unittest.TestCase):
    def test_masks_partition_the_spectrum(self) -> None:
        edges = normalize_band_edges([0.0, 0.125, 0.25, 0.5, 2.0])
        masks = band_masks(32, 48, edges, torch.device("cpu"))
        self.assertEqual(tuple(masks.shape), (4, 32, 48))
        self.assertTrue(torch.allclose(masks.sum(dim=0), torch.ones(32, 48)))

    def test_invalid_edges_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            normalize_band_edges([0.1, 0.5, 2.0])
        with self.assertRaises(ValueError):
            normalize_band_edges([0.0, 0.5, 0.25, 2.0])

    def test_band_filter_keeps_image_mean_and_is_idempotent_on_full_mask(self) -> None:
        x = torch.rand(2, 3, 32, 32)
        normalized = (x - torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)) / torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        masks = band_masks(32, 32, normalize_band_edges(None), torch.device("cpu"))
        full = band_filter(normalized, masks.sum(dim=0), clamp=False)
        self.assertTrue(torch.allclose(full, normalized, atol=1e-4))
        stopped = band_stop(normalized, masks, 0, clamp=False)
        # DC is kept: per-channel means survive the removal of the lowest band.
        self.assertTrue(torch.allclose(stopped.mean(dim=(-2, -1)), normalized.mean(dim=(-2, -1)), atol=1e-4))

    def test_random_band_augment_respects_probability(self) -> None:
        x = torch.randn(2, 3, 16, 16)
        self.assertTrue(torch.equal(random_band_augment(x, normalize_band_edges(None), 0.0), x))
        generator = torch.Generator().manual_seed(0)
        out = random_band_augment(x, normalize_band_edges(None), 1.0, generator=generator)
        self.assertEqual(tuple(out.shape), tuple(x.shape))
        self.assertFalse(torch.equal(out, x))


class SteeringWeightTests(unittest.TestCase):
    def test_weights_are_zero_sum_and_l1_normalised(self) -> None:
        for mode in ("high", "low", "reliance", "auto"):
            w = steering_weights(mode, 4, reliance_profile=[0.6, 0.3, 0.1, 0.0], sensitivity_profile=[0.1, 0.1, 0.3, 0.5])
            self.assertAlmostEqual(sum(w), 0.0, places=6)
            self.assertAlmostEqual(sum(abs(v) for v in w), 1.0, places=6)
        self.assertEqual(steering_weights("flat", 4), [0.0] * 4)

    def test_auto_weights_vanish_when_profiles_match(self) -> None:
        profile = [0.4, 0.3, 0.2, 0.1]
        w = steering_weights("auto", 4, reliance_profile=profile, sensitivity_profile=profile)
        self.assertTrue(all(abs(v) < 1e-12 for v in w))
        self.assertEqual(profile_mismatch(profile, profile), 0.0)

    def test_high_profile_prefers_high_bands(self) -> None:
        w = steering_weights("high", 4)
        self.assertLess(w[0], 0.0)
        self.assertGreater(w[-1], 0.0)


class SpectralSaliencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 2, "layer_normalization": "none"})
        config["pruning"]["spectral"].update({"microbatch_size": 2, "reliance_batches": 1, "noise_samples_per_band": 1})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        cls.loaders = build_loaders(bundle, config, False)

    def _scores(self, method: str, **spectral):
        config = copy.deepcopy(self.config)
        config["pruning"]["method"] = method
        config["pruning"]["spectral"].update(spectral)
        torch.manual_seed(0)
        model = build_model("resnet18", 4, "NONE", 32)
        return compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))

    def test_every_estimator_produces_finite_scores(self) -> None:
        for method, kwargs in (
            ("taylor", {}),
            ("lfs", {}),
            ("spectral_steering", {"estimator": "exact"}),
            ("spectral_steering", {"estimator": "noise"}),
            ("spectral_steering", {"estimator": "filtered"}),
            ("spectral_steering", {"estimator": "exact", "signed": False, "target_profile": "high"}),
        ):
            result = self._scores(method, **kwargs)
            self.assertGreater(len(result.scores), 0)
            for scores in result.scores.values():
                self.assertTrue(torch.isfinite(scores).all(), msg=f"{method} {kwargs}")

    def test_flat_profile_equals_gate_taylor(self) -> None:
        taylor = self._scores("taylor")
        flat = self._scores("spectral_steering", target_profile="flat")
        for name in taylor.scores:
            self.assertTrue(torch.allclose(taylor.scores[name], flat.scores[name], atol=1e-6, rtol=1e-4))

    def test_auto_profile_records_diagnostics(self) -> None:
        result = self._scores("spectral_steering", target_profile="auto")
        diag = result.diagnostics
        self.assertEqual(len(diag["steering_weights"]), 4)
        self.assertAlmostEqual(sum(diag["steering_weights"]), 0.0, places=5)
        self.assertEqual(len(diag["sensitivity_profile"]), 4)
        self.assertEqual(len(diag["reliance_profile"]), 4)
        self.assertIn("unit_band_contribution", diag)
        unit_names = [name for name, _ in iter_prunable_units(build_model("resnet18", 4, "NONE", 32), named=True)]
        self.assertEqual(sorted(diag["unit_band_contribution"]), sorted(unit_names))


class RecoveryProtocolTests(unittest.TestCase):
    def test_batchnorm_recalibration_updates_statistics(self) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        bundle = build_dataset_bundle(config)
        loaders = build_loaders(bundle, config, False)
        model = build_model("resnet18", 4, "NONE", 32).eval()
        before = model.bn1.running_mean.clone()
        report = recalibrate_batchnorm(model, loaders["calibration"], torch.device("cpu"), max_batches=2)
        self.assertTrue(report["recalibrated"])
        self.assertEqual(report["batches"], 2)
        self.assertFalse(torch.allclose(before, model.bn1.running_mean))
        self.assertFalse(model.training)

    def test_dense_budget_rules(self) -> None:
        config = resolve_config(None, [
            "pruning.target_sparsity=0.5", "pruning.num_rounds=4", "pruning.sparsity_schedule=[]",
            "train.epochs_before_pruning=1", "train.recovery_epochs=2", "train.final_epochs=10",
        ])
        config["pruning"]["method"] = "spectral_steering"
        self.assertEqual(total_training_epochs(config), 1 + 4 * 2 + 10)
        config["pruning"]["method"] = "dense_finetuned"
        self.assertEqual(total_training_epochs(config), 1 + 4 * 2 + 10)
        self.assertEqual(dense_finetune_epochs(config), 4 * 2 + 10)
        config["pruning"]["method"] = "dense"
        self.assertEqual(total_training_epochs(config), 1)


class OrchestrationSpecTests(unittest.TestCase):
    def test_method_specs(self) -> None:
        name, method, overrides = resolve_method_spec("spectral_noise")
        self.assertEqual((name, method), ("spectral_noise", "spectral_steering"))
        self.assertIn("pruning.spectral.estimator=noise", overrides)
        self.assertEqual(overrides[0], "pruning.method=spectral_steering")
        name, method, overrides = resolve_method_spec("taylor_fourier_aug")
        self.assertEqual(method, "taylor")
        self.assertIn("train.frequency_augment=true", overrides)
        name, method, overrides = resolve_method_spec("spectral_steering@spectral.lambda=0.25,train.lr=0.02")
        self.assertIn("pruning.spectral.lambda=0.25", overrides)
        self.assertIn("train.lr=0.02", overrides)
        self.assertTrue(name.startswith("spectral_steering_lambda0.25"))
        self.assertEqual(sparsity_tag(0.5), "sp50")
        with self.assertRaises(ValueError):
            resolve_method_spec("taylor@novalue")

    def test_invalid_config_values_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            resolve_config(None, ["pruning.spectral.estimator=magic"])
        with self.assertRaises(ValueError):
            resolve_config(None, ["pruning.spectral.target_profile=sideways"])
        with self.assertRaises(ValueError):
            resolve_config(None, ["pruning.method=unknown_method"])


if __name__ == "__main__":
    unittest.main()


class BudgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 1, "layer_normalization": "zscore", "min_units": 4, "min_unit_fraction": 0.1, "method": "taylor"})
        config["pruning"]["spectral"].update({"microbatch_size": 4})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        loaders = build_loaders(bundle, config, False)
        torch.manual_seed(0)
        cls.model = build_model("resnet18", 4, "NONE", 32).eval()
        cls.result = compute_method_scores(cls.model, loaders["calibration"], config, torch.device("cpu"))

    def test_mac_budget_reaches_target(self) -> None:
        from frequency_pruning.pruning.iterative import macs_for_plan, select_pruning_plan_for_mac_target

        dense = macs_for_plan(self.model, [], (1, 3, 32, 32))
        plan, info = select_pruning_plan_for_mac_target(
            self.model, self.result, 0.3, self.config, dense_macs=dense, input_shape=(1, 3, 32, 32), alignment=4
        )
        self.assertFalse(info["capped"])
        self.assertGreaterEqual(info["achieved_mac_reduction"], 0.3)
        self.assertLess(info["achieved_mac_reduction"], 0.36)
        # the model itself must be left untouched by the search
        self.assertEqual(sum(u.active_count() for u in iter_prunable_units(self.model)), sum(u.num_units for u in iter_prunable_units(self.model)))
        achieved = 1.0 - macs_for_plan(self.model, plan, (1, 3, 32, 32)) / dense
        self.assertAlmostEqual(achieved, info["achieved_mac_reduction"], places=6)

    def test_alignment_rounds_kept_counts(self) -> None:
        from frequency_pruning.pruning.iterative import align_plan_to_multiple, select_pruning_plan

        plan = select_pruning_plan(self.model, self.result, 300, self.config)
        aligned = align_plan_to_multiple(self.model, self.result, plan, 8, self.config)
        pruned_per_group: dict[str, int] = {}
        for row in aligned:
            pruned_per_group[row["group"]] = pruned_per_group.get(row["group"], 0) + 1
        for name, unit in iter_prunable_units(self.model, named=True):
            kept = unit.active_count() - pruned_per_group.get(name, 0)
            self.assertEqual(kept % 8, 0, msg=f"{name} keeps {kept}")
            self.assertGreaterEqual(kept, 8)


class SpectralRelianceTests(unittest.TestCase):
    """v5: Spectral Reliance Pruning (band-stop reliance derivative)."""

    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 2, "layer_normalization": "zscore"})
        config["pruning"]["spectral"].update({"microbatch_size": 4, "reliance_batches": 1})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        cls.loaders = build_loaders(bundle, config, False)

    def _scores(self, method: str = "spectral_reliance", top: dict | None = None, **spectral):
        config = copy.deepcopy(self.config)
        config["pruning"]["method"] = method
        config["pruning"]["spectral"].update(spectral)
        if top:
            config["pruning"].update(top)
        torch.manual_seed(0)
        model = build_model("resnet18", 4, "NONE", 32)
        return compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))

    def test_scores_are_finite_for_every_mode(self) -> None:
        for kwargs in (
            {},
            {"reliance_weights": "task"},
            {"reliance_weights": "low"},
            {"reliance_weights": "source", "source_reliance": [0.5, 0.2, 0.2, 0.1]},
            {"reliance_weights": "shift", "source_reliance": [0.5, 0.2, 0.2, 0.1]},
            {"reliance_estimator": "pass", "reliance_weights": "task"},
            {"reliance_estimator": "outdiff", "reliance_weights": "task"},
            {"reliance_estimator": "outdiff", "reliance_weights": "task", "clean_weight": 0.0},
            {"layer_normalization": "zscore"},
        ):
            result = self._scores(**kwargs)
            for scores in result.scores.values():
                self.assertTrue(torch.isfinite(scores).all(), msg=str(kwargs))
            self.assertEqual(result.diagnostics["layer_normalization"], kwargs.get("layer_normalization", "none"))

    def test_reliance_filtered_calibration(self) -> None:
        result = self._scores("reliance_filtered")
        self.assertIn("kept_bands", result.diagnostics)
        self.assertEqual(result.diagnostics["layer_normalization"], "none")
        for scores in result.scores.values():
            self.assertTrue(torch.isfinite(scores).all())
        # with a threshold of zero no band is removed -> identical to global gate-level Taylor
        full = self._scores("reliance_filtered", reliance_threshold=0.0)
        taylor = self._scores("taylor", top={"layer_normalization": "none"})
        self.assertEqual(len(full.diagnostics["kept_bands"]), 4)
        for name in taylor.scores:
            self.assertTrue(torch.allclose(full.raw_scores[name], taylor.raw_scores[name], rtol=1e-4, atol=1e-8), msg=name)

    def test_lambda_zero_is_global_gate_taylor(self) -> None:
        srp0 = self._scores(**{"lambda": 0.0})
        taylor = self._scores("taylor", top={"layer_normalization": "none"})
        for name in taylor.scores:
            a, b = srp0.raw_scores[name], taylor.raw_scores[name]
            # identical up to a positive global scale -> identical global ranking
            ratio = (a / b.clamp_min(1e-20))[b > 1e-12]
            self.assertTrue(torch.allclose(ratio, ratio.mean().expand_as(ratio), rtol=1e-3), msg=name)

    def test_reliance_term_changes_the_ranking(self) -> None:
        base = self._scores(**{"lambda": 0.0})
        steered = self._scores(**{"lambda": 4.0})
        changed = False
        for name in base.scores:
            if not torch.equal(torch.argsort(base.raw_scores[name]), torch.argsort(steered.raw_scores[name])):
                changed = True
        self.assertTrue(changed)

    def test_reliance_weight_modes(self) -> None:
        from frequency_pruning.pruning.spectral import reliance_weights

        task = [0.4, 0.3, 0.2, 0.1]
        src = [0.6, 0.2, 0.1, 0.1]
        for mode in ("task", "uniform", "source", "low"):
            w = reliance_weights(mode, 4, task_reliance=task, source_reliance=src)
            self.assertAlmostEqual(sum(w), 1.0, places=6)
            self.assertTrue(all(v >= 0 for v in w))
        shift = reliance_weights("shift", 4, task_reliance=task, source_reliance=src)
        self.assertAlmostEqual(sum(shift), 0.0, places=6)
        self.assertLess(shift[0], 0.0)  # task relies less on the low band than the source
        self.assertGreater(shift[1], 0.0)
        self.assertEqual(reliance_weights("shift", 4, task_reliance=src, source_reliance=src), [0.0] * 4)
        with self.assertRaises(ValueError):
            reliance_weights("source", 4, task_reliance=task, source_reliance=[0.5, 0.5])

    def test_method_aliases_resolve(self) -> None:
        for alias, expected in (
            ("srp", "spectral_reliance"),
            ("srp_low", "spectral_reliance"),
            ("srp_pass", "spectral_reliance"),
            ("srp_rpr", "spectral_reliance"),
            ("taylor_global", "taylor"),
            ("taylor_augcal", "taylor"),
            ("magnitude_rpr", "magnitude"),
        ):
            name, method, overrides = resolve_method_spec(alias)
            self.assertEqual(method, expected)
            self.assertEqual(overrides[0], f"pruning.method={expected}")
        _, _, overrides = resolve_method_spec("srp_rpr")
        self.assertIn("train.reliance_distill_beta=1.0", overrides)


class TransferProtocolTests(unittest.TestCase):
    def test_dense_gate_thresholds(self) -> None:
        import transfer
        from frequency_pruning.orchestration import load_json_config

        reference = load_json_config("configs/dense_reference.json")
        self.assertGreaterEqual(transfer._gate_threshold(reference, "dtd", "resnet50"), 60.0)
        self.assertGreaterEqual(transfer._gate_threshold(reference, "cub_200_2011", "efficientnet_b4"), 70.0)
        self.assertEqual(transfer._gate_threshold(reference, "unknown_dataset", "resnet50"), 0.0)
        self.assertEqual(transfer._gate_threshold(reference, "flowers102", "resnet50"), 88.0)

    def test_source_reliance_table_matches_band_layout(self) -> None:
        from frequency_pruning.orchestration import load_json_config

        table = load_json_config("configs/source_reliance.json")
        bands = len(table["band_edges"]) - 1
        for arch in ("resnet50", "efficientnet_b4", "deit_base_patch16_224", "vit_b_16"):
            self.assertEqual(len(table[arch]), bands)
            self.assertAlmostEqual(sum(table[arch]), 1.0, delta=0.02)

    def test_torchvision_subset_wrapper(self) -> None:
        from PIL import Image

        from frequency_pruning.datasets import _TransformedSubset, _tv_targets

        class Tiny(torch.utils.data.Dataset):
            def __init__(self) -> None:
                self._labels = [0, 1, 0, 1, 2, 2]

            def __len__(self) -> int:
                return len(self._labels)

            def __getitem__(self, index: int):
                return Image.new("L", (8, 8), color=index * 10), self._labels[index]

        base = Tiny()
        self.assertEqual(_tv_targets(base), [0, 1, 0, 1, 2, 2])
        subset = _TransformedSubset(base, [1, 4], transform=lambda image: image.size)
        self.assertEqual(len(subset), 2)
        value, target = subset[1]
        self.assertEqual(value, (8, 8))
        self.assertEqual(target, 2)


class CalibrationFamilyTests(unittest.TestCase):
    """v6: rank-mix cross-layer calibration, hold-out split, look-ahead plumbing."""

    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 2, "method": "taylor"})
        config["pruning"]["spectral"].update({"microbatch_size": 4})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        cls.loaders = build_loaders(bundle, config, False)

    def _scores(self, normalization: str, alpha: float = 0.5):
        config = copy.deepcopy(self.config)
        config["pruning"].update({"layer_normalization": normalization, "rank_mix_alpha": alpha})
        torch.manual_seed(0)
        model = build_model("resnet18", 4, "NONE", 32)
        return compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))

    @staticmethod
    def _global_order(result) -> list[tuple[str, int]]:
        items = [(float(v), name, i) for name, values in result.scores.items() for i, v in enumerate(values.tolist())]
        return [(name, i) for _, name, i in sorted(items)]

    def test_alpha_one_is_the_global_ranking(self) -> None:
        mixed = self._scores("rankmix", 1.0)
        raw = self._scores("none")
        self.assertEqual(self._global_order(mixed)[:200], self._global_order(raw)[:200])

    def test_alpha_zero_prunes_every_group_by_the_same_percentile(self) -> None:
        mixed = self._scores("rankmix", 0.0)
        for values in mixed.scores.values():
            self.assertAlmostEqual(float(values.min()), 0.0, places=6)
            self.assertAlmostEqual(float(values.max()), 1.0, places=6)
        # the lowest 25% of the global order contains ~25% of every group
        order = self._global_order(mixed)
        cut = order[: len(order) // 4]
        for name, values in mixed.scores.items():
            share = sum(1 for n, _ in cut if n == name) / values.numel()
            self.assertAlmostEqual(share, 0.25, delta=0.05)

    def test_intermediate_alpha_is_between_the_two(self) -> None:
        lo, mid, hi = self._scores("rankmix", 0.0), self._scores("rankmix", 0.5), self._scores("rankmix", 1.0)
        for name in lo.scores:
            self.assertTrue(torch.allclose(mid.scores[name], 0.5 * (lo.scores[name] + hi.scores[name]), atol=1e-5))

    def test_holdout_is_carved_from_the_training_split(self) -> None:
        config = copy.deepcopy(self.config)
        config["data"].update({"holdout_fraction": 0.25, "eval_subset_size": 0})
        full = build_dataset_bundle(copy.deepcopy(self.config))
        bundle = build_dataset_bundle(config)
        self.assertIn("holdout", bundle.ood)
        self.assertEqual(len(bundle.ood["holdout"]) + len(bundle.train), len(full.train))
        self.assertTrue(set(bundle.ood["holdout"].indices).isdisjoint(bundle.train.indices))

    def test_train_subset(self) -> None:
        config = copy.deepcopy(self.config)
        full = build_dataset_bundle(copy.deepcopy(self.config))
        config["data"]["train_subset_size"] = max(1, len(full.train) // 2)
        bundle = build_dataset_bundle(config)
        self.assertEqual(len(bundle.train), max(1, len(full.train) // 2))

    def test_latency_budget_selection(self) -> None:
        from frequency_pruning.pruning.iterative import latency_for_plan, select_pruning_plan_for_latency_target

        torch.manual_seed(0)
        model = build_model("resnet18", 4, "NONE", 32).eval()
        result = self._scores("none")
        config = copy.deepcopy(self.config)
        config["pruning"].update({"min_units": 4, "min_unit_fraction": 0.1})
        dense = latency_for_plan(model, [], (8, 3, 32, 32), warmup=2, steps=6)
        self.assertGreater(dense, 0.0)
        plan, info = select_pruning_plan_for_latency_target(
            model, result, 0.05, config, dense_latency=dense, input_shape=(8, 3, 32, 32), alignment=4, max_iterations=4
        )
        self.assertIn("achieved_latency_reduction", info)
        self.assertGreater(len(plan), 0)
        # the search must leave the model untouched
        self.assertEqual(sum(u.active_count() for u in iter_prunable_units(model)), sum(u.num_units for u in iter_prunable_units(model)))

    def test_fixed_normalisers(self) -> None:
        for name in ("sum", "mean", "max", "standardization", "gaussian", "lamp"):
            result = self._scores(name)
            for group, values in result.scores.items():
                self.assertTrue(torch.isfinite(values).all(), msg=f"{name}/{group}")
        lamp = self._scores("lamp")
        raw = self._scores("none")
        for group, values in lamp.scores.items():
            # LAMP keeps the within-group order and gives the largest unit a score of one
            self.assertTrue(torch.equal(torch.argsort(values), torch.argsort(raw.scores[group])) or
                            torch.allclose(torch.sort(values).values, values[torch.argsort(raw.scores[group])]))
            self.assertAlmostEqual(float(values.max()), 1.0, places=5)
        maxed = self._scores("max")
        for values in maxed.scores.values():
            self.assertAlmostEqual(float(values.max()), 1.0, places=5)

    def test_v6_aliases(self) -> None:
        for alias, key in (("taylor_mix0.5", "pruning.rank_mix_alpha=0.5"), ("taylor_auto", "pruning.layer_normalization=rankmix_auto")):
            _, method, overrides = resolve_method_spec(alias)
            self.assertEqual(method, "taylor")
            self.assertIn(key, overrides)


class BandAugmentationTests(unittest.TestCase):
    def test_targeted_band_removal(self) -> None:
        from frequency_pruning.pruning.spectral import band_masks, normalize_band_edges, random_band_augment

        torch.manual_seed(0)
        # realistic pixel range, so that the clamp after filtering stays inactive
        raw = (0.5 + 0.08 * torch.randn(2, 3, 32, 32)).clamp(0.05, 0.95)
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        x = (raw - mean) / std
        edges = normalize_band_edges(None)
        masks = band_masks(32, 32, edges, x.device)

        def band_energy(t: torch.Tensor) -> torch.Tensor:
            spectrum = torch.fft.fftshift(torch.fft.fft2(t - t.mean(dim=(-2, -1), keepdim=True), norm="ortho"), dim=(-2, -1)).abs() ** 2
            return torch.stack([(spectrum * m).sum() for m in masks])

        before = band_energy(x)
        high_removed = random_band_augment(x, edges, 1.0, mode="stop_set", bands=[2, 3])
        after = band_energy(high_removed)
        self.assertLess(float(after[2] + after[3]), 1e-3 * float(before[2] + before[3]))
        self.assertGreater(float(after[0]), 0.9 * float(before[0]))
        low_removed = random_band_augment(x, edges, 1.0, mode="stop_set", bands=[0])
        after = band_energy(low_removed)
        # clamping to the valid pixel range after filtering re-introduces a little low-frequency energy
        self.assertLess(float(after[0]), 0.02 * float(before[0]))
        self.assertGreater(float(after[3]), 0.9 * float(before[3]))
        # probability zero leaves the batch untouched; the mean (DC) is preserved by the filters
        self.assertTrue(torch.equal(random_band_augment(x, edges, 0.0, mode="stop_set", bands=[0]), x))
        self.assertTrue(torch.allclose(low_removed.mean(dim=(-2, -1)), x.mean(dim=(-2, -1)), atol=1e-3))
        with self.assertRaises(ValueError):
            random_band_augment(x, edges, 1.0, mode="stop_set", bands=[7])

    def test_specialisation_aliases(self) -> None:
        for alias, base in (("taylor_mix0_aug_hi", "taylor"), ("taylor_mix0_aug_lo", "taylor"), ("dense_finetuned_aug_lo", "dense_finetuned")):
            _, method, overrides = resolve_method_spec(alias)
            self.assertEqual(method, base)
            self.assertIn("train.frequency_augment=true", overrides)
            self.assertIn("train.frequency_augment_mode=stop_set", overrides)


class RobustAllocationTests(unittest.TestCase):
    """Layer-wise sparsity from frequency robustness; unit selection by clean Taylor."""

    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 2})
        config["pruning"]["spectral"].update({"microbatch_size": 4})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        cls.loaders = build_loaders(bundle, config, False)

    def _scores(self, method: str, **pruning):
        config = copy.deepcopy(self.config)
        config["pruning"]["method"] = method
        allocation = pruning.pop("allocation", None)
        config["pruning"].update(pruning)
        if allocation:
            config["pruning"]["allocation"].update(allocation)
        torch.manual_seed(0)
        model = build_model("resnet18", 4, "NONE", 32)
        return compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))

    def test_alpha_zero_is_uniform_taylor(self) -> None:
        robust = self._scores("robust_allocation", rank_mix_alpha=0.0, allocation={"bands": [2, 3]})
        uniform = self._scores("taylor", layer_normalization="rankmix", rank_mix_alpha=0.0)
        for name in uniform.scores:
            self.assertTrue(torch.allclose(robust.scores[name], uniform.scores[name], atol=1e-5), msg=name)

    def test_selection_inside_a_layer_follows_clean_taylor(self) -> None:
        for perturbation in ("noise", "stop"):
            result = self._scores("robust_allocation", rank_mix_alpha=1.0, allocation={"bands": [0, 1], "perturbation": perturbation})
            self.assertEqual(result.diagnostics["estimator"], "robustness_gap_" + perturbation)
            for name, scores in result.scores.items():
                self.assertTrue(torch.isfinite(scores).all())
                order = torch.argsort(result.raw_scores[name])
                ordered = scores[order]
                self.assertTrue(bool((ordered[1:] >= ordered[:-1] - 1e-7).all()), msg=f"{perturbation}/{name}")
            self.assertEqual(len(result.diagnostics["band_gap"]), 4)
            self.assertGreater(len(result.diagnostics["layer_robust_sensitivity"]), 0)

    def test_band_choice_changes_the_layer_counts(self) -> None:
        high = self._scores("robust_allocation", rank_mix_alpha=1.0, allocation={"bands": [3]})
        low = self._scores("robust_allocation", rank_mix_alpha=1.0, allocation={"bands": [0]})

        def counts(result) -> dict[str, int]:
            items = sorted((float(v), name) for name, values in result.scores.items() for v in values.tolist())
            cut = items[: len(items) // 3]
            return {name: sum(1 for _, n in cut if n == name) for name in result.scores}

        self.assertNotEqual(counts(high), counts(low))

    def test_band_noise_is_confined_to_the_chosen_bands(self) -> None:
        from frequency_pruning.pruning.spectral import add_band_noise, band_masks, normalize_band_edges

        torch.manual_seed(0)
        raw = torch.full((2, 3, 32, 32), 0.5)
        mean = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
        std = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        x = (raw - mean) / std
        masks = band_masks(32, 32, normalize_band_edges(None), x.device)
        noisy = add_band_noise(x, masks, [2, 3], 0.05)
        delta = noisy * std + mean - raw
        spectrum = torch.fft.fftshift(torch.fft.fft2(delta, norm="ortho"), dim=(-2, -1)).abs() ** 2
        energy = torch.stack([(spectrum * m).sum() for m in masks])
        self.assertLess(float(energy[0] + energy[1]), 1e-4 * float(energy[2] + energy[3]))
        self.assertAlmostEqual(float(delta.pow(2).mean().sqrt()), 0.05, delta=0.005)
        self.assertLess(float(delta.mean(dim=(-2, -1)).abs().max()), 1e-4)

    def test_aliases(self) -> None:
        for alias, method, key in (
            ("ralloc_hi", "robust_allocation", "pruning.allocation.bands=[2,3]"),
            ("ralloc_lo_a1", "robust_allocation", "pruning.rank_mix_alpha=1.0"),
            ("taylor_mix0_noise_hi", "taylor", "train.frequency_augment_mode=noise"),
            ("ralloc_lo_noise_lo", "robust_allocation", "train.frequency_augment_bands=[0,1]"),
            ("dense_finetuned_noise_lo", "dense_finetuned", "train.frequency_augment_mode=noise"),
        ):
            _, resolved, overrides = resolve_method_spec(alias)
            self.assertEqual(resolved, method)
            self.assertIn(key, overrides)
