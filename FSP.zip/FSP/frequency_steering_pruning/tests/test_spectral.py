from __future__ import annotations

import copy
import unittest

import torch

from frequency_pruning.config import DEFAULT_CONFIG, resolve_config
from frequency_pruning.datasets import build_dataset_bundle, build_loaders
from frequency_pruning.models import build_model, iter_prunable_units
from frequency_pruning.orchestration import resolve_method_spec, sparsity_tag
from frequency_pruning.pruning.recalibrate import recalibrate_batchnorm
from frequency_pruning.pruning.saliency import compute_method_scores
from frequency_pruning.pruning.spectral import (
    band_filter,
    band_masks,
    band_stop,
    normalize_band_edges,
    profile_mismatch,
    random_band_augment,
    steering_weights,
)
from frequency_pruning.runner import dense_finetune_epochs, total_training_epochs


class BandGeometryTests(unittest.TestCase):
    def test_masks_partition_the_spectrum(self) -> None:
        edges = normalize_band_edges([0.0, 0.125, 0.25, 0.5, 2.0])
        masks = band_masks(32, 48, edges, torch.device("cpu"))
        self.assertEqual(tuple(masks.shape), (4, 32, 48))
        self.assertTrue(torch.allclose(masks.sum(dim=0), torch.ones(32, 48)))

    def test_invalid_edges_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            normalize_band_edges([0.1, 0.5, 2.0])
        with self.assertRaises(ValueError):
            normalize_band_edges([0.0, 0.5, 0.25, 2.0])

    def test_band_filter_keeps_image_mean_and_is_idempotent_on_full_mask(self) -> None:
        x = torch.rand(2, 3, 32, 32)
        normalized = (x - torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)) / torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
        masks = band_masks(32, 32, normalize_band_edges(None), torch.device("cpu"))
        full = band_filter(normalized, masks.sum(dim=0), clamp=False)
        self.assertTrue(torch.allclose(full, normalized, atol=1e-4))
        stopped = band_stop(normalized, masks, 0, clamp=False)
        # DC is kept: per-channel means survive the removal of the lowest band.
        self.assertTrue(torch.allclose(stopped.mean(dim=(-2, -1)), normalized.mean(dim=(-2, -1)), atol=1e-4))

    def test_random_band_augment_respects_probability(self) -> None:
        x = torch.randn(2, 3, 16, 16)
        self.assertTrue(torch.equal(random_band_augment(x, normalize_band_edges(None), 0.0), x))
        generator = torch.Generator().manual_seed(0)
        out = random_band_augment(x, normalize_band_edges(None), 1.0, generator=generator)
        self.assertEqual(tuple(out.shape), tuple(x.shape))
        self.assertFalse(torch.equal(out, x))


class SteeringWeightTests(unittest.TestCase):
    def test_weights_are_zero_sum_and_l1_normalised(self) -> None:
        for mode in ("high", "low", "reliance", "auto"):
            w = steering_weights(mode, 4, reliance_profile=[0.6, 0.3, 0.1, 0.0], sensitivity_profile=[0.1, 0.1, 0.3, 0.5])
            self.assertAlmostEqual(sum(w), 0.0, places=6)
            self.assertAlmostEqual(sum(abs(v) for v in w), 1.0, places=6)
        self.assertEqual(steering_weights("flat", 4), [0.0] * 4)

    def test_auto_weights_vanish_when_profiles_match(self) -> None:
        profile = [0.4, 0.3, 0.2, 0.1]
        w = steering_weights("auto", 4, reliance_profile=profile, sensitivity_profile=profile)
        self.assertTrue(all(abs(v) < 1e-12 for v in w))
        self.assertEqual(profile_mismatch(profile, profile), 0.0)

    def test_high_profile_prefers_high_bands(self) -> None:
        w = steering_weights("high", 4)
        self.assertLess(w[0], 0.0)
        self.assertGreater(w[-1], 0.0)


class SpectralSaliencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 2, "layer_normalization": "none"})
        config["pruning"]["spectral"].update({"microbatch_size": 2, "reliance_batches": 1, "noise_samples_per_band": 1})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        cls.loaders = build_loaders(bundle, config, False)

    def _scores(self, method: str, **spectral):
        config = copy.deepcopy(self.config)
        config["pruning"]["method"] = method
        config["pruning"]["spectral"].update(spectral)
        torch.manual_seed(0)
        model = build_model("resnet18", 4, "NONE", 32)
        return compute_method_scores(model, self.loaders["calibration"], config, torch.device("cpu"))

    def test_every_estimator_produces_finite_scores(self) -> None:
        for method, kwargs in (
            ("taylor", {}),
            ("lfs", {}),
            ("spectral_steering", {"estimator": "exact"}),
            ("spectral_steering", {"estimator": "noise"}),
            ("spectral_steering", {"estimator": "filtered"}),
            ("spectral_steering", {"estimator": "exact", "signed": False, "target_profile": "high"}),
        ):
            result = self._scores(method, **kwargs)
            self.assertGreater(len(result.scores), 0)
            for scores in result.scores.values():
                self.assertTrue(torch.isfinite(scores).all(), msg=f"{method} {kwargs}")

    def test_flat_profile_equals_gate_taylor(self) -> None:
        taylor = self._scores("taylor")
        flat = self._scores("spectral_steering", target_profile="flat")
        for name in taylor.scores:
            self.assertTrue(torch.allclose(taylor.scores[name], flat.scores[name], atol=1e-6, rtol=1e-4))

    def test_auto_profile_records_diagnostics(self) -> None:
        result = self._scores("spectral_steering", target_profile="auto")
        diag = result.diagnostics
        self.assertEqual(len(diag["steering_weights"]), 4)
        self.assertAlmostEqual(sum(diag["steering_weights"]), 0.0, places=5)
        self.assertEqual(len(diag["sensitivity_profile"]), 4)
        self.assertEqual(len(diag["reliance_profile"]), 4)
        self.assertIn("unit_band_contribution", diag)
        unit_names = [name for name, _ in iter_prunable_units(build_model("resnet18", 4, "NONE", 32), named=True)]
        self.assertEqual(sorted(diag["unit_band_contribution"]), sorted(unit_names))


class RecoveryProtocolTests(unittest.TestCase):
    def test_batchnorm_recalibration_updates_statistics(self) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        bundle = build_dataset_bundle(config)
        loaders = build_loaders(bundle, config, False)
        model = build_model("resnet18", 4, "NONE", 32).eval()
        before = model.bn1.running_mean.clone()
        report = recalibrate_batchnorm(model, loaders["calibration"], torch.device("cpu"), max_batches=2)
        self.assertTrue(report["recalibrated"])
        self.assertEqual(report["batches"], 2)
        self.assertFalse(torch.allclose(before, model.bn1.running_mean))
        self.assertFalse(model.training)

    def test_dense_budget_rules(self) -> None:
        config = resolve_config(None, [
            "pruning.target_sparsity=0.5", "pruning.num_rounds=4", "pruning.sparsity_schedule=[]",
            "train.epochs_before_pruning=1", "train.recovery_epochs=2", "train.final_epochs=10",
        ])
        config["pruning"]["method"] = "spectral_steering"
        self.assertEqual(total_training_epochs(config), 1 + 4 * 2 + 10)
        config["pruning"]["method"] = "dense_finetuned"
        self.assertEqual(total_training_epochs(config), 1 + 4 * 2 + 10)
        self.assertEqual(dense_finetune_epochs(config), 4 * 2 + 10)
        config["pruning"]["method"] = "dense"
        self.assertEqual(total_training_epochs(config), 1)


class OrchestrationSpecTests(unittest.TestCase):
    def test_method_specs(self) -> None:
        name, method, overrides = resolve_method_spec("spectral_noise")
        self.assertEqual((name, method), ("spectral_noise", "spectral_steering"))
        self.assertIn("pruning.spectral.estimator=noise", overrides)
        self.assertEqual(overrides[0], "pruning.method=spectral_steering")
        name, method, overrides = resolve_method_spec("taylor_fourier_aug")
        self.assertEqual(method, "taylor")
        self.assertIn("train.frequency_augment=true", overrides)
        name, method, overrides = resolve_method_spec("spectral_steering@spectral.lambda=0.25,train.lr=0.02")
        self.assertIn("pruning.spectral.lambda=0.25", overrides)
        self.assertIn("train.lr=0.02", overrides)
        self.assertTrue(name.startswith("spectral_steering_lambda0.25"))
        self.assertEqual(sparsity_tag(0.5), "sp50")
        with self.assertRaises(ValueError):
            resolve_method_spec("taylor@novalue")

    def test_invalid_config_values_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            resolve_config(None, ["pruning.spectral.estimator=magic"])
        with self.assertRaises(ValueError):
            resolve_config(None, ["pruning.spectral.target_profile=sideways"])
        with self.assertRaises(ValueError):
            resolve_config(None, ["pruning.method=unknown_method"])


if __name__ == "__main__":
    unittest.main()


class BudgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config = copy.deepcopy(DEFAULT_CONFIG)
        config["model"].update({"arch": "resnet18", "weights": "NONE", "num_classes": 4, "image_size": 32, "channels_last": False})
        config["data"].update({"dataset": "synthetic", "resize_size": 32, "batch_size": 4, "eval_batch_size": 4, "workers": 0, "calibration_size": 8, "calibration_batch_size": 4})
        config["pruning"].update({"score_batches": 1, "layer_normalization": "zscore", "min_units": 4, "min_unit_fraction": 0.1, "method": "taylor"})
        config["pruning"]["spectral"].update({"microbatch_size": 4})
        config["train"]["amp"] = "none"
        cls.config = config
        bundle = build_dataset_bundle(config)
        loaders = build_loaders(bundle, config, False)
        torch.manual_seed(0)
        cls.model = build_model("resnet18", 4, "NONE", 32).eval()
        cls.result = compute_method_scores(cls.model, loaders["calibration"], config, torch.device("cpu"))

    def test_mac_budget_reaches_target(self) -> None:
        from frequency_pruning.pruning.iterative import macs_for_plan, select_pruning_plan_for_mac_target

        dense = macs_for_plan(self.model, [], (1, 3, 32, 32))
        plan, info = select_pruning_plan_for_mac_target(
            self.model, self.result, 0.3, self.config, dense_macs=dense, input_shape=(1, 3, 32, 32), alignment=4
        )
        self.assertFalse(info["capped"])
        self.assertGreaterEqual(info["achieved_mac_reduction"], 0.3)
        self.assertLess(info["achieved_mac_reduction"], 0.36)
        # the model itself must be left untouched by the search
        self.assertEqual(sum(u.active_count() for u in iter_prunable_units(self.model)), sum(u.num_units for u in iter_prunable_units(self.model)))
        achieved = 1.0 - macs_for_plan(self.model, plan, (1, 3, 32, 32)) / dense
        self.assertAlmostEqual(achieved, info["achieved_mac_reduction"], places=6)

    def test_alignment_rounds_kept_counts(self) -> None:
        from frequency_pruning.pruning.iterative import align_plan_to_multiple, select_pruning_plan

        plan = select_pruning_plan(self.model, self.result, 300, self.config)
        aligned = align_plan_to_multiple(self.model, self.result, plan, 8, self.config)
        pruned_per_group: dict[str, int] = {}
        for row in aligned:
            pruned_per_group[row["group"]] = pruned_per_group.get(row["group"], 0) + 1
        for name, unit in iter_prunable_units(self.model, named=True):
            kept = unit.active_count() - pruned_per_group.get(name, 0)
            self.assertEqual(kept % 8, 0, msg=f"{name} keeps {kept}")
            self.assertGreaterEqual(kept, 8)
