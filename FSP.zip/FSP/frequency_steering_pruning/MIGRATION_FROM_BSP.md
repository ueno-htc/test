# Migration map from the BSP repository

| BSP-style responsibility | Frequency-Steering replacement |
|---|---|
| `main.py` entry point | `main.py` delegates to `train.py` |
| pruning saliency | `frequency_pruning/pruning/saliency.py` |
| iterative pruning/fallback | `frequency_pruning/pruning/iterative.py` |
| gated ResNet | `frequency_pruning/models/resnet.py` |
| physical ResNet export | `export_slim_resnet` in the same module |
| dataset construction | `dataset.py` compatibility wrapper and `frequency_pruning/datasets.py` |
| training/evaluation engine | `frequency_pruning/engine.py`, `evaluation.py`, and `runner.py` |
| experiment configurations | `configs/*.yaml` |
| experiment launch scripts | `scripts/*.sh` and `run_all.sh` |

The main architectural change is that the pruning interface is no longer ResNet-specific. Every removable group implements `StructuredPruningUnit`, exposing its gate, dependency-coupled parameters, score aggregation, and exact export path. This lets the same saliency and iterative-selection code operate on ResNet-50, EfficientNet-B4, ViT-B/L, and DeiT-B.

The original cue-conflict probe is intentionally absent. Ordinary labeled images are transformed into low-pass and high-pass calibration views on demand, so no fixed shape/texture or corruption calibration dataset is required.
