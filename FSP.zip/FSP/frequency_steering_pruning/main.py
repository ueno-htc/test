#!/usr/bin/env python3
"""Backward-compatible entry point matching the original BSP repository."""
from train import main

if __name__ == "__main__":
    main()
