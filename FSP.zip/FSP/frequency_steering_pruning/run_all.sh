#!/usr/bin/env bash
# Sole supported production entrypoint for Frequency-Steering Pruning (FSP v5,
# Spectral Reliance Pruning). Stages: preflight -> transfer (fast hypothesis loop)
# -> main (ImageNet CNNs) -> vit -> ablations -> aggregate -> analysis -> figures.
# Every knob below is an optional environment variable; the dataset paths and
# NPROC are fixed.
set -Eeuo pipefail
umask 002

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXPECTED_ROOT="${FSP_EXPECTED_ROOT:-/home/ueno/FSP/frequency_steering_pruning}"
FSP_PYTHON="${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}"
export FSP_PYTHON
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

# Dataset paths are intentionally unchanged from the supplied launcher.
export IMAGENET_ROOT=/localdata/imagenet/
export IMAGENET_C_ROOT=/localdata/imagenet_family/imagenet-c
export NEU_ROOT=/localdata/NEU-CLS
export DTD_ROOT=/localdata
export CUB_ROOT=/localdata/CUB_200_2011
export NPROC=8
# Optional (empty = skipped): low-frequency / shape-biased ImageNet OOD sets and
# extra ImageFolder transfer datasets ("name=/path;name2=/path2").
export IMAGENET_SKETCH_ROOT="${IMAGENET_SKETCH_ROOT:-}"
export STYLIZED_IMAGENET_ROOT="${STYLIZED_IMAGENET_ROOT:-}"
export TRANSFER_EXTRA="${TRANSFER_EXTRA:-}"
# Experiment matrix knobs.
export FSP_SPARSITIES="${FSP_SPARSITIES:-0.5,0.7}"
export FSP_SEEDS="${FSP_SEEDS:-42}"
export FSP_VIT_SPARSITIES="${FSP_VIT_SPARSITIES:-0.5}"
export FSP_TRANSFER_SPARSITIES="${FSP_TRANSFER_SPARSITIES:-0.5}"
export FSP_ABLATION_SPARSITIES="${FSP_ABLATION_SPARSITIES:-0.5}"

# H200 and reliability defaults. User-provided values take precedence except for
# the immutable paths/NPROC above.
export FSP_PRECISION="${FSP_PRECISION:-bf16}"
export FSP_HAP_MODE="${FSP_HAP_MODE:-gate_empirical_fisher}"
export FSP_HAP_MICROBATCH_SIZE="${FSP_HAP_MICROBATCH_SIZE:-8}"
export FSP_SALIENCY_EXECUTION="${FSP_SALIENCY_EXECUTION:-all_ranks}"
export FSP_MAX_PARALLEL_JOBS="${FSP_MAX_PARALLEL_JOBS:-8}"
export FSP_MAX_WORKERS_PER_JOB="${FSP_MAX_WORKERS_PER_JOB:-4}"
export FSP_EVAL_WORKERS_PER_JOB="${FSP_EVAL_WORKERS_PER_JOB:-2}"
export FSP_CALIBRATION_WORKERS_PER_JOB="${FSP_CALIBRATION_WORKERS_PER_JOB:-2}"
export FSP_PREFETCH_FACTOR="${FSP_PREFETCH_FACTOR:-2}"
export FSP_SHARING_STRATEGY="${FSP_SHARING_STRATEGY:-file_system}"
export FSP_DATALOADER_START_METHOD="${FSP_DATALOADER_START_METHOD:-spawn}"
export FSP_ALLOW_PERSISTENT_WORKERS="${FSP_ALLOW_PERSISTENT_WORKERS:-1}"
export FSP_NOFILE_LIMIT="${FSP_NOFILE_LIMIT:-1048576}"
export FSP_TASK_RETRIES="${FSP_TASK_RETRIES:-1}"
export FSP_DISTRIBUTED_TIMEOUT_SECONDS="${FSP_DISTRIBUTED_TIMEOUT_SECONDS:-3600}"
export FSP_CONTROL_TIMEOUT_SECONDS="${FSP_CONTROL_TIMEOUT_SECONDS:-3600}"
export FSP_BARRIER_TIMEOUT_SECONDS="${FSP_BARRIER_TIMEOUT_SECONDS:-900}"
export FSP_CONTROL_BACKEND="${FSP_CONTROL_BACKEND:-gloo}"
export FSP_ALLOW_TF32="${FSP_ALLOW_TF32:-1}"
export FSP_CUDNN_BENCHMARK="${FSP_CUDNN_BENCHMARK:-1}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True,garbage_collection_threshold:0.80}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export NUMEXPR_NUM_THREADS="${NUMEXPR_NUM_THREADS:-1}"
export MALLOC_ARENA_MAX="${MALLOC_ARENA_MAX:-4}"
export PYTHONUNBUFFERED=1
export PYTHONFAULTHANDLER=1

# Current ProcessGroupNCCL diagnostics. The deprecated NCCL_ASYNC_ERROR_HANDLING
# variable is explicitly removed to avoid the warning observed in the supplied log.
unset NCCL_ASYNC_ERROR_HANDLING || true
export TORCH_NCCL_ASYNC_ERROR_HANDLING="${TORCH_NCCL_ASYNC_ERROR_HANDLING:-1}"
export TORCH_NCCL_DUMP_ON_TIMEOUT="${TORCH_NCCL_DUMP_ON_TIMEOUT:-1}"
export TORCH_NCCL_DESYNC_DEBUG="${TORCH_NCCL_DESYNC_DEBUG:-1}"
export TORCH_NCCL_ENABLE_TIMING="${TORCH_NCCL_ENABLE_TIMING:-1}"
export NCCL_DEBUG="${NCCL_DEBUG:-WARN}"
export NCCL_DEBUG_SUBSYS="${NCCL_DEBUG_SUBSYS:-COLL}"

cd "$ROOT"
if [[ "$ROOT" != "$EXPECTED_ROOT" && "${FSP_ALLOW_NONSTANDARD_ROOT:-0}" != "1" ]]; then
  printf 'ERROR: project root is %s, expected %s\n' "$ROOT" "$EXPECTED_ROOT" >&2
  printf 'Extract the release into %s, or set FSP_ALLOW_NONSTANDARD_ROOT=1 only for testing.\n' "$EXPECTED_ROOT" >&2
  exit 2
fi
if [[ ! -x "$FSP_PYTHON" ]]; then
  printf 'ERROR: required Python interpreter is not executable: %s\n' "$FSP_PYTHON" >&2
  exit 2
fi

# PyTorch 2.10+ renamed the generic flight-recorder buffer setting to
# TORCH_FR_BUFFER_SIZE. Older ProcessGroupNCCL releases use
# TORCH_NCCL_TRACE_BUFFER_SIZE. Detect the installed runtime before any child
# process imports torch, so both environments remain warning-free.
read -r FSP_TORCH_MAJOR FSP_TORCH_MINOR < <(
  "$FSP_PYTHON" -c 'import re, torch; m=re.match(r"(\d+)\.(\d+)", torch.__version__); print(*(m.groups() if m else (0, 0)))'
)
if (( FSP_TORCH_MAJOR > 2 || (FSP_TORCH_MAJOR == 2 && FSP_TORCH_MINOR >= 10) )); then
  unset TORCH_NCCL_TRACE_BUFFER_SIZE || true
  export TORCH_FR_BUFFER_SIZE="${TORCH_FR_BUFFER_SIZE:-1048576}"
else
  unset TORCH_FR_BUFFER_SIZE || true
  export TORCH_NCCL_TRACE_BUFFER_SIZE="${TORCH_NCCL_TRACE_BUFFER_SIZE:-1048576}"
fi
if [[ "$FSP_SALIENCY_EXECUTION" != "all_ranks" && "$FSP_SALIENCY_EXECUTION" != "all" && "$FSP_SALIENCY_EXECUTION" != "sharded" && "$FSP_SALIENCY_EXECUTION" != "all_rank_sharded" ]]; then
  printf 'ERROR: FSP_SALIENCY_EXECUTION=%s is unsafe. Use all_ranks.\n' "$FSP_SALIENCY_EXECUTION" >&2
  exit 2
fi

# Raise the soft descriptor limit as far as cluster policy permits.
current_hard="$(ulimit -Hn)"
target_nofile="$FSP_NOFILE_LIMIT"
if [[ "$current_hard" != "unlimited" ]] && (( target_nofile > current_hard )); then
  target_nofile="$current_hard"
fi
ulimit -Sn "$target_nofile" 2>/dev/null || true

STATUS_ROOT="${FSP_STATUS_ROOT:-outputs/_orchestrator}"
mkdir -p "$STATUS_ROOT/logs" "$STATUS_ROOT/matplotlib/driver" "$STATUS_ROOT/flight_recorder"
if [[ -n "${TORCH_FR_BUFFER_SIZE:-}" ]]; then
  export TORCH_FR_DUMP_TEMP_FILE="${TORCH_FR_DUMP_TEMP_FILE:-$STATUS_ROOT/flight_recorder/rank_}"
else
  export TORCH_NCCL_DEBUG_INFO_TEMP_FILE="${TORCH_NCCL_DEBUG_INFO_TEMP_FILE:-$STATUS_ROOT/flight_recorder/rank_}"
fi
export MPLBACKEND=Agg
export MPLCONFIGDIR="$STATUS_ROOT/matplotlib/driver"
RUN_LOG="$STATUS_ROOT/run_all.log"
FAILURE_FILE="$STATUS_ROOT/RUN_ALL_FAILED.json"
SUCCESS_FILE="$STATUS_ROOT/RUN_ALL_COMPLETED.json"
LOCK_DIR=""
CURRENT_STAGE_PID=""
rm -f "$FAILURE_FILE" "$SUCCESS_FILE"

# Prevent two run_all instances from assigning the same GPUs/output directories.
if command -v flock >/dev/null 2>&1; then
  exec 9>"$STATUS_ROOT/run_all.lock"
  if ! flock -n 9; then
    printf 'ERROR: another run_all.sh holds %s/run_all.lock\n' "$STATUS_ROOT" >&2
    exit 3
  fi
else
  LOCK_DIR="$STATUS_ROOT/run_all.lockdir"
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    printf 'ERROR: another run_all.sh appears active (%s)\n' "$LOCK_DIR" >&2
    exit 3
  fi
fi

write_failure() {
  local exit_code=$1
  local line_no=$2
  local reason=$3
  "$FSP_PYTHON" - "$FAILURE_FILE" "$exit_code" "$line_no" "$reason" <<'PY' || true
import json, os, socket, sys, time
path, code, line, reason = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
payload = {
    "status": "failed",
    "pipeline_version": "fsp-v5-spectral-reliance",
    "exit_code": code,
    "line": line,
    "reason": reason,
    "time_unix": time.time(),
    "host": socket.gethostname(),
    "pid": os.getpid(),
}
with open(path + ".tmp", "w", encoding="utf-8") as handle:
    json.dump(payload, handle, indent=2)
os.replace(path + ".tmp", path)
PY
}

terminate_current_stage() {
  if [[ -n "$CURRENT_STAGE_PID" ]] && kill -0 "$CURRENT_STAGE_PID" 2>/dev/null; then
    kill -TERM -- "-$CURRENT_STAGE_PID" 2>/dev/null || kill -TERM "$CURRENT_STAGE_PID" 2>/dev/null || true
    local deadline=$((SECONDS + ${FSP_CHILD_TERM_GRACE_SECONDS:-20}))
    while kill -0 "$CURRENT_STAGE_PID" 2>/dev/null && (( SECONDS < deadline )); do sleep 0.2; done
    if kill -0 "$CURRENT_STAGE_PID" 2>/dev/null; then
      kill -KILL -- "-$CURRENT_STAGE_PID" 2>/dev/null || kill -KILL "$CURRENT_STAGE_PID" 2>/dev/null || true
    fi
  fi
}

cleanup_lock() {
  if [[ -n "$LOCK_DIR" ]]; then rmdir "$LOCK_DIR" 2>/dev/null || true; fi
}

on_error() {
  local exit_code=$?
  local line_no=${1:-0}
  trap - ERR INT TERM
  terminate_current_stage
  write_failure "$exit_code" "$line_no" "command_error"
  cleanup_lock
  printf 'run_all.sh failed at line %s (exit %s). See %s and %s/logs.\n' \
    "$line_no" "$exit_code" "$RUN_LOG" "$STATUS_ROOT" >&2
  exit "$exit_code"
}

on_signal() {
  local signal_name=$1
  trap - ERR INT TERM
  terminate_current_stage
  write_failure 130 0 "signal:$signal_name"
  cleanup_lock
  printf 'run_all.sh interrupted by %s; child process groups were terminated.\n' "$signal_name" >&2
  exit 130
}

trap 'on_error $LINENO' ERR
trap 'on_signal INT' INT
trap 'on_signal TERM' TERM
trap cleanup_lock EXIT

FAILED_STAGES=()
# Research stages run to completion even if one of them reports failed runs:
# a single broken ablation variant must not prevent the ViT and transfer stages
# from running (this aborted the v4.0 pipeline). The final status is still
# "failed" when any stage failed, and RUN_ALL_FAILED.json lists the stages.
run_stage_soft() {
  local name=$1
  if ! run_stage "$@"; then
    FAILED_STAGES+=("$name")
    printf 'Stage %s reported failures; continuing with the remaining stages (FSP_STOP_ON_STAGE_FAILURE=1 to stop).\n' "$name" | tee -a "$RUN_LOG"
    if [[ "${FSP_STOP_ON_STAGE_FAILURE:-0}" == "1" ]]; then
      return 1
    fi
  fi
  return 0
}

# Extra --set overrides applied to every research stage: "key=value;key2=value2".
EXTRA_SET_ARGS=()
if [[ -n "${FSP_EXTRA_SETS:-}" ]]; then
  IFS=';' read -r -a _extra_sets <<< "$FSP_EXTRA_SETS"
  for item in "${_extra_sets[@]}"; do
    [[ -n "$item" ]] && EXTRA_SET_ARGS+=(--set "$item")
  done
fi
export RESNET50_WEIGHTS="${RESNET50_WEIGHTS:-DEFAULT}"

run_stage() {
  local name=$1
  shift
  printf '\n===== [%s] %s =====\n' "$(date --iso-8601=seconds)" "$name" | tee -a "$RUN_LOG"
  set +e
  if command -v setsid >/dev/null 2>&1; then
    setsid "$@" > >(tee -a "$RUN_LOG") 2>&1 &
  else
    "$@" > >(tee -a "$RUN_LOG") 2>&1 &
  fi
  CURRENT_STAGE_PID=$!
  wait "$CURRENT_STAGE_PID"
  local code=$?
  CURRENT_STAGE_PID=""
  set -e
  if (( code != 0 )); then
    return "$code"
  fi
}

write_success() {
  local mode=$1
  local lambda_value=${2:-}
  local cutoff_value=${3:-}
  "$FSP_PYTHON" - "$SUCCESS_FILE" "$mode" "$lambda_value" "$cutoff_value" <<'PY'
import json, os, socket, sys, time
path, mode, lam, cutoff = sys.argv[1:]
payload = {
    "status": "completed",
    "mode": mode,
    "pipeline_version": "fsp-v5-spectral-reliance",
    "time_unix": time.time(),
    "host": socket.gethostname(),
    "results": "outputs/all_results.csv" if mode == "full" else "outputs/smoke/run_all_entrypoint/summary.json",
}
if lam:
    payload["lambda"] = float(lam)
if cutoff:
    payload["cutoff"] = float(cutoff)
with open(path + ".tmp", "w", encoding="utf-8") as handle:
    json.dump(payload, handle, indent=2)
os.replace(path + ".tmp", path)
PY
}

# This two-process CPU/Gloo probe validates the exact status/error control-plane
# protocol that replaces the failing asymmetric NCCL broadcast path.
if [[ "${FSP_SKIP_DISTRIBUTED_SELFTEST:-0}" != "1" ]]; then
  run_stage distributed_control_plane_selftest \
    env CUDA_VISIBLE_DEVICES="" FSP_DISTRIBUTED_TIMEOUT_SECONDS=120 \
    "$FSP_PYTHON" -m torch.distributed.run --standalone --nproc_per_node=2 \
    scripts/distributed_collective_selftest.py
fi

if [[ "${FSP_SMOKE_ONLY:-0}" == "1" ]]; then
  run_stage preflight_smoke \
    "$FSP_PYTHON" scripts/preflight_h200.py \
      --project-root "$ROOT" \
      --python "$FSP_PYTHON" \
      --expected-gpus 0 \
      --allow-cpu \
      --output "$STATUS_ROOT/preflight_smoke.json" \
      --strict
  run_stage smoke_pipeline \
    "$FSP_PYTHON" train.py \
      --config configs/smoke_test.yaml \
      --run-dir outputs/smoke/run_all_entrypoint \
      --set experiment.overwrite=true
  run_stage smoke_pipeline_taylor_aug \
    "$FSP_PYTHON" train.py \
      --config configs/smoke_test.yaml \
      --run-dir outputs/smoke/run_all_entrypoint_taylor_aug \
      --set pruning.method=taylor \
      --set train.frequency_augment=true \
      --set visualization.fourier_heatmap=false \
      --set visualization.layer_heatmap=false \
      --set experiment.overwrite=true
  run_stage smoke_collect \
    "$FSP_PYTHON" tools/collect_results.py --root outputs/smoke --output outputs/smoke/results.csv
  write_success smoke
  printf '\nSmoke-only run_all.sh completed.\n' | tee -a "$RUN_LOG"
  exit 0
fi

preflight_args=(
  --project-root "$ROOT"
  --python "$FSP_PYTHON"
  --expected-gpus 8
  --dataset "imagenet=$IMAGENET_ROOT"
  --dataset "imagenet_c=$IMAGENET_C_ROOT"
  --output "$STATUS_ROOT/preflight.json"
  --strict
)
if [[ "${SKIP_TRANSFER:-0}" != "1" ]]; then
  _transfer_datasets="${TRANSFER_DATASETS:-dtd,cub_200_2011}"
  if [[ ",$_transfer_datasets," == *",neu_cls,"* ]]; then preflight_args+=(--dataset "neu=$NEU_ROOT"); fi
  if [[ ",$_transfer_datasets," == *",dtd,"* ]]; then preflight_args+=(--dataset "dtd=$DTD_ROOT"); fi
  if [[ ",$_transfer_datasets," == *",cub_200_2011,"* ]]; then preflight_args+=(--dataset "cub=$CUB_ROOT"); fi
fi
run_stage preflight "$FSP_PYTHON" scripts/preflight_h200.py "${preflight_args[@]}"

if [[ "${FSP_RUN_UNIT_TESTS:-0}" == "1" ]]; then
  run_stage unit_tests "$FSP_PYTHON" -m pytest -q
fi

# v5: the legacy lambda/profile tuning of spectral_steering is skipped by default.
if [[ "${SKIP_TUNING:-1}" != "1" ]]; then
  run_stage_soft tuning \
    "$FSP_PYTHON" tune.py \
      --config configs/tune_v4.yaml \
      --output-root "${TUNING_OUTPUT:-outputs/tuning/resnet50}" \
      --status-root "$STATUS_ROOT" \
      --lambdas "${LAMBDAS:-0.5,1.0,2.0}" \
      --profiles "${PROFILES:-auto,reliance}" \
      --set "data.root=$IMAGENET_ROOT" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

LAMBDA="${LAMBDA:-0.25}"
PROFILE="${PROFILE:-auto}"
CUTOFF="${CUTOFF:-0.25}"
export LAMBDA PROFILE CUTOFF
printf 'Spectral Reliance Pruning: lambda=%s (legacy profile=%s cutoff=%s)\n' "$LAMBDA" "$PROFILE" "$CUTOFF" | tee -a "$RUN_LOG"

# ---------------------------------------------------------------------------
# Stage 0 (minutes, off by default: SKIP_CONTROLLED=0 to enable): controlled
# frequency tasks with known band reliance. Seed-to-seed spread is 5-10 points,
# so it is a smoke test of mechanisms, never transfer evidence.
# ---------------------------------------------------------------------------
if [[ "${SKIP_CONTROLLED:-1}" != "1" ]]; then
  run_stage_soft controlled \
    "$FSP_PYTHON" tools/controlled_experiment.py \
      --output-root "${CONTROLLED_OUTPUT_ROOT:-outputs/controlled}" \
      --tasks "${CONTROLLED_TASKS:-high,low}" \
      --methods "${CONTROLLED_METHODS:-magnitude,taylor,taylor_global,lfs,srp,srp_lambda1,srp_od,srp_od_only,srp_pass,srp_low,rfc,taylor_global_rpr}" \
      --seeds "${CONTROLLED_SEEDS:-0,1,2,3,4}" \
      --target "${CONTROLLED_TARGET:-0.8}"
fi

# ---------------------------------------------------------------------------
# Stage 1 (fast loop, hours): transfer tasks. This is where the task-specialisation
# hypotheses are decided; it runs first so that verdicts arrive before the
# multi-day ImageNet stages.
# ---------------------------------------------------------------------------
if [[ "${SKIP_TRANSFER:-0}" != "1" ]]; then
  transfer_extra_args=()
  if [[ -n "$TRANSFER_EXTRA" ]]; then
    IFS=';' read -r -a _extra_items <<< "$TRANSFER_EXTRA"
    for item in "${_extra_items[@]}"; do
      [[ -n "$item" ]] && transfer_extra_args+=(--extra "$item")
    done
  fi
  if [[ -n "${TRANSFER_TV:-}" ]]; then
    IFS=';' read -r -a _tv_items <<< "$TRANSFER_TV"
    for item in "${_tv_items[@]}"; do
      [[ -n "$item" ]] && transfer_extra_args+=(--tv "$item")
    done
  fi
  if [[ "${FSP_DOWNLOAD:-0}" == "1" ]]; then
    transfer_extra_args+=(--download)
  fi
  if [[ "${FSP_DENSE_GATE:-1}" != "1" ]]; then
    transfer_extra_args+=(--no-dense-gate)
  fi
  transfer_method_args=()
  if [[ -n "${TRANSFER_METHODS:-}" ]]; then
    transfer_method_args+=(--methods "$TRANSFER_METHODS")
  fi
  run_stage_soft transfer \
    "$FSP_PYTHON" transfer.py \
      --config configs/transfer_v4.yaml \
      --datasets "${TRANSFER_DATASETS:-dtd,cub_200_2011}" \
      --models "${TRANSFER_MODELS:-resnet50,deit_base_patch16_224}" \
      ${transfer_method_args[@]+"${transfer_method_args[@]}"} \
      --sparsities "$FSP_TRANSFER_SPARSITIES" \
      --seeds "${FSP_TRANSFER_SEEDS:-42,43,44}" \
      --output-root "${TRANSFER_OUTPUT_ROOT:-outputs/transfer}" \
      --status-root "$STATUS_ROOT" \
      --neu-root "$NEU_ROOT" \
      --dtd-root "$DTD_ROOT" \
      --cub-root "$CUB_ROOT" \
      ${transfer_extra_args[@]+"${transfer_extra_args[@]}"} \
      --set "pruning.spectral.lambda=$LAMBDA" \
      --set "pruning.cutoff=$CUTOFF" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

# ---------------------------------------------------------------------------
# Stage 1b (hours): the same transfer tasks at equal MEASURED latency (ViT).
# At equal MACs the globally ranked DeiT reached 1.15x and the per-layer one
# 1.78x, so the MAC-matched ViT comparison is not a speed-matched one.
# ---------------------------------------------------------------------------
if [[ "${SKIP_LATENCY:-0}" != "1" && "${SKIP_TRANSFER:-0}" != "1" ]]; then
  run_stage_soft transfer_latency \
    "$FSP_PYTHON" transfer.py \
      --config configs/transfer_v4.yaml \
      --datasets "${TRANSFER_DATASETS:-dtd,cub_200_2011}" \
      --models "${LATENCY_MODELS:-deit_base_patch16_224}" \
      --methods "${LATENCY_METHODS:-dense,random,magnitude,taylor,taylor_mean,taylor_mix0,taylor_mix0.5,taylor_global,taylor_auto}" \
      --sparsities "${FSP_LATENCY_TARGETS:-0.3}" \
      --seeds "${FSP_TRANSFER_SEEDS:-42,43,44}" \
      --output-root "${LATENCY_OUTPUT_ROOT:-outputs/latency}" \
      --status-root "$STATUS_ROOT" \
      --neu-root "$NEU_ROOT" \
      --dtd-root "$DTD_ROOT" \
      --cub-root "$CUB_ROOT" \
      ${transfer_extra_args[@]+"${transfer_extra_args[@]}"} \
      --set "pruning.budget=latency" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

# ---------------------------------------------------------------------------
# Stage 1c (hours): ImageNet ResNet-50 with scarce recovery data. Tests whether
# the amount of recovery data, not the identity of the task, decides which
# cross-layer calibration wins (hypothesis G3).
# ---------------------------------------------------------------------------
if [[ "${SKIP_LOWDATA:-0}" != "1" ]]; then
  run_stage_soft lowdata \
    "$FSP_PYTHON" main_experiments.py \
      --models "${LOWDATA_MODELS:-resnet50}" \
      --methods "${LOWDATA_METHODS:-dense,random,magnitude,taylor,taylor_mean,taylor_mix0,taylor_mix0.25,taylor_mix0.5,taylor_global,taylor_auto}" \
      --sparsities "${FSP_LOWDATA_SPARSITIES:-0.5}" \
      --seeds "${FSP_LOWDATA_SEEDS:-42,43,44}" \
      --output-root "${LOWDATA_OUTPUT_ROOT:-outputs/lowdata}" \
      --status-root "$STATUS_ROOT" \
      --lambda "$LAMBDA" \
      --profile "$PROFILE" \
      --cutoff "$CUTOFF" \
      --imagenet-root "$IMAGENET_ROOT" \
      --imagenet-c-root "" \
      --resnet50-weights "$RESNET50_WEIGHTS" \
      --skip-figures \
      --set "data.train_subset_size=${LOWDATA_TRAIN_SIZE:-128000}" \
      --set "evaluation.eval_imagenet_c=false" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

# ---------------------------------------------------------------------------
# Stage 1d (about 16 h on 8 GPUs): specialisation to one family of corruptions,
# judged per ImageNet-C family, not on the average (docs/RESEARCH_PLAN_V7.md).
#   A  ralloc_*        layer-wise sparsity from frequency robustness (unit selection: Taylor)
#   B  *_noise_*       recovery on images with band-limited noise added
#      *_aug_*         recovery on images with a band removed
#   A+B ralloc_*_noise_*   both together
# Dense counterparts show whether pruning changes the trade-off.
# ---------------------------------------------------------------------------
if [[ "${SKIP_SPECIALIZE:-0}" != "1" ]]; then
  run_stage_soft specialize \
    "$FSP_PYTHON" main_experiments.py \
      --models "${SPECIALIZE_MODELS:-resnet50}" \
      --methods "${SPECIALIZE_METHODS:-dense,taylor_mix0,ralloc_hi,ralloc_lo,ralloc_all,ralloc_hi_a1,ralloc_lo_a1,taylor_mix0_noise_hi,taylor_mix0_noise_lo,taylor_mix0_aug_hi,taylor_mix0_aug_lo,ralloc_hi_noise_hi,ralloc_lo_noise_lo,dense_finetuned_noise_hi,dense_finetuned_noise_lo}" \
      --sparsities "${FSP_SPECIALIZE_SPARSITIES:-0.5}" \
      --seeds "${FSP_SPECIALIZE_SEEDS:-42}" \
      --output-root "${SPECIALIZE_OUTPUT_ROOT:-outputs/specialize}" \
      --status-root "$STATUS_ROOT" \
      --lambda "$LAMBDA" \
      --profile "$PROFILE" \
      --cutoff "$CUTOFF" \
      --imagenet-root "$IMAGENET_ROOT" \
      --imagenet-c-root "$IMAGENET_C_ROOT" \
      --imagenet-sketch-root "$IMAGENET_SKETCH_ROOT" \
      --stylized-imagenet-root "$STYLIZED_IMAGENET_ROOT" \
      --resnet50-weights "$RESNET50_WEIGHTS" \
      --skip-figures \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

# ---------------------------------------------------------------------------
# Stage 2 (days): ImageNet with full recovery data, the source task.
# ---------------------------------------------------------------------------
if [[ "${SKIP_MAIN:-0}" != "1" ]]; then
  run_stage_soft main_experiments \
    "$FSP_PYTHON" main_experiments.py \
      --models "${MODELS:-resnet50,efficientnet_b4}" \
      --methods "${METHODS:-dense,dense_finetuned,random,magnitude,lfs,taylor,taylor_mean,taylor_mix0,taylor_mix0.25,taylor_mix0.5,taylor_global,taylor_auto}" \
      --sparsities "$FSP_SPARSITIES" \
      --seeds "$FSP_SEEDS" \
      --output-root "${OUTPUT_ROOT:-outputs/main}" \
      --status-root "$STATUS_ROOT" \
      --lambda "$LAMBDA" \
      --profile "$PROFILE" \
      --cutoff "$CUTOFF" \
      --imagenet-root "$IMAGENET_ROOT" \
      --imagenet-c-root "$IMAGENET_C_ROOT" \
      --imagenet-sketch-root "$IMAGENET_SKETCH_ROOT" \
      --stylized-imagenet-root "$STYLIZED_IMAGENET_ROOT" \
      --resnet50-weights "$RESNET50_WEIGHTS" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

if [[ "${SKIP_VIT:-0}" != "1" ]]; then
  run_stage_soft vit_ablation \
    "$FSP_PYTHON" vit_ablation.py \
      --config configs/vit_v4.yaml \
      --models "${VIT_MODELS:-deit_base_patch16_224,vit_b_16}" \
      --methods "${VIT_METHODS:-dense,dense_finetuned,random,magnitude,lfs,taylor,taylor_mean,taylor_mix0,taylor_mix0.5,taylor_global,taylor_auto}" \
      --sparsities "$FSP_VIT_SPARSITIES" \
      --seeds "$FSP_SEEDS" \
      --output-root "${VIT_OUTPUT_ROOT:-outputs/vit}" \
      --status-root "$STATUS_ROOT" \
      --set "data.root=$IMAGENET_ROOT" \
      --set "data.imagenet_c_root=$IMAGENET_C_ROOT" \
      --set "data.imagenet_sketch_root=$IMAGENET_SKETCH_ROOT" \
      --set "data.stylized_imagenet_root=$STYLIZED_IMAGENET_ROOT" \
      --set "pruning.spectral.lambda=$LAMBDA" \
      --set "pruning.cutoff=$CUTOFF" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

if [[ "${SKIP_ABLATIONS:-1}" != "1" ]]; then
  run_stage_soft ablations \
    "$FSP_PYTHON" ablations.py \
      --config configs/imagenet_resnet50_v4.yaml \
      --arch "${ABLATION_ARCH:-resnet50}" \
      --variants "${ABLATION_VARIANTS:-taylor,taylor_global,magnitude,srp,srp_lambda0,srp_lambda1,srp_od,srp_pass,srp_low,srp_zscore,rfc,rfc_zscore}" \
      --sparsities "$FSP_ABLATION_SPARSITIES" \
      --seeds "$FSP_SEEDS" \
      --output-root "${ABLATION_OUTPUT_ROOT:-outputs/ablations}" \
      --status-root "$STATUS_ROOT" \
      --set "data.root=$IMAGENET_ROOT" \
      --set "data.imagenet_c_root=$IMAGENET_C_ROOT" \
      --set "pruning.spectral.lambda=$LAMBDA" \
      ${EXTRA_SET_ARGS[@]+"${EXTRA_SET_ARGS[@]}"}
fi

run_stage aggregate \
  "$FSP_PYTHON" tools/collect_results.py \
    --root outputs \
    --output outputs/all_results.csv

# Automated audit: dense gate, rankings with noise bands, hypothesis verdicts and
# the paper-readiness gate (outputs/analysis/analysis_report.md).
run_stage_soft analysis \
  "$FSP_PYTHON" tools/analyze_results.py \
    --results outputs/all_results.csv \
    --output-dir outputs/analysis

run_stage_soft figures \
  "$FSP_PYTHON" tools/make_figures.py \
    --results outputs/all_results.csv \
    --output-dir outputs/figures

if (( ${#FAILED_STAGES[@]} > 0 )); then
  joined=$(IFS=,; printf '%s' "${FAILED_STAGES[*]}")
  write_failure 1 0 "stage_failures:${joined}"
  printf '\nCompleted with failed stages: %s. See %s and outputs/_orchestrator/logs/.\n' "$joined" "$FAILURE_FILE" | tee -a "$RUN_LOG"
  exit 1
fi
write_success full "$LAMBDA" "$CUTOFF"
printf '\nAll stages completed. Results: %s  Figures: %s\n' "$ROOT/outputs/all_results.csv" "$ROOT/outputs/figures" | tee -a "$RUN_LOG"
