# v4.0 実行結果の分析と v4.1 への改訂（2026-11-10）

対象：`analysis_download.zip`（tuning 6 run、main 36 run、ablations 15/16 run、seed 42 のみ）。
vit / transfer stage は ablations の 1 run（`spectral_noise`）の失敗で run_all.sh が停止したため未実行。

## 1. Dense の妥当性（最優先確認）

| モデル | 本実験 dense top-1 | 公称値（torchvision） | 判定 |
|---|---|---|---|
| ResNet-50 (IMAGENET1K_V2) | 80.83 | 80.86 | ○（差 0.03） |
| EfficientNet-B4 | 83.44 | 83.38 | ○ |

v3 の 47% は解消。ImageNet-C 平均 top-1 は ResNet-50 48.6 / EfficientNet-B4 56.8 で妥当な範囲。
ただし `dense_finetuned`（18 epoch の追加学習）は ResNet-50 で 80.83 → 79.63、ImageNet-C 48.6 → 46.2（低周波破損 56.3 → 49.6）と**劣化**。
V2 重みは強い augmentation（TrivialAugment, mixup/cutmix, EMA, 600 epoch）で得られたもので、本実験の素朴な回復レシピ（RRC+flip, LS, lr 0.01）では
その利得を保てない。全プルーニング手法はこの「レシピ損失」約 1.2 pt を共通に被っている。

## 2. 主結果（ImageNet）

### 2.1 単位スパース率は公平な比較軸ではない

同じ単位スパース率 0.5 でも MAC 削減率は magnitude 58.5% / random 55.3% / spectral 62.4% / taylor 64.9% / hap 64.5%。
Taylor 系（gate 勾配）は早期の高解像度層（1 ch あたりの MAC が大きい）を多く削るため、同じ単位数でより多くの MAC を削り、精度も多く落ちる。
sp50/sp70 の 2 点を線形補間して **iso-MAC** で比べると（ResNet-50）：

| method | top-1 @65% MAC | @74% MAC | ImageNet-C @65% |
|---|---|---|---|
| magnitude | 74.2 | 71.7 | 34.5 |
| taylor | 74.2 | 69.5 | 33.2 |
| lfs（VTC-LFC 型） | 74.1 | 70.2 | 33.9 |
| frequency_steering（v3） | 73.9 | 70.5 | 33.6 |
| **spectral_steering（auto, λ=0.5）** | **73.2** | **68.9** | **33.6** |
| hap | 73.3 | 68.3 | 31.9 |

EfficientNet-B4 でも同様（@55% MAC：magnitude 76.4 / taylor 76.4 / lfs 76.0 / spectral 75.2）。
**結論：ImageNet のクリーン精度・ImageNet-C 平均では、Spectral-Steering は iso-MAC で Taylor-FO とほぼ同等かやや下（−0.5〜−1 pt）。優位ではない。**

### 2.2 制御可能性（唯一の明確な正の結果）

steering gain（‖r̂−ŝ‖₁ の減少量）：spectral 0.102 / 0.048（ResNet-50 sp50/70）、0.069 / 0.154（EffNet）に対し、他手法はすべて ≈0 または負。
dense ResNet-50 の依存プロファイル r̂ = [0.56, 0.14, 0.18, 0.12]（低域依存）に対し感度 ŝ = [0.02, 0.08, 0.22, 0.67]（高域に過敏）という大きな不整合が存在し（L1 = 1.20）、
Spectral-Steering はこれを ŝ = [0.05, 0.11, 0.28, 0.56] まで動かす。band-stop 精度も整合（低域除去時の精度 26.9 → 18.0：低域への依存が増える）。
EfficientNet では taylor/magnitude のプルーニングが高域感度を **増やす**（0.57 → 0.73 / 0.80）のに対し、spectral は 0.53 に保つ。
**「通常のプルーニングは周波数感度を高域へ漂流させ、提案法はそれを制御できる」は実データで成立。**

### 2.3 一次の帯域感度は有限振幅の頑健性を予測しない（仮説の否定）

ResNet-50 のプルーニング済み 28 run で、ImageNet-C 高域破損（noise 3 種）の精度を回帰すると
`C_high ≈ −104.6 + 1.69·top1 + 7.7·s_high`（R² = 0.93）。クリーン精度で 93% が説明され、
クリーン精度を除いた残差と高域感度 s_high の相関は +0.19（符号が理論と逆、かつ弱い）、steering gain との相関は 0.04。
つまり **入力勾配の帯域パワー（無限小摂動）を下げても、severity 1–5 の有限振幅ノイズへの頑健性はクリーン精度以上には改善しない**。
Yin et al. の heat map は有限ノルム摂動で定義されており、本実験の一次量とは別物であることが実証的に示された形。
→ ImageNet での「頑健性の物語」は成立しない。論文の主張は（i）制御可能性と（ii）転移タスクでのタスク特化に絞るべき。

### 2.4 速度：MAC 削減は GPU 速度にほぼ変換されていない

`measured_speedup` は masked（ゲート付き）モデルに対する比で、ゲートの overhead（ResNet-50 で 1.24 倍、EffNet で 1.61 倍）を含むため過大。
dense の slim モデルを基準に取り直すと、ResNet-50 bf16 batch128 H100 で MAC −58〜65% に対し **0.96〜1.12 倍**（magnitude/random は dense より遅い）。
原因：グローバルプルーニングが生む不規則なチャネル数（8 の倍数でない）と tensor core の効率低下。
v4.1 では (a) 保持チャネル数を 8 の倍数に揃える `channel_alignment`、(b) dense 基準の `speedup_vs_dense`、(c) batch 1/32/128 の計測を導入。

## 3. ablations の有効性

| 変種 | 有効か | 結果（sp50, ResNet-50） |
|---|---|---|
| spectral_high / low / reliance / flat / lambda0.5 / lambda2 | **無効**（run_all の `--set lambda/profile` が変種設定を上書き：全て auto, λ=0.5 の再実行になった） | 74.37–74.54（同一設定の再実行 6 本 → run 間ばらつきの推定値 ±0.1 pt） |
| spectral_filtered（VTC-LFC 型推定器） | 有効 | 75.46 @60.9% MAC、steering gain 0.037（≒ 操舵できない） |
| spectral_unsigned / bands8 / norecal | 有効 | 74.60 / 74.35 / 74.49（ノイズ範囲内） |
| spectral_nokd / taylor_nokd | 有効 | KD なしの方が +0.2〜0.3 pt。LS で学習された教師からの KD は効かない（Müller et al. 2019 と整合） |
| taylor_fourier_aug | 有効 | 71.50（−2.7 pt）。band-stop 精度は大幅に向上（低域除去 25.5 → 49.9）するが高域破損には悪化 |
| spectral_noise（元の有限振幅案） | 失敗 | `torch.randint(..., generator=cuda)` に device 未指定（修正済み） |

同一設定 6 本の範囲 74.37–74.54 から、Taylor 系手法間の差（74.2–74.7）は **有意ではない**。seed 3 本以上が必須。

## 4. 理論的な整理

1. **Taylor 系が MAC を多く削る理由**：層ごと z-score 後も分布の裾の重さが層で異なり、勾配ベースのスコアは高解像度層で裾が重いため、グローバル閾値で早期層が多く削られる。早期層のチャネルは MAC が大きく、かつ高周波フィルタが多い。→ 低域方向の誘導は「早期の高周波フィルタを先に削る」と等価になり、MAC 削減率が上がり、単位数基準の比較では不利に見える。**MAC 予算での比較が必須**。
2. **なぜ ImageNet で精度利得がないか**：ImageNet のクリーン精度は高周波成分を活用して得られている（Wang et al., CVPR 2020）。低域方向の誘導は有用な高周波特徴も捨てるため、iso-MAC で精度は上がらない。理論的に予想された通りで、利得が期待できるのは依存プロファイルが ImageNet と大きく異なる転移タスク（テクスチャ・欠陥＝高域依存、場面・スケッチ＝低域依存）。
3. **一次感度 vs 有限頑健性**：2.3 の通り、無限小摂動への感度と大振幅ノイズへの頑健性は別の量。頑健性を主張するなら有限振幅の Fourier heat map（既存の可視化）か ImageNet-C そのものを目標にする必要がある。
4. **回復学習による再感作（仮説）**：短い回復（tuning: 2 round × 1 epoch）では steering gain 0.19–0.20、18 epoch の main では 0.10–0.12。回復学習が感度を高域へ戻す可能性。v4.1 で各 round の「刈り直後／BN 再校正後／回復後」の感度を記録し、一次予測 −Σc_{g,b} と実測 ΔS_b の一致も検証する。
5. **帯域面積の影響**：外周帯域（r ≥ 0.5）は周波数平面の約 80% を占めるため、extensive な感度プロファイルは平坦な応答でも高域優勢になる。周波数あたり密度で見ると dense ResNet-50 は [0.30, 0.34, 0.23, 0.13] と低域の方が高感度。目標 w の定義は perturbation の分布（白色雑音＝extensive、自然画像 1/f＝density 寄り）に依存する。v4.1 で `profile_normalization: density` をアブレーションに追加。

## 5. v4.1 の変更点

- バグ修正：`spectral_noise` の CUDA generator、ablations/vit の上書き順序（変種設定が最後に適用される）、stage 失敗時も後続 stage を継続（`run_stage_soft`）、失敗しても結果を集計。
- **MAC 予算**（`pruning.budget: macs`）：ランキングの prefix を二分探索し、物理 export 後の MAC 削減率が目標に達する最小集合を選ぶ。全手法が同じ MAC 予算で比較される。
- **チャネル整列**（`pruning.channel_alignment: 8`）：保持チャネル数を 8 の倍数へ（head は対象外）。
- 速度：`speedup_vs_dense`（dense slim 基準）、batch 1/32/128 の throughput。
- 感度の軌跡：round ごとに刈り直後・再校正後・回復後の ŝ、一次予測と実測の相対変化を記録（`spectral_trajectory`）。
- `kept_fraction_by_group`（層ごとの保持率）を summary と図に追加。
- KD は ImageNet 設定で既定 off（アブレーション `spectral_kd`/`taylor_kd` で再検証）。transfer では on のまま。
- 新規アブレーション：λ ∈ {0.1, 0.25, 1, 2, 4}、`spectral_density`、`spectral_current`、`spectral_units`／`taylor_units`／`magnitude_units`（単位予算との対照）。
- `RESNET50_WEIGHTS=IMAGENET1K_V1`（既存論文と同じ 76.13 基準で比較する表を作るため）、`FSP_EXTRA_SETS="key=value;..."`（レシピ検証用の一括上書き）。

## 6. 次に回す順序（提案）

1. `mv outputs outputs_v4.0`（旧プロトコルの結果は比較不能なので退避）。
2. `SKIP_TUNING=1 LAMBDA=0.5 PROFILE=auto METHODS=dense,dense_finetuned,magnitude,taylor,lfs,spectral_steering FSP_SPARSITIES=0.5,0.7 FSP_SEEDS=42,43,44 bash run_all.sh`
   （MAC 予算・整列・KD off・速度計測の新プロトコルで主結果を取り直し、ablations/vit/transfer まで通す）。
3. 転移に低域依存タスクを追加：`TRANSFER_EXTRA="kth=/localdata/kth_tips2b;sun=/localdata/sun397_sub;sketch=/localdata/imagenet_sketch_cls"`。
4. レシピ検証（任意）：`FSP_EXTRA_SETS="train.lr=0.004" METHODS=dense_finetuned,taylor,spectral_steering FSP_SPARSITIES=0.5 bash run_all.sh` で dense_finetuned の劣化が縮むか確認。
5. 既存論文との対比表：`RESNET50_WEIGHTS=IMAGENET1K_V1 FSP_EXTRA_SETS="train.final_epochs=30" METHODS=dense,taylor,spectral_steering ...`。

## 7. 論文執筆の可否

**まだ早い。** 現時点で成立しているのは「制御可能性」のみで、CVPR の主張に必要な (a) iso-MAC での精度優位、(b) 転移タスクでのタスク特化、(c) 複数 seed、(d) 有効なアブレーション、(e) 実測速度のいずれも未達。
v4.1 の再実行（特に transfer と iso-MAC main）の結果が出た時点で、改めて可否を判断する。
