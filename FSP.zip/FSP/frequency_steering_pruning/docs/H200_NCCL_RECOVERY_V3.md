# H200 NCCL recovery v3

本版は、dense validation直後の非対称NCCL broadcast timeoutを修正し、Frequency-Steering Pruningの数式と構造的プルーニング概念を維持したproduction refactorである。

主な変更は、all-rank sharded saliency、NCCL data planeとGloo control planeの分離、deterministic pruning plan、versioned completion contract、1 GPU/1 independent experimentによる8-way scheduling、DataLoader/FD lifecycle管理、gate-level HAP、および`run_all.sh`への全工程統合である。

唯一のサポート対象コマンドは次である。

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

詳細はリポジトリ直下の`FSP_H200_NCCL_RECOVERY_EXECUTION_PROMPT.md`、`FSP_H200_NCCL_INCIDENT_REPORT.md`、`FSP_H200_NCCL_TEST_MANIFEST.json`を参照する。
