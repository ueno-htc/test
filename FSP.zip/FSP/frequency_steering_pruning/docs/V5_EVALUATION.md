# v5 実行結果の評価（2026-11-19）

対象：`analysis_download_a8bb24.zip`（377 run：controlled 131、transfer 180、main 36、vit 18、ablations 12）。
全 stage 完走。集計は `tools/analyze_results.py`（`docs/figures_v5run/v5run_audit_report.md`）、図は `docs/figures_v5run/`。

## 1. Dense は一般的な数値と遜色ないか → 問題なし

| | 本実験 | 公称／目安 | 判定 |
|---|---|---|---|
| ResNet-50 / ImageNet | 80.83 | 80.86 | ○ |
| EfficientNet-B4 / ImageNet | 83.44 | 83.38 | ○ |
| DeiT-B / ImageNet | 81.82 | 81.80 | ○ |
| ViT-B/16 / ImageNet | 81.03 | 81.07 | ○ |
| ResNet-50 / CUB・DTD（30 epoch 適応、3 seed） | 84.02 / 70.62 | 81–84 / 72–75 | ○ / △（下限付近） |
| DeiT-B / CUB・DTD | 85.04 / 74.04 | 80+ / 70+ | ○ |

v4.1 で学習不足だった転移の dense は解消。`dense_finetuned − dense` は転移で +0.03 pt（差なし）。
ImageNet では引き続き ResNet-50 −1.1、DeiT-B −1.9、ViT-B −2.5 pt で、回復レシピ自体の損失が残っている。

## 2. 提案手法（SRP）は優位か

### 2.1 従来基準に対しては大きく優位（転移、同一 MAC 50%、3 seed × 4 グループ = 12 対）

| 比較 | 平均差 | 勝敗 | p |
|---|---|---|---|
| SRP − Taylor（層ごと z-score） | +3.39 pt | 12/12 | 0.0005 |
| SRP − Magnitude | +7.04 pt | 12/12 | 0.0002 |
| Taylor global − Taylor（z-score） | +3.11 pt | 12/12 | 0.002 |
| Taylor global − LFS（VTC-LFC 型） | +1.79 pt | 10/12 | 0.009 |

グループ別（Taylor global − Taylor z-score）：DTD/ResNet-50 +7.15、CUB/ResNet-50 +3.17、DTD/DeiT-B +1.12、CUB/DeiT-B +1.02。
ResNet-50 ではパラメータ削減率も 62–72% 対 21–25% と大きい（`F2_transfer.png`）。

### 2.2 ただし利得の源は「グローバル順位」であり、帯域依存項ではない

| 比較（転移 12 対） | 平均差 | p |
|---|---|---|
| SRP（λ=0.25）− Taylor global | +0.28 pt | 0.10 |
| SRP（λ=1）− Taylor global | +0.21 pt | 0.30 |
| RFC − Taylor global | +0.07 pt | 0.63 |
| SRP 出力差分 − Taylor global | −0.10 pt | 0.39 |
| SRP band-pass − Taylor global | −0.02 pt | 0.91 |

同値のはずの `srp_lambda0` と `taylor_global` の差が ResNet-50 で 0.3 pt あり、+0.28 pt は誤差の範囲（`F4_band_terms.png`）。
ImageNet（単一 seed、7 設定）では SRP − Taylor global は平均 −0.26 pt。**帯域依存項に実証された効果はない。**

### 2.3 ソースタスク（ImageNet）では一様ではない（単一 seed）

| 設定 | Taylor global − Taylor z-score | 備考 |
|---|---|---|
| ResNet-50 @50% / @70% | **−1.0 / −2.3** | Magnitude が最良（76.9 / 73.5） |
| EfficientNet-B4 @50% / @70% | +0.3 / +0.6 | 誤差の範囲 |
| DeiT-B / ViT-B/16 @50% | +1.4 / +0.7 | ただし実測速度は 1.15 倍 対 1.78 / 1.68 倍 |

自動監査の論文ゲートは **NOT READY**（SRP は最良ベースラインである Taylor global と同等、ImageNet/ResNet-50 では Magnitude に −1.6 pt）。

## 3. 根拠と Ablation による裏付け

1. **順位付け方式が配分を決め、配分が精度を決める**（`F3_allocation.png`）。ResNet-50 @50% の保持率（layer1–4）は、Taylor global で [0.79, 0.66, 0.39, 0.32]（早期層を残す）、Taylor z-score で [0.21, 0.34, 0.56, 0.96]（後段を残す）、Magnitude で [0.50, 0.45, 0.58, 0.67]。ユニットの選び方だけを変える変種（SRP 各種、RFC）は同じ配分になり、精度も同じ。
2. **転移では後段の容量が余っている**。DTD/CUB の ResNet-50 で layer4 を 20–39% まで削っても dense から −1.5〜−3 pt に留まる。逆に z-score は layer1 を 22–29% まで削って −5〜−10 pt。
3. **ImageNet/ResNet-50 では逆**。グローバル順位は刈った直後の損失は低い（1.36 対 2.11）が、回復後の精度は低い。直後の損傷の小ささと、回復後の精度は別物。
4. **ViT ではグローバル順位は attention head を全て残し、MLP チャネルだけを削る**（保持率 heads 1.00、MLP 0.06–0.33）。同じ MAC 削減でも実測速度は 1.15 倍に留まり、head を削る z-score（1.78 倍）と速度が揃っていない。ViT の精度差は速度を揃えて再評価が必要。
5. **飽和した calibration の影響は小さい**：`taylor_augcal − taylor` = +0.54 pt（p = 0.06）。
6. **依存プロファイルのずれ（H2）は棄却**：プール相関 r = −0.38 だが負のグループは 69%（基準 70%）。

### 対照実験についての訂正

前回、CPU・2〜3 seed の対照実験から「帯域項は高周波課題で悪化する」と報告したが、GPU・5 seed の結果では再現しなかった
（SRP λ=0.25 は Taylor global 比 +10.0 pt、p = 0.14。標準偏差が 5–10 pt あり有意ではない）。
対照実験は seed 間のばらつきが大きすぎ、帯域項については**どちらとも言えない**が正しい。再現したのは、
依存保存回復の悪化（−28.5 pt、p = 0.005）と、z-score Taylor・Magnitude がグローバル順位より低いこと（低周波課題で −7.1 / −4.7 pt）である。

## 4. 仮説の判定（v5 事前登録分）

| ID | 判定 | 内容 |
|---|---|---|
| H1 | 支持 | 帯域依存はタスクで異なる（DTD と ImageNet の L1 = 0.35） |
| H2 | 棄却 | 依存のずれは精度を一貫して予測しない |
| H3a/H3b | 支持 | SRP は Taylor z-score・Magnitude に勝つ（ただし下の H4a/H6 により帯域項の寄与ではない） |
| H4a | 判定不能 | SRP − SRP(λ=0) = +0.34 pt、p = 0.07 |
| H4d/H4e | 棄却 | RFC・出力差分は上乗せなし |
| H5 | 判定不能 | 拡張 calibration は +0.54 pt、p = 0.06 |
| H6 | **支持** | グローバル順位 − z-score = +3.11 pt、12/12、p = 0.002 |
| H8 | 棄却 | ImageNet で SRP − Taylor = −0.31 pt（ResNet-50 が −1.3〜−3.1） |
| H9 | 判定不能 | 配分と帯域依存の関係はタスク数不足（ResNet-50 の 3 タスクでは単調） |

## 5. 結論

- **周波数（帯域依存）を選択基準に使う案は、v3・v4・v4.1・v5 の 4 世代すべてで効果が示せなかった。** この主題で CVPR 論文は書けない。
- 一方、実験の過程で**大きく再現性のある効果**が 1 つ見つかった：損失単位のグローバル順位は、転移タスクで従来の層正規化基準を 3〜7 pt（ResNet-50）上回る。
  ただしグローバル Taylor 自体は既知（Molchanov et al., 2019）で、ImageNet/ResNet-50 では逆に 1〜2 pt 劣り、ViT では速度が揃っていない。
- したがって現時点では**論文を書く段階ではない**。v6 では主題を「層間の較正（cross-layer calibration）はタスクとデータ量で最適が変わる」に移し、
  (i) 単一パラメータ族 α での掃引、(ii) 回復データ量が逆転の原因かの因果検証、(iii) 先読みによる自動選択、(iv) 実測速度を揃えた ViT 比較、を行う
  （`docs/HYPOTHESES_V6.md`, `docs/PAPER_LOGIC_V6.md`）。
