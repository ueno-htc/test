# FSP v4 (Spectral-Steering) — 変更点と根拠

## 1. v3 実行結果（`docs/previous_results_v3.csv`）の診断

| 観察 | 原因 | v4 での対処 |
|---|---|---|
| EfficientNet-B4 dense ImageNet top-1 = 47.1%（本来 83.4%）、ViT-B 77.4%（81.1%）、DeiT-B 79.5%（81.8%） | `dense` でも `epochs_before_pruning + final_epochs` の再学習が走り、RMSprop lr=0.005 / AdamW lr=5e-5@batch64 で事前学習重みが劣化 | `dense` は追加学習なし（転移では task-adaptation のみ）。同一予算の `dense_finetuned` を別手法として追加 |
| 構造スパース率 0.9（MAC −84%）で全手法が 52–54% に潰れ、差が消える | 動作点が極端 | `FSP_SPARSITIES=0.5,0.7`（幾何級数 4 段）。Pareto 図を標準出力に |
| 回復学習が短い（ImageNet 計 12 epoch、DTD 70.6→50%） | 予算不足・教師なし | recovery 2×4 + final 10 epoch、dense 教師からの KD、BN 再キャリブレーション |
| ViT で `frequency_steering` と `steering_only` が完全同一 | チューニングで λ=0 が選ばれた＝周波数項が効いていない | 基準を再定式化（下記） |
| `snip`/`frequency_steering` のクリーン項がほぼノイズ | 勾配をキャリブレーション全体で合算してから絶対値（収束済みモデルでは平均勾配 ≈ 0） | gate レベル Taylor-FO をミニバッチごとに絶対値で集計（`taylor`、`spectral_steering`） |
| NEU/CUB で calibration を val から抽出（val = test） | テストリーク | calibration は train split から抽出 |
| EfficientNet-B4 の評価・学習設定 | lr・optimizer が事前学習済みモデルの fine-tune 向きでない | SGD lr 0.005、bf16、384→380 bicubic |

## 2. 基準の再定式化

v3 の `|(g_HP − λ g_LP) w|` は VTC-LFC（NeurIPS 2022）の LFS とほぼ同型で、「低周波を残す」固定方向の派生と見なされる。v4 は次の 3 点で差別化する。

1. **厳密な帯域感度の帰属**：Fourier 基底ノイズに対する一次損失変化は入力勾配の DFT 係数そのものなので、帯域感度 $S_b$ は入力勾配のスペクトルパワーとして（サンプリングなしで）定義でき、単位 $g$ の寄与 $c_{g,b}=(\partial S_b/\partial \text{gate}_g)/S_b$ を double back-propagation で厳密に求める。元の有限振幅ノイズ案（`estimator=noise`）と帯域フィルタ入力案（`estimator=filtered`、VTC-LFC の多帯域版）はアブレーションとして残す。
2. **感度と依存の分離**：band-stop 入力での損失増 $r_b$（タスク依存）と $S_b$（モデル感度）を別に測り、目標重み $w=\hat r-\hat s$ を自動決定する（`target_profile=auto`）。タスクが依存しない帯域にだけ反応する単位（ノイズ増幅器）を優先的に削除し、依存する帯域を支える単位を保護する。両者が一致すれば $w=0$ となり Taylor-FO に帰着する。
3. **双方向・タスク適応**：`high`/`low` の手動方向、`reliance`、`manual` も選べ、DTD/NEU（高域寄り）と SUN397 等（低域寄り）の両方向を同じ機構で扱う。

## 3. 制御可能性の評価

- `dense.spectral` / `final.spectral`：帯域感度 $\hat s$、band-stop 依存 $\hat r$、band-stop top-1
- `profile_mismatch_dense/pruned`、`steering_gain`、`sens_shift_<band>`（`tools/collect_results.py`）
- ImageNet-C を周波数帯で分割（高域：noise 3 種／中域：blur・digital 7 種／低域：weather・contrast 5 種、Yin et al. 2019 に基づく）
- `tools/make_figures.py`：Pareto、プロファイル比較（Fig.1 相当）、steering gain、ImageNet-C 帯域別、Markdown 表（seed 平均±std）

## 4. 実験計画（`run_all.sh`）

| stage | 既定 | 目的 |
|---|---|---|
| tuning | λ∈{0.5,1,2} × profile∈{auto,reliance}、ImageNet val 10k | ハイパラ凍結 |
| main | ResNet-50・EfficientNet-B4 × sp{50,70} × 9 手法 | 主結果（Pareto、ImageNet-C 帯域別） |
| ablations | ResNet-50 sp50 × 16 変種 | 推定器／符号／目標／λ／帯域数／KD／BN 再校正／周波数拡張のみ |
| vit | DeiT-B・ViT-B/16 sp50 × 9 手法 | CNN/ViT 共通性、attention（低域）vs MLP の配分分析 |
| transfer | NEU-CLS・DTD・CUB（＋任意の ImageFolder）× ResNet-50・EfficientNet-B4・DeiT-B | タスク特化の主張。低域依存タスクは `TRANSFER_EXTRA` で追加 |

seed は `FSP_SEEDS=42,43,44` で 3 本に拡張できる（`results_table.md` に平均±std）。

## 5. 残課題（コードでは解決できないもの）

- NEU-CLS は 1800 枚・6 クラスで飽和する。NEU-DET／MVTec／KolektorSDD2／Severstal の分類パッチを `TRANSFER_EXTRA` で加えること。
- 低周波依存タスク（SUN397 の部分集合、ImageNet-Sketch、Stylized-ImageNet）を加えないと「高周波を残すテクスチャ用プルーニング」に矮小化される。
- VTC-LFC（`lfs`）との差が小さく見える場合は `estimator=filtered` との対比（同じ入力操作で、重み付けだけが違う）を前面に出す。
- ImageNet-R は評価対象から外した（`evaluation.eval_imagenet_r=false`、`run_all.sh` からパスを削除）。OOD は ImageNet-C 帯域別と任意の ImageNet-Sketch / Stylized-ImageNet で扱う。
- 本リリースの CPU 検証は実装の完全性のみを保証し、精度・頑健性・統計的有意性は実機実験で確認すること。

## 7. v4.1（2026-11-10）

v4.0 の実行結果（dense は公称値と一致、Spectral-Steering は制御可能性のみ優位、iso-MAC では精度優位なし、
MAC 削減が GPU 速度に変換されていない、ablations の上書き順序バグ、`spectral_noise` の CUDA generator バグ）を受けた改訂。
詳細な分析と変更点は `docs/V4_1_RESULTS_ANALYSIS.md` を参照。
