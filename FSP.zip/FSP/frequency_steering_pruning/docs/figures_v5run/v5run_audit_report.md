# Automated results audit

## 1. Dense gate

| stage | dataset | arch | dense top-1 | reference / minimum | status |
|---|---|---|---|---|---|
| controlled | bandtask_joint | resnet18 | 97.27 | >= 0.0 | OK |
| controlled | bandtask_high | resnet18 | 76.81 | >= 0.0 | OK |
| controlled | bandtask_low | resnet18 | 95.78 | >= 0.0 | OK |
| main | imagenet | efficientnet_b4 | 83.44 | 83.38 ± 0.3 | OK |
| main | imagenet | resnet50 | 80.83 | 80.86 ± 0.3 | OK |
| transfer | cub_200_2011 | deit_base_patch16_224 | 85.04 | >= 80.0 | OK |
| transfer | cub_200_2011 | resnet50 | 84.02 | >= 80.0 | OK |
| transfer | dtd | deit_base_patch16_224 | 74.04 | >= 70.0 | OK |
| transfer | dtd | resnet50 | 70.62 | >= 70.0 | OK |
| vit | imagenet | deit_base_patch16_224 | 81.82 | 81.80 ± 0.3 | OK |
| vit | imagenet | vit_b_16 | 81.03 | 81.07 ± 0.3 | OK |

## 2. Rankings at equal budget

### ablations / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| magnitude | 76.96 |  | 1 | 50.1 | 0.061 | 1.07 |
| taylor | 76.68 |  | 1 | 50.1 | 0.072 | 1.13 |
| rfc_zscore | 76.65 |  | 1 | 50.1 | 0.046 | 1.13 |
| srp_zscore | 76.49 |  | 1 | 50.1 | 0.042 | 1.14 |
| srp_od | 75.71 |  | 1 | 50.3 | 0.067 | 1.06 |
| taylor_global | 75.70 |  | 1 | 50.1 | 0.071 | 1.06 |
| rfc | 75.68 |  | 1 | 50.4 | 0.065 | 1.06 |
| srp_lambda0 | 75.57 |  | 1 | 50.2 | 0.068 | 1.07 |
| srp_pass | 75.50 |  | 1 | 50.2 | 0.061 | 1.06 |
| srp_low | 75.45 |  | 1 | 50.2 | 0.064 | 1.07 |
| srp ← proposed | 75.39 |  | 1 | 50.0 | 0.066 | 1.07 |
| srp_lambda1 | 74.97 |  | 1 | 50.1 | 0.072 | 1.06 |

srp vs best baseline (magnitude): -1.57 pt → **worse** (noise band ±0.40).

### controlled / bandtask_high / resnet18 / target 0.80

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| srp ← proposed | 69.76 | 5.44 | 5 | 80.2 | 0.137 |  |
| srp_lambda1 | 69.33 | 4.82 | 5 | 80.5 | 0.180 |  |
| srp_od | 66.23 | 2.06 | 5 | 80.4 | 0.185 |  |
| rfc | 65.79 | 9.44 | 5 | 80.4 | 0.216 |  |
| srp_pass | 64.37 | 4.25 | 5 | 80.4 | 0.097 |  |
| srp_low | 64.16 | 5.66 | 5 | 80.4 | 0.144 |  |
| taylor_global | 59.74 | 8.35 | 5 | 80.4 | 0.115 |  |
| lfs | 58.94 | 7.25 | 5 | 80.4 | 0.135 |  |
| srp_od_only | 58.24 | 7.10 | 5 | 80.4 | 0.167 |  |
| taylor | 51.90 | 10.38 | 5 | 80.3 | 0.071 |  |
| magnitude | 41.75 | 15.47 | 5 | 80.1 | 0.131 |  |
| taylor_global_rpr | 31.20 | 4.46 | 5 | 80.3 | 0.513 |  |

srp vs best baseline (rfc): +3.96 pt → **tie** (noise band ±10.88).

### controlled / bandtask_low / resnet18 / target 0.80

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| srp ← proposed | 93.23 | 1.03 | 5 | 80.2 | 0.116 |  |
| srp_lambda1 | 93.11 | 0.59 | 5 | 80.2 | 0.199 |  |
| srp_pass | 93.09 | 1.03 | 5 | 80.3 | 0.108 |  |
| taylor_global | 92.77 | 0.74 | 5 | 80.5 | 0.142 |  |
| srp_low | 92.67 | 1.10 | 5 | 80.2 | 0.195 |  |
| srp_od | 92.59 | 1.52 | 5 | 80.3 | 0.189 |  |
| srp_od_only | 92.52 | 1.07 | 5 | 80.2 | 0.117 |  |
| rfc | 91.88 | 2.72 | 5 | 80.3 | 0.063 |  |
| magnitude | 88.11 | 2.19 | 5 | 80.2 | 0.125 |  |
| taylor | 85.64 | 6.02 | 5 | 80.4 | 0.154 |  |
| lfs | 83.96 | 7.62 | 5 | 80.1 | 0.148 |  |
| taylor_global_rpr | 80.34 | 11.73 | 5 | 80.6 | 0.202 |  |

srp vs best baseline (taylor_global): +0.46 pt → **tie** (noise band ±2.05).

### main / imagenet / efficientnet_b4 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 83.44 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 83.18 |  | 1 | 0.0 | 0.074 | 1.01 |
| taylor_global | 79.35 |  | 1 | 50.1 | 0.117 | 1.29 |
| magnitude | 79.27 |  | 1 | 50.2 | 0.021 | 1.50 |
| rfc | 79.13 |  | 1 | 50.2 | 0.149 | 1.29 |
| srp ← proposed | 79.12 |  | 1 | 50.0 | 0.110 | 1.29 |
| taylor | 79.07 |  | 1 | 50.1 | 0.045 | 1.44 |
| lfs | 78.89 |  | 1 | 50.0 | 0.037 | 1.52 |
| random | 78.21 |  | 1 | 50.0 | 0.052 | 1.45 |

srp vs best baseline (taylor_global): -0.23 pt → **tie** (noise band ±0.40).

### main / imagenet / efficientnet_b4 / target 0.70

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 83.44 |  | 1 | 0.0 | 0.000 | 1.01 |
| dense_finetuned | 83.19 |  | 1 | 0.0 | 0.076 | 1.01 |
| rfc | 73.40 |  | 1 | 70.1 | 0.245 | 1.62 |
| taylor_global | 73.30 |  | 1 | 70.1 | 0.254 | 1.62 |
| srp ← proposed | 73.25 |  | 1 | 70.1 | 0.248 | 1.59 |
| magnitude | 73.03 |  | 1 | 70.1 | 0.119 | 1.63 |
| taylor | 72.71 |  | 1 | 70.2 | 0.151 | 1.62 |
| random | 71.94 |  | 1 | 70.2 | 0.085 | 1.90 |
| lfs | 71.26 |  | 1 | 70.1 | 0.148 | 1.89 |

srp vs best baseline (rfc): -0.15 pt → **tie** (noise band ±0.40).

### main / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.82 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.76 |  | 1 | 0.0 | 0.123 | 1.00 |
| magnitude | 76.89 |  | 1 | 50.6 | 0.053 | 1.09 |
| lfs | 76.81 |  | 1 | 50.2 | 0.071 | 1.12 |
| taylor | 76.61 |  | 1 | 50.0 | 0.052 | 1.12 |
| random | 76.51 |  | 1 | 50.3 | 0.053 | 1.07 |
| taylor_global | 75.64 |  | 1 | 50.1 | 0.068 | 1.07 |
| rfc | 75.53 |  | 1 | 50.0 | 0.065 | 1.07 |
| srp ← proposed | 75.35 |  | 1 | 50.1 | 0.060 | 1.06 |

srp vs best baseline (magnitude): -1.54 pt → **worse** (noise band ±0.40).

### main / imagenet / resnet50 / target 0.70

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.83 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.52 |  | 1 | 0.0 | 0.120 | 1.00 |
| magnitude | 73.50 |  | 1 | 70.0 | 0.017 | 1.17 |
| lfs | 72.79 |  | 1 | 70.2 | 0.034 | 1.20 |
| random | 72.71 |  | 1 | 70.1 | 0.064 | 1.16 |
| taylor | 72.51 |  | 1 | 70.1 | 0.054 | 1.20 |
| rfc | 70.40 |  | 1 | 70.2 | 0.109 | 1.14 |
| taylor_global | 70.17 |  | 1 | 70.4 | 0.083 | 1.14 |
| srp ← proposed | 69.44 |  | 1 | 70.2 | 0.099 | 1.14 |

srp vs best baseline (magnitude): -4.06 pt → **worse** (noise band ±0.40).

### transfer / cub_200_2011 / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 85.04 | 0.47 | 3 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 84.50 | 0.14 | 3 | 0.0 | 0.108 | 1.00 |
| srp ← proposed | 83.39 | 0.38 | 3 | 50.1 | 0.074 | 1.15 |
| srp_pass | 83.33 | 0.18 | 3 | 50.1 | 0.064 | 1.15 |
| srp_lambda1 | 83.29 | 0.45 | 3 | 50.1 | 0.075 | 1.15 |
| srp_lambda0 | 83.28 | 0.03 | 3 | 50.1 | 0.061 | 1.15 |
| taylor_global | 83.28 | 0.03 | 3 | 50.1 | 0.061 | 1.15 |
| srp_od | 83.18 | 0.25 | 3 | 50.1 | 0.082 | 1.15 |
| srp_low | 83.10 | 0.17 | 3 | 50.1 | 0.081 | 1.15 |
| rfc | 83.05 | 0.30 | 3 | 50.1 | 0.049 | 1.15 |
| taylor | 82.25 | 0.46 | 3 | 50.1 | 0.133 | 1.78 |
| taylor_augcal | 82.04 | 0.44 | 3 | 50.1 | 0.096 | 1.74 |
| lfs | 81.52 | 0.39 | 3 | 50.1 | 0.185 | 1.82 |
| frequency_steering | 79.96 | 0.85 | 3 | 50.1 | 0.245 | 1.82 |
| magnitude | 75.38 | 0.17 | 3 | 50.1 | 0.077 | 1.61 |

srp vs best baseline (taylor_global): +0.11 pt → **tie** (noise band ±0.76).

### transfer / cub_200_2011 / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 84.26 | 0.19 | 3 | 0.0 | 0.036 | 0.99 |
| dense | 84.02 | 0.00 | 3 | 0.0 | 0.000 | 1.00 |
| srp ← proposed | 82.57 | 0.08 | 3 | 50.2 | 0.082 | 1.06 |
| rfc | 82.55 | 0.45 | 3 | 50.1 | 0.059 | 1.06 |
| srp_pass | 82.42 | 0.35 | 3 | 50.1 | 0.056 | 1.06 |
| srp_lambda1 | 82.37 | 0.22 | 3 | 50.2 | 0.072 | 1.07 |
| srp_low | 82.34 | 0.04 | 3 | 50.5 | 0.075 | 1.06 |
| srp_od | 82.33 | 0.20 | 3 | 50.2 | 0.070 | 1.06 |
| taylor_global | 82.33 | 0.50 | 3 | 50.3 | 0.065 | 1.06 |
| srp_lambda0 | 82.06 | 0.50 | 3 | 50.2 | 0.061 | 1.06 |
| lfs | 81.03 | 0.31 | 3 | 50.2 | 0.070 | 1.09 |
| frequency_steering | 80.89 | 0.17 | 3 | 50.3 | 0.077 | 1.10 |
| magnitude | 79.84 | 0.11 | 3 | 50.3 | 0.135 | 1.10 |
| taylor_augcal | 79.49 | 0.34 | 3 | 50.2 | 0.149 | 1.10 |
| taylor | 79.16 | 0.52 | 3 | 50.0 | 0.094 | 1.12 |

srp vs best baseline (rfc): +0.02 pt → **tie** (noise band ±0.40).

### transfer / dtd / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 74.04 | 0.51 | 3 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 73.51 | 0.38 | 3 | 0.0 | 0.070 | 1.00 |
| srp_lambda1 | 70.76 | 0.59 | 3 | 50.0 | 0.057 | 1.15 |
| srp ← proposed | 70.59 | 0.73 | 3 | 50.0 | 0.065 | 1.15 |
| lfs | 70.14 | 0.86 | 3 | 50.1 | 0.315 | 1.78 |
| srp_pass | 70.14 | 0.80 | 3 | 50.1 | 0.106 | 1.15 |
| srp_lambda0 | 70.09 | 0.36 | 3 | 50.1 | 0.102 | 1.15 |
| srp_low | 70.07 | 0.63 | 3 | 50.1 | 0.107 | 1.15 |
| srp_od | 69.91 | 0.69 | 3 | 50.1 | 0.100 | 1.15 |
| rfc | 69.84 | 0.33 | 3 | 50.0 | 0.104 | 1.15 |
| taylor_global | 69.72 | 1.00 | 3 | 50.1 | 0.089 | 1.15 |
| taylor_augcal | 69.08 | 0.20 | 3 | 50.1 | 0.292 | 1.78 |
| taylor | 68.60 | 1.18 | 3 | 50.1 | 0.320 | 1.79 |
| frequency_steering | 67.96 | 1.05 | 3 | 50.1 | 0.326 | 1.81 |
| magnitude | 57.02 | 0.21 | 3 | 50.1 | 0.323 | 1.60 |

srp vs best baseline (lfs): +0.44 pt → **tie** (noise band ±1.46).

### transfer / dtd / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 71.56 | 0.40 | 3 | 0.0 | 0.022 | 1.01 |
| dense | 70.62 | 0.51 | 3 | 0.0 | 0.000 | 1.00 |
| rfc | 67.82 | 0.09 | 3 | 50.1 | 0.051 | 1.08 |
| taylor_global | 67.68 | 0.49 | 3 | 50.2 | 0.038 | 1.07 |
| srp ← proposed | 67.57 | 0.03 | 3 | 50.3 | 0.046 | 1.07 |
| srp_lambda1 | 67.41 | 0.08 | 3 | 50.6 | 0.043 | 1.08 |
| srp_lambda0 | 67.32 | 1.06 | 3 | 50.2 | 0.025 | 1.08 |
| srp_low | 67.18 | 0.61 | 3 | 50.2 | 0.052 | 1.07 |
| srp_od | 67.18 | 0.27 | 3 | 50.1 | 0.044 | 1.08 |
| srp_pass | 67.02 | 0.84 | 3 | 50.3 | 0.050 | 1.08 |
| frequency_steering | 64.11 | 0.76 | 3 | 50.1 | 0.061 | 1.12 |
| magnitude | 63.71 | 0.56 | 3 | 50.2 | 0.253 | 1.12 |
| lfs | 63.16 | 0.51 | 3 | 50.2 | 0.108 | 1.10 |
| taylor_augcal | 62.09 | 0.86 | 3 | 50.4 | 0.137 | 1.11 |
| taylor | 60.53 | 0.93 | 3 | 50.3 | 0.124 | 1.12 |

srp vs best baseline (rfc): -0.25 pt → **tie** (noise band ±0.40).

### vit / imagenet / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 81.82 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.89 |  | 1 | 0.0 | 0.033 | 1.00 |
| taylor_global | 78.15 |  | 1 | 50.1 | 0.232 | 1.15 |
| srp ← proposed | 78.02 |  | 1 | 50.1 | 0.191 | 1.15 |
| rfc | 77.94 |  | 1 | 50.1 | 0.232 | 1.15 |
| taylor | 76.72 |  | 1 | 50.1 | 0.286 | 1.78 |
| random | 76.56 |  | 1 | 50.0 | 0.182 | 1.46 |
| lfs | 75.92 |  | 1 | 50.1 | 0.352 | 1.94 |
| magnitude | 75.52 |  | 1 | 50.0 | 0.197 | 1.63 |

srp vs best baseline (taylor_global): -0.13 pt → **tie** (noise band ±0.40).

### vit / imagenet / vit_b_16 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 81.03 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 78.49 |  | 1 | 0.0 | 0.033 | 1.00 |
| taylor_global | 77.17 |  | 1 | 50.1 | 0.168 | 1.15 |
| srp ← proposed | 77.11 |  | 1 | 50.1 | 0.169 | 1.16 |
| rfc | 76.85 |  | 1 | 50.1 | 0.159 | 1.15 |
| taylor | 76.49 |  | 1 | 50.2 | 0.251 | 1.68 |
| random | 75.84 |  | 1 | 50.0 | 0.185 | 1.45 |
| lfs | 75.56 |  | 1 | 50.2 | 0.296 | 1.87 |
| magnitude | 74.04 |  | 1 | 50.2 | 0.213 | 1.64 |

srp vs best baseline (taylor_global): -0.07 pt → **tie** (noise band ±0.40).

## 3. Pre-registered hypotheses (docs/HYPOTHESES_V5.md)

- **G1** — SUPPORTED: transfer: loss-calibrated global ranking beats per-layer normalisation: taylor_global − taylor = +3.11 pt over 12 paired runs, wins 12/12, p = 0.00202
- **G2** — INCONCLUSIVE: source task (ImageNet ResNet-50, full data): per-layer normalisation beats global ranking: taylor − taylor_global = +1.43 pt over 3 paired runs, wins 3/3, p = 0.0893
- **G3a** — NO DATA: ImageNet ResNet-50 with scarce recovery data: global ranking is not worse: no paired runs (taylor_global vs taylor)
- **G3b** — NO DATA: needs the lowdata stage (>= 3 pairs) and the full-data ImageNet ResNet-50 runs
- **G4** — NO DATA: no taylor_auto runs
- **G5** — NO DATA: ViT at equal measured latency: global ranking is not worse than per-layer: no paired runs (taylor_global vs taylor)
- **G6** — INCONCLUSIVE: the band-reliance term adds to global Taylor on transfer: srp − taylor_global = +0.28 pt over 12 paired runs, wins 9/12, p = 0.103 (fewer than 18 pairs)
- **G7** — NO DATA: no rank-mix alpha sweep
- **H1** — SUPPORTED: L1(task reliance, source reliance) per dataset: cub_200_2011: 0.12, dtd: 0.35 (threshold 0.2 on at least one task)
- **H2** — REJECTED: pooled within-group r(drift, acc) = -0.38 (n=330); negative in 69% of 13 groups (need r <= -0.3 and >= 70%)
- **H3a** — SUPPORTED: SRP beats clean gate-Taylor on transfer tasks (>= +0.5 pt): srp − taylor = +3.39 pt over 12 paired runs, wins 12/12, p = 0.000499
- **H3b** — SUPPORTED: SRP beats magnitude on transfer tasks (>= +0.5 pt): srp − magnitude = +7.04 pt over 12 paired runs, wins 12/12, p = 0.000198
- **H4a** — INCONCLUSIVE: the reliance term adds to global Taylor (lambda = 0): srp − srp_lambda0 = +0.34 pt over 12 paired runs, wins 9/12, p = 0.0685
- **H4b** — SUPPORTED: all bands matter (vs preserving only the low band, VTC-LFC prior): srp − srp_low = +0.36 pt over 12 paired runs, wins 10/12, p = 0.00706
- **H4c** — SUPPORTED: band-stop derivative is at least as good as band-pass shares: srp − srp_pass = +0.30 pt over 12 paired runs, wins 9/12, p = 0.0507
- **H4d** — REJECTED: restricting calibration inputs to the task's reliant bands adds to global Taylor: rfc − taylor_global = +0.07 pt over 12 paired runs, wins 7/12, p = 0.631
- **H4e** — REJECTED: the output-difference band term adds to global Taylor: srp_od − taylor_global = -0.10 pt over 12 paired runs, wins 4/12, p = 0.393
- **H5** — INCONCLUSIVE: augmented calibration views repair saturated Taylor gradients: taylor_augcal − taylor = +0.54 pt over 12 paired runs, wins 7/12, p = 0.0606
- **H6** — SUPPORTED: global (un-normalised) ranking beats per-layer z-scoring: taylor_global − taylor = +3.11 pt over 12 paired runs, wins 12/12, p = 0.00202
- **H7a** — NO DATA: srp_rpr vs srp: no paired runs
- **H7b** — NO DATA: taylor_rpr vs taylor: no paired runs
- **H8** — REJECTED: no harm on the source task (ImageNet): SRP >= Taylor − 0.3: srp − taylor = -0.31 pt over 6 paired runs, wins 4/6, p = 0.66
- **H9** — INCONCLUSIVE: fewer than 4 tasks per architecture with taylor_global. transfer/cub_200_2011/deit_base_patch16_224: reliance on upper bands 0.10, kept-capacity depth 0.478 (n=3); transfer/cub_200_2011/resnet50: reliance on upper bands 0.22, kept-capacity depth 0.396 (n=3); transfer/dtd/deit_base_patch16_224: reliance on upper bands 0.23, kept-capacity depth 0.470 (n=3); transfer/dtd/resnet50: reliance on upper bands 0.40, kept-capacity depth 0.371 (n=3); controlled/bandtask_high/resnet18: reliance on upper bands 1.00, kept-capacity depth 0.250 (n=5); controlled/bandtask_low/resnet18: reliance on upper bands 0.07, kept-capacity depth 0.345 (n=5); main/imagenet/efficientnet_b4: reliance on upper bands 0.10, kept-capacity depth 0.376 (n=2); main/imagenet/resnet50: reliance on upper bands 0.30, kept-capacity depth 0.349 (n=2); vit/imagenet/deit_base_patch16_224: reliance on upper bands 0.12, kept-capacity depth 0.480 (n=1); vit/imagenet/vit_b_16: reliance on upper bands 0.10, kept-capacity depth 0.477 (n=1)

## 3b. Controlled frequency tasks (mechanism check, not transfer evidence)

| task | comparison | mean diff (pt) | pairs | wins | p |
|---|---|---|---|---|---|
| bandtask_high | taylor_global − taylor | +7.83 | 5 | 3/5 | 0.249 |
| bandtask_high | taylor_global − magnitude | +17.99 | 5 | 5/5 | 0.111 |
| bandtask_high | srp − taylor_global | +10.02 | 5 | 4/5 | 0.141 |
| bandtask_high | srp_lambda1 − taylor_global | +9.59 | 5 | 4/5 | 0.106 |
| bandtask_high | srp_od − taylor_global | +6.49 | 5 | 4/5 | 0.145 |
| bandtask_high | srp_od_only − taylor_global | -1.49 | 5 | 1/5 | 0.745 |
| bandtask_high | srp_pass − taylor_global | +4.63 | 5 | 3/5 | 0.219 |
| bandtask_high | srp_low − taylor_global | +4.42 | 5 | 3/5 | 0.339 |
| bandtask_high | rfc − taylor_global | +6.05 | 5 | 3/5 | 0.478 |
| bandtask_high | lfs − taylor_global | -0.80 | 5 | 3/5 | 0.845 |
| bandtask_high | taylor_global_rpr − taylor_global | -28.54 | 5 | 0/5 | 0.00535 |
| bandtask_low | taylor_global − taylor | +7.13 | 5 | 5/5 | 0.0638 |
| bandtask_low | taylor_global − magnitude | +4.67 | 5 | 5/5 | 0.0148 |
| bandtask_low | srp − taylor_global | +0.46 | 5 | 3/5 | 0.333 |
| bandtask_low | srp_lambda1 − taylor_global | +0.33 | 5 | 3/5 | 0.297 |
| bandtask_low | srp_od − taylor_global | -0.19 | 5 | 3/5 | 0.846 |
| bandtask_low | srp_od_only − taylor_global | -0.25 | 5 | 1/5 | 0.738 |
| bandtask_low | srp_pass − taylor_global | +0.31 | 5 | 4/5 | 0.536 |
| bandtask_low | srp_low − taylor_global | -0.11 | 5 | 2/5 | 0.817 |
| bandtask_low | rfc − taylor_global | -0.89 | 5 | 2/5 | 0.56 |
| bandtask_low | lfs − taylor_global | -8.82 | 5 | 0/5 | 0.0659 |
| bandtask_low | taylor_global_rpr − taylor_global | -12.43 | 5 | 0/5 | 0.0784 |

## 4. Paper gate

- [x] dense gate passed
- [x] >= 3 seeds per configuration
- [ ] >= 6 transfer (dataset, arch) groups evaluated
- [x] equal budgets in every transfer group
- [x] G1 supported (global ranking wins on transfer)
- [ ] G2 supported (per-layer wins on the source task, >= 3 seeds)
- [ ] G3b supported (recovery-data regime drives the flip)
- [ ] G4 supported (look-ahead calibration matches the better regime)

**Paper readiness: NOT READY**

