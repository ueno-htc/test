# Automated results audit

## 1. Dense gate

| stage | dataset | arch | dense top-1 | reference / minimum | status |
|---|---|---|---|---|---|
| main | imagenet | efficientnet_b4 | 83.44 | 83.38 ± 0.3 | OK |
| main | imagenet | resnet50 | 80.82 | 80.86 ± 0.3 | OK |
| transfer | cub_200_2011 | deit_base_patch16_224 | 57.90 | >= 80.0 | **FAIL** |
| transfer | cub_200_2011 | efficientnet_b4 | 36.49 | >= 78.0 | **FAIL** |
| transfer | cub_200_2011 | resnet50 | 81.95 | >= 80.0 | OK |
| transfer | dtd | deit_base_patch16_224 | 62.82 | >= 70.0 | **FAIL** |
| transfer | dtd | efficientnet_b4 | 42.45 | >= 68.0 | **FAIL** |
| transfer | dtd | resnet50 | 70.64 | >= 70.0 | OK |
| transfer | neu_cls | deit_base_patch16_224 | 98.33 | >= 97.0 | OK |
| transfer | neu_cls | efficientnet_b4 | 98.33 | >= 97.0 | OK |
| transfer | neu_cls | resnet50 | 98.33 | >= 97.0 | OK |
| vit | imagenet | deit_base_patch16_224 | 81.82 | 81.80 ± 0.3 | OK |
| vit | imagenet | vit_b_16 | 81.03 | 81.07 ± 0.3 | OK |

## 2. Rankings at equal budget

### ablations / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| taylor_kd | 76.93 |  | 1 | 50.2 | 0.012 | 1.13 |
| spectral_lambda0.1 | 76.79 |  | 1 | 50.0 | 0.085 | 1.12 |
| spectral_high | 76.76 |  | 1 | 50.1 | 0.118 | 1.11 |
| spectral_noise | 76.65 |  | 1 | 50.1 | 0.119 | 1.11 |
| spectral_filtered | 76.64 |  | 1 | 50.1 | 0.056 | 1.07 |
| spectral_flat | 76.61 |  | 1 | 50.2 | 0.053 | 1.12 |
| taylor | 76.59 |  | 1 | 50.1 | 0.061 | 1.13 |
| spectral_kd | 76.48 |  | 1 | 50.1 | 0.086 | 1.12 |
| spectral_norecal | 76.45 |  | 1 | 50.1 | 0.140 | 1.10 |
| spectral_lambda0.25 | 76.43 |  | 1 | 50.2 | 0.104 | 1.12 |
| spectral_steering ← proposed | 76.31 |  | 1 | 50.1 | 0.144 | 1.09 |
| spectral_low | 76.30 |  | 1 | 50.4 | 0.134 | 1.10 |
| spectral_unsigned | 76.28 |  | 1 | 50.0 | 0.103 | 1.11 |
| spectral_reliance | 76.26 |  | 1 | 50.0 | 0.109 | 1.12 |
| spectral_bands8 | 76.24 |  | 1 | 50.1 | 0.227 | 1.11 |
| spectral_current | 76.22 |  | 1 | 50.4 | 0.129 | 1.11 |
| spectral_density | 76.17 |  | 1 | 50.1 | 0.090 | 1.10 |
| spectral_lambda1 | 76.17 |  | 1 | 50.1 | 0.130 | 1.11 |
| spectral_lambda4 | 75.88 |  | 1 | 50.1 | 0.116 | 1.09 |
| spectral_lambda2 | 75.86 |  | 1 | 50.3 | 0.098 | 1.10 |
| magnitude_units | 75.63 |  | 1 | 61.6 | 0.035 | 1.14 |
| taylor_fourier_aug | 75.22 |  | 1 | 50.0 | 0.159 | 1.11 |
| spectral_units | 74.10 |  | 1 | 64.1 | 0.069 | 1.18 |
| taylor_units | 74.05 |  | 1 | 65.4 | 0.028 | 1.19 |

spectral_steering vs best baseline (taylor_kd): -0.62 pt → **worse** (noise band ±0.40).

### main / imagenet / efficientnet_b4 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 83.44 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 83.18 |  | 1 | 0.0 | 0.075 | 1.01 |
| magnitude | 79.28 |  | 1 | 50.1 | 0.021 | 1.37 |
| lfs | 79.02 |  | 1 | 50.1 | 0.034 | 1.57 |
| taylor | 78.96 |  | 1 | 50.0 | 0.043 | 1.57 |
| spectral_steering ← proposed | 78.84 |  | 1 | 50.2 | 0.068 | 1.59 |
| random | 78.22 |  | 1 | 50.0 | 0.052 | 1.53 |
| frequency_steering | 77.40 |  | 1 | 50.1 | 0.038 | 1.65 |
| hap | 77.36 |  | 1 | 50.2 | 0.035 | 1.59 |

spectral_steering vs best baseline (magnitude): -0.44 pt → **worse** (noise band ±0.40).

### main / imagenet / efficientnet_b4 / target 0.70

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 83.44 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 83.19 |  | 1 | 0.0 | 0.075 | 1.01 |
| magnitude | 73.11 |  | 1 | 70.1 | 0.137 | 1.66 |
| taylor | 72.43 |  | 1 | 70.0 | 0.130 | 1.69 |
| random | 71.94 |  | 1 | 70.2 | 0.093 | 1.62 |
| spectral_steering ← proposed | 71.51 |  | 1 | 70.0 | 0.120 | 1.79 |
| hap | 71.40 |  | 1 | 70.0 | 0.115 | 2.01 |
| lfs | 71.13 |  | 1 | 70.1 | 0.163 | 1.99 |
| frequency_steering | 69.41 |  | 1 | 70.1 | 0.107 | 1.95 |

spectral_steering vs best baseline (magnitude): -1.61 pt → **worse** (noise band ±0.40).

### main / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.82 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.67 |  | 1 | 0.0 | 0.120 | 1.00 |
| frequency_steering | 76.89 |  | 1 | 50.1 | 0.057 | 1.09 |
| magnitude | 76.88 |  | 1 | 50.6 | 0.061 | 1.09 |
| lfs | 76.79 |  | 1 | 50.0 | 0.058 | 1.11 |
| taylor | 76.67 |  | 1 | 50.0 | 0.038 | 1.12 |
| random | 76.57 |  | 1 | 50.3 | 0.050 | 1.06 |
| spectral_steering ← proposed | 76.21 |  | 1 | 50.0 | 0.118 | 1.11 |
| hap | 75.66 |  | 1 | 50.1 | 0.034 | 1.15 |

spectral_steering vs best baseline (frequency_steering): -0.67 pt → **worse** (noise band ±0.40).

### main / imagenet / resnet50 / target 0.70

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.83 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.60 |  | 1 | 0.0 | 0.118 | 1.00 |
| magnitude | 73.45 |  | 1 | 70.0 | 0.021 | 1.18 |
| frequency_steering | 72.97 |  | 1 | 70.2 | 0.051 | 1.20 |
| random | 72.61 |  | 1 | 70.1 | 0.078 | 1.16 |
| lfs | 72.61 |  | 1 | 70.1 | 0.034 | 1.19 |
| taylor | 72.30 |  | 1 | 70.0 | 0.022 | 1.20 |
| spectral_steering ← proposed | 72.13 |  | 1 | 70.0 | 0.036 | 1.19 |
| hap | 71.78 |  | 1 | 70.1 | 0.064 | 1.21 |

spectral_steering vs best baseline (magnitude): -1.32 pt → **worse** (noise band ±0.40).

### transfer / cub_200_2011 / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 82.78 |  | 1 | 0.0 | 0.032 | 0.99 |
| taylor | 77.91 |  | 1 | 50.1 | 0.291 | 1.83 |
| lfs | 77.77 |  | 1 | 50.1 | 0.240 | 1.82 |
| frequency_steering | 74.84 |  | 1 | 50.2 | 0.312 | 1.86 |
| spectral_steering ← proposed | 72.90 |  | 1 | 50.0 | 0.112 | 1.86 |
| magnitude | 66.34 |  | 1 | 50.1 | 0.108 | 1.60 |
| dense | 57.90 |  | 1 | 0.0 | 0.000 | 1.00 |

spectral_steering vs best baseline (taylor): -5.01 pt → **worse** (noise band ±0.40).

### transfer / cub_200_2011 / efficientnet_b4 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 80.19 |  | 1 | 0.0 | 0.304 | 0.99 |
| lfs | 40.78 |  | 1 | 50.1 | 0.616 | 1.70 |
| spectral_steering ← proposed | 38.07 |  | 1 | 50.1 | 0.509 | 1.64 |
| dense | 36.49 |  | 1 | 0.0 | 0.000 | 1.00 |
| taylor | 32.50 |  | 1 | 50.2 | 0.540 | 1.63 |
| magnitude | 32.48 |  | 1 | 50.0 | 0.266 | 1.56 |
| frequency_steering | 20.78 |  | 1 | 50.1 | 0.346 | 1.65 |

spectral_steering vs best baseline (lfs): -2.71 pt → **worse** (noise band ±0.40).

### transfer / cub_200_2011 / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 83.95 |  | 1 | 0.0 | 0.106 | 1.00 |
| dense | 81.95 |  | 1 | 0.0 | 0.000 | 1.00 |
| lfs | 80.58 |  | 1 | 50.1 | 0.122 | 1.09 |
| frequency_steering | 80.57 |  | 1 | 50.1 | 0.094 | 1.10 |
| magnitude | 80.50 |  | 1 | 50.1 | 0.108 | 1.10 |
| taylor | 79.65 |  | 1 | 50.0 | 0.164 | 1.10 |
| spectral_steering ← proposed | 78.82 |  | 1 | 50.0 | 0.344 | 1.11 |

spectral_steering vs best baseline (lfs): -1.76 pt → **worse** (noise band ±0.40).

### transfer / dtd / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 71.38 |  | 1 | 0.0 | 0.297 | 1.00 |
| lfs | 67.77 |  | 1 | 50.1 | 0.159 | 1.79 |
| taylor | 67.34 |  | 1 | 50.1 | 0.146 | 1.78 |
| frequency_steering | 65.85 |  | 1 | 50.1 | 0.145 | 1.89 |
| dense | 62.82 |  | 1 | 0.0 | 0.000 | 1.00 |
| spectral_steering ← proposed | 58.30 |  | 1 | 50.2 | 0.223 | 1.85 |
| magnitude | 53.03 |  | 1 | 50.1 | 0.136 | 1.60 |

spectral_steering vs best baseline (lfs): -9.47 pt → **worse** (noise band ±0.40).

### transfer / dtd / efficientnet_b4 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 66.97 |  | 1 | 0.0 | 0.097 | 1.00 |
| dense | 42.45 |  | 1 | 0.0 | 0.000 | 1.00 |
| magnitude | 34.79 |  | 1 | 50.0 | 0.264 | 1.57 |
| lfs | 27.61 |  | 1 | 50.2 | 0.225 | 1.68 |
| spectral_steering ← proposed | 26.38 |  | 1 | 50.2 | 0.165 | 1.69 |
| frequency_steering | 24.95 |  | 1 | 50.1 | 0.426 | 1.67 |
| taylor | 23.46 |  | 1 | 50.1 | 0.505 | 1.70 |

spectral_steering vs best baseline (magnitude): -8.40 pt → **worse** (noise band ±0.40).

### transfer / dtd / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 71.86 |  | 1 | 0.0 | 0.090 | 1.00 |
| dense | 70.64 |  | 1 | 0.0 | 0.000 | 1.00 |
| magnitude | 64.95 |  | 1 | 50.2 | 0.161 | 1.11 |
| frequency_steering | 64.04 |  | 1 | 50.1 | 0.082 | 1.10 |
| lfs | 62.39 |  | 1 | 50.2 | 0.180 | 1.11 |
| taylor | 60.90 |  | 1 | 50.1 | 0.182 | 1.10 |
| spectral_steering ← proposed | 60.16 |  | 1 | 50.1 | 0.321 | 1.12 |

spectral_steering vs best baseline (magnitude): -4.79 pt → **worse** (noise band ±0.40).

### transfer / neu_cls / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 98.61 |  | 1 | 0.0 | 0.666 | 1.00 |
| dense | 98.33 |  | 1 | 0.0 | 0.000 | 1.00 |
| frequency_steering | 98.33 |  | 1 | 50.2 | 0.499 | 1.88 |
| lfs | 98.33 |  | 1 | 50.0 | 0.863 | 1.86 |
| magnitude | 98.33 |  | 1 | 50.0 | 0.515 | 1.59 |
| spectral_steering ← proposed | 98.33 |  | 1 | 50.2 | 0.358 | 1.92 |
| taylor | 98.33 |  | 1 | 50.2 | 0.730 | 1.87 |

spectral_steering vs best baseline (frequency_steering): +0.00 pt → **tie** (noise band ±0.40).

### transfer / neu_cls / efficientnet_b4 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 98.33 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 98.33 |  | 1 | 0.0 | 0.071 | 1.00 |
| frequency_steering | 98.33 |  | 1 | 50.2 | 0.819 | 1.65 |
| lfs | 98.33 |  | 1 | 50.1 | 0.640 | 1.85 |
| magnitude | 98.33 |  | 1 | 50.2 | 1.374 | 1.65 |
| spectral_steering ← proposed | 98.33 |  | 1 | 50.0 | 0.820 | 1.68 |
| taylor | 98.33 |  | 1 | 50.0 | 0.555 | 1.86 |

spectral_steering vs best baseline (frequency_steering): +0.00 pt → **tie** (noise band ±0.40).

### transfer / neu_cls / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 98.33 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 98.33 |  | 1 | 0.0 | 0.610 | 1.01 |
| frequency_steering | 98.33 |  | 1 | 50.2 | 0.587 | 1.11 |
| lfs | 98.33 |  | 1 | 50.2 | 0.750 | 1.13 |
| magnitude | 98.33 |  | 1 | 50.5 | 0.610 | 1.12 |
| spectral_steering ← proposed | 98.33 |  | 1 | 50.0 | 0.515 | 1.10 |
| taylor | 98.33 |  | 1 | 50.2 | 0.354 | 1.13 |

spectral_steering vs best baseline (frequency_steering): +0.00 pt → **tie** (noise band ±0.40).

### vit / imagenet / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 81.82 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.89 |  | 1 | 0.0 | 0.033 | 1.00 |
| random | 76.55 |  | 1 | 50.0 | 0.182 | 1.45 |
| taylor | 76.00 |  | 1 | 50.1 | 0.316 | 1.83 |
| lfs | 75.92 |  | 1 | 50.1 | 0.352 | 1.92 |
| magnitude | 75.41 |  | 1 | 50.2 | 0.207 | 1.64 |
| spectral_steering ← proposed | 74.57 |  | 1 | 50.2 | 0.290 | 1.81 |
| frequency_steering | 74.51 |  | 1 | 50.1 | 0.376 | 1.96 |
| hap | 73.97 |  | 1 | 50.2 | 0.450 | 2.10 |

spectral_steering vs best baseline (random): -1.98 pt → **worse** (noise band ±0.40).

### vit / imagenet / vit_b_16 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 81.03 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 78.49 |  | 1 | 0.0 | 0.033 | 1.00 |
| taylor | 76.49 |  | 1 | 50.2 | 0.251 | 1.69 |
| random | 75.77 |  | 1 | 50.0 | 0.185 | 1.45 |
| lfs | 75.56 |  | 1 | 50.2 | 0.296 | 1.87 |
| spectral_steering ← proposed | 74.87 |  | 1 | 50.1 | 0.239 | 1.72 |
| frequency_steering | 74.46 |  | 1 | 50.0 | 0.329 | 1.92 |
| magnitude | 74.24 |  | 1 | 50.1 | 0.209 | 1.64 |
| hap | 73.42 |  | 1 | 50.2 | 0.362 | 2.03 |

spectral_steering vs best baseline (taylor): -1.62 pt → **worse** (noise band ±0.40).

## 3. Pre-registered hypotheses (docs/HYPOTHESES_V5.md)

- **H1** — SUPPORTED: L1(task reliance, source reliance) per dataset: cub_200_2011: 0.25, dtd: 0.59, neu_cls: 0.63 (threshold 0.2 on at least one task)
- **H2** — REJECTED: pooled within-group r(drift, acc) = -0.11 (n=96); negative in 62% of 13 groups (need r <= -0.3 and >= 70%)
- **H3a** — REJECTED: SRP beats clean gate-Taylor on transfer tasks (>= +0.5 pt): spectral_steering − taylor = -0.79 pt over 9 paired runs, wins 2/9, p = 0.589
- **H3b** — INCONCLUSIVE: SRP beats magnitude on transfer tasks (>= +0.5 pt): spectral_steering − magnitude = +0.28 pt over 9 paired runs, wins 3/9, p = 0.868
- **H4a** — NO DATA: spectral_steering vs srp_lambda0: no paired runs
- **H4b** — NO DATA: spectral_steering vs srp_low: no paired runs
- **H4c** — NO DATA: spectral_steering vs srp_pass: no paired runs
- **H5** — NO DATA: taylor_augcal vs taylor: no paired runs
- **H6** — NO DATA: taylor_global vs taylor: no paired runs
- **H7a** — NO DATA: srp_rpr vs spectral_steering: no paired runs
- **H7b** — NO DATA: taylor_rpr vs taylor: no paired runs
- **H8** — REJECTED: no harm on the source task (ImageNet): SRP >= Taylor − 0.3: spectral_steering − taylor = -0.79 pt over 6 paired runs, wins 0/6, p = 0.0298

## 4. Paper gate

- [ ] dense gate passed
- [ ] >= 3 seeds per configuration
- [x] >= 4 transfer (dataset, arch) groups evaluated
- [ ] proposed better than best baseline on >= half of the transfer groups
- [ ] proposed not worse than best baseline anywhere
- [ ] H3a and H3b supported
- [ ] at least one mechanism hypothesis supported (H2, H4a/b/c or H7a)

**Paper readiness: NOT READY**

