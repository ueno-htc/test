# Automated results audit

## 1. Dense gate

| stage | dataset | arch | dense top-1 | reference / minimum | status |
|---|---|---|---|---|---|
| controlled | bandtask_high | resnet18 | 75.55 | >= 0.0 | OK |
| controlled | bandtask_low | resnet18 | 95.08 | >= 0.0 | OK |

## 2. Rankings at equal budget

### controlled / bandtask_high / resnet18 / target 0.80

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| taylor_global | 64.73 | 2.40 | 3 | 80.4 | 0.358 |  |
| srp_lambda0.25 | 64.31 | 5.80 | 2 | 80.4 | 0.107 |  |
| rfc | 63.44 | 1.45 | 3 | 80.4 | 0.209 |  |
| srp_pass | 62.33 | 3.35 | 2 | 80.3 | 0.265 |  |
| srp_od_only | 60.43 | 2.36 | 3 | 80.5 | 0.312 |  |
| srp_od | 58.94 | 3.59 | 2 | 80.4 | 0.225 |  |
| rfc_tau0.2 | 55.71 | 9.00 | 3 | 80.3 | 0.263 |  |
| taylor | 54.46 | 13.96 | 3 | 80.2 | 0.251 |  |
| magnitude | 52.69 | 4.07 | 2 | 80.2 | 0.103 |  |
| srp ← proposed | 46.04 | 4.28 | 2 | 80.4 | 0.245 |  |
| taylor_global_rpr | 39.40 | 0.54 | 3 | 80.4 | 0.316 |  |

srp vs best baseline (taylor_global): -18.68 pt → **worse** (noise band ±8.56).

### controlled / bandtask_low / resnet18 / target 0.80

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| srp_od | 94.51 | 1.07 | 2 | 80.2 | 0.075 |  |
| taylor_global | 94.25 | 0.37 | 3 | 80.3 | 0.068 |  |
| srp_lambda0.25 | 93.29 | 1.62 | 2 | 80.4 | 0.061 |  |
| srp ← proposed | 92.85 | 0.66 | 2 | 80.2 | 0.228 |  |
| srp_od_only | 92.84 | 0.83 | 3 | 80.3 | 0.050 |  |
| rfc | 92.29 | 2.90 | 3 | 80.2 | 0.279 |  |
| rfc_tau0.2 | 92.06 | 2.88 | 3 | 80.2 | 0.092 |  |
| srp_pass | 92.02 | 1.07 | 2 | 80.3 | 0.130 |  |
| magnitude | 89.79 | 0.14 | 2 | 80.2 | 0.129 |  |
| taylor | 87.40 | 2.83 | 2 | 80.6 | 0.083 |  |
| taylor_global_rpr | 79.48 | 11.32 | 3 | 80.2 | 0.150 |  |

srp vs best baseline (taylor_global): -1.41 pt → **worse** (noise band ±1.31).

## 3. Pre-registered hypotheses (docs/HYPOTHESES_V5.md)

- **H1** — NO DATA: no transfer dense profiles
- **H2** — REJECTED: pooled within-group r(drift, acc) = -0.14 (n=55); negative in 100% of 2 groups (need r <= -0.3 and >= 70%)
- **H3a** — NO DATA: srp vs taylor: no paired runs
- **H3b** — NO DATA: srp vs magnitude: no paired runs
- **H4a** — NO DATA: srp vs srp_lambda0: no paired runs
- **H4b** — NO DATA: srp vs srp_low: no paired runs
- **H4c** — NO DATA: srp vs srp_pass: no paired runs
- **H4d** — NO DATA: rfc vs taylor_global: no paired runs
- **H4e** — NO DATA: srp_od vs taylor_global: no paired runs
- **H5** — NO DATA: taylor_augcal vs taylor: no paired runs
- **H6** — NO DATA: taylor_global vs taylor: no paired runs
- **H7a** — NO DATA: srp_rpr vs srp: no paired runs
- **H7b** — NO DATA: taylor_rpr vs taylor: no paired runs
- **H8** — NO DATA: srp vs taylor: no paired runs
- **H9** — INCONCLUSIVE: fewer than 4 tasks per architecture with taylor_global. controlled/bandtask_high/resnet18: reliance on upper bands 1.00, kept-capacity depth 0.257 (n=3); controlled/bandtask_low/resnet18: reliance on upper bands 0.03, kept-capacity depth 0.338 (n=3)

## 3b. Controlled frequency tasks (mechanism check, not transfer evidence)

| task | comparison | mean diff (pt) | pairs | wins | p |
|---|---|---|---|---|---|
| bandtask_high | taylor_global − taylor | +10.27 | 3 | 3/3 | 0.264 |
| bandtask_high | taylor_global − magnitude | +13.40 | 2 | 2/2 | 0.114 |
| bandtask_high | srp − taylor_global | -20.04 | 2 | 0/2 | 0.081 |
| bandtask_high | srp_od − taylor_global | -7.15 | 2 | 0/2 | 0.253 |
| bandtask_high | srp_od_only − taylor_global | -4.30 | 3 | 1/3 | 0.257 |
| bandtask_high | srp_pass − taylor_global | -3.76 | 2 | 0/2 | 0.411 |
| bandtask_high | rfc − taylor_global | -1.29 | 3 | 1/3 | 0.525 |
| bandtask_high | taylor_global_rpr − taylor_global | -25.33 | 3 | 0/3 | 0.00318 |
| bandtask_low | taylor_global − taylor | +6.86 | 2 | 2/2 | 0.149 |
| bandtask_low | taylor_global − magnitude | +4.47 | 2 | 2/2 | 0.0382 |
| bandtask_low | srp − taylor_global | -1.42 | 2 | 0/2 | 0.0438 |
| bandtask_low | srp_od − taylor_global | +0.24 | 2 | 1/2 | 0.644 |
| bandtask_low | srp_od_only − taylor_global | -1.42 | 3 | 0/3 | 0.0489 |
| bandtask_low | srp_pass − taylor_global | -2.25 | 2 | 0/2 | 0.11 |
| bandtask_low | rfc − taylor_global | -1.97 | 3 | 1/3 | 0.311 |
| bandtask_low | taylor_global_rpr − taylor_global | -14.78 | 3 | 0/3 | 0.146 |

## 4. Paper gate

- [x] dense gate passed
- [x] >= 3 seeds per configuration
- [ ] >= 4 transfer (dataset, arch) groups evaluated
- [ ] proposed better than best baseline on >= half of the transfer groups
- [ ] proposed not worse than best baseline anywhere
- [x] equal MAC budgets in every transfer group
- [ ] H3a and H3b supported
- [ ] at least one mechanism hypothesis supported (H2, H4a/b/d/e or H7a)

**Paper readiness: NOT READY**

