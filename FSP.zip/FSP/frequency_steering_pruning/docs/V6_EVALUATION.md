# v6 実行結果の評価（2026-11-25）

対象：`analysis_download_283846.zip`（356 run：transfer 221、latency 36、lowdata 21、main 44、vit 22、ablations 12）。
v5 とは独立に全 stage を再実行した結果であり、v5（246 run）と合わせて 2 回の独立な実行として扱える。
自動監査は `docs/figures_v6run/v6run_audit_report.md`、論文草稿は `paper/paper_draft_ja.pdf`。

## 1. Dense は一般的な数値と遜色ないか

| | 本実験 | 公開値／目安 | 判定 |
|---|---|---|---|
| ResNet-50 / ImageNet | 80.82 | 80.86 | ○ |
| EfficientNet-B4 / ImageNet | 83.44 | 83.38 | ○ |
| DeiT-B / ImageNet | 81.82 | 81.80 | ○ |
| ViT-B/16 / ImageNet | 81.03 | 81.07 | ○ |
| ResNet-50 / CUB・DTD（6 seed） | 83.90 ± 0.30 / 70.43 ± 0.49 | 81–84 / 72–75 | ○ / △ |
| DeiT-B / CUB・DTD | 85.04 ± 0.42 / 74.04 ± 0.45 | 80+ / 70+ | ○ |

DTD / ResNet-50 は目安の下限付近。Dense ゲートの下限 70.0 が平均値と同じ位置にあったため、seed 43（69.68）が止められ、
この条件だけ 2 seed になった（transfer stage が「失敗」と記録された原因）。下限を 68.0 に修正した。

## 2. 提案（層間較正）は優位か

### 支持された点

- **較正だけで転移精度が平均 7 pt 動く**（同じ Taylor スコア、MAC 50%）。4 条件平均：mean 76.37、rank-mix α=0.25 76.33、一様 76.07、グローバル 75.47、gaussian（z-score）72.74、standardization 69.23。
- **グローバル順位 − gaussian：+2.78 pt、23/23、p = 10⁻⁵**（2 回の実行を合算）。
- **先読み選択（`taylor_auto`）は良い側を選べる**：gaussian とグローバルの良い方に対し 20 run 平均 +0.28 pt、最悪 −0.38 pt（G4 支持）。ImageNet / ResNet-50 では α=0 を選び、MAC 50% で 77.18%（Magnitude 76.92、gaussian 76.60、グローバル 75.69）。
- **実測速度を揃えると ViT の順位が逆転**：MAC 一致では グローバル − gaussian = +0.9 pt、速度一致（1.44 倍）では −12.53 pt（6/6、p = 0.001）。

### 支持されなかった点

- **G3（逆転の原因は回復データ量）は棄却**。ImageNet 10% でもグローバル順位は gaussian より 2.03 pt 低い（3/3、p = 0.004）。
- **G8（先読みは最良の固定正規化と同等）は棄却**。転移では mean 正規化が先読みより 0.79 pt 高い（10/11、p = 0.003）。mean は既存の道具立てにある選択肢であり、**提案の新規部分（rank-mix と先読み）は既存の選択肢を上回っていない**。
- **G7（最適 α は転移で 1 側）は不成立**。転移の最良は α = 0.25（3/4 条件）で、一様配分（α=0）もグローバル順位より平均 0.56 pt 高い。v5 で見えた「グローバル順位の優位」は、比較相手の gaussian 正規化が悪かったことによる。
- **G6（帯域依存項）**：2 回合算で +0.26 pt（16/23、p = 0.02）。有意だが実装経路の違い程度で、ImageNet / ResNet-50 では −0.48 pt（0/6）。

## 3. 根拠と Ablation

- gaussian・standardization は ResNet-50 の layer1 を 12–33% まで削り layer4 を 94–100% 残す。mean・一様は全層 40–62%。精度はこの配分に沿って並ぶ。
- 同じ一様配分でも層内の選び方は効く：Taylor − Random = +4.05 pt、Taylor − Magnitude = +7.08 pt（いずれも 11/11）。
- 刈った直後の損失は最終精度を予測しない（ImageNet / ResNet-50 でグローバル順位は直後の損失が低いが最終精度も低い）。
- ImageNet-C の順位はクリーン精度とほぼ一致（順位相関 0.78–0.98）。

## 4. 判定

自動監査の論文ゲート：**NOT READY**（転移グループ 4 < 6、G1 は 11 対で 1 対不足、G2 は単一 seed、G3b 棄却）。

事前登録した v6 の主張のうち、「データ量が逆転の原因」と「先読みが最良」は成立しなかった。成立したのは
(i) 較正が支配的、(ii) 予算指標で順位が逆転、(iii) 周波数系基準は効かない、(iv) 先読みは 2 端の良い側を選べる、の 4 点で、
いずれも**新しい手法ではなく実証的な知見**である。最も良い設定（Taylor + mean 正規化、一様配分）は既知の構成要素の組み合わせである。

したがって **CVPR 本会議に通る水準の手法的貢献はない**。一方、調査としては収束しており（3 つの仮説を順に検証して棄却、残る未知は確認的なもの）、
実証研究としては一貫した形で書ける。その草稿を `paper/paper_draft_ja.pdf`（8 ページ）として作成した。

## 5. 草稿を確定させるための確認実験（任意）

| 目的 | 実行 | 規模 |
|---|---|---|
| ImageNet で mean・α=0・α=0.25 を直接評価（草稿の限界 v） | `SKIP_VIT=1 MODELS=resnet50 METHODS=dense,magnitude,taylor,taylor_mean,taylor_mix0,taylor_mix0.25,taylor_global,taylor_auto bash run_all.sh` | 追加 6 run 程度 |
| ImageNet / ResNet-50 を 3 seed に（限界 ii） | 上に `FSP_SEEDS=42,43,44` を追加 | 追加 12–16 run |
| 転移タスクを増やす（限界 i） | `TRANSFER_TV="Flowers102=...;OxfordIIITPet=..."` | データセットあたり半日未満 |
| 速度一致で mean・一様・先読みを比較 | 既定の `transfer_latency` stage に追加済み | 数時間 |
