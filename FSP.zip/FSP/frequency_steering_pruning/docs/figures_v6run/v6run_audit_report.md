# Automated results audit

## 1. Dense gate

| stage | dataset | arch | dense top-1 | reference / minimum | status |
|---|---|---|---|---|---|
| latency | cub_200_2011 | deit_base_patch16_224 | 85.04 | >= 80.0 | OK |
| latency | dtd | deit_base_patch16_224 | 74.04 | >= 70.0 | OK |
| lowdata | imagenet | resnet50 | 80.83 | 80.86 ± 0.3 | OK |
| main | imagenet | efficientnet_b4 | 83.44 | 83.38 ± 0.3 | OK |
| main | imagenet | resnet50 | 80.81 | 80.86 ± 0.3 | OK |
| transfer | cub_200_2011 | deit_base_patch16_224 | 85.04 | >= 80.0 | OK |
| transfer | cub_200_2011 | resnet50 | 83.79 | >= 80.0 | OK |
| transfer | dtd | deit_base_patch16_224 | 74.04 | >= 70.0 | OK |
| transfer | dtd | resnet50 | 70.23 | >= 70.0 | OK |
| vit | imagenet | deit_base_patch16_224 | 81.82 | 81.80 ± 0.3 | OK |
| vit | imagenet | vit_b_16 | 81.03 | 81.07 ± 0.3 | OK |

## 2. Rankings at equal budget

### ablations / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| magnitude | 76.91 |  | 1 | 50.1 | 0.037 | 1.08 |
| srp_zscore | 76.67 |  | 1 | 50.1 | 0.052 | 1.13 |
| taylor | 76.59 |  | 1 | 50.1 | 0.038 | 1.13 |
| rfc_zscore | 76.53 |  | 1 | 50.4 | 0.057 | 1.14 |
| rfc | 75.73 |  | 1 | 50.1 | 0.068 | 1.07 |
| srp_od | 75.68 |  | 1 | 50.2 | 0.071 | 1.07 |
| taylor_global | 75.59 |  | 1 | 50.2 | 0.073 | 1.06 |
| srp_lambda0 | 75.58 |  | 1 | 50.0 | 0.063 | 1.07 |
| srp_pass | 75.45 |  | 1 | 50.0 | 0.065 | 1.07 |
| srp ← proposed | 75.31 |  | 1 | 50.4 | 0.063 | 1.07 |
| srp_low | 75.21 |  | 1 | 50.2 | 0.061 | 1.06 |
| srp_lambda1 | 74.90 |  | 1 | 50.1 | 0.066 | 1.08 |

srp vs best baseline (magnitude): -1.60 pt → **worse** (noise band ±0.40).

### latency / cub_200_2011 / deit_base_patch16_224 / target 0.30

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| taylor | 84.08 | 0.24 | 3 | 30.1 | 0.052 | 1.45 |
| random | 80.57 | 0.30 | 3 | 46.5 | 0.027 | 1.44 |
| taylor_mix0.5 | 79.79 | 0.28 | 3 | 67.8 | 0.119 | 1.44 |
| magnitude | 78.31 | 0.62 | 3 | 40.3 | 0.071 | 1.45 |
| taylor_global | 75.80 | 0.38 | 3 | 70.2 | 0.190 | 1.44 |

### latency / dtd / deit_base_patch16_224 / target 0.30

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| taylor | 72.20 | 1.04 | 3 | 29.2 | 0.145 | 1.44 |
| random | 66.52 | 0.35 | 3 | 46.5 | 0.054 | 1.44 |
| taylor_mix0.5 | 64.80 | 1.36 | 3 | 67.9 | 0.310 | 1.44 |
| magnitude | 64.34 | 0.31 | 3 | 39.5 | 0.226 | 1.44 |
| taylor_global | 55.43 | 0.89 | 3 | 70.2 | 0.181 | 1.44 |

### lowdata / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.83 | 0.01 | 3 | 0.0 | 0.000 | 1.00 |
| taylor_auto | 71.19 | 0.06 | 3 | 50.0 | 0.042 | 1.08 |
| magnitude | 71.00 | 0.15 | 3 | 50.1 | 0.150 | 1.09 |
| taylor | 70.29 | 0.31 | 3 | 50.2 | 0.093 | 1.13 |
| random | 68.99 | 0.11 | 3 | 50.3 | 0.063 | 1.07 |
| taylor_mix0.5 | 68.72 | 0.08 | 3 | 50.2 | 0.127 | 1.07 |
| taylor_global | 68.26 | 0.15 | 3 | 50.2 | 0.134 | 1.07 |

### main / imagenet / efficientnet_b4 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 83.44 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 83.20 |  | 1 | 0.0 | 0.076 | 1.00 |
| taylor_auto | 79.44 |  | 1 | 50.0 | 0.104 | 1.33 |
| taylor_mix0.5 | 79.32 |  | 1 | 50.0 | 0.098 | 1.33 |
| taylor_global | 79.31 |  | 1 | 50.0 | 0.120 | 1.28 |
| magnitude | 79.24 |  | 1 | 50.1 | 0.023 | 1.47 |
| rfc | 79.23 |  | 1 | 50.1 | 0.136 | 1.29 |
| srp ← proposed | 79.16 |  | 1 | 50.1 | 0.096 | 1.29 |
| lfs | 79.01 |  | 1 | 50.1 | 0.054 | 1.57 |
| taylor | 78.95 |  | 1 | 50.2 | 0.032 | 1.56 |
| random | 78.26 |  | 1 | 50.0 | 0.054 | 1.53 |

srp vs best baseline (taylor_auto): -0.27 pt → **tie** (noise band ±0.40).

### main / imagenet / efficientnet_b4 / target 0.70

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 83.44 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 83.22 |  | 1 | 0.0 | 0.077 | 1.01 |
| taylor_mix0.5 | 74.08 |  | 1 | 70.0 | 0.225 | 1.62 |
| taylor_global | 73.69 |  | 1 | 70.0 | 0.250 | 1.61 |
| taylor_auto | 73.60 |  | 1 | 70.1 | 0.223 | 1.59 |
| rfc | 73.40 |  | 1 | 70.2 | 0.226 | 1.60 |
| srp ← proposed | 73.16 |  | 1 | 70.2 | 0.217 | 1.62 |
| magnitude | 73.09 |  | 1 | 70.2 | 0.139 | 1.74 |
| taylor | 72.77 |  | 1 | 70.2 | 0.136 | 1.57 |
| random | 72.00 |  | 1 | 70.2 | 0.095 | 1.86 |
| lfs | 71.87 |  | 1 | 70.2 | 0.138 | 1.98 |

srp vs best baseline (taylor_mix0.5): -0.92 pt → **worse** (noise band ±0.40).

### main / imagenet / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.81 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.73 |  | 1 | 0.0 | 0.112 | 1.00 |
| taylor_auto | 77.18 |  | 1 | 50.0 | 0.060 | 1.08 |
| magnitude | 76.93 |  | 1 | 50.3 | 0.053 | 1.09 |
| lfs | 76.76 |  | 1 | 50.1 | 0.079 | 1.13 |
| taylor | 76.54 |  | 1 | 50.2 | 0.051 | 1.14 |
| random | 76.50 |  | 1 | 50.3 | 0.057 | 1.07 |
| taylor_global | 75.82 |  | 1 | 50.2 | 0.067 | 1.07 |
| taylor_mix0.5 | 75.74 |  | 1 | 50.2 | 0.061 | 1.07 |
| rfc | 75.43 |  | 1 | 50.1 | 0.064 | 1.07 |
| srp ← proposed | 75.34 |  | 1 | 50.1 | 0.057 | 1.07 |

srp vs best baseline (taylor_auto): -1.84 pt → **worse** (noise band ±0.40).

### main / imagenet / resnet50 / target 0.70

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 80.81 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.69 |  | 1 | 0.0 | 0.103 | 1.00 |
| magnitude | 73.54 |  | 1 | 70.1 | 0.038 | 1.19 |
| taylor_auto | 73.41 |  | 1 | 70.0 | 0.045 | 1.17 |
| random | 72.78 |  | 1 | 70.1 | 0.058 | 1.17 |
| lfs | 72.57 |  | 1 | 70.2 | 0.032 | 1.21 |
| taylor | 72.40 |  | 1 | 70.1 | 0.053 | 1.21 |
| taylor_mix0.5 | 71.02 |  | 1 | 70.2 | 0.076 | 1.15 |
| taylor_global | 70.41 |  | 1 | 70.2 | 0.095 | 1.14 |
| rfc | 70.05 |  | 1 | 70.1 | 0.077 | 1.15 |
| srp ← proposed | 69.66 |  | 1 | 70.2 | 0.104 | 1.14 |

srp vs best baseline (magnitude): -3.89 pt → **worse** (noise band ±0.40).

### transfer / cub_200_2011 / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 85.04 | 0.47 | 3 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 84.50 | 0.14 | 3 | 0.0 | 0.108 | 1.00 |
| taylor_mix0.25 | 84.24 | 0.43 | 3 | 50.0 | 0.052 | 1.31 |
| taylor_mean | 83.87 | 0.27 | 3 | 50.1 | 0.031 | 1.30 |
| taylor_mix0 | 83.70 | 0.43 | 3 | 50.2 | 0.107 | 1.66 |
| taylor_mix0.5 | 83.51 | 0.14 | 3 | 50.1 | 0.063 | 1.16 |
| srp ← proposed | 83.39 | 0.38 | 3 | 50.1 | 0.074 | 1.16 |
| taylor_auto | 83.34 | 0.03 | 3 | 50.2 | 0.082 | 1.16 |
| taylor_global | 83.28 | 0.03 | 3 | 50.1 | 0.061 | 1.15 |
| taylor_lamp | 83.26 | 0.18 | 3 | 50.1 | 0.063 | 1.15 |
| taylor_max | 83.20 | 0.30 | 3 | 50.1 | 0.056 | 1.16 |
| taylor_mix0.75 | 83.13 | 0.24 | 3 | 50.1 | 0.064 | 1.16 |
| taylor_sum | 82.98 | 0.21 | 3 | 50.1 | 0.083 | 1.15 |
| taylor | 82.55 | 0.14 | 3 | 50.1 | 0.122 | 1.77 |
| lfs | 81.04 | 0.49 | 3 | 50.1 | 0.204 | 1.85 |
| random | 79.89 | 0.10 | 3 | 50.1 | 0.029 | 1.54 |
| taylor_std | 78.68 | 0.66 | 3 | 50.1 | 0.317 | 2.12 |
| magnitude_mean | 76.86 | 0.11 | 3 | 50.2 | 0.120 | 1.32 |
| magnitude | 75.38 | 0.17 | 3 | 50.1 | 0.077 | 1.61 |
| magnitude_lamp | 73.69 | 0.37 | 3 | 50.1 | 0.182 | 1.15 |

srp vs best baseline (taylor_mix0.25): -0.86 pt → **worse** (noise band ±0.76).

### transfer / cub_200_2011 / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 84.00 | 0.30 | 3 | 0.0 | 0.031 | 0.99 |
| dense | 83.79 | 0.44 | 3 | 0.0 | 0.000 | 0.99 |
| taylor_mean | 83.32 | 0.11 | 3 | 50.2 | 0.065 | 1.08 |
| taylor_mix0.25 | 82.49 | 0.37 | 3 | 50.1 | 0.050 | 1.08 |
| taylor_mix0.5 | 82.47 | 0.16 | 3 | 50.3 | 0.056 | 1.08 |
| taylor_mix0.75 | 82.44 | 0.16 | 3 | 50.1 | 0.057 | 1.07 |
| taylor_lamp | 82.32 | 0.55 | 3 | 50.1 | 0.088 | 1.07 |
| taylor_mix0 | 82.21 | 0.48 | 3 | 50.1 | 0.087 | 1.07 |
| srp ← proposed | 82.18 | 0.08 | 3 | 50.3 | 0.083 | 1.07 |
| taylor_global | 82.11 | 0.05 | 3 | 50.1 | 0.062 | 1.06 |
| taylor_sum | 81.83 | 0.33 | 3 | 50.1 | 0.096 | 1.07 |
| taylor_auto | 81.81 | 0.10 | 3 | 50.2 | 0.050 | 1.08 |
| taylor_max | 80.92 | 0.17 | 3 | 50.2 | 0.111 | 1.08 |
| lfs | 80.68 | 0.19 | 3 | 50.1 | 0.066 | 1.09 |
| random | 80.62 | 0.22 | 3 | 50.4 | 0.085 | 1.07 |
| magnitude | 80.32 | 0.20 | 3 | 50.2 | 0.124 | 1.10 |
| magnitude_mean | 79.90 | 0.30 | 3 | 50.1 | 0.160 | 1.10 |
| magnitude_lamp | 79.86 | 0.15 | 3 | 50.2 | 0.156 | 1.07 |
| taylor | 79.24 | 0.11 | 3 | 50.1 | 0.120 | 1.11 |
| taylor_std | 77.62 | 0.25 | 3 | 50.1 | 0.121 | 1.14 |

srp vs best baseline (taylor_mean): -1.14 pt → **worse** (noise band ±0.40).

### transfer / dtd / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 74.04 | 0.51 | 3 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 73.51 | 0.38 | 3 | 0.0 | 0.070 | 1.00 |
| taylor_mix0.75 | 71.01 | 0.59 | 3 | 50.1 | 0.112 | 1.15 |
| taylor_mean | 70.87 | 0.86 | 3 | 50.1 | 0.093 | 1.30 |
| srp ← proposed | 70.59 | 0.73 | 3 | 50.0 | 0.065 | 1.14 |
| taylor_mix0 | 70.57 | 0.21 | 3 | 50.2 | 0.205 | 1.64 |
| taylor_mix0.25 | 70.57 | 0.17 | 3 | 50.0 | 0.067 | 1.31 |
| taylor_auto | 70.53 | 1.32 | 3 | 50.1 | 0.099 | 1.15 |
| lfs | 70.14 | 0.86 | 3 | 50.1 | 0.315 | 1.77 |
| taylor_mix0.5 | 70.09 | 0.71 | 3 | 50.1 | 0.093 | 1.15 |
| taylor_global | 69.70 | 0.98 | 3 | 50.1 | 0.091 | 1.14 |
| taylor_sum | 69.68 | 0.14 | 3 | 50.1 | 0.172 | 1.15 |
| taylor_max | 69.59 | 0.46 | 3 | 50.1 | 0.157 | 1.15 |
| taylor_lamp | 69.57 | 0.64 | 3 | 50.1 | 0.113 | 1.14 |
| taylor | 68.60 | 1.18 | 3 | 50.1 | 0.320 | 1.78 |
| random | 65.11 | 0.63 | 3 | 50.1 | 0.056 | 1.53 |
| taylor_std | 64.18 | 0.69 | 3 | 50.1 | 0.510 | 2.14 |
| magnitude_mean | 57.66 | 0.40 | 3 | 50.1 | 0.231 | 1.30 |
| magnitude | 57.02 | 0.21 | 3 | 50.1 | 0.323 | 1.60 |
| magnitude_lamp | 53.00 | 0.38 | 3 | 50.1 | 0.202 | 1.15 |

srp vs best baseline (taylor_mix0.75): -0.43 pt → **tie** (noise band ±1.46).

### transfer / dtd / resnet50 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense_finetuned | 71.46 | 0.11 | 2 | 0.0 | 0.017 | 1.00 |
| dense | 70.23 | 0.48 | 3 | 0.0 | 0.000 | 1.00 |
| taylor_mix0.25 | 68.03 | 0.00 | 2 | 50.1 | 0.101 | 1.09 |
| taylor_mix0 | 67.82 | 1.05 | 2 | 50.1 | 0.150 | 1.08 |
| taylor_mix0.5 | 67.47 | 0.49 | 2 | 50.0 | 0.067 | 1.07 |
| taylor_mean | 67.42 | 0.79 | 2 | 50.1 | 0.064 | 1.09 |
| taylor_global | 66.81 | 0.60 | 2 | 50.1 | 0.061 | 1.06 |
| taylor_sum | 66.81 | 1.05 | 2 | 50.3 | 0.068 | 1.08 |
| taylor_lamp | 66.76 | 0.15 | 2 | 50.6 | 0.056 | 1.07 |
| taylor_auto | 66.62 | 0.49 | 2 | 50.1 | 0.104 | 1.07 |
| srp ← proposed | 66.60 | 0.53 | 2 | 50.2 | 0.036 | 1.07 |
| taylor_mix0.75 | 66.54 | 0.30 | 2 | 50.2 | 0.046 | 1.07 |
| taylor_max | 66.41 | 0.49 | 2 | 50.0 | 0.066 | 1.08 |
| magnitude | 64.49 | 1.32 | 2 | 50.1 | 0.277 | 1.11 |
| magnitude_lamp | 64.04 | 0.08 | 2 | 50.2 | 0.124 | 1.08 |
| magnitude_mean | 63.38 | 0.19 | 2 | 50.1 | 0.240 | 1.11 |
| lfs | 62.50 | 0.15 | 2 | 50.2 | 0.108 | 1.10 |
| random | 61.81 | 0.60 | 2 | 50.4 | 0.100 | 1.09 |
| taylor | 60.59 | 0.15 | 2 | 50.2 | 0.139 | 1.12 |
| taylor_std | 56.44 | 0.90 | 2 | 50.1 | 0.087 | 1.13 |

srp vs best baseline (taylor_mix0.25): -1.44 pt → **worse** (noise band ±1.05).

### vit / imagenet / deit_base_patch16_224 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 81.82 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 79.89 |  | 1 | 0.0 | 0.033 | 1.01 |
| srp ← proposed | 78.02 |  | 1 | 50.1 | 0.191 | 1.15 |
| rfc | 77.94 |  | 1 | 50.1 | 0.232 | 1.15 |
| taylor_global | 77.94 |  | 1 | 50.1 | 0.232 | 1.16 |
| taylor_auto | 77.94 |  | 1 | 50.1 | 0.235 | 1.15 |
| taylor_mix0.5 | 77.89 |  | 1 | 50.2 | 0.214 | 1.15 |
| random | 76.56 |  | 1 | 50.0 | 0.182 | 1.45 |
| taylor | 76.00 |  | 1 | 50.1 | 0.317 | 1.83 |
| lfs | 75.92 |  | 1 | 50.1 | 0.352 | 1.92 |
| magnitude | 75.41 |  | 1 | 50.2 | 0.207 | 1.63 |

srp vs best baseline (rfc): +0.08 pt → **tie** (noise band ±0.40).

### vit / imagenet / vit_b_16 / target 0.50

| method | top-1 | std | n | MAC red. % | reliance drift | speed-up vs dense |
|---|---|---|---|---|---|---|
| dense | 81.03 |  | 1 | 0.0 | 0.000 | 1.00 |
| dense_finetuned | 78.49 |  | 1 | 0.0 | 0.033 | 1.00 |
| srp ← proposed | 77.09 |  | 1 | 50.2 | 0.170 | 1.16 |
| taylor_mix0.5 | 77.07 |  | 1 | 50.1 | 0.163 | 1.16 |
| taylor_global | 77.04 |  | 1 | 50.1 | 0.177 | 1.16 |
| rfc | 76.85 |  | 1 | 50.1 | 0.159 | 1.16 |
| taylor_auto | 76.84 |  | 1 | 50.1 | 0.194 | 1.16 |
| taylor | 76.61 |  | 1 | 50.2 | 0.238 | 1.70 |
| random | 75.77 |  | 1 | 50.0 | 0.185 | 1.46 |
| lfs | 75.56 |  | 1 | 50.2 | 0.296 | 1.89 |
| magnitude | 74.04 |  | 1 | 50.2 | 0.213 | 1.66 |

srp vs best baseline (taylor_mix0.5): +0.02 pt → **tie** (noise band ±0.40).

## 3. Pre-registered hypotheses (docs/HYPOTHESES_V5.md)

- **G1** — INCONCLUSIVE: transfer: loss-calibrated global ranking beats per-layer normalisation: taylor_global − taylor = +2.41 pt over 11 paired runs, wins 11/11, p = 0.00357 (fewer than 12 pairs)
- **G2** — INCONCLUSIVE: source task (ImageNet ResNet-50, full data): per-layer normalisation beats global ranking: taylor − taylor_global = +1.23 pt over 3 paired runs, wins 3/3, p = 0.0853
- **G3a** — REJECTED: ImageNet ResNet-50 with scarce recovery data: global ranking is not worse: taylor_global − taylor = -2.03 pt over 3 paired runs, wins 0/3, p = 0.00434
- **G3b** — REJECTED: data regime drives the flip: (global − per-layer) is -2.03 pt with scarce data vs -1.23 pt with full data; difference-in-differences -0.80 pt (need >= +1.0)
- **G4** — SUPPORTED: look-ahead calibration vs the better of (per-layer, global): mean +0.28 pt, worst -0.38 pt over 20 runs; vs the worse end +2.23 pt (need mean >= −0.3 and >= +1.0)
- **G5** — REJECTED: ViT at equal measured latency: global ranking is not worse than per-layer: taylor_global − taylor = -12.53 pt over 6 paired runs, wins 0/6, p = 0.0014
- **G6** — INCONCLUSIVE: the band-reliance term adds to global Taylor on transfer: srp − taylor_global = +0.25 pt over 11 paired runs, wins 7/11, p = 0.124 (fewer than 18 pairs)
- **G7** — INCONCLUSIVE: best alpha of the rank-mix family (need >= 0.75 on >= 75% of transfer groups and <= 0.5 on ImageNet ResNet-50). transfer/cub_200_2011/deit_base_patch16_224/0.50: 0.25; transfer/cub_200_2011/resnet50/0.50: 0.25; transfer/dtd/deit_base_patch16_224/0.50: 0.75; transfer/dtd/resnet50/0.50: 0.25
- **G8** — REJECTED: look-ahead calibration vs the best fixed normaliser in hindsight: mean -0.79 pt over 11 runs (need >= −0.5); best fixed normaliser per run: taylor_mean x11
- **H1** — SUPPORTED: L1(task reliance, source reliance) per dataset: cub_200_2011: 0.12, dtd: 0.35 (threshold 0.2 on at least one task)
- **H2** — SUPPORTED: pooled within-group r(drift, acc) = -0.38 (n=312); negative in 86% of 14 groups (need r <= -0.3 and >= 70%)
- **H3a** — SUPPORTED: SRP beats clean gate-Taylor on transfer tasks (>= +0.5 pt): srp − taylor = +2.66 pt over 11 paired runs, wins 11/11, p = 0.000834
- **H3b** — SUPPORTED: SRP beats magnitude on transfer tasks (>= +0.5 pt): srp − magnitude = +6.77 pt over 11 paired runs, wins 11/11, p = 0.00142
- **H4a** — NO DATA: srp vs srp_lambda0: no paired runs
- **H4b** — NO DATA: srp vs srp_low: no paired runs
- **H4c** — NO DATA: srp vs srp_pass: no paired runs
- **H4d** — NO DATA: rfc vs taylor_global: no paired runs
- **H4e** — NO DATA: srp_od vs taylor_global: no paired runs
- **H5** — NO DATA: taylor_augcal vs taylor: no paired runs
- **H6** — SUPPORTED: global (un-normalised) ranking beats per-layer z-scoring: taylor_global − taylor = +2.41 pt over 11 paired runs, wins 11/11, p = 0.00357
- **H7a** — NO DATA: srp_rpr vs srp: no paired runs
- **H7b** — NO DATA: taylor_rpr vs taylor: no paired runs
- **H8** — SUPPORTED: no harm on the source task (ImageNet): SRP >= Taylor − 0.3: srp − taylor = -0.14 pt over 6 paired runs, wins 4/6, p = 0.844
- **H9** — INCONCLUSIVE: fewer than 4 tasks per architecture with taylor_global. transfer/cub_200_2011/deit_base_patch16_224: reliance on upper bands 0.10, kept-capacity depth 0.478 (n=3); transfer/cub_200_2011/resnet50: reliance on upper bands 0.22, kept-capacity depth 0.395 (n=3); transfer/dtd/deit_base_patch16_224: reliance on upper bands 0.23, kept-capacity depth 0.468 (n=3); transfer/dtd/resnet50: reliance on upper bands 0.40, kept-capacity depth 0.371 (n=2); main/imagenet/efficientnet_b4: reliance on upper bands 0.10, kept-capacity depth 0.377 (n=2); main/imagenet/resnet50: reliance on upper bands 0.30, kept-capacity depth 0.353 (n=2); vit/imagenet/deit_base_patch16_224: reliance on upper bands 0.12, kept-capacity depth 0.480 (n=1); vit/imagenet/vit_b_16: reliance on upper bands 0.10, kept-capacity depth 0.477 (n=1)

## 4. Paper gate

- [x] dense gate passed
- [x] >= 3 seeds per configuration
- [ ] >= 6 transfer (dataset, arch) groups evaluated
- [x] equal budgets in every transfer group
- [ ] G1 supported (global ranking wins on transfer)
- [ ] G2 supported (per-layer wins on the source task, >= 3 seeds)
- [ ] G3b supported (recovery-data regime drives the flip)
- [x] G4 supported (look-ahead calibration matches the better regime)

**Paper readiness: NOT READY**

