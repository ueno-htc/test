#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec "${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}" "$ROOT/vit_ablation.py" \
  --config "$ROOT/configs/vit_ablation.yaml" \
  --models "${VIT_MODELS:-vit_b_16,vit_l_16,deit_base_patch16_224}" \
  --methods "${VIT_METHODS:-dense,random,magnitude,snip,hap,steering_only,frequency_steering}" \
  --output-root "${VIT_OUTPUT_ROOT:-$ROOT/outputs/vit_ablation}" \
  --status-root "${FSP_STATUS_ROOT:-$ROOT/outputs/_orchestrator}" \
  --set "data.root=${IMAGENET_ROOT:?}" \
  --set "data.imagenet_c_root=${IMAGENET_C_ROOT:-}" \
  --set "data.imagenet_r_root=${IMAGENET_R_ROOT:-}"
