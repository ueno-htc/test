#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import torch
import torch.distributed as dist

from frequency_pruning.distributed import (
    DistributedPhaseError,
    all_gather_object,
    assert_consensus,
    cleanup_distributed,
    setup_distributed,
    synchronize_failures,
)


def main() -> None:
    context = setup_distributed("cpu")
    if context.world_size != 2:
        raise RuntimeError(f"selftest expects 2 ranks, got {context.world_size}")
    value = torch.tensor([context.rank + 1.0], dtype=torch.float32)
    dist.all_reduce(value)
    if float(value.item()) != 3.0:
        raise AssertionError(f"unexpected all-reduce value: {value.item()}")
    assert_consensus({"protocol": "fsp-v3", "world_size": 2}, phase="selftest_consensus")
    synchronize_failures(None, phase="selftest_success")

    caught = False
    local_error = RuntimeError("injected-control-plane-failure") if context.rank == 1 else None
    try:
        synchronize_failures(local_error, phase="selftest_injected_failure")
    except DistributedPhaseError as error:
        caught = "injected-control-plane-failure" in str(error)
    flags = all_gather_object(caught)
    if not all(flags):
        raise AssertionError(f"failure was not propagated to all ranks: {flags}")
    cleanup_distributed(synchronize=True)


if __name__ == "__main__":
    main()
