#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec "${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}" "$ROOT/transfer.py" \
  --config "$ROOT/configs/transfer_cnn.yaml" \
  --datasets "${TRANSFER_DATASETS:-neu_cls,dtd,cub_200_2011}" \
  --models "${TRANSFER_MODELS:-resnet50,efficientnet_b4}" \
  --methods "${TRANSFER_METHODS:-dense,magnitude,snip,steering_only,frequency_steering}" \
  --output-root "${TRANSFER_OUTPUT_ROOT:-$ROOT/outputs/transfer}" \
  --status-root "${FSP_STATUS_ROOT:-$ROOT/outputs/_orchestrator}" \
  --neu-root "${NEU_ROOT:-}" --dtd-root "${DTD_ROOT:-}" --cub-root "${CUB_ROOT:-}"
