#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 4 ]]; then
  echo "Usage: $0 CONFIG DENSE_CHECKPOINT PRUNED_CHECKPOINT OUTPUT_DIR" >&2
  exit 2
fi
CONFIG="$1"
DENSE="$2"
PRUNED="$3"
OUTPUT="$4"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FSP_PYTHON="${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}"
if [[ ! -x "$FSP_PYTHON" ]]; then
  echo "Required Python interpreter is not executable: $FSP_PYTHON" >&2
  exit 2
fi
cd "$ROOT"
"$FSP_PYTHON" evaluate.py --config "$CONFIG" --checkpoint "$PRUNED" --output-dir "$OUTPUT/evaluation"
"$FSP_PYTHON" visualize_fourier.py \
  --config "$CONFIG" \
  --dense-checkpoint "$DENSE" \
  --pruned-checkpoint "$PRUNED" \
  --output-dir "$OUTPUT/fourier"
