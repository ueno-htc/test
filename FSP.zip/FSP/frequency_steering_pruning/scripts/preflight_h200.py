#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import warnings
from pathlib import Path

PROJECT_IMPORT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_IMPORT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_IMPORT_ROOT))

from frequency_pruning.h200_runtime import initialize_runtime, runtime_snapshot


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Preflight one-node 8xH200 FSP execution")
    parser.add_argument("--project-root", default="/home/ueno/FSP/frequency_steering_pruning")
    parser.add_argument("--python", default="/home/ueno/.conda/envs/vip/bin/python")
    parser.add_argument("--expected-gpus", type=int, default=8)
    parser.add_argument("--dataset", action="append", default=[], metavar="NAME=PATH")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--allow-cpu", action="store_true")
    parser.add_argument("--output", default="")
    return parser.parse_args()


def _dataset_entries(values: list[str]) -> dict[str, str]:
    output: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"--dataset expects NAME=PATH, got {value!r}")
        name, path = value.split("=", 1)
        output[name] = path
    return output


def main() -> int:
    args = parse_args()
    project = Path(args.project_root).resolve()
    failures: list[str] = []
    warnings_out: list[str] = []
    runtime = initialize_runtime()
    report: dict[str, object] = {
        "project_root": str(project),
        "project_exists": project.exists(),
        "python_requested": args.python,
        "python_running": sys.executable,
        "python_requested_exists": Path(args.python).exists(),
        "python_matches_requested": Path(sys.executable).resolve() == Path(args.python).resolve()
        if Path(args.python).exists()
        else False,
        "platform": platform.platform(),
        "hostname": platform.node(),
        "cpu_count": os.cpu_count(),
        "runtime_initialization": {
            "nofile": runtime.nofile,
            "torch": runtime.torch,
            "loader": runtime.loader,
        },
        "runtime_snapshot": runtime_snapshot(),
        "environment": {
            key: os.environ.get(key)
            for key in (
                "CUDA_VISIBLE_DEVICES",
                "FSP_PRECISION",
                "FSP_HAP_MODE",
                "FSP_SALIENCY_EXECUTION",
                "FSP_MAX_WORKERS_PER_JOB",
                "FSP_EVAL_WORKERS_PER_JOB",
                "FSP_CALIBRATION_WORKERS_PER_JOB",
                "FSP_PREFETCH_FACTOR",
                "FSP_SHARING_STRATEGY",
                "FSP_DATALOADER_START_METHOD",
                "PYTORCH_CUDA_ALLOC_CONF",
                "TORCH_NCCL_ASYNC_ERROR_HANDLING",
                "TORCH_NCCL_DUMP_ON_TIMEOUT",
                "TORCH_NCCL_TRACE_BUFFER_SIZE",
                "TORCH_FR_BUFFER_SIZE",
                "TORCH_FR_DUMP_TEMP_FILE",
                "TORCH_NCCL_DEBUG_INFO_TEMP_FILE",
                "TORCH_NCCL_DESYNC_DEBUG",
                "FSP_CONTROL_BACKEND",
                "NCCL_ASYNC_ERROR_HANDLING",
            )
        },
    }

    saliency_execution = os.environ.get("FSP_SALIENCY_EXECUTION", "all_ranks").lower()
    if saliency_execution not in {"all", "all_ranks", "sharded", "all_rank_sharded"}:
        failures.append(f"unsafe_saliency_execution:{saliency_execution}")
    if os.environ.get("NCCL_ASYNC_ERROR_HANDLING"):
        warnings_out.append(
            "deprecated_env:NCCL_ASYNC_ERROR_HANDLING; run_all.sh unsets it and uses "
            "TORCH_NCCL_ASYNC_ERROR_HANDLING"
        )

    required_files = [
        project / "run_all.sh",
        project / "train.py",
        project / "frequency_pruning" / "pruning" / "saliency.py",
    ]
    report["required_files"] = {str(path): path.exists() for path in required_files}
    if not project.exists():
        failures.append("project_root_missing")
    for path in required_files:
        if not path.exists():
            failures.append(f"required_file_missing:{path}")
    if not Path(args.python).exists():
        failures.append("python_missing")
    elif not report["python_matches_requested"]:
        failures.append(f"wrong_python:{sys.executable}")

    dataset_report: dict[str, object] = {}
    for name, raw_path in _dataset_entries(args.dataset).items():
        path = Path(raw_path)
        entry: dict[str, object] = {"path": str(path), "exists": path.exists()}
        if name == "imagenet":
            entry["train_exists"] = (path / "train").is_dir()
            entry["val_exists"] = (path / "val").is_dir()
            if not entry["train_exists"] or not entry["val_exists"]:
                failures.append(f"imagenet_train_or_val_missing:{path}")
        elif not path.exists():
            failures.append(f"dataset_missing:{name}:{path}")
        dataset_report[name] = entry
    report["datasets"] = dataset_report

    try:
        import torch

        torch_report: dict[str, object] = {
            "version": torch.__version__,
            "cuda_version": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(),
            "device_count": torch.cuda.device_count(),
            "nccl_available": torch.distributed.is_nccl_available(),
        }
        devices = []
        for index in range(torch.cuda.device_count()):
            properties = torch.cuda.get_device_properties(index)
            devices.append(
                {
                    "index": index,
                    "name": torch.cuda.get_device_name(index),
                    "total_memory_gib": round(properties.total_memory / 2**30, 2),
                    "capability": list(torch.cuda.get_device_capability(index)),
                    "bf16_supported": bool(torch.cuda.is_bf16_supported()),
                }
            )
        torch_report["devices"] = devices
        report["torch"] = torch_report
        if not args.allow_cpu and torch.cuda.device_count() != args.expected_gpus:
            failures.append(
                f"expected_{args.expected_gpus}_gpus_found_{torch.cuda.device_count()}"
            )
        if torch.cuda.is_available():
            non_h200 = [str(item["name"]) for item in devices if "H200" not in str(item["name"]).upper()]
            if non_h200:
                warnings_out.append(f"non_H200_devices:{non_h200}")
            if not all(bool(item["bf16_supported"]) for item in devices):
                failures.append("bf16_not_supported_on_all_gpus")
    except Exception as exc:
        report["torch_import_error"] = f"{type(exc).__name__}: {exc}"
        if not args.allow_cpu:
            failures.append("torch_import_failed")

    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            import torchvision
            from torchvision import datasets, models, transforms  # noqa: F401

        warning_text = [str(item.message) for item in caught]
        compiled_ops = bool(
            getattr(getattr(torchvision, "extension", None), "_HAS_OPS", False)
        )
        abi_warning = any(
            "undefined symbol" in item.lower()
            or "failed to load image python extension" in item.lower()
            for item in warning_text
        )
        report["torchvision"] = {
            "version": torchvision.__version__,
            "warnings": warning_text,
            "compiled_ops_available": compiled_ops,
            "abi_warning": abi_warning,
            "pil_imagefolder_path_available": True,
        }
        if warning_text:
            warnings_out.extend(f"torchvision:{item}" for item in warning_text)
        if abi_warning or not compiled_ops:
            message = (
                "torchvision compiled extensions are unavailable or ABI-incompatible. "
                "This repository's ImageFolder/PIL/model path is available, so the run can "
                "continue, but torchvision.io/ops must not be used. Reinstall torch and "
                "torchvision as a matching pair from the same official PyTorch channel if "
                "compiled torchvision operators are required."
            )
            warnings_out.append(f"torchvision_binary_compatibility:{message}")
            if os.environ.get("FSP_REQUIRE_TORCHVISION_OPS", "0") == "1":
                failures.append("torchvision_compiled_ops_required_but_unavailable")
    except Exception as exc:
        report["torchvision_import_error"] = f"{type(exc).__name__}: {exc}"
        failures.append("torchvision_import_failed")

    try:
        completed = subprocess.run(
            [sys.executable, "-m", "pip", "check"],
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
        report["pip_check"] = {
            "returncode": completed.returncode,
            "stdout": completed.stdout.strip(),
            "stderr": completed.stderr.strip(),
        }
        if completed.returncode != 0:
            warnings_out.append("pip_check_reported_dependency_conflicts")
    except Exception as exc:
        report["pip_check_error"] = f"{type(exc).__name__}: {exc}"

    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    report["nofile"] = {
        "soft": int(soft),
        "hard": "unlimited" if hard == resource.RLIM_INFINITY else int(hard),
    }
    if soft < 65536:
        warnings_out.append(
            f"nofile_soft_limit_below_recommended:{soft}; "
            "DataLoader workers will be reduced automatically to remain within the limit"
        )
    if Path("/dev/shm").exists():
        usage = shutil.disk_usage("/dev/shm")
        report["dev_shm"] = {
            "total_bytes": usage.total,
            "free_bytes": usage.free,
        }
        if usage.free < 1 * 1024**3:
            warnings_out.append(f"low_dev_shm_free_bytes:{usage.free}")

    output_root = project / "outputs"
    try:
        output_root.mkdir(parents=True, exist_ok=True)
        probe = output_root / ".fsp_write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        report["output_writable"] = True
    except OSError as exc:
        report["output_writable"] = False
        report["output_write_error"] = f"{type(exc).__name__}: {exc}"
        failures.append("output_not_writable")

    report["warnings"] = warnings_out
    report["failures"] = failures
    rendered = json.dumps(report, indent=2, ensure_ascii=False)
    print(rendered)
    if args.output:
        path = Path(args.output)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(rendered + "\n", encoding="utf-8")
    return 1 if args.strict and failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
