#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec "${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}" "$ROOT/tune.py" \
  --config "$ROOT/configs/tune_imagenet.yaml" \
  --output-root "${TUNING_OUTPUT:-$ROOT/outputs/tuning/resnet50}" \
  --status-root "${FSP_STATUS_ROOT:-$ROOT/outputs/_orchestrator}" \
  --lambdas "${LAMBDAS:-0.0,0.25,0.5,1.0,2.0}" \
  --cutoffs "${CUTOFFS:-0.125,0.25,0.375,0.5}" \
  --set "data.root=${IMAGENET_ROOT:?}" \
  --set "data.imagenet_c_root=${IMAGENET_C_ROOT:-}" \
  --set "data.imagenet_r_root=${IMAGENET_R_ROOT:-}"
