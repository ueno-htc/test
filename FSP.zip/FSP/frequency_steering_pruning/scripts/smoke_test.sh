#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FSP_PYTHON="${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}"
if [[ ! -x "$FSP_PYTHON" ]]; then
  echo "Required Python interpreter is not executable: $FSP_PYTHON" >&2
  exit 2
fi
cd "$ROOT"
export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
"$FSP_PYTHON" train.py --config configs/smoke_test.yaml --run-dir outputs/smoke/latest
"$FSP_PYTHON" tools/validate_run.py outputs/smoke/latest
