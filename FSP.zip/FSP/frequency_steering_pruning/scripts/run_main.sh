#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec "${FSP_PYTHON:-/home/ueno/.conda/envs/vip/bin/python}" "$ROOT/main_experiments.py" \
  --models "${MODELS:-resnet50,efficientnet_b4}" \
  --methods "${METHODS:-dense,random,magnitude,snip,hap,steering_only,frequency_steering}" \
  --output-root "${OUTPUT_ROOT:-$ROOT/outputs/main}" \
  --status-root "${FSP_STATUS_ROOT:-$ROOT/outputs/_orchestrator}" \
  --lambda "${LAMBDA:-1.0}" --cutoff "${CUTOFF:-0.25}" \
  --imagenet-root "${IMAGENET_ROOT:?}" \
  --imagenet-c-root "${IMAGENET_C_ROOT:-}" \
  --imagenet-r-root "${IMAGENET_R_ROOT:-}"
