# Frequency-Steering Pruning H200 NCCL Incident and Recovery Report

## 1. Scope

This report covers the production failure recorded in `6398.txt`, the distributed-state refactor applied to the Frequency-Steering Pruning repository, and the verification performed in the available CPU environment. The target production environment remains one node with eight NVIDIA H200 GPUs.

The only supported user command after this refactor is:

```bash
cd /home/ueno/FSP/frequency_steering_pruning
bash run_all.sh
```

`run_all.sh` performs environment setup, runtime preflight, distributed control-plane self-test, tuning, main CNN experiments, ViT ablations, transfer experiments, aggregation, resume validation, retry handling, and final completion marking.

## 2. Incident facts from `6398.txt`

Observed facts, separated from implementation inference:

1. Eight processes initialized ResNet-50 successfully with `world_size=8`.
2. The run completed one training epoch and dense ImageNet validation with `val_top1=80.39`.
3. Immediately after dense validation, ranks 1–7 waited on the same NCCL collective: `BROADCAST`, sequence 1905, one element.
4. Sequence 1904 had completed; sequence 1905 remained outstanding for 600 seconds.
5. The NCCL watchdog aborted the communicator and torchrun reported `ChildFailedError` and SIGABRT.
6. The warning stream also showed a deprecated `NCCL_ASYNC_ERROR_HANDLING` variable and a torch/torchvision compiled-extension ABI mismatch.
7. Earlier dense, random, and magnitude experiment directories had completed; the next gradient-based method entered the failure path.

## 3. Root cause

### 3.1 Direct cause

The direct cause was an asymmetric distributed phase at the transition from dense evaluation to saliency. Non-source ranks entered a one-element NCCL broadcast while source rank 0 executed a long rank-local saliency path. The old path mixed rank-0-only work, data-plane broadcast, and helper functions that were also capable of distributed collectives. This violated the requirement that all ranks enqueue collectives in the same order.

Increasing the watchdog timeout would only delay the abort. It would not repair collective ordering.

### 3.2 Adjacent defects

The audit also found the following reliability risks:

- rank-local Python/CUDA failures could leave healthy ranks waiting in a later NCCL collective;
- calibration shards could be padded by a standard distributed sampler, duplicating samples;
- batch-mean reduction could bias saliency when final shard sizes differed;
- exact full-model HAP could construct a prohibitively large second-order graph;
- stale directories could be mistaken for completed experiments;
- repeated independent experiments could multiply DataLoader workers and file descriptors;
- physical export equivalence was logged but not treated as a hard correctness condition;
- current and deprecated NCCL diagnostic variable names were mixed;
- shell scripts exposed multiple apparent launch paths instead of one production entrypoint.

## 4. Distributed recovery architecture

### 4.1 All-rank sharded saliency

The production default is now `all_ranks_sharded`.

1. Every rank receives a deterministic, non-padding shard of the same global calibration subset.
2. Saliency uses the unwrapped module and `torch.autograd.grad`; it does not invoke DDP backward synchronization.
3. Each rank accumulates FP32 sample sums locally.
4. Before any tensor all-reduce, ranks exchange success/failure status on a Gloo control group.
5. If any rank fails, every rank receives one descriptive `DistributedPhaseError` before entering the next NCCL collective.
6. Healthy local accumulators are reduced in bounded flat buckets on the NCCL data plane.
7. Division uses the globally reduced sample count, so uneven final shards are handled correctly.
8. Every rank obtains identical structured-unit scores and verifies a score checksum consensus.
9. Rank 0 selects the small deterministic pruning plan; the plan is broadcast on the control plane and applied by all ranks.
10. Mask-state consensus is checked after application.

The former `rank0` saliency policy is rejected in configuration and at runtime. It cannot silently reactivate the failing code path.

### 4.2 Data plane and control plane

- NCCL is used for large tensor reductions.
- A secondary Gloo group is used for compact metadata, phase status, error propagation, deterministic plans, and monitored barriers.
- Distributed cleanup avoids an unconditional NCCL barrier after an exception.
- The control-plane self-test intentionally injects a failure on rank 1 and verifies that both ranks terminate with the same bounded error.

## 5. Scientific invariants

The refactor preserves the Frequency-Steering Pruning concept.

### High-frequency steering

```text
I_j = abs((dL(X_HP,Y)/dw_j - lambda * dL(X_LP,Y)/dw_j) * w_j)
```

### Low-frequency steering

The configured target/opposite reversal is retained.

### Structural aggregation

Parameter scores are still aggregated through the dependency-aware structured units for ResNet hidden channels, EfficientNet expanded MBConv channels, ViT/DeiT attention heads, and Transformer MLP channels. The pruning schedule, target sparsity semantics, recovery training, class mappings, and final metrics are not silently changed.

### Numerical policy

- FFT-sensitive work, saliency accumulation, score ranking, and structural decisions remain FP32.
- BF16 remains the H200 forward/training default where configured.
- `steering_only` uses `lambda=0` and skips the mathematically zero opposite-frequency gradient pass.
- Calibration reduction is sample weighted, not batch weighted.

## 6. HAP refactor

The production HAP baseline is `gate_empirical_fisher`, recorded as:

```text
mini_batch_empirical_fisher_gate_diagonal
```

It computes second-order-style gate sensitivity without constructing a full-model `create_graph=True` graph. The diagnostic `gate_hutchinson` mode remains available with microbatching. The result metadata records the effective estimator and states that no full-model second-order graph was built.

This estimator must be reported by its actual name in a paper or table; it must not be described as exact full-weight Hessian HAP.

## 7. H200 utilization strategy

The experiment matrix is scheduled as independent one-GPU jobs, with up to eight jobs active concurrently. This is preferable to assigning all eight H200s to one small pruning trial because the project contains many independent combinations of model, method, lambda, cutoff, architecture, and transfer dataset.

This scheduling preserves each run's original single-process effective batch and optimizer-step semantics. Manual DDP remains supported for a single oversized run, and its saliency path uses the corrected all-rank protocol.

## 8. File-descriptor and DataLoader hardening

The earlier `Too many open files` class remains addressed through:

- soft nofile limit elevation up to the permitted hard limit;
- `file_system` tensor-sharing strategy;
- worker limits derived from CPU, FD, shared-memory, and concurrent-job budgets;
- separate train/eval/calibration worker budgets;
- bounded prefetch;
- persistent workers only for repeatedly reused training loaders;
- explicit DataLoader iterator shutdown;
- reuse of one validation/test loader where the dataset is identical;
- reuse of ImageFolder indices for alternate transforms;
- lazy ImageNet-C split construction and immediate cleanup;
- automatic one-time retry with zero workers only after an actual FD exhaustion failure.

The retry does not alter the model, data samples, training batch, optimizer, objective, or pruning schedule.

## 9. Runtime and environment hardening

`run_all.sh` now:

- preserves all supplied dataset paths and `NPROC=8`;
- uses `/home/ueno/.conda/envs/vip/bin/python` by default;
- refuses an unexpected project root unless explicitly allowed for testing;
- performs strict dataset/GPU/interpreter/output preflight;
- detects torch/torchvision ABI warnings before long experiments;
- unsets deprecated `NCCL_ASYNC_ERROR_HANDLING`;
- uses `TORCH_NCCL_ASYNC_ERROR_HANDLING` and timeout/desync diagnostics;
- selects the flight-recorder variable names appropriate to the installed PyTorch version;
- prevents two launchers from claiming the same GPUs and output directories;
- traps signals and terminates child process groups;
- emits atomic failure and success JSON files;
- validates completion using `summary.json` plus a versioned `COMPLETED` marker;
- archives incomplete or stale directories and resumes only validated work.

The torchvision ABI warning is treated as safe only for this repository's PIL/ImageFolder/model path. Preflight fails when compiled torchvision operators are explicitly required.

## 10. Verification performed

The following checks completed in the available CPU environment:

- repository-wide `compileall`: passed;
- shell syntax: 8 scripts passed `bash -n`;
- full pytest suite: 30 passed, 3 TorchScript deprecation warnings;
- two-process Gloo distributed saliency/injected-failure test: passed;
- FSP combined-gradient equivalence test: passed;
- steering-only opposite-pass elimination test: passed;
- uneven 9-sample calibration shard accounting: passed;
- HAP no-full-model-second-order assertion: passed;
- FD retry and worker-disable behavior: passed;
- stale/incomplete completion-contract tests: passed;
- ResNet, EfficientNet, and ViT physical-export tests: passed;
- complete CPU synthetic pipeline invoked through `run_all.sh`: passed;
- smoke final validation top-1: 37.5 on the synthetic test only;
- smoke actual structured sparsity: 0.0197916667;
- smoke masked/slim maximum absolute logit difference: 1.4901161e-6;
- smoke parameter count: 11,178,564 to 11,050,616;
- smoke estimated MAC reduction: 3.4361%;
- run validator status: `ok`.

The synthetic accuracy is only a control-flow test and is not a research result.

## 11. What remains hardware dependent

The available environment did not contain the user's eight H200 GPUs or the six production datasets. Consequently, this release does not fabricate H200 wall-clock speed, GPU peak memory, ImageNet accuracy, ImageNet-C/R results, transfer accuracy, or final statistical significance.

The release is structured so that the production node performs those checks from the sole supported command and stops before long experiments when hardware, paths, ABI, or writable-output requirements are not met.

## 12. Clean release archive verification

A release ZIP was generated from the committed source tree, extracted into a new directory with no development outputs or caches, and tested independently. In that extracted tree:

- `compileall` passed;
- all shell scripts passed syntax validation;
- the full pytest suite passed with 30 tests and 3 deprecation warnings in 44.63 seconds;
- `run_all.sh` completed its two-process distributed control-plane self-test, strict CPU preflight, synthetic pruning/recovery/evaluation/export pipeline, and versioned completion marker;
- the extracted smoke run reproduced actual sparsity 0.0197916667 and masked/slim maximum absolute logit difference 1.4901161e-6.

This verifies that the distributed recovery does not depend on untracked development files or prior output directories.
