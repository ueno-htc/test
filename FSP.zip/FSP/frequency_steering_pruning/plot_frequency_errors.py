#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import glob
from pathlib import Path
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def discover_runs(patterns: list[str]) -> list[Path]:
    runs: list[Path] = []
    for pattern in patterns:
        matches = [Path(path) for path in glob.glob(pattern)]
        if not matches and Path(pattern).exists():
            matches = [Path(pattern)]
        for path in matches:
            if path.is_file() and path.name == "curve.csv":
                runs.append(path.parent)
            elif (path / "curve.csv").exists():
                runs.append(path)
    return sorted(set(runs))


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot L2-defined frequency-region error against structured sparsity")
    parser.add_argument("--runs", nargs="+", required=True, help="Run directories or glob patterns")
    parser.add_argument("--output", required=True)
    parser.add_argument("--title", default="Frequency-region error vs structured sparsity")
    args = parser.parse_args()

    runs = discover_runs(args.runs)
    if not runs:
        raise FileNotFoundError("No curve.csv files found")
    series: Dict[str, List[dict]] = {}
    combined: list[dict] = []
    for run in runs:
        config_path = run / "config.yaml"
        method = run.name
        arch = ""
        if config_path.exists():
            import yaml

            config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            method = str(config["pruning"]["method"])
            arch = str(config["model"]["arch"])
        label = f"{arch}:{method}" if arch else method
        with (run / "curve.csv").open("r", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        usable = [row for row in rows if row.get("low_frequency_region_error") and row.get("high_frequency_region_error")]
        # Keep one entry per sparsity (the latest phase wins).
        by_sparsity = {float(row["sparsity"]): row for row in usable}
        series[label] = [by_sparsity[key] for key in sorted(by_sparsity)]
        for row in series[label]:
            combined.append({"label": label, "run": str(run), **row})

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8.4, 5.6))
    for label, rows in series.items():
        if not rows:
            continue
        x = [float(row["sparsity"]) for row in rows]
        low = [float(row["low_frequency_region_error"]) for row in rows]
        high = [float(row["high_frequency_region_error"]) for row in rows]
        line = ax.plot(x, low, marker="o", label=f"{label} / low-L2")[0]
        ax.plot(x, high, marker="s", linestyle="--", color=line.get_color(), label=f"{label} / high-L2")
    ax.set_xlabel("Structured sparsity")
    ax.set_ylabel("Mean error rate (%)")
    ax.set_title(args.title)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(output, dpi=180)
    plt.close(fig)

    if combined:
        fields = sorted({key for row in combined for key in row})
        with output.with_suffix(".csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(combined)
    print(output.resolve())


if __name__ == "__main__":
    main()
