#!/usr/bin/env python3
"""Spectral-Steering ablations on one architecture / sparsity.

Variants are plain method specs understood by
``frequency_pruning.orchestration.resolve_method_spec``; the defaults cover the
questions a reviewer will ask:

* estimator      exact (double-backprop) vs noise (original FSP) vs filtered (VTC-LFC-style)
* signed vs unsigned band contributions
* target profile auto (mismatch) vs reliance vs high vs low vs flat (= Taylor-FO)
* lambda         0.5 / 1 / 2
* recovery       taylor + frequency augmentation (does filtered data alone explain gains?),
                 no distillation, no BN recalibration
* band count     4 vs 8 bands
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from frequency_pruning.orchestration import (
    ExperimentTask,
    arch_overrides,
    command_with_overrides,
    parse_floats,
    parse_ints,
    resolve_method_spec,
    run_tasks,
    sparsity_tag,
    split_csv,
)

DEFAULT_VARIANTS = ",".join(
    [
        "spectral_steering",
        "spectral_noise",
        "spectral_filtered",
        "spectral_unsigned",
        "spectral_reliance",
        "spectral_high",
        "spectral_low",
        "spectral_flat",
        "spectral_lambda0.1",
        "spectral_lambda0.25",
        "spectral_lambda1",
        "spectral_lambda2",
        "spectral_lambda4",
        "spectral_density",
        "spectral_current",
        "spectral_bands8",
        "spectral_kd",
        "spectral_norecal",
        "spectral_units",
        "taylor",
        "taylor_fourier_aug",
        "taylor_kd",
        "taylor_units",
        "magnitude_units",
    ]
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Spectral-Steering ablations")
    parser.add_argument("--config", default="configs/imagenet_resnet50_v4.yaml")
    parser.add_argument("--arch", default="resnet50")
    parser.add_argument("--dataset", default="imagenet")
    parser.add_argument("--variants", default=DEFAULT_VARIANTS)
    parser.add_argument("--sparsities", default="0.5")
    parser.add_argument("--seeds", default="42")
    parser.add_argument("--output-root", default="outputs/ablations")
    parser.add_argument("--status-root", default="outputs/_orchestrator")
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    python = os.environ.get("FSP_PYTHON", sys.executable)
    tasks: list[ExperimentTask] = []
    for target in parse_floats(args.sparsities):
        for seed in parse_ints(args.seeds):
            for spec in split_csv(args.variants):
                run_name, method, method_overrides = resolve_method_spec(spec)
                run_dir = root / args.arch / sparsity_tag(target) / f"seed{seed}" / run_name
                # Stage-wide --set values come BEFORE the variant's own overrides so
                # that a global lambda/profile cannot silently neutralise an ablation
                # (this ordering bug invalidated the v4.0 lambda/profile variants).
                overrides = [
                    f"model.arch={args.arch}",
                    f"data.dataset={args.dataset}",
                    f"experiment.seed={seed}",
                    *arch_overrides(args.arch),
                    *args.overrides,
                    *method_overrides,
                    f"pruning.target_sparsity={target}",
                    "pruning.sparsity_schedule=[]",
                ]
                tasks.append(
                    ExperimentTask(
                        name=f"ablation/{args.arch}/{sparsity_tag(target)}/seed{seed}/{run_name}",
                        command=command_with_overrides(python, args.config, run_dir, overrides),
                        run_dir=str(run_dir),
                        metadata={"arch": args.arch, "method": method, "variant": run_name, "sparsity": target},
                    )
                )
    try:
        run_tasks(tasks, stage="ablations", status_root=args.status_root)
    finally:
        subprocess.run(
            [python, "tools/collect_results.py", "--root", str(root), "--output", str(root / "results.csv")],
            check=False,
        )


if __name__ == "__main__":
    main()
