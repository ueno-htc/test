#!/usr/bin/env python3
"""Task-specialised pruning on transfer datasets.

Built-in datasets: ``neu_cls`` (surface defects), ``dtd`` (textures),
``cub_200_2011`` (fine-grained).  Additional datasets are added without code via
``--extra name=/path`` where ``/path`` contains ``train/<class>/`` and
``val/<class>/`` (and optionally ``test/<class>/``) folders; this is how
high-frequency (KTH-TIPS2b, MVTec-cls, Severstal patches) and low-frequency /
shape-biased (SUN397 subset, ImageNet-Sketch classes) tasks are included so the
bidirectional steering claim can be tested.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from frequency_pruning.orchestration import (
    ExperimentTask,
    arch_overrides,
    command_with_overrides,
    parse_floats,
    parse_ints,
    resolve_method_spec,
    run_tasks,
    sparsity_tag,
    split_csv,
)

ROOT_KEYS = {"neu_cls": "data.neu_root", "dtd": "data.dtd_root", "cub_200_2011": "data.cub_root"}


def main() -> None:
    parser = argparse.ArgumentParser(description="Transfer learning + pruning on texture / defect / fine-grained tasks")
    parser.add_argument("--config", default="configs/transfer_v4.yaml")
    parser.add_argument("--datasets", default="neu_cls,dtd,cub_200_2011")
    parser.add_argument("--models", default="resnet50,efficientnet_b4")
    parser.add_argument(
        "--methods",
        default="dense,dense_finetuned,magnitude,taylor,lfs,frequency_steering,spectral_steering",
    )
    parser.add_argument("--sparsities", default="0.5")
    parser.add_argument("--seeds", default="42")
    parser.add_argument("--output-root", default="outputs/transfer")
    parser.add_argument("--status-root", default="outputs/_orchestrator")
    parser.add_argument("--neu-root", default="")
    parser.add_argument("--dtd-root", default="")
    parser.add_argument("--cub-root", default="")
    parser.add_argument(
        "--extra",
        action="append",
        default=[],
        metavar="NAME=PATH",
        help="extra ImageFolder-style dataset (train/ and val/ sub-folders)",
    )
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    roots = {"neu_cls": args.neu_root, "dtd": args.dtd_root, "cub_200_2011": args.cub_root}
    extra: dict[str, str] = {}
    for item in args.extra:
        if "=" not in item:
            raise ValueError(f"--extra expects NAME=PATH, got {item!r}")
        name, path = item.split("=", 1)
        extra[name.strip()] = path.strip()

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    python = os.environ.get("FSP_PYTHON", sys.executable)
    # Phase 1: task-adapt the dense model once per (dataset, arch, seed).
    # Phase 2: every other method starts from that exact checkpoint, so all
    # criteria prune the same task-adapted network and the adaptation epochs
    # are not repeated per method.
    dense_tasks: list[ExperimentTask] = []
    tasks: list[ExperimentTask] = []
    datasets = split_csv(args.datasets) + sorted(extra)
    for dataset in datasets:
        if dataset in extra:
            dataset_root = extra[dataset]
            dataset_overrides = ["data.dataset=imagefolder", f"data.folder_root={dataset_root}"]
        else:
            dataset_root = roots.get(dataset, "")
            if dataset not in ROOT_KEYS:
                raise ValueError(f"Unknown built-in transfer dataset {dataset}; use --extra NAME=PATH")
            dataset_overrides = [f"data.dataset={dataset}", f"{ROOT_KEYS[dataset]}={dataset_root}"]
        if not dataset_root:
            print(f"Skipping {dataset}: no root supplied", flush=True)
            continue
        if not Path(dataset_root).exists():
            raise FileNotFoundError(f"Transfer dataset root does not exist: {dataset_root}")
        for arch in split_csv(args.models):
            for seed in parse_ints(args.seeds):
                common = [
                    *dataset_overrides,
                    f"model.arch={arch}",
                    f"experiment.seed={seed}",
                    "evaluation.eval_imagenet_c=false",
                    "evaluation.eval_imagenet_r=false",
                    *arch_overrides(arch),
                ]
                dense_dir = root / dataset / arch / "dense" / f"seed{seed}"
                dense_tasks.append(
                    ExperimentTask(
                        name=f"transfer/{dataset}/{arch}/dense/seed{seed}",
                        command=command_with_overrides(
                            python, args.config, dense_dir, [*common, *args.overrides, "pruning.method=dense"]
                        ),
                        run_dir=str(dense_dir),
                        metadata={"dataset": dataset, "arch": arch, "method": "dense", "seed": seed},
                    )
                )
                checkpoint = dense_dir / "checkpoint_dense_calibrated.pt"
                for target in parse_floats(args.sparsities):
                    for spec in split_csv(args.methods):
                        run_name, method, method_overrides = resolve_method_spec(spec)
                        if method == "dense":
                            continue  # handled in phase 1
                        run_dir = root / dataset / arch / sparsity_tag(target) / f"seed{seed}" / run_name
                        overrides = [
                            *common,
                            *method_overrides,
                            *args.overrides,
                            # Structural settings of phase 2 come last so that
                            # user --set overrides cannot break the shared-checkpoint
                            # protocol.
                            f"experiment.checkpoint={checkpoint}",
                            "train.epochs_before_pruning=0",
                            f"pruning.target_sparsity={target}",
                            "pruning.sparsity_schedule=[]",
                        ]
                        tasks.append(
                            ExperimentTask(
                                name=f"transfer/{dataset}/{arch}/{sparsity_tag(target)}/seed{seed}/{run_name}",
                                command=command_with_overrides(python, args.config, run_dir, overrides),
                                run_dir=str(run_dir),
                                metadata={"dataset": dataset, "arch": arch, "method": method, "sparsity": target},
                            )
                        )
    if dense_tasks:
        run_tasks(dense_tasks, stage="transfer_dense", status_root=args.status_root)
        missing = [t.run_dir for t in dense_tasks if not (Path(t.run_dir) / "checkpoint_dense_calibrated.pt").exists()]
        if missing:
            raise RuntimeError(f"Task-adapted dense checkpoints are missing: {missing}")
    try:
        if tasks:
            run_tasks(tasks, stage="transfer", status_root=args.status_root)
    finally:
        if dense_tasks or tasks:
            subprocess.run(
                [python, "tools/collect_results.py", "--root", str(root), "--output", str(root / "results.csv")],
                check=False,
            )


if __name__ == "__main__":
    main()
