#!/usr/bin/env python3
"""Task-specialised pruning on transfer datasets (the fast hypothesis-testing loop).

Datasets
  built-in      neu_cls, dtd, cub_200_2011
  --tv          torchvision classification datasets: ``--tv Flowers102=/data/flowers``
                (Flowers102, OxfordIIITPet, FGVCAircraft, Food101, GTSRB, EuroSAT,
                SUN397, Caltech101, Country211, PCAM, StanfordCars)
  --extra       ImageFolder layout: ``--extra kth=/data/kth`` with train/ and val/

Protocol
  Phase 1  task-adapt the dense model once per (dataset, arch, seed).
  Gate     the dense model must reach the minimum accuracy in
           configs/dense_reference.json; otherwise no pruning run is launched
           for that (dataset, arch) -- v4.1 pruned 36%-accurate EfficientNets.
  Phase 2  every method starts from the same dense checkpoint.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from frequency_pruning.orchestration import (
    ExperimentTask,
    command_with_overrides,
    load_json_config,
    parse_floats,
    parse_ints,
    resolve_method_spec,
    run_tasks,
    sparsity_tag,
    split_csv,
    transfer_arch_overrides,
)

ROOT_KEYS = {"neu_cls": "data.neu_root", "dtd": "data.dtd_root", "cub_200_2011": "data.cub_root"}
DEFAULT_METHODS = ",".join(
    [
        "dense",
        "dense_finetuned",
        "random",
        "magnitude",
        "magnitude_mean",
        "lfs",
        "taylor",  # gaussian (z-score) normalisation
        "taylor_std",
        "taylor_max",
        "taylor_sum",
        "taylor_lamp",
        "taylor_mean",
        "taylor_mix0",  # rank-mix family: alpha = 0 (uniform allocation) ... 1 (global ranking)
        "taylor_mix0.25",
        "taylor_mix0.5",
        "taylor_mix0.75",
        "taylor_global",
        "taylor_auto",  # look-ahead choice of alpha on a training hold-out
    ]
)


def _parse_pairs(items: list[str], flag: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"{flag} expects NAME=PATH, got {item!r}")
        name, path = item.split("=", 1)
        out[name.strip()] = path.strip()
    return out


def _dense_accuracy(run_dir: Path) -> float | None:
    summary = run_dir / "summary.json"
    if not summary.exists():
        return None
    data = json.loads(summary.read_text(encoding="utf-8"))
    final = data.get("final", {})
    for key in ("test", "val"):
        value = (final.get(key) or {}).get("top1")
        if value is not None:
            return float(value)
    return None


def _gate_threshold(reference: dict, dataset: str, arch: str) -> float:
    table = reference.get("transfer_min", {})
    entry = table.get(dataset.lower())
    if isinstance(entry, dict):
        return float(entry.get(arch, entry.get("default", table.get("default", 0.0))))
    return float(table.get("default", 0.0))


def main() -> None:
    parser = argparse.ArgumentParser(description="Transfer learning + pruning on texture / defect / fine-grained tasks")
    parser.add_argument("--config", default="configs/transfer_v4.yaml")
    parser.add_argument("--datasets", default="dtd,cub_200_2011")
    parser.add_argument("--models", default="resnet50,deit_base_patch16_224")
    parser.add_argument("--methods", default=DEFAULT_METHODS)
    parser.add_argument("--sparsities", default="0.5")
    parser.add_argument("--seeds", default="42,43,44")
    parser.add_argument("--output-root", default="outputs/transfer")
    parser.add_argument("--status-root", default="outputs/_orchestrator")
    parser.add_argument("--neu-root", default="")
    parser.add_argument("--dtd-root", default="")
    parser.add_argument("--cub-root", default="")
    parser.add_argument("--extra", action="append", default=[], metavar="NAME=PATH")
    parser.add_argument("--tv", action="append", default=[], metavar="TVNAME=PATH")
    parser.add_argument("--download", action="store_true", help="allow torchvision to download missing datasets")
    parser.add_argument("--source-reliance", default="configs/source_reliance.json")
    parser.add_argument("--dense-reference", default="configs/dense_reference.json")
    parser.add_argument("--no-dense-gate", action="store_true")
    parser.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    roots = {"neu_cls": args.neu_root, "dtd": args.dtd_root, "cub_200_2011": args.cub_root}
    extra = _parse_pairs(args.extra, "--extra")
    tv = _parse_pairs(args.tv, "--tv")
    source_reliance = load_json_config(args.source_reliance)
    reference = load_json_config(args.dense_reference)

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    python = os.environ.get("FSP_PYTHON", sys.executable)

    # (dataset label, dataset overrides)
    dataset_specs: list[tuple[str, list[str]]] = []
    for dataset in split_csv(args.datasets):
        if dataset not in ROOT_KEYS:
            raise ValueError(f"Unknown built-in transfer dataset {dataset}; use --tv or --extra")
        dataset_root = roots.get(dataset, "")
        if not dataset_root:
            print(f"Skipping {dataset}: no root supplied", flush=True)
            continue
        if not Path(dataset_root).exists():
            raise FileNotFoundError(f"Transfer dataset root does not exist: {dataset_root}")
        dataset_specs.append(
            (dataset, [f"data.dataset={dataset}", f"data.dataset_label={dataset}", f"{ROOT_KEYS[dataset]}={dataset_root}"])
        )
    for name, path in sorted(extra.items()):
        if not Path(path).exists():
            raise FileNotFoundError(f"Transfer dataset root does not exist: {path}")
        dataset_specs.append(
            (name, ["data.dataset=imagefolder", f"data.dataset_label={name}", f"data.folder_root={path}"])
        )
    for name, path in sorted(tv.items()):
        if not args.download and not Path(path).exists():
            raise FileNotFoundError(f"torchvision dataset root does not exist: {path} (pass --download to fetch)")
        overrides = [
            "data.dataset=torchvision",
            f"data.tv_name={name}",
            f"data.dataset_label={name.lower()}",
            f"data.folder_root={path}",
        ]
        if args.download:
            overrides.append("data.download=true")
        dataset_specs.append((name.lower(), overrides))

    dense_tasks: list[ExperimentTask] = []
    pending: list[dict] = []
    for dataset, dataset_overrides in dataset_specs:
        for arch in split_csv(args.models):
            arch_source = source_reliance.get(arch)
            for seed in parse_ints(args.seeds):
                common = [
                    *dataset_overrides,
                    f"model.arch={arch}",
                    f"experiment.seed={seed}",
                    "evaluation.eval_imagenet_c=false",
                    "evaluation.eval_imagenet_r=false",
                    *transfer_arch_overrides(arch),
                ]
                if arch_source:
                    common.append("pruning.spectral.source_reliance=" + json.dumps(arch_source).replace(" ", ""))
                dense_dir = root / dataset / arch / "dense" / f"seed{seed}"
                dense_tasks.append(
                    ExperimentTask(
                        name=f"transfer/{dataset}/{arch}/dense/seed{seed}",
                        command=command_with_overrides(
                            python, args.config, dense_dir, [*common, *args.overrides, "pruning.method=dense"]
                        ),
                        run_dir=str(dense_dir),
                        metadata={"dataset": dataset, "arch": arch, "method": "dense", "seed": seed},
                    )
                )
                pending.append({"dataset": dataset, "arch": arch, "seed": seed, "common": common, "dense_dir": dense_dir})

    failures: list[str] = []
    if dense_tasks:
        try:
            run_tasks(dense_tasks, stage="transfer_dense", status_root=args.status_root)
        except RuntimeError as error:
            failures.append(f"transfer_dense: {error}")

    # Dense sanity gate
    gate_report: list[dict] = []
    tasks: list[ExperimentTask] = []
    for item in pending:
        dense_dir: Path = item["dense_dir"]
        checkpoint = dense_dir / "checkpoint_dense_calibrated.pt"
        accuracy = _dense_accuracy(dense_dir)
        threshold = _gate_threshold(reference, item["dataset"], item["arch"])
        passed = checkpoint.exists() and accuracy is not None and (args.no_dense_gate or accuracy >= threshold)
        gate_report.append(
            {"dataset": item["dataset"], "arch": item["arch"], "seed": item["seed"], "dense_top1": accuracy,
             "minimum": threshold, "passed": bool(passed), "checkpoint": checkpoint.exists()}
        )
        if not passed:
            print(
                f"[dense gate] {item['dataset']}/{item['arch']}/seed{item['seed']}: dense top-1 "
                f"{accuracy} < required {threshold} (or checkpoint missing); pruning runs are NOT launched.",
                flush=True,
            )
            continue
        for target in parse_floats(args.sparsities):
            for spec in split_csv(args.methods):
                run_name, method, method_overrides = resolve_method_spec(spec)
                if method == "dense":
                    continue  # handled in phase 1
                run_dir = root / item["dataset"] / item["arch"] / sparsity_tag(target) / f"seed{item['seed']}" / run_name
                overrides = [
                    *item["common"],
                    *args.overrides,
                    *method_overrides,
                    # Structural settings of phase 2 come last so that user --set
                    # overrides cannot break the shared-checkpoint protocol.
                    f"experiment.checkpoint={checkpoint}",
                    "train.epochs_before_pruning=0",
                    f"pruning.target_sparsity={target}",
                    "pruning.sparsity_schedule=[]",
                ]
                tasks.append(
                    ExperimentTask(
                        name=f"transfer/{item['dataset']}/{item['arch']}/{sparsity_tag(target)}/seed{item['seed']}/{run_name}",
                        command=command_with_overrides(python, args.config, run_dir, overrides),
                        run_dir=str(run_dir),
                        metadata={"dataset": item["dataset"], "arch": item["arch"], "method": method, "sparsity": target},
                    )
                )
    (root / "dense_gate.json").write_text(json.dumps(gate_report, indent=2), encoding="utf-8")
    blocked = [g for g in gate_report if not g["passed"]]
    if blocked:
        failures.append(f"dense gate blocked {len(blocked)} (dataset, arch, seed) combinations; see {root / 'dense_gate.json'}")

    try:
        if tasks:
            run_tasks(tasks, stage="transfer", status_root=args.status_root)
    except RuntimeError as error:
        failures.append(f"transfer: {error}")
    finally:
        if dense_tasks or tasks:
            subprocess.run(
                [python, "tools/collect_results.py", "--root", str(root), "--output", str(root / "results.csv")],
                check=False,
            )
    if failures:
        raise SystemExit("Transfer stage finished with problems:\n  - " + "\n  - ".join(failures))


if __name__ == "__main__":
    main()
